<?php
declare(strict_types=1);

$secureCookie = (!empty($_SERVER['HTTPS']) && strtolower((string) $_SERVER['HTTPS']) !== 'off') || (int) ($_SERVER['SERVER_PORT'] ?? 0) === 443;
$cookiePath = rtrim(str_replace('\\', '/', dirname((string) ($_SERVER['SCRIPT_NAME'] ?? '/'))), '/') . '/';
session_set_cookie_params([
    'lifetime' => 0,
    'path' => $cookiePath,
    'secure' => $secureCookie,
    'httponly' => true,
    'samesite' => 'Strict',
]);
session_start();
header('Cache-Control: no-store, private');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: same-origin');

require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/smtp.php';
require_once dirname(__DIR__) . '/mall.php';
require_once __DIR__ . '/mall_admin.php';
$pdo = db();

function adminEscape(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function adminIsTokenContractAddress(string $address): bool
{
    return in_array(strtolower(trim($address)), [
        '0x55d398326f99059ff775485246999027b3197955',
        '0x0e920821464625cf661a4dcedeb6406e1b48ffff',
    ], true);
}

function adminAmount4(mixed $value): string
{
    $raw = trim((string) $value);
    if (!preg_match('/^(-?)(\d+)(?:\.(\d+))?$/', $raw, $matches)) return $raw;
    $negative = $matches[1] === '-';
    $whole = ltrim($matches[2], '0') ?: '0';
    $fraction = str_pad($matches[3] ?? '', 5, '0');
    $scaled = (int) substr($fraction, 0, 4);
    if ((int) $fraction[4] >= 5) {
        $scaled++;
        if ($scaled === 10000) {
            $scaled = 0;
            for ($index = strlen($whole) - 1; $index >= 0; $index--) {
                if ($whole[$index] !== '9') {
                    $whole[$index] = (string) ((int) $whole[$index] + 1);
                    break;
                }
                $whole[$index] = '0';
                if ($index === 0) $whole = '1' . $whole;
            }
        }
    }
    $rounded = $whole . '.' . str_pad((string) $scaled, 4, '0', STR_PAD_LEFT);
    return $negative && $rounded !== '0.0000' ? '-' . $rounded : $rounded;
}

function adminRedirect(string $section = 'dashboard'): never
{
    header('Location: admin.php?section=' . rawurlencode($section), true, 303);
    exit;
}

function adminFlash(string $message, string $type = 'success'): void
{
    $_SESSION['admin_flash'] = ['message' => $message, 'type' => $type];
}

function adminCsrf(): string
{
    if (!isset($_SESSION['admin_csrf'])) {
        $_SESSION['admin_csrf'] = bin2hex(random_bytes(32));
    }
    return (string) $_SESSION['admin_csrf'];
}

function adminCheckCsrf(): void
{
    $submitted = (string) ($_POST['csrf'] ?? '');
    if ($submitted === '' || !hash_equals(adminCsrf(), $submitted)) {
        http_response_code(419);
        exit('页面已过期，请刷新后重试。');
    }
}

function adminRequireLogin(): array
{
    global $pdo;
    $adminId = (int) ($_SESSION['admin_id'] ?? 0);
    if ($adminId <= 0) {
        header('Location: login.php', true, 303);
        exit;
    }
    $statement = $pdo->prepare('SELECT id,username,role,last_login_at FROM admin_users WHERE id=? AND status=1 LIMIT 1');
    $statement->execute([$adminId]);
    $admin = $statement->fetch();
    if (!$admin) {
        unset($_SESSION['admin_id']);
        header('Location: login.php', true, 303);
        exit;
    }
    return $admin;
}

function adminPostString(string $key, int $maxLength = 5000): string
{
    $value = trim((string) ($_POST[$key] ?? ''));
    if (strlen($value) > $maxLength) throw new InvalidArgumentException('提交内容过长');
    return $value;
}

function adminDateIsValid(string $value): bool
{
    $date = DateTimeImmutable::createFromFormat('!Y-m-d', $value);
    return $date instanceof DateTimeImmutable && $date->format('Y-m-d') === $value;
}

function adminStatusLabel(string $status): string
{
    $labels = [
        'pending' => '待处理', 'completed' => '已完成', 'failed' => '失败', 'sending' => '发送中',
        'rejected' => '已拒绝', 'open' => '待处理', 'processing' => '处理中',
        'resolved' => '已解决', 'closed' => '已关闭', 'cancelled' => '已取消',
        'active' => '进行中', 'inactive' => '已停用', 'paid' => '已支付',
        'shipped' => '已发货', 'delivered' => '已完成', 'answered' => '已答复',
        'reviewed' => '已查看', 'success' => '成功', 'owner' => '群主', 'admin' => '管理员',
        'member' => '成员',
    ];
    return $labels[$status] ?? $status;
}

function adminRoleLabel(string $role): string
{
    return ['superadmin' => '超级管理员', 'finance' => '财务', 'support' => '客服', 'operator' => '运营'][$role] ?? $role;
}

function adminTargetLabel(string $target): string
{
    return [
        'user' => '用户', 'recharge' => '充值记录', 'wallet_transaction' => '钱包流水',
        'product' => '商品', 'order' => '订单', 'ticket' => '客服工单', 'question' => '用户问题',
        'feedback' => '用户反馈', 'faq' => 'FAQ', 'group' => '群组', 'group_member' => '群成员',
        'admin' => '管理员', 'setting' => '系统设置', 'app_release' => 'Android 版本',
    ][$target] ?? $target;
}

function adminActionLabel(string $action): string
{
    $labels = [
        'user.update' => '用户状态/备注调整', 'user.password.reset' => '重置用户密码', 'wallet.adjust' => '调整用户余额',
        'recharge.manual.complete' => '人工补记充值', 'wallet.status.update' => '仅修改充值/提现状态', 'withdraw.approve' => '通过提现', 'withdraw.batch_approve' => '批量通过提现', 'withdraw.reject' => '拒绝提现并退款', 'withdraw.retry' => '失败提现重试',
        'order.complete' => '完成订单', 'order.cancel' => '取消订单并退款', 'order.ship' => '商品订单发货', 'product.save' => '维护商品',
        'ticket.reply' => '回复客服工单', 'question.reply' => '答复用户问题', 'feedback.update' => '更新用户反馈',
        'faq.save' => '维护 FAQ', 'group.update' => '更新群组', 'admin.create' => '创建管理员',
        'admin.update' => '更新管理员', 'admin.toggle' => '启停管理员', 'admin.password' => '修改管理员密码', 'finance.email.test' => '发送财务邮件测试', 'finance.recipient.save' => '维护邮件收件人', 'finance.recipient.delete' => '删除邮件收件人', 'finance.template.save' => '维护邮件模板', 'finance.template.reset' => '恢复邮件模板',
        'settings.deposit' => '修改充值收款地址', 'app.release.upload' => '发布 Android 更新', 'staking.phase.save' => '调整质押奖励期', 'staking.plans.save' => '调整质押方案', 'user.wallet.update' => '修改用户绑定钱包地址', 'group.member.mute' => '禁言群成员',
        'group.member.unmute' => '解除群成员禁言', 'group.member.remove' => '移除群成员',
    ];
    return $labels[$action] ?? $action;
}

function adminTransactionLabel(string $type): string
{
    $labels = [
        'deposit' => '链上充值', 'withdraw' => '提现', 'withdraw_refund' => '提现退款',
        'admin_adjustment' => '管理员余额调整', 'refund' => '订单退款', 'redeem' => '商城兑换', 'staking_dividend' => '质押分红', 'staking_interest' => '质押收益',
        'exchange_out' => '兑换扣款', 'exchange_in' => '兑换到账', 'staking' => '质押',
        'staking_redeem' => '质押赎回', 'referral_reward' => '推荐奖励',
    ];
    return $labels[$type] ?? $type;
}

function adminVariantLines(mixed $json): string
{
    $variants = json_decode((string) $json, true);
    if (!is_array($variants)) return '';
    return implode("\n", array_map(static fn(array $variant): string => implode('|', [
        (string) ($variant['name'] ?? ''), (string) ($variant['price'] ?? '0'), (string) ($variant['stock'] ?? '0'),
    ]), $variants));
}

function adminStoreProductImages(): array
{
    $files = $_FILES['images'] ?? null;
    if (!is_array($files) || !isset($files['name']) || !is_array($files['name'])) return [];
    $selected = [];
    foreach ($files['name'] as $index => $name) {
        if (($files['error'][$index] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) continue;
        $selected[] = $index;
    }
    if (count($selected) > 8) throw new InvalidArgumentException('每次最多上传 8 张商品图片。');
    $directory = dirname(__DIR__) . '/uploads/products';
    if (!is_dir($directory) && !mkdir($directory, 0755, true) && !is_dir($directory)) throw new RuntimeException('无法创建商品图片目录。');
    $mimeExtensions = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif'];
    $stored = [];
    try {
        foreach ($selected as $index) {
            $error = (int) ($files['error'][$index] ?? UPLOAD_ERR_NO_FILE);
            $temporary = (string) ($files['tmp_name'][$index] ?? '');
            if ($error !== UPLOAD_ERR_OK || $temporary === '' || !is_uploaded_file($temporary)) throw new InvalidArgumentException('图片上传失败，请重新选择文件。');
            if ((int) ($files['size'][$index] ?? 0) > 5 * 1024 * 1024) throw new InvalidArgumentException('单张商品图片不能超过 5 MB。');
            $mime = (new finfo(FILEINFO_MIME_TYPE))->file($temporary);
            $imageInfo = @getimagesize($temporary);
            if (!isset($mimeExtensions[$mime]) || !$imageInfo || ($imageInfo['mime'] ?? '') !== $mime) throw new InvalidArgumentException('商品图片仅支持有效的 JPG、PNG、WebP 或 GIF 文件。');
            $filename = bin2hex(random_bytes(20)) . '.' . $mimeExtensions[$mime];
            if (!move_uploaded_file($temporary, $directory . '/' . $filename)) throw new RuntimeException('商品图片保存失败。');
            $stored[] = ['url' => '/uploads/products/' . $filename, 'path' => $directory . '/' . $filename];
        }
    } catch (Throwable $exception) {
        foreach ($stored as $image) @unlink($image['path']);
        throw $exception;
    }
    return $stored;
}

function adminTrendSvg(array $rows, string $field, string $color): string
{
    $values = array_reverse(array_map(static fn(array $row): float => (float) ($row[$field] ?? 0), $rows));
    if (!$values) $values = array_fill(0, 30, 0.0);
    $max = max($values) ?: 1.0;
    $last = max(0, count($values) - 1);
    $points = [];
    $markers = [];
    foreach ($values as $index => $value) {
        $x = $last > 0 ? $index * 580 / $last : 290;
        $y = 112 - ($value / $max) * 96;
        $points[] = number_format($x, 1, '.', '') . ',' . number_format($y, 1, '.', '');
        $source = $rows[count($rows) - 1 - $index] ?? [];
        $unit = $field === 'recharge_usdt' ? 'USDT' : 'SPX001';
        $label = (string) ($source['day'] ?? '') . ' · 金额 ' . adminAmount4($source[$field] ?? '0') . ' ' . $unit;
        $markers[] = '<circle class="trend-marker" cx="' . number_format($x, 1, '.', '') . '" cy="' . number_format($y, 1, '.', '') . '" r="5" fill="' . adminEscape($color) . '" tabindex="0" role="img" aria-label="' . adminEscape($label) . '" data-tooltip="' . adminEscape($label) . '"><title>' . adminEscape($label) . '</title></circle>';
    }
    return '<svg class="trend-svg" viewBox="0 0 580 120" role="img" aria-label="近 30 日趋势"><path class="trend-grid" d="M0 16H580 M0 64H580 M0 112H580"/><polyline points="' . implode(' ', $points) . '" fill="none" stroke="' . adminEscape($color) . '" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>' . implode('', $markers) . '</svg>';
}

function adminCan(string $section): bool
{
    global $admin;
    $roles = [
        'dashboard' => ['superadmin', 'finance', 'support', 'operator'],
        'merchants' => ['superadmin', 'finance', 'operator'],
        'mall_finance' => ['superadmin', 'finance'],
        'users' => ['superadmin', 'finance', 'support', 'operator'],
         'user_control' => ['superadmin', 'operator'],
         'wallets' => ['superadmin', 'finance', 'operator'], 'recharges' => ['superadmin', 'finance', 'operator'],
         'withdrawals' => ['superadmin', 'finance', 'operator'], 'transactions' => ['superadmin', 'finance', 'operator'],
         'exchanges' => ['superadmin', 'finance', 'operator'], 'staking' => ['superadmin', 'finance', 'operator'], 'staking_plans' => ['superadmin', 'finance', 'operator'],
         'referrals' => ['superadmin', 'finance', 'operator'], 'products' => ['superadmin', 'operator'],
         'orders' => ['superadmin', 'finance', 'operator'], 'tickets' => ['superadmin', 'support', 'operator'],
         'questions' => ['superadmin', 'support', 'operator'], 'feedback' => ['superadmin', 'support', 'operator'],
         'faqs' => ['superadmin', 'operator', 'support'], 'groups' => ['superadmin', 'operator'],
        'logs' => ['superadmin'], 'admins' => ['superadmin'], 'settings' => ['superadmin'],
          'profile' => ['superadmin', 'finance', 'support'], 'wallet_address_control' => ['superadmin'], 'email_notifications' => ['superadmin', 'operator'], 'email_notification_control' => ['superadmin'],
         'reports' => ['superadmin', 'finance', 'operator'], 'export' => ['superadmin', 'finance', 'support', 'operator'],
         'export_finance' => ['superadmin', 'finance', 'operator'], 'export_orders' => ['superadmin', 'finance', 'operator'],
         'export_tickets' => ['superadmin', 'support', 'operator'],
    ];
    return isset($admin['role']) && in_array((string) $admin['role'], $roles[$section] ?? [], true);
}

function adminAudit(PDO $pdo, array $admin, string $action, string $targetType, ?int $targetId,
                    ?string $reason, ?array $before, ?array $after, ?string $requestId = null): void
{
    $statement = $pdo->prepare('INSERT INTO admin_audit_logs (admin_id,admin_username,`action`,target_type,target_id,request_id,reason,before_data,after_data,ip_address) VALUES (?,?,?,?,?,?,?,?,?,?)');
    $statement->execute([
        $admin['id'], $admin['username'], $action, $targetType, $targetId, $requestId,
        $reason, $before === null ? null : json_encode($before, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        $after === null ? null : json_encode($after, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        substr((string) ($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45) ?: null,
    ]);
}

$action = (string) ($_POST['action'] ?? '');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    adminCheckCsrf();
    $admin = adminRequireLogin();
    $section = (string) ($_POST['section'] ?? 'dashboard');
    $newProductImages = [];
    $removedProductImages = [];
    $newReleasePath = null;
    try {
        mallAdminPost($pdo, $admin, $action);
        $actionModules = [
            'user.save' => 'user_control', 'user.password.reset' => 'user_control', 'wallet.adjust' => 'wallets', 'recharge.manual.complete' => 'recharges', 'withdraw.process' => 'withdrawals', 'withdraw.batch_approve' => 'withdrawals', 'withdraw.retry' => 'withdrawals', 'wallet.status.update' => 'wallets',
            'product.save' => 'products', 'app.release.upload' => 'settings', 'staking.phase.save' => 'staking_plans', 'staking.plans.save' => 'staking_plans', 'order.process' => 'orders', 'order.ship' => 'orders', 'ticket.save' => 'tickets', 'question.save' => 'questions',
            'feedback.save' => 'feedback', 'faq.save' => 'faqs',
            'group.save' => 'groups', 'group.member' => 'groups', 'settings.deposit.save' => 'settings', 'settings.api_nodes.save' => 'settings', 'settings.invite_base.save' => 'settings', 'password.save' => 'profile',
            'admin.save' => 'admins', 'admin.toggle' => 'admins', 'user.wallet.update' => 'wallet_address_control', 'finance.email.test' => 'email_notifications', 'finance.recipient.save' => 'email_notification_control', 'finance.recipient.delete' => 'email_notification_control', 'finance.template.save' => 'email_notification_control', 'finance.template.reset' => 'email_notification_control',
        ];
        if (isset($actionModules[$action]) && !adminCan($actionModules[$action])) {
            throw new RuntimeException('当前管理员角色无权执行此操作。');
        }

        if ($action === 'finance.email.test') {
            $templateId = max(0, (int) ($_POST['template_id'] ?? 0));
            $reason = adminPostString('reason', 500);
            if ($reason === '') throw new InvalidArgumentException('请填写测试邮件原因。');
            if ($templateId <= 0) throw new InvalidArgumentException('请选择要测试的邮件模板。');
            $test = sendFinanceTemplate($pdo, '', ['username' => '测试用户', 'nickname' => '测试昵称', 'user_id' => 0, 'symbol' => 'SPX001 / BSC', 'amount' => '100', 'fee' => '1', 'net_amount' => '99', 'address' => '0x0000000000000000000000000000000000000000', 'reason' => '测试失败原因', 'status' => '测试状态', 'created_at' => date('Y-m-d H:i:s')], $templateId);
            if ((int) ($test['sent'] ?? 0) === 0) throw new RuntimeException((string) ($test['message'] ?? '测试邮件发送失败。'));
            adminAudit($pdo, $admin, 'finance.email.test', 'setting', null, $reason, null, ['recipient' => financeNotificationEmail()]);
            adminFlash('测试邮件已发送 ' . (int) $test['sent'] . ' 封，失败 ' . (int) ($test['failed'] ?? 0) . ' 封。');
            adminRedirect('email_notifications');
        }

        if ($action === 'finance.recipient.save') {
            $recipientId = max(0, (int) ($_POST['recipient_id'] ?? 0));
            $email = strtolower(trim(adminPostString('email', 190)));
            $status = (int) ($_POST['status'] ?? 0) === 1 ? 1 : 0;
            $templateIds = array_values(array_unique(array_filter(array_map('intval', (array) ($_POST['template_ids'] ?? [])), static fn(int $id): bool => $id > 0)));
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) throw new InvalidArgumentException('邮箱格式无效。');
            $pdo->beginTransaction();
            if ($recipientId > 0) {
                $beforeQuery = $pdo->prepare('SELECT id,email,status FROM email_notification_recipients WHERE id=? FOR UPDATE');
                $beforeQuery->execute([$recipientId]);
                $before = $beforeQuery->fetch();
                if (!$before) throw new InvalidArgumentException('收件人不存在。');
                $pdo->prepare('UPDATE email_notification_recipients SET email=?,status=? WHERE id=?')->execute([$email, $status, $recipientId]);
            } else {
                $pdo->prepare('INSERT INTO email_notification_recipients (email,status) VALUES (?,?)')->execute([$email, $status]);
                $recipientId = (int) $pdo->lastInsertId();
                $before = null;
            }
            $pdo->prepare('DELETE FROM email_notification_subscriptions WHERE recipient_id=?')->execute([$recipientId]);
            $subscribe = $pdo->prepare('INSERT IGNORE INTO email_notification_subscriptions (recipient_id,template_id) VALUES (?,?)');
            foreach ($templateIds as $templateId) $subscribe->execute([$recipientId, $templateId]);
            adminAudit($pdo, $admin, 'finance.recipient.save', 'setting', $recipientId, '维护邮件收件人', $before, ['email' => $email, 'status' => $status, 'template_ids' => $templateIds]);
            $pdo->commit();
            adminFlash('邮件收件人已保存。');
            adminRedirect('email_notifications');
        }

        if ($action === 'finance.recipient.delete') {
            $recipientId = max(0, (int) ($_POST['recipient_id'] ?? 0));
            if ($recipientId <= 0) throw new InvalidArgumentException('收件人无效。');
            $pdo->beginTransaction();
            $lookup = $pdo->prepare('SELECT id,email,status FROM email_notification_recipients WHERE id=? FOR UPDATE');
            $lookup->execute([$recipientId]);
            $before = $lookup->fetch();
            if (!$before) throw new InvalidArgumentException('收件人不存在。');
            $pdo->prepare('DELETE FROM email_notification_recipients WHERE id=?')->execute([$recipientId]);
            adminAudit($pdo, $admin, 'finance.recipient.delete', 'setting', $recipientId, '删除邮件收件人', $before, null);
            $pdo->commit();
            adminFlash('邮件收件人已删除。');
            adminRedirect('email_notifications');
        }

        if ($action === 'finance.template.save' || $action === 'finance.template.reset') {
            $templateId = max(0, (int) ($_POST['template_id'] ?? 0));
            $templateQuery = $pdo->prepare('SELECT id,event_key,name,subject,body_html,status FROM email_notification_templates WHERE id=? LIMIT 1');
            $templateQuery->execute([$templateId]);
            $before = $templateQuery->fetch();
            if (!$before) throw new InvalidArgumentException('邮件模板不存在。');
            $defaults = [
                'recharge_completed' => ['充值到账', 'SPX Chat 充值到账通知', '<h2>充值已到账</h2><p>用户：{{username}}（{{nickname}}）</p><p>用户 ID：{{user_id}}</p><p>资产：{{symbol}}</p><p>到账金额：{{amount}}</p><p>状态：{{status}}</p><p>时间：{{created_at}}</p>'],
                'withdraw_submitted' => ['提现申请', 'SPX Chat 提现申请通知', '<h2>提现申请</h2><p>用户：{{username}}（{{nickname}}）</p><p>用户 ID：{{user_id}}</p><p>资产：{{symbol}}</p><p>申请金额：{{amount}}</p><p>手续费：{{fee}}</p><p>实际到账：{{net_amount}}</p><p>状态：{{status}}</p><p>时间：{{created_at}}</p>'],
                'withdraw_failed' => ['提现失败', 'SPX Chat 提现失败通知', '<h2>提现失败</h2><p>用户：{{username}}（{{nickname}}）</p><p>用户 ID：{{user_id}}</p><p>资产：{{symbol}}</p><p>提现金额：{{amount}}</p><p>失败原因：{{reason}}</p><p>状态：{{status}}</p><p>时间：{{created_at}}</p>'],
            ];
            $default = $defaults[$before['event_key']] ?? [$before['name'], $before['subject'], $before['body_html']];
            $subject = $action === 'finance.template.reset' ? $default[1] : adminPostString('subject', 255);
            $body = $action === 'finance.template.reset' ? $default[2] : adminPostString('body_html', 50000);
            $pdo->prepare('UPDATE email_notification_templates SET subject=?,body_html=? WHERE id=?')->execute([$subject, $body, $templateId]);
            adminAudit($pdo, $admin, $action, 'setting', $templateId, $action === 'finance.template.reset' ? '恢复邮件模板默认内容' : '修改邮件模板', $before, ['subject' => $subject, 'body_html' => $body]);
            adminFlash($action === 'finance.template.reset' ? '邮件模板已恢复默认内容。' : '邮件模板已保存。');
            adminRedirect('email_notifications');
        }

        if ($action === 'user.save') {
            $userId = max(0, (int) ($_POST['user_id'] ?? 0));
            $status = (int) ($_POST['status'] ?? -1);
            $remark = adminPostString('remark', 100);
            $reason = adminPostString('reason', 500);
            if ($userId <= 0 || !in_array($status, [0, 1], true) || $reason === '') throw new InvalidArgumentException('用户、状态和操作原因不能为空。');
            $pdo->beginTransaction();
            $lookup = $pdo->prepare('SELECT id,status,remark FROM users WHERE id=? FOR UPDATE');
            $lookup->execute([$userId]);
            $before = $lookup->fetch();
            if (!$before) { $pdo->rollBack(); throw new InvalidArgumentException('用户不存在。'); }
            $pdo->prepare('UPDATE users SET status=?,remark=? WHERE id=?')->execute([$status, $remark ?: null, $userId]);
            if ($status === 0) $pdo->prepare('DELETE FROM user_tokens WHERE user_id=?')->execute([$userId]);
            adminAudit($pdo, $admin, 'user.update', 'user', $userId, $reason, $before, ['status' => $status, 'remark' => $remark]);
            $pdo->commit();
            adminFlash($status === 1 ? '用户已启用。' : '用户已停用，现有登录令牌已撤销。');
            header('Location: admin.php?section=users&detail_id=' . $userId, true, 303);
            exit;
        }

        if ($action === 'user.password.reset') {
            $userId = max(0, (int) ($_POST['user_id'] ?? 0));
            $newPassword = (string) ($_POST['new_password'] ?? '');
            $reason = adminPostString('reason', 500);
            if ($userId <= 0 || strlen($newPassword) < 12 || strlen($newPassword) > 200 || $reason === '') {
                throw new InvalidArgumentException('用户、至少 12 位的新密码和重置原因均为必填项。');
            }
            $pdo->beginTransaction();
            $lookup = $pdo->prepare('SELECT id,username,status FROM users WHERE id=? FOR UPDATE');
            $lookup->execute([$userId]);
            $targetUser = $lookup->fetch();
            if (!$targetUser) { $pdo->rollBack(); throw new InvalidArgumentException('用户不存在。'); }
            $pdo->prepare('UPDATE users SET password_hash=? WHERE id=?')->execute([password_hash($newPassword, PASSWORD_DEFAULT), $userId]);
            $pdo->prepare('DELETE FROM user_tokens WHERE user_id=?')->execute([$userId]);
            adminAudit($pdo, $admin, 'user.password.reset', 'user', $userId, $reason, ['status' => $targetUser['status']], ['password_reset' => true, 'tokens_revoked' => true]);
            $pdo->commit();
            adminFlash('用户密码已重置，原有登录令牌已撤销。');
            header('Location: admin.php?section=users&detail_id=' . $userId, true, 303);
            exit;
        }

        if ($action === 'user.wallet.update') {
            $userId = max(0, (int) ($_POST['user_id'] ?? 0));
            $walletAddress = strtolower(trim((string) ($_POST['wallet_address'] ?? '')));
            $reason = adminPostString('reason', 500);
            $requestId = (string) ($_POST['request_id'] ?? '');
            if ($userId <= 0 || !preg_match('/^0x[0-9a-f]{40}$/', $walletAddress) || adminIsTokenContractAddress($walletAddress) || $reason === '') {
                throw new InvalidArgumentException('钱包地址格式无效，不能填写代币合约地址，且必须填写操作原因。');
            }
            if (!preg_match('/^[a-f0-9]{32}$/', $requestId)) throw new InvalidArgumentException('钱包地址修改请求已失效，请刷新页面重试。');
            $pdo->beginTransaction();
            $lookup = $pdo->prepare('SELECT id,username,bsc_wallet_address FROM users WHERE id=? FOR UPDATE');
            $lookup->execute([$userId]);
            $targetUser = $lookup->fetch();
            if (!$targetUser) { $pdo->rollBack(); throw new InvalidArgumentException('用户不存在。'); }
            if (strtolower((string) ($targetUser['bsc_wallet_address'] ?? '')) === $walletAddress) {
                $pdo->rollBack();
                throw new InvalidArgumentException('新钱包地址与当前绑定地址相同。');
            }
            $addressOwner = $pdo->prepare('SELECT id,username FROM users WHERE bsc_wallet_address=? AND id<>? LIMIT 1 FOR UPDATE');
            $addressOwner->execute([$walletAddress, $userId]);
            if ($addressOwner->fetch()) { $pdo->rollBack(); throw new InvalidArgumentException('该钱包地址已绑定其他用户，不能重复绑定。'); }
            $pdo->prepare('UPDATE users SET bsc_wallet_address=? WHERE id=?')->execute([$walletAddress, $userId]);
            adminAudit($pdo, $admin, 'user.wallet.update', 'user', $userId, $reason,
                ['username' => $targetUser['username'], 'bsc_wallet_address' => $targetUser['bsc_wallet_address']],
                ['username' => $targetUser['username'], 'bsc_wallet_address' => $walletAddress], $requestId);
            $pdo->commit();
            adminFlash('用户绑定钱包地址已更新，历史记录未修改。');
            adminRedirect('users');
        }

        if ($action === 'wallet.status.update') {
            $recordType = (string) ($_POST['record_type'] ?? '');
            $recordId = max(0, (int) ($_POST['record_id'] ?? 0));
            $status = trim((string) ($_POST['status'] ?? ''));
            $reason = adminPostString('reason', 500);
            $allowedStatuses = $recordType === 'withdraw'
                ? ['pending', 'completed', 'failed', 'rejected', 'cancelled']
                : ['pending', 'processing', 'completed', 'failed', 'rejected', 'cancelled'];
            if (!in_array($recordType, ['recharge', 'withdraw'], true) || $recordId <= 0 || !in_array($status, $allowedStatuses, true) || $reason === '') {
                throw new InvalidArgumentException('记录类型、状态和操作原因不能为空。');
            }
            $pdo = db();
            $pdo->beginTransaction();
            if ($recordType === 'recharge') {
                $lookup = $pdo->prepare('SELECT id,user_id,tx_hash,currency,amount,status FROM recharge_records WHERE id=? FOR UPDATE');
                $lookup->execute([$recordId]);
                $before = $lookup->fetch();
                if (!$before) { $pdo->rollBack(); throw new InvalidArgumentException('充值记录不存在。'); }
                $pdo->prepare('UPDATE recharge_records SET status=? WHERE id=?')->execute([$status, $recordId]);
                adminAudit($pdo, $admin, 'wallet.status.update', 'recharge', $recordId, $reason, $before, ['status' => $status, 'funds_changed' => false]);
                $redirect = 'recharges';
            } else {
                $lookup = $pdo->prepare('SELECT t.id,t.user_id,t.symbol,t.amount,t.fee_amount,t.address,t.status,t.tx_hash,u.username,u.nickname FROM wallet_transactions t JOIN users u ON u.id=t.user_id WHERE t.id=? AND t.type="withdraw" FOR UPDATE');
                $lookup->execute([$recordId]);
                $before = $lookup->fetch();
                if (!$before) { $pdo->rollBack(); throw new InvalidArgumentException('提现记录不存在。'); }
                if ($before['status'] === 'completed') { $pdo->rollBack(); throw new InvalidArgumentException('已完成提现禁止再次修改状态。'); }
                $pdo->prepare('UPDATE wallet_transactions SET status=? WHERE id=? AND type="withdraw"')->execute([$status, $recordId]);
                adminAudit($pdo, $admin, 'wallet.status.update', 'wallet_transaction', $recordId, $reason, $before, ['status' => $status, 'funds_changed' => false]);
                $redirect = 'withdrawals';
            }
            $pdo->commit();
            if ($recordType === 'withdraw' && $status === 'failed' && ($before['status'] ?? '') !== 'failed') {
                try {
                    sendFinanceTemplate($pdo, 'withdraw_failed', [
                        'username' => (string) ($before['username'] ?? $before['user_id']),
                        'nickname' => (string) ($before['nickname'] ?? ''),
                        'user_id' => (int) $before['user_id'],
                        'symbol' => (string) $before['symbol'] . ' / BSC',
                        'amount' => (string) $before['amount'],
                        'fee' => (string) ($before['fee_amount'] ?? '0'),
                        'net_amount' => (string) $before['amount'],
                        'address' => (string) ($before['address'] ?? ''),
                        'reason' => $reason,
                        'status' => '失败',
                        'created_at' => date('Y-m-d H:i:s'),
                    ]);
                } catch (Throwable $exception) {
                    error_log('Admin withdrawal failure email notification failed: ' . $exception->getMessage());
                }
            }
            adminFlash('状态已修改，未改变任何资金或余额。');
            adminRedirect($redirect);
        }

        if ($action === 'wallet.adjust') {
            $userId = max(0, (int) ($_POST['user_id'] ?? 0));
            $symbol = strtoupper(adminPostString('symbol', 20));
            $operation = (string) ($_POST['operation'] ?? '');
            $amount = adminPostString('amount', 40);
            $reason = adminPostString('reason', 500);
            $requestId = (string) ($_POST['request_id'] ?? '');
            if ($userId <= 0 || !in_array($symbol, ['USDT', 'SPX001'], true) || !in_array($operation, ['add', 'subtract', 'set'], true) || $reason === '' || !preg_match('/^(?:0|[1-9][0-9]{0,17})(?:\.[0-9]{1,4})?$/', $amount)) {
                throw new InvalidArgumentException('余额调整参数无效，且必须填写操作原因。');
            }
            if (!preg_match('/^[a-f0-9]{32}$/', $requestId)) throw new InvalidArgumentException('余额调整请求已失效，请刷新页面重试。');
            if ($operation !== 'set' && !preg_match('/[1-9]/', $amount)) throw new InvalidArgumentException('增加或扣减金额必须大于 0。');
            $pdo->beginTransaction();
            $pdo->prepare('INSERT IGNORE INTO wallet_assets (user_id,symbol,chain,balance) VALUES (?, ?, "BSC", 0)')->execute([$userId, $symbol]);
            $asset = $pdo->prepare('SELECT id,balance,stakeable_balance FROM wallet_assets WHERE user_id=? AND symbol=? AND chain="BSC" FOR UPDATE');
            $asset->execute([$userId, $symbol]);
            $wallet = $asset->fetch();
            if (!$wallet) { $pdo->rollBack(); throw new InvalidArgumentException('用户或钱包资产不存在。'); }
            $beforeBalance = (string) $wallet['balance'];
            $stakeableDelta = '0';
            if ($operation === 'set') {
                $deltaQuery = $pdo->prepare('SELECT CAST(? AS DECIMAL(36,18))-CAST(? AS DECIMAL(36,18))');
                $deltaQuery->execute([$amount, $beforeBalance]);
                $delta = (string) $deltaQuery->fetchColumn();
            } else {
                $delta = $operation === 'add' ? $amount : '-' . $amount;
            }
            $zero = $pdo->prepare('SELECT CAST(? AS DECIMAL(36,18))=0');
            $zero->execute([$delta]);
            if ((int) $zero->fetchColumn() === 1) { $pdo->rollBack(); throw new InvalidArgumentException('余额没有变化，无需提交。'); }
            if (!str_starts_with($delta, '-')) {
                walletCredit($pdo, $userId, $symbol, 'BSC', $delta, $symbol === 'SPX001');
                $stakeableDelta = $symbol === 'SPX001' ? $delta : '0';
            } else {
                $stakeableUsed = walletDebit($pdo, $userId, $symbol, 'BSC', ltrim($delta, '-'), false);
                $stakeableDelta = $symbol === 'SPX001' ? '-' . $stakeableUsed : '0';
            }
            $afterQuery = $pdo->prepare('SELECT balance FROM wallet_assets WHERE id=?');
            $afterQuery->execute([$wallet['id']]);
            $afterBalance = (string) $afterQuery->fetchColumn();
            $pdo->prepare('INSERT INTO wallet_transactions (user_id,symbol,chain,type,amount,stakeable_amount,address,status) VALUES (?, ?, "BSC", "admin_adjustment", ?, ?, "ADMIN", "completed")')->execute([$userId, $symbol, $delta, $stakeableDelta]);
            adminAudit($pdo, $admin, 'wallet.adjust', 'user', $userId, $reason, ['symbol' => $symbol, 'balance' => $beforeBalance], ['symbol' => $symbol, 'balance' => $afterBalance, 'delta' => $delta], $requestId);
            $pdo->commit();
            adminFlash('余额已调整，钱包流水和审计日志已记录。');
            header('Location: admin.php?section=users&detail_id=' . $userId, true, 303);
            exit;
        }

        if ($action === 'recharge.manual.complete') {
            $recordId = max(0, (int) ($_POST['record_id'] ?? 0));
            $reason = adminPostString('reason', 500);
            $requestId = (string) ($_POST['request_id'] ?? '');
            if ($recordId <= 0 || $reason === '' || !preg_match('/^[a-f0-9]{32}$/', $requestId)) {
                throw new InvalidArgumentException('充值记录、处理原因或请求编号无效。');
            }
            $pdo->beginTransaction();
            $lookup = $pdo->prepare('SELECT * FROM recharge_records WHERE id=? FOR UPDATE');
            $lookup->execute([$recordId]);
            $recharge = $lookup->fetch();
            if (!$recharge || $recharge['status'] !== 'failed' || strtoupper((string) $recharge['currency']) !== 'USDT') {
                throw new InvalidArgumentException('仅可人工补记失败状态的 USDT 充值。');
            }
            $ledgerQuery = $pdo->prepare('SELECT id,amount,status FROM wallet_transactions WHERE tx_hash=? AND user_id=? AND type="deposit" AND symbol="USDT" AND chain="BSC" FOR UPDATE');
            $ledgerQuery->execute([$recharge['tx_hash'], $recharge['user_id']]);
            $ledger = $ledgerQuery->fetch();
            if (!$ledger || !in_array($ledger['status'], ['rejected', 'pending'], true)) {
                throw new InvalidArgumentException('找不到可补记的原始充值流水，或该流水已处理。');
            }
            $sameAmount = $pdo->prepare('SELECT CAST(? AS DECIMAL(36,18))=CAST(? AS DECIMAL(36,18))');
            $sameAmount->execute([$ledger['amount'], $recharge['amount']]);
            if ((int) $sameAmount->fetchColumn() !== 1) throw new RuntimeException('充值记录金额与钱包流水不一致，已停止补记。');
            $pdo->prepare('INSERT IGNORE INTO wallet_assets (user_id,symbol,chain,balance) VALUES (?,"USDT","BSC",0)')->execute([$recharge['user_id']]);
            $assetQuery = $pdo->prepare('SELECT id,balance FROM wallet_assets WHERE user_id=? AND symbol="USDT" AND chain="BSC" FOR UPDATE');
            $assetQuery->execute([$recharge['user_id']]);
            $asset = $assetQuery->fetch();
            if (!$asset) throw new RuntimeException('用户 USDT 资产不存在，已停止补记。');
            $balanceQuery = $pdo->prepare('SELECT CAST(? AS DECIMAL(36,18))+CAST(? AS DECIMAL(36,18))');
            $balanceQuery->execute([$asset['balance'], $recharge['amount']]);
            $afterBalance = (string) $balanceQuery->fetchColumn();
            $pdo->prepare('UPDATE wallet_assets SET balance=? WHERE id=?')->execute([$afterBalance, $asset['id']]);
            $pdo->prepare('UPDATE wallet_transactions SET status="completed" WHERE id=?')->execute([$ledger['id']]);
            $pdo->prepare('UPDATE recharge_records SET status="completed",error_message=NULL WHERE id=? AND status="failed"')->execute([$recordId]);
            $pdo->prepare('INSERT INTO recharge_audit_logs (record_id,user_id,tx_hash,amount,token,status,from_address,to_address,error_message) VALUES (?,?,?, ?,"USDT","completed",?,?,?)')->execute([
                $recordId, $recharge['user_id'], $recharge['tx_hash'], $recharge['amount'],
                $recharge['wallet_address'], $recharge['deposit_address'], $reason,
            ]);
            adminAudit($pdo, $admin, 'recharge.manual.complete', 'recharge', $recordId, $reason,
                ['status' => 'failed', 'balance' => (string) $asset['balance']],
                ['status' => 'completed', 'amount' => (string) $recharge['amount'], 'balance' => $afterBalance], $requestId);
            $pdo->commit();
            adminFlash('充值已人工补记到账，钱包流水和审计记录已更新。');
            adminRedirect('recharges');
        }

        if ($action === 'withdraw.process') {
            $transactionId = max(0, (int) ($_POST['transaction_id'] ?? 0));
            $decision = (string) ($_POST['decision'] ?? '');
            $reason = adminPostString('reason', 500);
            $txHash = strtolower(adminPostString('tx_hash', 120));
            if ($transactionId <= 0 || !in_array($decision, ['approve', 'reject'], true) || $reason === '') throw new InvalidArgumentException('提现操作参数无效，必须填写处理原因。');
            $pdo->beginTransaction();
            $lookup = $pdo->prepare('SELECT * FROM wallet_transactions WHERE id=? AND type="withdraw" AND status="pending" FOR UPDATE');
            $lookup->execute([$transactionId]);
            $withdrawal = $lookup->fetch();
            if (!$withdrawal) { $pdo->rollBack(); throw new InvalidArgumentException('提现不存在或已处理。'); }
            if ($decision === 'approve') {
                $pdo->prepare('UPDATE wallet_transactions SET status="processing",tx_hash=NULL WHERE id=?')->execute([$transactionId]);
                $after = ['status' => 'processing', 'automatic_withdrawal' => true];
            } else {
                $pdo->prepare('UPDATE wallet_transactions SET status="rejected" WHERE id=?')->execute([$transactionId]);
                $refundQuery = $pdo->prepare('SELECT CAST(? AS DECIMAL(36,18))+CAST(? AS DECIMAL(36,18))');
                $refundQuery->execute([$withdrawal['amount'], $withdrawal['fee_amount'] ?? '0']);
                $refundAmount = (string) $refundQuery->fetchColumn();
                walletCreditSplit($pdo, (int) $withdrawal['user_id'], (string) $withdrawal['symbol'], (string) $withdrawal['chain'], $refundAmount, (string) ($withdrawal['stakeable_amount'] ?? '0'));
                $pdo->prepare('INSERT INTO wallet_transactions (user_id,symbol,chain,type,amount,stakeable_amount,address,status) VALUES (?,?,?,"withdraw_refund",?,?,"ADMIN", "completed")')->execute([$withdrawal['user_id'], $withdrawal['symbol'], $withdrawal['chain'], $refundAmount, (string) ($withdrawal['stakeable_amount'] ?? '0')]);
                $after = ['status' => 'rejected', 'refunded' => $refundAmount];
            }
            adminAudit($pdo, $admin, 'withdraw.' . $decision, 'wallet_transaction', $transactionId, $reason, ['status' => 'pending', 'amount' => $withdrawal['amount']], $after);
            $pdo->commit();
            adminFlash($decision === 'approve' ? '提现已通过并登记交易哈希。' : '提现已拒绝，余额已退回。');
            adminRedirect('withdrawals');
        }

        if ($action === 'withdraw.batch_approve') {
            $rawIds = $_POST['transaction_ids'] ?? [];
            $reason = adminPostString('reason', 500);
            if (!is_array($rawIds) || $reason === '') throw new InvalidArgumentException('请选择待处理提现，并填写审核原因。');
            $transactionIds = array_values(array_unique(array_filter(array_map('intval', $rawIds), static fn(int $id): bool => $id > 0)));
            if (!$transactionIds || count($transactionIds) > 100) throw new InvalidArgumentException('请选择 1 至 100 笔待处理提现。');
            $pdo->beginTransaction();
            $lookup = $pdo->prepare('SELECT id,user_id,symbol,amount,status FROM wallet_transactions WHERE id=? AND type="withdraw" FOR UPDATE');
            $approve = $pdo->prepare('UPDATE wallet_transactions SET status="processing",tx_hash=NULL,error_message=NULL WHERE id=? AND type="withdraw" AND status="pending"');
            $approved = 0;
            foreach ($transactionIds as $transactionId) {
                $lookup->execute([$transactionId]);
                $withdrawal = $lookup->fetch();
                if (!$withdrawal || $withdrawal['status'] !== 'pending') continue;
                $approve->execute([$transactionId]);
                if ($approve->rowCount() !== 1) continue;
                $approved++;
                adminAudit($pdo, $admin, 'withdraw.batch_approve', 'wallet_transaction', $transactionId, $reason,
                    ['status' => 'pending', 'amount' => $withdrawal['amount'], 'symbol' => $withdrawal['symbol']],
                    ['status' => 'processing', 'automatic_withdrawal' => true]);
            }
            $pdo->commit();
            if ($approved === 0) throw new InvalidArgumentException('所选提现已不处于待处理状态，请刷新后重试。');
            adminFlash('已批量通过 ' . $approved . ' 笔提现，自动打币服务将逐笔处理。');
            adminRedirect('withdrawals');
        }

        if ($action === 'withdraw.retry') {
            $transactionId = max(0, (int) ($_POST['transaction_id'] ?? 0));
            $reason = adminPostString('reason', 500);
            if ($transactionId <= 0 || $reason === '') throw new InvalidArgumentException('提现记录和重试原因不能为空。');
            $pdo->beginTransaction();
            $lookup = $pdo->prepare('SELECT id,user_id,symbol,amount,status,tx_hash,error_message FROM wallet_transactions WHERE id=? AND type="withdraw" AND status="failed" FOR UPDATE');
            $lookup->execute([$transactionId]);
            $withdrawal = $lookup->fetch();
            if (!$withdrawal) { $pdo->rollBack(); throw new InvalidArgumentException('提现不存在或当前不是失败状态。'); }
            $pdo->prepare('UPDATE wallet_transactions SET status="processing",error_message=NULL WHERE id=? AND type="withdraw" AND status="failed"')->execute([$transactionId]);
            adminAudit($pdo, $admin, 'withdraw.retry', 'wallet_transaction', $transactionId, $reason,
                ['status' => 'failed', 'error_message' => $withdrawal['error_message']],
                ['status' => 'processing', 'automatic_withdrawal' => true, 'retry' => true]);
            $pdo->commit();
            adminFlash('提现已重新加入自动打币队列。');
            adminRedirect('withdrawals');
        }

        if ($action === 'order.process') {
            $orderId = max(0, (int) ($_POST['order_id'] ?? 0));
            $decision = (string) ($_POST['decision'] ?? '');
            $reason = adminPostString('reason', 500);
            if ($orderId <= 0 || !in_array($decision, ['complete', 'cancel'], true) || $reason === '') throw new InvalidArgumentException('订单操作参数无效，必须填写处理原因。');
            $pdo->beginTransaction();
            $owner=$pdo->prepare("SELECT user_id FROM orders WHERE id=?");$owner->execute([$orderId]);$ownerId=(int)$owner->fetchColumn();
            if($ownerId){$buyerLock=$pdo->prepare("SELECT id FROM users WHERE id=? FOR UPDATE");$buyerLock->execute([$ownerId]);}
            $lookup = $pdo->prepare('SELECT * FROM orders WHERE id=? AND status="pending" FOR UPDATE');
            $lookup->execute([$orderId]);
            $order = $lookup->fetch();
            if (!$order) { $pdo->rollBack(); throw new InvalidArgumentException('订单不存在或已处理。'); }
            if (!empty($order['merchant_id'])) throw new InvalidArgumentException('商家订单请在商家商城模块处理，以保护结算与售后状态。');
            if ($decision === 'complete') {
                if (($order['order_type'] ?? 'digital') === 'physical') throw new InvalidArgumentException('实物订单请填写物流信息后执行发货。');
                $pdo->prepare('UPDATE orders SET status="delivered",received_at=NOW() WHERE id=?')->execute([$orderId]);
                mallEvent($pdo,$orderId,"delivered","平台已完成商品交付，进入售后期");
                $after = ['status' => 'delivered'];
            } else {
                mallRefundOrder($pdo,$order);
                $after = ['status' => 'refunded', 'refunded_spx' => $order['total_spx'], 'restocked_quantity' => $order['quantity']];
            }
            adminAudit($pdo, $admin, 'order.' . $decision, 'order', $orderId, $reason, ['status' => 'pending', 'total_spx' => $order['total_spx']], $after);
            $pdo->commit();
            adminFlash($decision === 'complete' ? '订单已标记完成。' : '订单已取消，余额已退回且库存已恢复。');
            adminRedirect('orders');
        }

        if ($action === 'order.ship') {
            $orderId = max(0, (int) ($_POST['order_id'] ?? 0));
            $carrier = adminPostString('carrier', 100);
            $trackingNumber = adminPostString('tracking_number', 120);
            $reason = adminPostString('reason', 500);
            if ($orderId <= 0 || $carrier === '' || $trackingNumber === '' || $reason === '') throw new InvalidArgumentException('订单、承运商、物流单号和操作原因均为必填。');
            $pdo->beginTransaction();
            $lookup = $pdo->prepare('SELECT id,user_id,merchant_id,after_sale_status,order_type,status,carrier,tracking_number FROM orders WHERE id=? FOR UPDATE');
            $lookup->execute([$orderId]);
            $order = $lookup->fetch();
            if (!$order || $order['order_type'] !== 'physical' || $order['status'] !== 'pending' || in_array($order['after_sale_status'],['requested','return_approved','return_shipped'],true)) throw new InvalidArgumentException('仅待发货的实物订单可以登记发货。');
            $pdo->prepare('UPDATE orders SET status="shipped",carrier=?,tracking_number=?,shipped_at=NOW() WHERE id=?')->execute([$carrier, $trackingNumber, $orderId]);
            mallEvent($pdo,$orderId,'shipped','平台已登记发货物流');
            adminAudit($pdo, $admin, 'order.ship', 'order', $orderId, $reason, ['status' => $order['status']], ['status' => 'shipped', 'carrier' => $carrier, 'tracking_number' => $trackingNumber]);
            $pdo->commit();
            adminFlash('已登记物流信息，用户可在订单详情查看。');
            adminRedirect('orders');
        }

        if ($action === 'admin.save') {
            $adminId = max(0, (int) ($_POST['admin_id'] ?? 0));
            $username = adminPostString('username', 64);
            $role = (string) ($_POST['role'] ?? '');
            $password = (string) ($_POST['new_password'] ?? '');
            if (!preg_match('/^[A-Za-z0-9_.-]{3,64}$/', $username) || !in_array($role, ['superadmin', 'finance', 'support', 'operator'], true)) throw new InvalidArgumentException('管理员账号或角色无效。');
            if ($adminId === 0) {
                if (strlen($password) < 12) throw new InvalidArgumentException('新管理员密码至少 12 位。');
                $pdo->beginTransaction();
                $pdo->prepare('INSERT INTO admin_users (username,password_hash,role) VALUES (?,?,?)')->execute([$username, password_hash($password, PASSWORD_DEFAULT), $role]);
                $adminId = (int) $pdo->lastInsertId();
                adminAudit($pdo, $admin, 'admin.create', 'admin', $adminId, '创建管理员账号', null, ['username' => $username, 'role' => $role]);
                $pdo->commit();
            } else {
                if ($adminId === (int) $admin['id'] && $role !== 'superadmin') throw new InvalidArgumentException('不能降低当前管理员自己的最高权限。');
                if ($adminId === (int) $admin['id'] && $password !== '') throw new InvalidArgumentException('请在“账号安全”页面通过当前密码修改自己的密码。');
                $pdo->beginTransaction();
                $beforeQuery = $pdo->prepare('SELECT username,role,status FROM admin_users WHERE id=?');
                $beforeQuery->execute([$adminId]);
                $before = $beforeQuery->fetch();
                if (!$before) throw new InvalidArgumentException('管理员账号不存在。');
                if ((int) $before['status'] === 1 && $before['role'] === 'superadmin' && $role !== 'superadmin') {
                    $activeSuperadmins = (int) $pdo->query('SELECT COUNT(*) FROM admin_users WHERE role="superadmin" AND status=1')->fetchColumn();
                    if ($activeSuperadmins <= 1) throw new InvalidArgumentException('系统至少需要保留一名启用的超级管理员。');
                }
                $pdo->prepare('UPDATE admin_users SET username=?,role=? WHERE id=?')->execute([$username, $role, $adminId]);
                if ($password !== '') {
                    if (strlen($password) < 12) throw new InvalidArgumentException('新密码至少 12 位。');
                    $pdo->prepare('UPDATE admin_users SET password_hash=? WHERE id=?')->execute([password_hash($password, PASSWORD_DEFAULT), $adminId]);
                }
                adminAudit($pdo, $admin, 'admin.update', 'admin', $adminId, '管理员账号和角色更新', $before, ['username' => $username, 'role' => $role]);
                $pdo->commit();
            }
            adminFlash('管理员账号已保存。');
            adminRedirect('admins');
        }

        if ($action === 'admin.toggle') {
            $targetId = max(0, (int) ($_POST['admin_id'] ?? 0));
            if ($targetId <= 0 || $targetId === (int) $admin['id']) throw new InvalidArgumentException('不能停用当前登录账号。');
            $pdo->beginTransaction();
            $lookup = $pdo->prepare('SELECT id,username,role,status FROM admin_users WHERE id=? FOR UPDATE');
            $lookup->execute([$targetId]);
            $target = $lookup->fetch();
            if (!$target) { $pdo->rollBack(); throw new InvalidArgumentException('管理员账号不存在。'); }
            $newStatus = (int) $target['status'] === 1 ? 0 : 1;
            if ($newStatus === 0 && $target['role'] === 'superadmin') {
                $activeSuperadmins = (int) $pdo->query('SELECT COUNT(*) FROM admin_users WHERE role="superadmin" AND status=1')->fetchColumn();
                if ($activeSuperadmins <= 1) { $pdo->rollBack(); throw new InvalidArgumentException('系统至少需要保留一名启用的超级管理员。'); }
            }
            $pdo->prepare('UPDATE admin_users SET status=? WHERE id=?')->execute([$newStatus, $targetId]);
            adminAudit($pdo, $admin, 'admin.toggle', 'admin', $targetId, '管理员启用状态变更', $target, ['status' => $newStatus]);
            $pdo->commit();
            adminFlash($newStatus === 1 ? '管理员账号已启用。' : '管理员账号已停用。');
            adminRedirect('admins');
        }

        if ($action === 'question.save') {
            $questionId = max(0, (int) ($_POST['question_id'] ?? 0));
            $answer = adminPostString('answer', 10000);
            $status = (string) ($_POST['status'] ?? 'answered');
            if ($questionId <= 0 || $answer === '' || !in_array($status, ['pending', 'answered', 'closed'], true)) throw new InvalidArgumentException('问题回复或状态无效。');
            $pdo->beginTransaction();
            $lookup = $pdo->prepare('SELECT status,answer FROM user_questions WHERE id=? FOR UPDATE');
            $lookup->execute([$questionId]);
            $before = $lookup->fetch();
            if (!$before) throw new InvalidArgumentException('用户问题不存在。');
            $pdo->prepare('UPDATE user_questions SET answer=?,status=? WHERE id=?')->execute([$answer, $status, $questionId]);
            adminAudit($pdo, $admin, 'question.reply', 'question', $questionId, '回复用户问题', $before, ['answer' => $answer, 'status' => $status]);
            $pdo->commit();
            adminFlash('问题回复已保存。');
            adminRedirect('questions');
        }

        if ($action === 'feedback.save') {
            $feedbackId = max(0, (int) ($_POST['feedback_id'] ?? 0));
            $status = (string) ($_POST['status'] ?? 'pending');
            if ($feedbackId <= 0 || !in_array($status, ['pending', 'reviewed', 'resolved'], true)) throw new InvalidArgumentException('反馈状态无效。');
            $pdo->beginTransaction();
            $lookup = $pdo->prepare('SELECT status FROM feedback WHERE id=? FOR UPDATE');
            $lookup->execute([$feedbackId]);
            $before = $lookup->fetch();
            if (!$before) throw new InvalidArgumentException('反馈记录不存在。');
            $pdo->prepare('UPDATE feedback SET status=? WHERE id=?')->execute([$status, $feedbackId]);
            adminAudit($pdo, $admin, 'feedback.update', 'feedback', $feedbackId, '更新反馈处理状态', $before, ['status' => $status]);
            $pdo->commit();
            adminFlash('反馈状态已更新。');
            adminRedirect('feedback');
        }

        if ($action === 'faq.save') {
            $faqId = max(0, (int) ($_POST['faq_id'] ?? 0));
            $category = adminPostString('category', 50);
            $question = adminPostString('question', 255);
            $answer = adminPostString('answer', 10000);
            $sortOrder = filter_var($_POST['sort_order'] ?? 0, FILTER_VALIDATE_INT);
            $status = (int) ($_POST['status'] ?? 0) === 1 ? 1 : 0;
            if ($category === '' || $question === '' || $answer === '' || $sortOrder === false) throw new InvalidArgumentException('FAQ 内容不能为空，排序值无效。');
            $pdo->beginTransaction();
            if ($faqId > 0) {
                $lookup = $pdo->prepare('SELECT category,question,answer,status,sort_order FROM faq_items WHERE id=? FOR UPDATE');
                $lookup->execute([$faqId]);
                $before = $lookup->fetch();
                if (!$before) { $pdo->rollBack(); throw new InvalidArgumentException('FAQ 不存在。'); }
                $pdo->prepare('UPDATE faq_items SET category=?,question=?,answer=?,status=?,sort_order=? WHERE id=?')->execute([$category, $question, $answer, $status, $sortOrder, $faqId]);
            } else {
                $pdo->prepare('INSERT INTO faq_items (category,question,answer,status,sort_order) VALUES (?,?,?,?,?)')->execute([$category, $question, $answer, $status, $sortOrder]);
                $faqId = (int) $pdo->lastInsertId();
                $before = null;
            }
            adminAudit($pdo, $admin, 'faq.save', 'faq', $faqId, '维护常见问题', $before, compact('category', 'question', 'answer', 'status', 'sortOrder'));
            $pdo->commit();
            adminFlash('FAQ 已保存。');
            adminRedirect('faqs');
        }

        if ($action === 'group.save') {
            $groupId = max(0, (int) ($_POST['group_id'] ?? 0));
            $name = adminPostString('name', 100);
            $announcement = adminPostString('announcement', 5000);
            if ($groupId <= 0 || $name === '') throw new InvalidArgumentException('群组名称不能为空。');
            $pdo->beginTransaction();
            $lookup = $pdo->prepare('SELECT name,announcement FROM chat_groups WHERE id=? FOR UPDATE');
            $lookup->execute([$groupId]);
            $before = $lookup->fetch();
            if (!$before) throw new InvalidArgumentException('群组不存在。');
            $pdo->prepare('UPDATE chat_groups SET announcement_version=announcement_version+CASE WHEN COALESCE(announcement,"")<>COALESCE(?,"") THEN 1 ELSE 0 END,name=?,announcement=? WHERE id=?')->execute([$announcement, $name, $announcement ?: null, $groupId]);
            adminAudit($pdo, $admin, 'group.update', 'group', $groupId, '更新群组资料', $before, ['name' => $name, 'announcement' => $announcement]);
            $pdo->commit();
            adminFlash('群组信息已更新。');
            adminRedirect('groups');
        }

        if ($action === 'group.member') {
            $groupId = max(0, (int) ($_POST['group_id'] ?? 0));
            $memberUserId = max(0, (int) ($_POST['user_id'] ?? 0));
            $operation = (string) ($_POST['operation'] ?? '');
            $reason = adminPostString('reason', 500);
            if ($groupId <= 0 || $memberUserId <= 0 || !in_array($operation, ['mute', 'unmute', 'remove'], true) || $reason === '') {
                throw new InvalidArgumentException('群成员操作参数无效，必须填写原因。');
            }
            $pdo->beginTransaction();
            $lookup = $pdo->prepare('SELECT gm.id,gm.role,gm.mute,u.username FROM chat_group_members gm JOIN users u ON u.id=gm.user_id WHERE gm.group_id=? AND gm.user_id=? FOR UPDATE');
            $lookup->execute([$groupId, $memberUserId]);
            $member = $lookup->fetch();
            if (!$member) { $pdo->rollBack(); throw new InvalidArgumentException('群成员不存在。'); }
            if ($member['role'] === 'owner') { $pdo->rollBack(); throw new InvalidArgumentException('不能通过此操作移除或禁言群主。'); }
            if ($operation === 'remove') {
                $pdo->prepare('DELETE FROM chat_group_members WHERE id=?')->execute([$member['id']]);
                $after = ['removed' => true];
            } else {
                $mute = $operation === 'mute' ? 1 : 0;
                $pdo->prepare('UPDATE chat_group_members SET mute=? WHERE id=?')->execute([$mute, $member['id']]);
                $after = ['mute' => $mute];
            }
            adminAudit($pdo, $admin, 'group.member.' . $operation, 'group_member', (int) $member['id'], $reason, ['group_id' => $groupId, 'user_id' => $memberUserId, 'role' => $member['role'], 'mute' => $member['mute']], $after);
            $pdo->commit();
            adminFlash($operation === 'remove' ? '成员已移出群组。' : ($operation === 'mute' ? '成员已禁言。' : '成员已解除禁言。'));
            header('Location: admin.php?section=groups&group_id=' . $groupId, true, 303);
            exit;
        }

        if ($action === 'staking.phase.save') {
            $phaseNo = filter_var($_POST['phase_no'] ?? null, FILTER_VALIDATE_INT);
            $name = adminPostString('name', 100);
            $quota = adminPostString('total_quota', 40);
            $active = (int) ($_POST['status'] ?? 0) === 1 ? 1 : 0;
            if ($phaseNo === false || $phaseNo < 1 || $phaseNo > 1000000 || $name === '' || !preg_match('/^(?:0|[1-9][0-9]{0,17})(?:\.[0-9]{1,18})?$/', $quota) || !preg_match('/[1-9]/', $quota)) {
                throw new InvalidArgumentException('质押期数、名称或总额度无效。');
            }
            $pdo->beginTransaction();
            $lookup = $pdo->prepare('SELECT * FROM staking_phases WHERE phase_no=? FOR UPDATE');
            $lookup->execute([$phaseNo]);
            $before = $lookup->fetch() ?: null;
            if ($before) {
                $quotaCheck = $pdo->prepare('SELECT CAST(? AS DECIMAL(36,18))>=CAST(? AS DECIMAL(36,18))');
                $quotaCheck->execute([$quota, $before['reserved_quota']]);
                if ((int) $quotaCheck->fetchColumn() !== 1) { $pdo->rollBack(); throw new InvalidArgumentException('总额度不能低于已经预分配额度。'); }
            }
            if ($active === 1) $pdo->prepare('UPDATE staking_phases SET status=0,ended_at=IF(status=1,NOW(),ended_at) WHERE status=1 AND phase_no<>?')->execute([$phaseNo]);
            if ($before) {
                $pdo->prepare('UPDATE staking_phases SET name=?,total_quota=?,status=?,started_at=IF(?=1,COALESCE(started_at,NOW()),started_at),ended_at=IF(?=1,NULL,NOW()) WHERE id=?')->execute([$name, $quota, $active, $active, $active, $before['id']]);
                $phaseId = (int) $before['id'];
            } else {
                $pdo->prepare('INSERT INTO staking_phases (phase_no,name,total_quota,status,started_at) VALUES (?,?,?,?,IF(?=1,NOW(),NULL))')->execute([$phaseNo, $name, $quota, $active, $active]);
                $phaseId = (int) $pdo->lastInsertId();
            }
            $afterQuery = $pdo->prepare('SELECT * FROM staking_phases WHERE id=?');
            $afterQuery->execute([$phaseId]);
            $after = $afterQuery->fetch() ?: [];
            adminAudit($pdo, $admin, 'staking.phase.save', 'staking_phase', $phaseId, '维护质押奖励额度和期数', $before, $after);
            $pdo->commit();
            adminFlash($active === 1 ? '质押期已开启，新的质押将按该期额度预分配。' : '质押期配置已保存但未开启。');
            adminRedirect('staking');
        }

        if ($action === 'staking.plans.save') {
            $submitted = $_POST['plans'] ?? [];
            if (!is_array($submitted) || !$submitted) throw new InvalidArgumentException('至少保留一个质押方案。');
            $plans = [];
            $seenDays = [];
            foreach (array_values($submitted) as $index => $input) {
                if (!is_array($input)) continue;
                if (trim((string) ($input['name'] ?? '')) === '' && trim((string) ($input['plan_days'] ?? '')) === '' && trim((string) ($input['apy'] ?? '')) === '' && trim((string) ($input['minimum_amount'] ?? '')) === '') continue;
                $id = max(0, (int) ($input['id'] ?? 0));
                $name = trim((string) ($input['name'] ?? ''));
                $days = filter_var($input['plan_days'] ?? null, FILTER_VALIDATE_INT);
                $apy = trim((string) ($input['apy'] ?? ''));
                $minimum = trim((string) ($input['minimum_amount'] ?? ''));
                $active = (int) ($input['status'] ?? 0) === 1 ? 1 : 0;
                if ($name === '' || strlen($name) > 100 || $days === false || $days < 1 || $days > 3650 || isset($seenDays[$days]
                    ) || !preg_match('/^(?:0|[1-9][0-9]{0,2})(?:\.[0-9]{1,4})?$/', $apy)
                    || !preg_match('/^(?:0|[1-9][0-9]{0,17})(?:\.[0-9]{1,18})?$/', $minimum) || !preg_match('/[1-9]/', $minimum)) {
                    throw new InvalidArgumentException('质押方案名称、唯一锁仓天数、年化利率或最低金额无效。');
                }
                $seenDays[$days] = true;
                $plans[] = compact('id', 'name', 'days', 'apy', 'minimum', 'active', 'index');
            }
            if (!$plans || !array_filter($plans, static fn(array $plan): bool => $plan['active'] === 1)) throw new InvalidArgumentException('至少保留一个资料完整且启用的质押方案。');
            $pdo->beginTransaction();
            $before = $pdo->query('SELECT id,name,plan_days,apy,minimum_amount,status FROM staking_plans ORDER BY sort_order,id FOR UPDATE')->fetchAll();
            $pdo->exec('UPDATE staking_plans SET status=0');
            foreach ($plans as $plan) {
                if ($plan['id'] > 0) {
                    $save = $pdo->prepare('UPDATE staking_plans SET name=?,plan_days=?,apy=?,minimum_amount=?,status=?,sort_order=? WHERE id=?');
                    $save->execute([$plan['name'], $plan['days'], $plan['apy'], $plan['minimum'], $plan['active'], ($plan['index'] + 1) * 10, $plan['id']]);
                    if ($save->rowCount() === 0) {
                        $exists = $pdo->prepare('SELECT id FROM staking_plans WHERE id=?'); $exists->execute([$plan['id']]);
                        if (!$exists->fetchColumn()) throw new InvalidArgumentException('质押方案已不存在，请刷新页面后重试。');
                    }
                } else {
                    $pdo->prepare('INSERT INTO staking_plans (name,plan_days,apy,minimum_amount,status,sort_order) VALUES (?,?,?,?,?,?)')->execute([$plan['name'], $plan['days'], $plan['apy'], $plan['minimum'], $plan['active'], ($plan['index'] + 1) * 10]);
                }
            }
            $after = $pdo->query('SELECT id,name,plan_days,apy,minimum_amount,status FROM staking_plans ORDER BY sort_order,id')->fetchAll();
            adminAudit($pdo, $admin, 'staking.plans.save', 'staking_plans', null, '维护动态质押方案', $before, $after);
            $pdo->commit();
            adminFlash('质押方案已更新，App 展示和服务端最低金额校验已同步。');
            adminRedirect('staking');
        }

        if ($action === 'product.save') {
            $id = max(0, (int) ($_POST['id'] ?? 0));
            $name = adminPostString('name', 150);
            $description = adminPostString('description', 10000);
            $imageUrl = adminPostString('image_url', 500);
            $price = adminPostString('spx_price', 32);
            $stock = filter_var($_POST['stock'] ?? null, FILTER_VALIDATE_INT);
            $sortOrder = filter_var($_POST['sort_order'] ?? 0, FILTER_VALIDATE_INT);
            $status = (int) ($_POST['status'] ?? 0) === 1 ? 1 : 0;
            $productType = (string) ($_POST['product_type'] ?? 'digital');
            $variantText = str_replace("\r", '', adminPostString('variants', 5000));
            if (!in_array($productType, ['digital', 'physical'], true)) throw new InvalidArgumentException('商品类型无效。');
            $variants = [];
            $lineStock = 0;
            $seenVariantNames = [];
            foreach (array_filter(explode("\n", $variantText), static fn(string $line): bool => trim($line) !== '') as $lineIndex => $line) {
                $parts = array_map('trim', explode('|', $line));
                if (count($parts) !== 3 || $parts[0] === '' || strlen($parts[0]) > 150 || isset($seenVariantNames[$parts[0]]) || !preg_match('/^(?:0|[1-9][0-9]{0,15})(?:\.[0-9]{1,8})?$/', $parts[1]) || !preg_match('/^(?:0|[1-9][0-9]{0,8})$/', $parts[2])) {
                    throw new InvalidArgumentException('规格请按“规格名称|SPX价格|库存”逐行填写，例如：红色 M|120|8。');
                }
                $seenVariantNames[$parts[0]] = true;
                $variants[] = ['id' => 'v' . bin2hex(random_bytes(8)), 'name' => $parts[0], 'price' => $parts[1], 'stock' => (int) $parts[2]];
                $lineStock += (int) $parts[2];
                if (count($variants) > 30) throw new InvalidArgumentException('每个商品最多设置 30 个规格。');
            }
            if ($variants) {
                $price = (string) $variants[0]['price'];
                $stock = $lineStock;
            }
            if ($name === '' || !preg_match('/^(?:0|[1-9][0-9]{0,15})(?:\.[0-9]{1,8})?$/', $price) || $stock === false || $stock < 0 || $sortOrder === false) {
                throw new InvalidArgumentException('商品名称、价格、库存或排序值无效。');
            }
            if ($imageUrl !== '' && !filter_var($imageUrl, FILTER_VALIDATE_URL)) {
                throw new InvalidArgumentException('商品图片地址格式无效。');
            }
            $newProductImages = adminStoreProductImages();
            $removeIds = array_values(array_unique(array_filter(array_map('intval', (array) ($_POST['remove_image_ids'] ?? [])), static fn(int $value): bool => $value > 0)));
            if (count($newProductImages) > 8 || count($removeIds) > 8) throw new InvalidArgumentException('图片操作数量超出限制。');
            $pdo->beginTransaction();
            $before = null;
            $existingImages = [];
            if ($id > 0) {
                $lookup = $pdo->prepare('SELECT merchant_id,name,description,image_url,spx_price,stock,status,sort_order,product_type,variants FROM products WHERE id=?');
                $lookup->execute([$id]);
                $before = $lookup->fetch();
                if (!$before) throw new InvalidArgumentException('商品不存在。');
                if (!empty($before['merchant_id'])) throw new InvalidArgumentException('商家商品请通过商家端编辑、商家商城审核模块处理。');
                $previousVariants = json_decode((string) ($before['variants'] ?? ''), true) ?: [];
                $previousVariantIds = [];
                foreach ($previousVariants as $previousVariant) {
                    if (!empty($previousVariant['name']) && !empty($previousVariant['id'])) $previousVariantIds[(string) $previousVariant['name']] = (string) $previousVariant['id'];
                }
                foreach ($variants as &$variant) $variant['id'] = $previousVariantIds[$variant['name']] ?? ('v' . bin2hex(random_bytes(8)));
                unset($variant);
                $previousPendingVariantIds = $pdo->prepare('SELECT DISTINCT variant_id FROM orders WHERE product_id=? AND status="pending" AND variant_id IS NOT NULL');
                $previousPendingVariantIds->execute([$id]);
                $activeVariantIds = $variants ? array_column($variants, 'id') : ['default'];
                foreach ($previousPendingVariantIds->fetchAll(PDO::FETCH_COLUMN) as $pendingVariantId) {
                    if (!in_array((string) $pendingVariantId, $activeVariantIds, true)) throw new InvalidArgumentException('商品存在待处理订单，不能删除或重命名其规格；请先处理相关订单。');
                }
                $imageQuery = $pdo->prepare('SELECT id,image_url,sort_order FROM product_images WHERE product_id=? ORDER BY sort_order,id FOR UPDATE');
                $imageQuery->execute([$id]);
                $existingImages = $imageQuery->fetchAll();
                $save = $pdo->prepare('UPDATE products SET name=?,description=?,spx_price=?,stock=?,status=?,sort_order=?,product_type=?,variants=? WHERE id=?');
                $save->execute([$name, $description, $price, $stock, $status, $sortOrder, $productType, $variants ? json_encode($variants, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : null, $id]);
            } else {
                $save = $pdo->prepare('INSERT INTO products (name,description,image_url,spx_price,stock,status,sort_order,product_type,variants) VALUES (?,?,NULL,?,?,?,?,?,?)');
                $save->execute([$name, $description, $price, $stock, $status, $sortOrder, $productType, $variants ? json_encode($variants, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : null]);
                $id = (int) $pdo->lastInsertId();
            }
            $removedIds = array_values(array_intersect(array_map(static fn(array $image): int => (int) $image['id'], $existingImages), $removeIds));
            if ($removedIds) {
                $marks = implode(',', array_fill(0, count($removedIds), '?'));
                $removedQuery = $pdo->prepare('SELECT image_url FROM product_images WHERE product_id=? AND id IN (' . $marks . ')');
                $removedQuery->execute(array_merge([$id], $removedIds));
                $removedProductImages = $removedQuery->fetchAll(PDO::FETCH_COLUMN);
                $deleteImages = $pdo->prepare('DELETE FROM product_images WHERE product_id=? AND id IN (' . $marks . ')');
                $deleteImages->execute(array_merge([$id], $removedIds));
            }
            $remainingImages = array_values(array_filter($existingImages, static fn(array $image): bool => !in_array((int) $image['id'], $removedIds, true)));
            if (count($remainingImages) + count($newProductImages) > 8) throw new InvalidArgumentException('每个商品最多保留 8 张图片，请先移除旧图片。');
            $maxSort = 0;
            foreach ($remainingImages as $image) $maxSort = max($maxSort, (int) $image['sort_order']);
            $insertImage = $pdo->prepare('INSERT INTO product_images (product_id,image_url,sort_order) VALUES (?,?,?)');
            foreach ($newProductImages as $image) {
                $insertImage->execute([$id, $image['url'], ++$maxSort]);
                $remainingImages[] = ['image_url' => $image['url'], 'sort_order' => $maxSort];
            }
            usort($remainingImages, static fn(array $a, array $b): int => (int) $a['sort_order'] <=> (int) $b['sort_order']);
            $primaryImage = $imageUrl !== '' && !in_array($imageUrl, $removedProductImages, true) ? $imageUrl : ($remainingImages[0]['image_url'] ?? null);
            if (count(array_unique(array_merge($primaryImage ? [$primaryImage] : [], array_column($remainingImages, 'image_url')))) > 8) throw new InvalidArgumentException('商品主图与图库图片合计最多 8 张。');
            $pdo->prepare('UPDATE products SET image_url=? WHERE id=?')->execute([$primaryImage, $id]);
            adminAudit($pdo, $admin, 'product.save', 'product', $id, '维护商品资料', $before, ['name' => $name, 'description' => $description, 'image_url' => $primaryImage, 'gallery_count' => count($remainingImages), 'spx_price' => $price, 'stock' => $stock, 'product_type' => $productType, 'variants' => $variants, 'status' => $status, 'sort_order' => $sortOrder]);
            $pdo->commit();
            foreach ($removedProductImages as $url) {
                if (preg_match('#^/uploads/products/[a-f0-9]{40}\.(?:jpg|png|webp|gif)$#', (string) $url)) @unlink(dirname(__DIR__) . $url);
            }
            $newProductImages = [];
            adminFlash('商品信息已保存。');
            adminRedirect('products');
        }

        if ($action === 'ticket.save') {
            $ticketId = max(0, (int) ($_POST['ticket_id'] ?? 0));
            $reply = adminPostString('admin_reply', 10000);
            $status = (string) ($_POST['status'] ?? 'open');
            if ($ticketId <= 0 || !in_array($status, ['open', 'processing', 'resolved', 'closed'], true) || $reply === '') {
                throw new InvalidArgumentException('请填写回复内容并选择有效状态。');
            }
            $pdo->beginTransaction();
            $lookup = $pdo->prepare('SELECT admin_reply,status FROM support_tickets WHERE id=? FOR UPDATE');
            $lookup->execute([$ticketId]);
            $before = $lookup->fetch();
            if (!$before) throw new InvalidArgumentException('工单不存在。');
            $save = $pdo->prepare('UPDATE support_tickets SET admin_reply=?,status=? WHERE id=?');
            $save->execute([$reply, $status, $ticketId]);
            adminAudit($pdo, $admin, 'ticket.reply', 'ticket', $ticketId, '处理客服工单', $before, ['admin_reply' => $reply, 'status' => $status]);
            $pdo->commit();
            adminFlash('工单回复已保存。');
            adminRedirect('tickets');
        }

        if ($action === 'app.release.upload') {
            $versionName = adminPostString('version_name', 32);
            $versionCode = filter_var($_POST['version_code'] ?? null, FILTER_VALIDATE_INT);
            $releaseNotes = adminPostString('release_notes', 10000);
            $upload = $_FILES['apk'] ?? null;
            if (!preg_match('/^[A-Za-z0-9][A-Za-z0-9._+-]{0,31}$/', $versionName) || $versionCode === false || $versionCode <= 0 || $releaseNotes === '') {
                throw new InvalidArgumentException('请填写有效的版本名称、递增版本代码和更新说明。');
            }
            if (!is_array($upload) || (int) ($upload['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || empty($upload['tmp_name']) || !is_uploaded_file((string) $upload['tmp_name'])) {
                throw new InvalidArgumentException('请选择 APK 文件；上传失败时请检查服务器上传大小限制。');
            }
            $apkSize = (int) ($upload['size'] ?? 0);
            if ($apkSize < 4 || $apkSize > 500 * 1024 * 1024) throw new InvalidArgumentException('APK 文件必须大于 0 且不超过 500 MB。');
            $signature = file_get_contents((string) $upload['tmp_name'], false, null, 0, 4);
            if ($signature !== "PK\x03\x04") throw new InvalidArgumentException('文件格式不是有效的 APK/ZIP 包。');
            if (class_exists('ZipArchive')) {
                $zip = new ZipArchive();
                if ($zip->open((string) $upload['tmp_name']) !== true || $zip->locateName('AndroidManifest.xml') === false) {
                    if ($zip->status === ZipArchive::ER_OK) $zip->close();
                    throw new InvalidArgumentException('APK 包内缺少 AndroidManifest.xml。');
                }
                $zip->close();
            }
            $apkSha256 = hash_file('sha256', (string) $upload['tmp_name']);
            if (!is_string($apkSha256)) throw new RuntimeException('无法计算 APK 校验值。');
            $uploadDirectory = dirname(__DIR__) . '/uploads/app-releases';
            if (!is_dir($uploadDirectory) && !mkdir($uploadDirectory, 0755, true) && !is_dir($uploadDirectory)) throw new RuntimeException('无法创建 APK 存储目录。');
            $filename = $apkSha256 . '-' . bin2hex(random_bytes(8)) . '.apk';
            $newReleasePath = $uploadDirectory . '/' . $filename;
            if (!move_uploaded_file((string) $upload['tmp_name'], $newReleasePath)) throw new RuntimeException('APK 保存失败。');
            $pdo->beginTransaction();
            $activeQuery = $pdo->query('SELECT id,version_code,version_name FROM app_releases WHERE is_active=1 ORDER BY version_code DESC LIMIT 1 FOR UPDATE');
            $activeRelease = $activeQuery->fetch();
            if ($activeRelease && (int) $versionCode <= (int) $activeRelease['version_code']) {
                throw new InvalidArgumentException('新版本代码必须大于当前已发布版本代码 ' . (int) $activeRelease['version_code'] . '。');
            }
            $pdo->exec('UPDATE app_releases SET is_active=0 WHERE is_active=1');
            $pdo->prepare('INSERT INTO app_releases (version_code,version_name,release_notes,file_path,apk_size,apk_sha256,is_active,admin_id) VALUES (?,?,?,?,?,?,1,?)')->execute([
                $versionCode, $versionName, $releaseNotes, '/uploads/app-releases/' . $filename, $apkSize, $apkSha256, $admin['id'],
            ]);
            $releaseId = (int) $pdo->lastInsertId();
            adminAudit($pdo, $admin, 'app.release.upload', 'app_release', $releaseId, '发布 Android APK 更新',
                $activeRelease ? ['version_name' => $activeRelease['version_name'], 'version_code' => (int) $activeRelease['version_code']] : null,
                ['version_name' => $versionName, 'version_code' => (int) $versionCode, 'apk_size' => $apkSize, 'apk_sha256' => $apkSha256]);
            $pdo->commit();
            $newReleasePath = null;
            adminFlash('Android ' . $versionName . ' 已发布；版本代码 ' . (int) $versionCode . '，APK SHA-256 已记录。');
            adminRedirect('settings');
        }

        if ($action === 'settings.deposit.save') {
            $address = trim(adminPostString('deposit_address', 42));
            if (!preg_match('/^0x[0-9a-fA-F]{40}$/', $address)) {
                throw new InvalidArgumentException('BSC 收款地址格式无效。');
            }
            $pdo->beginTransaction();
            $old = $pdo->prepare('SELECT `value` FROM app_settings WHERE `key`=? FOR UPDATE');
            $old->execute(['bsc_usdt_deposit_address']);
            $before = $old->fetchColumn();
            $save = $pdo->prepare('INSERT INTO app_settings (`key`,`value`) VALUES (?,?) ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)');
            $save->execute(['bsc_usdt_deposit_address', strtolower($address)]);
            adminAudit($pdo, $admin, 'settings.deposit', 'setting', null, '修改 BSC USDT 收款地址', ['address' => $before ?: ''], ['address' => strtolower($address)]);
            $pdo->commit();
            adminFlash('充值收款地址已更新。');
            adminRedirect('settings');
        }

        if ($action === 'settings.invite_base.save') {
            $base = rtrim(trim((string) ($_POST['invite_base_url'] ?? '')), '/');
            if (!preg_match('#^https?://[^/\s]+$#i', $base)) throw new InvalidArgumentException('邀请链接域名格式无效。');
            $save = $pdo->prepare('INSERT INTO app_settings (`key`,`value`) VALUES (?,?) ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)');
            $save->execute(['invite_base_url', $base]);
            adminFlash('邀请链接域名已更新。');
            adminRedirect('settings');
        }

        if ($action === 'password.save') {
            $currentPassword = (string) ($_POST['current_password'] ?? '');
            $newPassword = (string) ($_POST['new_password'] ?? '');
            $verify = $pdo->prepare('SELECT password_hash FROM admin_users WHERE id=?');
            $verify->execute([$admin['id']]);
            $hash = (string) $verify->fetchColumn();
            if (!password_verify($currentPassword, $hash)) throw new InvalidArgumentException('当前密码不正确。');
            if (strlen($newPassword) < 12 || strlen($newPassword) > 200) throw new InvalidArgumentException('新密码长度须为 12 至 200 个字符。');
            $pdo->beginTransaction();
            $pdo->prepare('UPDATE admin_users SET password_hash=? WHERE id=?')->execute([password_hash($newPassword, PASSWORD_DEFAULT), $admin['id']]);
            adminAudit($pdo, $admin, 'admin.password', 'admin', (int) $admin['id'], '修改管理员自身密码', null, ['password_changed' => true]);
            $pdo->commit();
            session_regenerate_id(true);
            adminFlash('管理员密码已更新。');
            adminRedirect('profile');
        }

        throw new InvalidArgumentException('不支持的管理操作。');
    } catch (Throwable $exception) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        foreach ($newProductImages as $image) @unlink($image['path']);
        if ($newReleasePath !== null) @unlink($newReleasePath);
        error_log('System admin action failed: ' . $exception->getMessage());
        adminFlash($exception instanceof InvalidArgumentException ? $exception->getMessage() : '保存失败，请检查数据后重试。', 'error');
        adminRedirect($section);
    }
}

$admin = adminRequireLogin();
$flash = $_SESSION['admin_flash'] ?? null;
unset($_SESSION['admin_flash']);
$csrf = adminCsrf();

if (isset($_GET['qualification_image'])) {
    if (!adminCan('merchants')) { http_response_code(403); exit; }
    $id = (string) $_GET['qualification_image'];
    $q = $pdo->prepare('SELECT owner_user_id,qualification_images FROM merchants WHERE id=?');
    $q->execute([(int) ($_GET['merchant_id'] ?? 0)]);
    $shop = $q->fetch();
    if (!$shop || !in_array($id, json_decode((string) ($shop['qualification_images'] ?? ''), true) ?: [], true)) { http_response_code(404); exit; }
    mallServeQualificationImage($id, (int) $shop['owner_user_id']);
}

if (isset($_GET['export'])) {
    if (!adminCan('export')) { http_response_code(403); exit('无权导出数据'); }
    $exports = [
        'users' => ['users', 'SELECT id,username,email,nickname,spx_id,status,remark,bsc_wallet_address,created_at FROM users ORDER BY id DESC'],
        'wallets' => ['wallets', 'SELECT w.user_id,u.username,w.symbol,w.chain,w.balance,w.stakeable_balance,w.updated_at FROM wallet_assets w JOIN users u ON u.id=w.user_id ORDER BY w.user_id,w.symbol'],
        'recharges' => ['recharges', 'SELECT id,user_id,tx_hash,currency,amount,status,wallet_address,deposit_address,error_message,created_at FROM recharge_records ORDER BY id DESC'],
        'withdrawals' => ['withdrawals', 'SELECT id,user_id,symbol,chain,amount,address,tx_hash,status,created_at FROM wallet_transactions WHERE type="withdraw" ORDER BY id DESC'],
        'transactions' => ['transactions', 'SELECT id,user_id,symbol,chain,type,amount,address,tx_hash,status,created_at FROM wallet_transactions ORDER BY id DESC'],
        'orders' => ['orders', 'SELECT id,user_id,product_id,quantity,total_spx,status,created_at FROM orders ORDER BY id DESC'],
        'tickets' => ['tickets', 'SELECT id,user_id,subject,content,status,admin_reply,created_at,updated_at FROM support_tickets ORDER BY id DESC'],
        'staking' => ['staking-orders', 'SELECT s.id,s.user_id,u.username,u.nickname,u.spx_id,s.phase_id,ph.name AS phase_name,p.name AS plan_name,s.plan_days,s.amount,s.apy,s.status,s.created_at,CAST(ROUND(s.amount*s.apy*s.plan_days/36500,18) AS DECIMAL(36,18)) AS expected_reward,COALESCE((SELECT SUM(d.amount) FROM staking_dividends d WHERE d.staking_id=s.id),0) AS paid_dividend,COALESCE((SELECT reward_amount FROM referral_rewards r WHERE r.staking_id=s.id LIMIT 1),0) AS referral_reward FROM staking_records s JOIN users u ON u.id=s.user_id LEFT JOIN staking_phases ph ON ph.id=s.phase_id LEFT JOIN staking_plans p ON p.plan_days=s.plan_days ORDER BY s.id DESC'],
    ];
    $exportKey = (string) $_GET['export'];
    if (!isset($exports[$exportKey])) { http_response_code(404); exit('导出类型不存在'); }
    $exportSections = ['users' => 'export_finance', 'wallets' => 'export_finance', 'recharges' => 'export_finance', 'withdrawals' => 'export_finance', 'transactions' => 'export_finance', 'orders' => 'export_orders', 'staking' => 'export_finance', 'tickets' => 'export_tickets'];
    if (!adminCan($exportSections[$exportKey])) { http_response_code(403); exit('无权导出此数据'); }
    [$filename, $sql] = $exports[$exportKey];
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="spxchat-' . $filename . '-' . date('Ymd-His') . '.csv"');
    $output = fopen('php://output', 'wb');
    fwrite($output, "\xEF\xBB\xBF");
    $statement = $pdo->query($sql);
    $first = $statement->fetch(PDO::FETCH_ASSOC);
    if ($first) {
        fputcsv($output, array_keys($first));
        do {
            $safeRow = array_map(static function (mixed $value): string {
                $cell = (string) ($value ?? '');
                return preg_match('/^\s*[=+@-]/', $cell) ? "'" . $cell : $cell;
            }, array_values($first));
            fputcsv($output, $safeRow);
        } while ($first = $statement->fetch(PDO::FETCH_ASSOC));
    }
    fclose($output);
    exit;
}

$sections = [
    'dashboard' => '总览', 'users' => '用户管理',
    'recharges' => '充值记录', 'withdrawals' => '提现审核', 'transactions' => '钱包流水',
    'exchanges' => '兑换记录', 'staking' => '质押记录', 'referrals' => '推荐奖励',
    'merchants' => '商家商城', 'products' => '商品管理', 'orders' => '商城订单', 'tickets' => '客服工单',
    'questions' => '用户问题', 'feedback' => '用户反馈', 'faqs' => 'FAQ 管理',
    'groups' => '群组管理', 'reports' => '财务报表', 'email_notifications' => '邮件通知', 'logs' => '操作审计', 'admins' => '管理员', 'settings' => '系统设置',
    'profile' => '账号安全',
];
$section = (string) ($_GET['section'] ?? 'dashboard');
if (!isset($sections[$section])) $section = 'dashboard';
if (!adminCan($section)) {
    adminFlash('当前管理员角色无权访问该模块。', 'error');
    adminRedirect('dashboard');
}
$sections = array_filter($sections, static fn(string $key): bool => adminCan($key), ARRAY_FILTER_USE_KEY);
$data = [];
$search = trim((string) ($_GET['q'] ?? ''));

try {
    if ($section === 'dashboard') {
        $data['stats'] = [
            '用户总数' => (int) $pdo->query('SELECT COUNT(*) FROM users')->fetchColumn(),
            '今日新增用户' => (int) $pdo->query('SELECT COUNT(*) FROM users WHERE created_at >= CURDATE()')->fetchColumn(),
            '停用用户' => (int) $pdo->query('SELECT COUNT(*) FROM users WHERE status=0')->fetchColumn(),
            'USDT 总余额' => (string) $pdo->query('SELECT COALESCE(SUM(balance),0) FROM wallet_assets WHERE symbol="USDT" AND chain="BSC"')->fetchColumn(),
            'SPX001 总余额' => (string) $pdo->query('SELECT COALESCE(SUM(balance),0) FROM wallet_assets WHERE symbol="SPX001" AND chain="BSC"')->fetchColumn(),
            '当前质押期' => (string) ($pdo->query('SELECT COALESCE(MAX(phase_no),0) FROM staking_phases WHERE status=1')->fetchColumn() ?: '未开启'),
            '质押剩余额度' => adminAmount4($pdo->query('SELECT COALESCE((SELECT total_quota-reserved_quota FROM staking_phases WHERE status=1 ORDER BY phase_no DESC LIMIT 1),0)')->fetchColumn() ?: '0'),
            '待验证充值' => (int) $pdo->query("SELECT COUNT(*) FROM recharge_records WHERE status='pending'")->fetchColumn(),
            '待审核提现' => (int) $pdo->query("SELECT COUNT(*) FROM wallet_transactions WHERE type='withdraw' AND status='pending'")->fetchColumn(),
            '待处理工单' => (int) $pdo->query("SELECT COUNT(*) FROM support_tickets WHERE status IN ('open','processing')")->fetchColumn(),
        ];
        $data['recent'] = $pdo->query('SELECT id,username,nickname,spx_id,status,created_at FROM users ORDER BY id DESC LIMIT 8')->fetchAll();
        $heartbeat = $pdo->prepare('SELECT status,checked_at,error_message FROM service_heartbeats WHERE service_name=? LIMIT 1');
        $heartbeat->execute(['bsc_recharge_verifier']);
        $data['heartbeat'] = $heartbeat->fetch() ?: null;
        $trends = $pdo->query('SELECT DATE(created_at) AS day,SUM(CASE WHEN type="deposit" AND symbol="USDT" AND status="completed" THEN amount ELSE 0 END) AS recharge_usdt,SUM(CASE WHEN type="staking" AND symbol="SPX001" AND status="completed" THEN amount ELSE 0 END) AS staking_spx FROM wallet_transactions WHERE created_at>=DATE_SUB(CURDATE(),INTERVAL 29 DAY) AND created_at<DATE_ADD(CURDATE(),INTERVAL 1 DAY) GROUP BY DATE(created_at) ORDER BY day ASC')->fetchAll();
        $trendByDay = [];
        foreach ($trends as $trend) $trendByDay[$trend['day']] = $trend;
        $data['trends'] = [];
        for ($day = 29; $day >= 0; $day--) {
            $date = date('Y-m-d', strtotime('-' . $day . ' days'));
            $data['trends'][] = $trendByDay[$date] ?? ['day' => $date, 'recharge_usdt' => '0', 'staking_spx' => '0'];
        }
    } elseif ($section === 'users') {
        $where = $search !== '' ? ' WHERE username LIKE ? OR nickname LIKE ? OR spx_id LIKE ? OR email LIKE ?' : '';
        $params = $search !== '' ? array_fill(0, 4, '%' . $search . '%') : [];
        $pageData = adminPageQuery($pdo, 'SELECT COUNT(*) FROM users' . $where, 'SELECT id,username,email,nickname,spx_id,bsc_wallet_address,status,remark,created_at FROM users' . $where . ' ORDER BY id DESC', $params);
        $data['rows'] = $pageData['rows']; $data['pagination'] = $pageData['pagination'];
        $detailId = max(0, (int) ($_GET['detail_id'] ?? 0));
        if ($detailId > 0) {
            $detail = $pdo->prepare('SELECT id,username,email,email_verified_at,nickname,spx_id,avatar_url,remark,bsc_wallet_address,status,registration_ip,device_id,device_model,android_version,app_version,created_at FROM users WHERE id=? LIMIT 1');
            $detail->execute([$detailId]);
            $data['user_detail'] = $detail->fetch() ?: null;
            if ($data['user_detail'] && adminCan('wallets')) {
                $assets = $pdo->prepare('SELECT id,symbol,chain,balance,stakeable_balance,updated_at FROM wallet_assets WHERE user_id=? ORDER BY symbol,chain');
                $assets->execute([$detailId]);
                $data['user_assets'] = $assets->fetchAll();
                $activity = $pdo->prepare('SELECT symbol,chain,type,amount,status,tx_hash,created_at FROM wallet_transactions WHERE user_id=? ORDER BY id DESC LIMIT 20');
                $activity->execute([$detailId]);
                $data['user_activity'] = $activity->fetchAll();
            }
        }
    } elseif ($section === 'recharges') {
        $pageData = adminPageQuery($pdo, 'SELECT COUNT(*) FROM recharge_records', 'SELECT r.*,u.username,u.nickname FROM recharge_records r JOIN users u ON u.id=r.user_id ORDER BY r.id DESC');
        $data['rows'] = $pageData['rows']; $data['pagination'] = $pageData['pagination'];
    } elseif ($section === 'withdrawals') {
        $pageData = adminPageQuery($pdo, 'SELECT COUNT(*) FROM wallet_transactions WHERE type="withdraw"', 'SELECT t.*,u.username,u.nickname FROM wallet_transactions t JOIN users u ON u.id=t.user_id WHERE t.type="withdraw" ORDER BY FIELD(t.status,"pending","completed","rejected","cancelled"),t.id DESC');
        $data['rows'] = $pageData['rows']; $data['pagination'] = $pageData['pagination'];
    } elseif ($section === 'transactions') {
        $pageData = adminPageQuery($pdo, 'SELECT COUNT(*) FROM wallet_transactions', 'SELECT t.*,u.username,u.nickname FROM wallet_transactions t JOIN users u ON u.id=t.user_id ORDER BY t.id DESC');
        $data['rows'] = $pageData['rows']; $data['pagination'] = $pageData['pagination'];
    } elseif ($section === 'exchanges') {
        $pageData = adminPageQuery($pdo, 'SELECT COUNT(*) FROM exchange_records', 'SELECT e.*,u.username,u.nickname FROM exchange_records e JOIN users u ON u.id=e.user_id ORDER BY e.id DESC');
        $data['rows'] = $pageData['rows']; $data['pagination'] = $pageData['pagination'];
    } elseif ($section === 'staking') {
        $pageData = adminPageQuery($pdo, 'SELECT COUNT(*) FROM staking_records', 'SELECT s.*,u.username,u.nickname,u.spx_id,ph.name AS phase_name,p.name AS plan_name,COALESCE((SELECT SUM(d.amount) FROM staking_dividends d WHERE d.staking_id=s.id),0) AS paid_dividend,COALESCE((SELECT reward_amount FROM referral_rewards r WHERE r.staking_id=s.id LIMIT 1),0) AS referral_reward FROM staking_records s JOIN users u ON u.id=s.user_id LEFT JOIN staking_phases ph ON ph.id=s.phase_id LEFT JOIN staking_plans p ON p.plan_days=s.plan_days ORDER BY s.id DESC');
        $data['rows'] = $pageData['rows']; $data['pagination'] = $pageData['pagination'];
        $data['staking_stats'] = [
            'active_people' => (int) $pdo->query('SELECT COUNT(DISTINCT user_id) FROM staking_records WHERE status="active"')->fetchColumn(),
            'active_amount' => (string) $pdo->query('SELECT COALESCE(SUM(amount),0) FROM staking_records WHERE status="active"')->fetchColumn(),
            'all_people' => (int) $pdo->query('SELECT COUNT(DISTINCT user_id) FROM staking_records')->fetchColumn(),
            'all_amount' => (string) $pdo->query('SELECT COALESCE(SUM(amount),0) FROM staking_records')->fetchColumn(),
        ];
        $data['plans'] = $pdo->query('SELECT id,name,plan_days,apy,minimum_amount,status FROM staking_plans ORDER BY sort_order,id')->fetchAll();
        $data['phase'] = $pdo->query('SELECT * FROM staking_phases ORDER BY status DESC,phase_no DESC LIMIT 1')->fetch() ?: null;
        if ($data['phase']) {
            $remaining = $pdo->prepare('SELECT CAST(? AS DECIMAL(36,18))-CAST(? AS DECIMAL(36,18))');
            $remaining->execute([$data['phase']['total_quota'], $data['phase']['reserved_quota']]);
            $data['phase']['remaining_quota'] = (string) $remaining->fetchColumn();
        }
        $detailId = max(0, (int) ($_GET['detail_id'] ?? 0));
        if ($detailId > 0) {
            $detail = $pdo->prepare('SELECT s.*,u.username,u.nickname,u.email,u.spx_id,ph.name AS phase_name,p.name AS plan_name,CAST(ROUND(s.amount*s.apy*s.plan_days/36500,18) AS DECIMAL(36,18)) AS expected_reward,COALESCE((SELECT SUM(d.amount) FROM staking_dividends d WHERE d.staking_id=s.id),0) AS paid_dividend,COALESCE((SELECT reward_amount FROM referral_rewards r WHERE r.staking_id=s.id LIMIT 1),0) AS referral_reward FROM staking_records s JOIN users u ON u.id=s.user_id LEFT JOIN staking_phases ph ON ph.id=s.phase_id LEFT JOIN staking_plans p ON p.plan_days=s.plan_days WHERE s.id=? LIMIT 1');
            $detail->execute([$detailId]);
            $data['staking_detail'] = $detail->fetch() ?: null;
            if ($data['staking_detail']) {
                $dividends = $pdo->prepare('SELECT period_no,amount,created_at FROM staking_dividends WHERE staking_id=? ORDER BY period_no');
                $dividends->execute([$detailId]);
                $data['staking_detail_dividends'] = $dividends->fetchAll();
            }
        }
    } elseif ($section === 'referrals') {
        $pageData = adminPageQuery($pdo, 'SELECT COUNT(*) FROM referral_rewards', 'SELECT r.*,owner.username AS referrer_username,owner.nickname AS referrer_nickname,staker.username AS staker_username,staker.nickname AS staker_nickname FROM referral_rewards r JOIN users owner ON owner.id=r.referrer_user_id JOIN users staker ON staker.id=r.staker_user_id ORDER BY r.id DESC');
        $data['rows'] = $pageData['rows']; $data['pagination'] = $pageData['pagination'];
    } elseif ($section === 'reports') {
        $reportFrom = (string) ($_GET['from'] ?? date('Y-m-d', strtotime('-29 days')));
        $reportTo = (string) ($_GET['to'] ?? date('Y-m-d'));
        if (!adminDateIsValid($reportFrom) || !adminDateIsValid($reportTo) || $reportFrom > $reportTo) {
            $reportFrom = date('Y-m-d', strtotime('-29 days'));
            $reportTo = date('Y-m-d');
        }
        $data['report_from'] = $reportFrom;
        $data['report_to'] = $reportTo;
        $dateParams = [$reportFrom . ' 00:00:00', $reportTo . ' 00:00:00'];
        $dailySelect = 'SELECT DATE(created_at) AS day,COUNT(*) AS transaction_count,SUM(CASE WHEN type="deposit" AND symbol="USDT" AND status="completed" THEN amount ELSE 0 END) AS recharge_usdt,SUM(CASE WHEN type="withdraw" AND symbol="USDT" AND status="completed" THEN amount ELSE 0 END) AS withdraw_usdt,SUM(CASE WHEN type="admin_adjustment" AND symbol="USDT" AND amount>0 THEN amount ELSE 0 END) AS admin_credit_usdt,-SUM(CASE WHEN type="admin_adjustment" AND symbol="USDT" AND amount<0 THEN amount ELSE 0 END) AS admin_debit_usdt FROM wallet_transactions WHERE created_at>=? AND created_at<DATE_ADD(?,INTERVAL 1 DAY) GROUP BY DATE(created_at) ORDER BY day DESC';
        $pageData = adminPageQuery($pdo, 'SELECT COUNT(DISTINCT DATE(created_at)) FROM wallet_transactions WHERE created_at>=? AND created_at<DATE_ADD(?,INTERVAL 1 DAY)', $dailySelect, $dateParams);
        $data['rows'] = $pageData['rows']; $data['pagination'] = $pageData['pagination'];
        $totals = $pdo->prepare('SELECT COALESCE(SUM(CASE WHEN type="deposit" AND symbol="USDT" AND status="completed" THEN amount ELSE 0 END),0) AS recharge_usdt,COALESCE(SUM(CASE WHEN type="withdraw" AND symbol="USDT" AND status="completed" THEN amount ELSE 0 END),0) AS withdraw_usdt,COUNT(*) AS transaction_count FROM wallet_transactions WHERE created_at>=? AND created_at<DATE_ADD(?,INTERVAL 1 DAY)');
        $totals->execute([$reportFrom . ' 00:00:00', $reportTo . ' 00:00:00']);
        $data['totals'] = $totals->fetch() ?: [];
    } elseif ($section === 'products') {
        $pageData = adminPageQuery($pdo, 'SELECT COUNT(*) FROM products', 'SELECT * FROM products ORDER BY sort_order ASC,id DESC');
        $data['rows'] = $pageData['rows']; $data['pagination'] = $pageData['pagination'];
        $editId = max(0, (int) ($_GET['edit'] ?? 0));
        if ($editId > 0) {
            $edit = $pdo->prepare('SELECT * FROM products WHERE id=?');
            $edit->execute([$editId]);
            $data['edit'] = $edit->fetch() ?: null;
            if ($data['edit']) {
                $images = $pdo->prepare('SELECT id,image_url,sort_order FROM product_images WHERE product_id=? ORDER BY sort_order,id');
                $images->execute([$editId]);
                $data['edit_images'] = $images->fetchAll();
            }
        }
    } elseif ($section === 'orders') {
        $pageData = adminPageQuery($pdo, 'SELECT COUNT(*) FROM orders', 'SELECT o.*,u.username,u.nickname,p.name AS product_name,p.image_url FROM orders o JOIN users u ON u.id=o.user_id JOIN products p ON p.id=o.product_id ORDER BY o.id DESC');
        $data['rows'] = $pageData['rows']; $data['pagination'] = $pageData['pagination'];
    } elseif ($section === 'tickets') {
        $pageData = adminPageQuery($pdo, 'SELECT COUNT(*) FROM support_tickets', 'SELECT t.*,u.username,u.nickname FROM support_tickets t JOIN users u ON u.id=t.user_id ORDER BY FIELD(t.status,"open","processing","resolved","closed"),t.id DESC');
        $data['rows'] = $pageData['rows']; $data['pagination'] = $pageData['pagination'];
    } elseif ($section === 'questions') {
        $pageData = adminPageQuery($pdo, 'SELECT COUNT(*) FROM user_questions', 'SELECT q.*,u.username,u.nickname FROM user_questions q JOIN users u ON u.id=q.user_id ORDER BY FIELD(q.status,"pending","answered","closed"),q.id DESC');
        $data['rows'] = $pageData['rows']; $data['pagination'] = $pageData['pagination'];
    } elseif ($section === 'feedback') {
        $pageData = adminPageQuery($pdo, 'SELECT COUNT(*) FROM feedback', 'SELECT f.*,u.username,u.nickname FROM feedback f JOIN users u ON u.id=f.user_id ORDER BY FIELD(f.status,"pending","reviewed","resolved"),f.id DESC');
        $data['rows'] = $pageData['rows']; $data['pagination'] = $pageData['pagination'];
    } elseif ($section === 'faqs') {
        $pageData = adminPageQuery($pdo, 'SELECT COUNT(*) FROM faq_items', 'SELECT * FROM faq_items ORDER BY sort_order,id DESC');
        $data['rows'] = $pageData['rows']; $data['pagination'] = $pageData['pagination'];
        $faqId = max(0, (int) ($_GET['faq_id'] ?? 0));
        if ($faqId > 0) {
            $editFaq = $pdo->prepare('SELECT * FROM faq_items WHERE id=?');
            $editFaq->execute([$faqId]);
            $data['edit_faq'] = $editFaq->fetch() ?: null;
        }
    } elseif ($section === 'groups') {
        $pageData = adminPageQuery($pdo, 'SELECT COUNT(*) FROM chat_groups', 'SELECT g.id,g.group_code,g.name,g.announcement,g.created_at,COUNT(gm.id) AS member_count FROM chat_groups g LEFT JOIN chat_group_members gm ON gm.group_id=g.id GROUP BY g.id,g.group_code,g.name,g.announcement,g.created_at ORDER BY g.id DESC');
        $data['rows'] = $pageData['rows']; $data['pagination'] = $pageData['pagination'];
        $groupId = max(0, (int) ($_GET['group_id'] ?? 0));
        if ($groupId > 0) {
            $groupQuery = $pdo->prepare('SELECT id,group_code,name FROM chat_groups WHERE id=?');
            $groupQuery->execute([$groupId]);
            $data['selected_group'] = $groupQuery->fetch() ?: null;
            if ($data['selected_group']) {
                $memberPage = adminPageQuery($pdo, 'SELECT COUNT(*) FROM chat_group_members WHERE group_id=?', 'SELECT gm.user_id,gm.role,gm.mute,gm.joined_at,u.username,u.nickname,u.spx_id FROM chat_group_members gm JOIN users u ON u.id=gm.user_id WHERE gm.group_id=? ORDER BY FIELD(gm.role,"owner","admin","member"),gm.joined_at ASC', [$groupId], 'member_page');
                $data['members'] = $memberPage['rows'];
                $data['member_pagination'] = $memberPage['pagination'];
            }
        }
    } elseif ($section === 'logs') {
        $pageData = adminPageQuery($pdo, 'SELECT COUNT(*) FROM admin_audit_logs', 'SELECT * FROM admin_audit_logs ORDER BY id DESC');
        $data['rows'] = $pageData['rows']; $data['pagination'] = $pageData['pagination'];
    } elseif ($section === 'admins') {
        $pageData = adminPageQuery($pdo, 'SELECT COUNT(*) FROM admin_users', 'SELECT id,username,role,status,last_login_at,created_at FROM admin_users ORDER BY id ASC');
        $data['rows'] = $pageData['rows']; $data['pagination'] = $pageData['pagination'];
    } elseif ($section === 'email_notifications') {
        $data['email_templates'] = $pdo->query('SELECT id,event_key,name,subject,body_html,status,updated_at FROM email_notification_templates ORDER BY id')->fetchAll();
        $data['email_recipients'] = $pdo->query('SELECT id,email,status,created_at FROM email_notification_recipients ORDER BY id')->fetchAll();
        $data['email_subscriptions'] = [];
        foreach ($pdo->query('SELECT recipient_id,template_id FROM email_notification_subscriptions')->fetchAll() as $subscription) {
            $data['email_subscriptions'][(int) $subscription['recipient_id']][] = (int) $subscription['template_id'];
        }
        $data['email_logs'] = $pdo->query('SELECT event_key,recipient_email,subject,status,error_message,created_at FROM email_notification_logs ORDER BY id DESC LIMIT 50')->fetchAll();
    } elseif ($section === 'settings') {
        $setting = $pdo->prepare('SELECT `value` FROM app_settings WHERE `key`=? LIMIT 1');
        $setting->execute(['bsc_usdt_deposit_address']);
        $data['deposit_address'] = (string) ($setting->fetchColumn() ?: '');
        $setting->execute(['invite_base_url']);
        $data['invite_base_url'] = (string) ($setting->fetchColumn() ?: 'http://spx001.top');
        $data['releases'] = $pdo->query('SELECT id,version_code,version_name,release_notes,apk_size,apk_sha256,download_count,is_active,created_at FROM app_releases ORDER BY version_code DESC LIMIT 20')->fetchAll();
    }
} catch (Throwable $exception) {
    error_log('System admin page query failed: ' . $exception->getMessage());
    $data['load_error'] = '数据读取失败，请检查数据库结构及账号权限。';
}

function adminHidden(string $csrf, string $action, string $section): string
{
    return '<input type="hidden" name="csrf" value="' . adminEscape($csrf) . '"><input type="hidden" name="action" value="' . adminEscape($action) . '"><input type="hidden" name="section" value="' . adminEscape($section) . '">';
}

function adminTableEmpty(int $columns): string
{
    return '<tr><td colspan="' . $columns . '" class="empty">暂无记录</td></tr>';
}

function adminPageQuery(PDO $pdo, string $countSql, string $rowsSql, array $params = [], string $pageParam = 'page'): array
{
    $count = $pdo->prepare($countSql);
    $count->execute($params);
    $total = (int) $count->fetchColumn();
    $perPage = 30;
    $pages = max(1, (int) ceil($total / $perPage));
    $page = min($pages, max(1, (int) ($_GET[$pageParam] ?? 1)));
    $offset = ($page - 1) * $perPage;
    $rows = $pdo->prepare($rowsSql . ' LIMIT ' . $offset . ',' . $perPage);
    $rows->execute($params);
    return ['rows' => $rows->fetchAll(), 'pagination' => ['page' => $page, 'pages' => $pages, 'total' => $total]];
}

?>
<!doctype html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= adminEscape($sections[$section]) ?> · SPX Chat 管理后台</title>
    <style>
        :root{font-family:Inter,-apple-system,BlinkMacSystemFont,"Segoe UI","Microsoft YaHei",sans-serif;color:#17211e;background:#f3f6f4;font-synthesis:none;text-rendering:optimizeLegibility}
        *{box-sizing:border-box}body{margin:0;font-size:14px}a{color:inherit;text-decoration:none}button,input,textarea,select{font:inherit}
        .shell{min-height:100vh;display:grid;grid-template-columns:224px minmax(0,1fr)}.sidebar{background:#14251e;color:#e6f0ea;padding:22px 14px;display:flex;flex-direction:column;gap:24px}
        .brand{padding:0 12px;font-size:13px;font-weight:750;letter-spacing:.04em}.brand small{display:block;color:#91ab9d;font-weight:500;margin-top:6px;letter-spacing:0}
        .nav{display:grid;gap:4px}.nav a{padding:10px 12px;border-radius:5px;color:#b8c9bf}.nav a:hover,.nav a.active{background:#244334;color:#fff}.side-bottom{margin-top:auto;border-top:1px solid #2a4035;padding:16px 12px 0;color:#9cb1a5;font-size:12px;line-height:1.7}
        .main{min-width:0}.topbar{height:64px;background:#fff;border-bottom:1px solid #dce5e0;display:flex;align-items:center;justify-content:space-between;padding:0 28px;position:sticky;top:0;z-index:2}.topbar h1{font-size:18px;margin:0}.admin-controls{display:flex;align-items:center;gap:14px;color:#54645b}.admin-controls form{margin:0}
        .content{max-width:1440px;margin:0 auto;padding:26px 28px 48px}.flash{padding:12px 14px;border-radius:5px;margin-bottom:18px;background:#e8f5ed;color:#17663f}.flash.error{background:#fff0ee;color:#9b352a}.load-error{padding:12px 14px;background:#fff5db;color:#765713;border-radius:5px;margin-bottom:18px}
        .stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px;margin-bottom:28px}.stat{background:#fff;border:1px solid #dce5e0;border-radius:6px;padding:17px 18px}.stat-label{color:#708078;font-size:12px}.stat-value{font-size:25px;font-weight:700;margin-top:9px;color:#17211e}
        .section-head{display:flex;align-items:center;justify-content:space-between;gap:12px;margin:0 0 14px}.section-head h2{margin:0;font-size:16px}.panel{background:#fff;border:1px solid #dce5e0;border-radius:6px;margin-bottom:22px;overflow:hidden}.panel-head{padding:15px 17px;border-bottom:1px solid #e5ebe7;display:flex;align-items:center;justify-content:space-between;gap:12px}.panel-head h2{font-size:15px;margin:0}.panel-body{padding:18px}
        .table-wrap{overflow:auto}table{width:100%;border-collapse:collapse;white-space:nowrap}th,td{text-align:left;padding:11px 13px;border-bottom:1px solid #edf1ee;vertical-align:top}th{font-size:11px;text-transform:uppercase;color:#738078;background:#f8faf9;font-weight:700}td{font-size:13px}tr:last-child td{border-bottom:0}.empty{text-align:center;color:#85928b;padding:30px}.mono{font-family:ui-monospace,SFMono-Regular,Consolas,monospace;font-size:12px}.muted{color:#738078}.sub{display:block;color:#87948d;font-size:11px;margin-top:3px}.status{display:inline-block;padding:4px 8px;border-radius:4px;background:#edf2ef;color:#52635a;font-size:11px}.status.pending,.status.open,.status.processing,.status.warning{background:#fff3d9;color:#875e0b}.status.completed,.status.resolved,.status.active,.status.ok{background:#e7f5ec;color:#17663f}.status.failed,.status.rejected,.status.closed,.status.inactive,.status.error,.status.stale{background:#fcebea;color:#9b352a}
        .toolbar{display:flex;gap:8px;align-items:center}.toolbar input,.field input,.field textarea,.field select{border:1px solid #ccd8d1;border-radius:5px;padding:9px 11px;background:#fff;color:#17211e;min-width:0}.toolbar input{width:min(280px,55vw)}.field{display:grid;gap:7px;margin-bottom:15px}.field label{font-size:12px;font-weight:650;color:#4d5c54}.field input,.field select{height:40px;width:100%}.field textarea{width:100%;min-height:105px;resize:vertical;line-height:1.5}.form-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:0 14px}.span-2{grid-column:1/-1}
        .detail-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:18px 24px}.detail-grid>div{display:grid;gap:5px;min-width:0}.detail-grid strong{font-weight:600;overflow-wrap:anywhere}.detail-heading{margin-top:22px}.trend-grid-layout{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px;margin-bottom:24px}.trend-panel{background:#fff;border:1px solid #dce5e0;border-radius:6px;padding:16px 18px;min-width:0}.trend-title{display:flex;justify-content:space-between;gap:12px;align-items:baseline;font-weight:650}.trend-title strong{font-size:14px}.trend-svg{display:block;width:100%;height:auto;margin-top:14px;overflow:visible}.trend-grid{fill:none;stroke:#e9efeb;stroke-width:1}.trend-foot{display:flex;justify-content:space-between;color:#748179;font-size:11px}.image-list{display:flex;flex-wrap:wrap;gap:10px}.image-item{display:grid;gap:5px;width:100px}.image-item img,.image-preview img{width:100%;aspect-ratio:1;object-fit:cover;border:1px solid #dce5e0;border-radius:4px}.image-preview{display:flex;gap:8px;flex-wrap:wrap}.image-preview img{width:76px}
        .pagination{display:flex;align-items:center;justify-content:flex-end;gap:6px;margin:12px 0 24px;color:#68776f;font-size:12px}.pagination a,.pagination span{min-width:34px;height:32px;padding:0 9px;border:1px solid #d5dfd9;border-radius:4px;display:inline-flex;align-items:center;justify-content:center;background:#fff}.pagination .current{background:#177b4d;border-color:#177b4d;color:#fff}.pagination .page-info{border:0;background:transparent}
        .modal-overlay{position:fixed;inset:0;z-index:20;background:rgba(18,31,25,.52);display:flex;align-items:center;justify-content:center;padding:24px}.modal-dialog{width:min(1120px,100%);max-height:calc(100vh - 48px);overflow:auto;background:#f3f6f4;border-radius:8px;box-shadow:0 20px 70px rgba(0,0,0,.28)}.modal-dialog .panel{margin:0;border:0;border-radius:8px}.modal-dialog .panel-head{position:sticky;top:0;background:#fff;z-index:1}.modal-close{font-size:24px;line-height:1;width:36px;height:36px;display:grid;place-items:center;border:1px solid #dce5e0;border-radius:4px;background:#fff}.trend-marker{stroke:#fff;stroke-width:2;cursor:crosshair;transition:r .12s}.trend-marker:hover{r:8}
        .trend-panel{position:relative}.trend-tooltip{display:none;position:absolute;z-index:4;max-width:calc(100% - 16px);padding:8px 10px;border-radius:4px;background:#17211e;color:#fff;font-size:12px;font-weight:600;line-height:1.4;box-shadow:0 4px 14px rgba(0,0,0,.2);pointer-events:none;white-space:nowrap}.trend-tooltip.visible{display:block}.trend-marker:focus{outline:none;stroke:#17211e;stroke-width:3;r:8}
        .btn{display:inline-flex;align-items:center;justify-content:center;min-height:35px;border:1px solid #ccd8d1;border-radius:5px;padding:0 12px;background:#fff;color:#27362e;font-weight:600;font-size:12px;cursor:pointer}.btn:hover{background:#f3f7f4}.btn.primary{border-color:#177b4d;background:#177b4d;color:#fff}.btn.primary:hover{background:#11663e}.btn.danger{color:#9b352a;border-color:#e8c7c3}.inline{display:inline}.inline-form{display:flex;gap:8px;align-items:center}.inline-form textarea{width:250px;min-height:56px}.ticket-content{white-space:normal;min-width:220px;max-width:380px;line-height:1.55}.address-box{overflow-wrap:anywhere}.actions{display:flex;gap:7px;align-items:center}.search-form{display:flex;gap:8px}
        @media(max-width:900px){.shell{grid-template-columns:184px minmax(0,1fr)}.content{padding:20px 18px 36px}.stats{grid-template-columns:repeat(2,minmax(0,1fr))}}
        @media(max-width:640px){.shell{display:block}.sidebar{padding:12px;gap:10px}.brand{padding:4px 8px}.brand small{display:inline;margin-left:7px}.nav{display:flex;overflow:auto;gap:4px}.nav a{white-space:nowrap;padding:8px 10px}.side-bottom{display:none}.topbar{height:54px;padding:0 14px}.topbar h1{font-size:16px}.admin-controls{gap:8px;font-size:12px}.content{padding:16px 12px 32px}.stats{gap:8px}.stat{padding:13px}.stat-value{font-size:21px}.panel-body{padding:13px}.form-grid{grid-template-columns:1fr}.span-2{grid-column:auto}.section-head{align-items:flex-start;flex-direction:column}.search-form{width:100%}.search-form input{flex:1;min-width:0}.detail-grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}.trend-grid-layout{grid-template-columns:1fr}.inline-form{flex-wrap:wrap}.modal-overlay{padding:8px;align-items:flex-end}.modal-dialog{max-height:calc(100vh - 16px);border-radius:8px 8px 0 0}}
    </style>
    <link rel="stylesheet" href="ui-premium.css?v=147">
</head>
<body>
<div class="shell">
    <aside class="sidebar">
        <div class="brand">SPX CHAT <small>系统管理</small></div>
        <nav class="nav" aria-label="后台导航">
            <?php foreach ($sections as $key => $label): ?>
                <a class="<?= $section === $key ? 'active' : '' ?>" href="admin.php?section=<?= adminEscape($key) ?>"><?= adminEscape($label) ?></a>
            <?php endforeach; ?>
        </nav>
        <div class="side-bottom">数据库直连管理<br>操作账号：<?= adminEscape($admin['username']) ?></div>
    </aside>
    <main class="main">
        <header class="topbar">
            <h1><?= adminEscape($sections[$section]) ?></h1>
            <div class="admin-controls">
                <span><?= adminEscape($admin['username']) ?></span>
                <form method="post" action="logout.php"><input type="hidden" name="csrf" value="<?= adminEscape($csrf) ?>"><button class="btn" type="submit">退出</button></form>
            </div>
        </header>
        <div class="content">
            <?php if (is_array($flash)): ?><div class="flash <?= ($flash['type'] ?? '') === 'error' ? 'error' : '' ?>"><?= adminEscape($flash['message'] ?? '') ?></div><?php endif; ?>
            <?php if (!empty($data['load_error'])): ?><div class="load-error"><?= adminEscape($data['load_error']) ?></div><?php endif; ?>

            <?php if ($section === 'dashboard'): ?>
                <div class="stats">
                    <?php foreach (($data['stats'] ?? []) as $label => $value): ?>
                        <div class="stat"><div class="stat-label"><?= adminEscape($label) ?></div><div class="stat-value"><?= adminEscape(str_ends_with((string) $label, '总余额') || $label === '质押剩余额度' ? adminAmount4($value) : $value) ?></div></div>
                    <?php endforeach; ?>
                </div>
                <div class="trend-grid-layout">
                    <section class="trend-panel"><div class="trend-title"><strong>USDT 充值到账</strong><span class="muted">近 30 日每日到账</span></div><?= adminTrendSvg($data['trends'] ?? [], 'recharge_usdt', '#177b4d') ?><div class="trend-tooltip" role="status" aria-live="polite"></div><div class="trend-foot"><span><?= adminEscape($data['trends'][0]['day'] ?? '') ?></span><span><?= adminEscape($data['trends'][29]['day'] ?? '') ?></span></div></section>
                    <section class="trend-panel"><div class="trend-title"><strong>SPX001 质押</strong><span class="muted">近 30 日每日质押</span></div><?= adminTrendSvg($data['trends'] ?? [], 'staking_spx', '#c06a28') ?><div class="trend-tooltip" role="status" aria-live="polite"></div><div class="trend-foot"><span><?= adminEscape($data['trends'][0]['day'] ?? '') ?></span><span><?= adminEscape($data['trends'][29]['day'] ?? '') ?></span></div></section>
                </div>
                <?php $heartbeat = $data['heartbeat'] ?? null; $heartbeatFresh = $heartbeat && strtotime((string) $heartbeat['checked_at']) >= time() - 120; $heartbeatStatus = !$heartbeatFresh ? 'stale' : (string) $heartbeat['status']; ?>
                <section class="panel"><div class="panel-head"><h2>BSC 充值验证器</h2><span class="status <?= adminEscape($heartbeatStatus) ?>"><?= !$heartbeat ? '尚无运行记录' : (!$heartbeatFresh ? '心跳超时' : (($heartbeatStatus === 'ok') ? '运行正常' : (($heartbeatStatus === 'warning') ? '有待检查错误' : '异常'))) ?></span></div><div class="panel-body"><span class="muted">最近心跳：<?= adminEscape($heartbeat['checked_at'] ?? '—') ?></span><?php if (!empty($heartbeat['error_message'])): ?><div class="load-error" style="margin:12px 0 0"><?= adminEscape($heartbeat['error_message']) ?></div><?php endif; ?></div></section>
                <section class="panel">
                    <div class="panel-head"><h2>最近注册用户</h2><a class="btn" href="admin.php?section=users">查看用户</a></div>
                    <div class="table-wrap"><table><thead><tr><th>ID</th><th>账号</th><th>昵称</th><th>SPX ID</th><th>状态</th><th>注册时间</th></tr></thead><tbody>
                        <?php foreach (($data['recent'] ?? []) as $row): ?><tr><td><?= (int) $row['id'] ?></td><td><?= adminEscape($row['username']) ?></td><td><?= adminEscape($row['nickname']) ?></td><td><?= adminEscape($row['spx_id']) ?></td><td><span class="status <?= (int) $row['status'] === 1 ? 'active' : 'inactive' ?>"><?= (int) $row['status'] === 1 ? '正常' : '停用' ?></span></td><td><?= adminEscape($row['created_at']) ?></td></tr><?php endforeach; ?>
                        <?= empty($data['recent']) ? adminTableEmpty(6) : '' ?>
                    </tbody></table></div>
                </section>
            <?php elseif ($section === 'users'): ?>
                <div class="section-head"><h2>用户列表 <span class="muted">每页 30 条</span></h2><form class="search-form" method="get"><input type="hidden" name="section" value="users"><input name="q" value="<?= adminEscape($search) ?>" placeholder="账号、昵称、SPX ID 或邮箱"><button class="btn primary">搜索</button></form></div>
                <?php if (!empty($data['user_detail'])): $detail = $data['user_detail']; ?>
                    <div class="modal-overlay" id="user-detail-modal" role="dialog" aria-modal="true" aria-labelledby="user-detail-title"><div class="modal-dialog"><section class="panel"><div class="panel-head"><h2 id="user-detail-title">用户详情 · #<?= (int) $detail['id'] ?> <?= adminEscape($detail['username']) ?></h2><a class="modal-close" href="admin.php?section=users" aria-label="关闭用户详情">×</a></div><div class="panel-body">
                        <div class="detail-grid">
                            <div><span class="muted">昵称</span><strong><?= adminEscape($detail['nickname']) ?></strong></div><div><span class="muted">SPX ID</span><strong><?= adminEscape($detail['spx_id']) ?></strong></div>
                            <div><span class="muted">邮箱</span><strong><?= adminEscape($detail['email'] ?: '未绑定') ?></strong></div><div><span class="muted">邮箱验证</span><strong><?= adminEscape($detail['email_verified_at'] ?: '未验证') ?></strong></div>
                            <div><span class="muted">绑定 BSC 钱包</span><strong class="mono address-box"><?= adminEscape($detail['bsc_wallet_address'] ?: '未绑定') ?></strong></div><div><span class="muted">账号状态</span><strong><?= (int) $detail['status'] === 1 ? '正常' : '已停用' ?></strong></div>
                            <div><span class="muted">注册时间</span><strong><?= adminEscape($detail['created_at']) ?></strong></div><div><span class="muted">注册 IP</span><strong><?= adminEscape($detail['registration_ip'] ?: '—') ?></strong></div>
                            <div><span class="muted">设备</span><strong><?= adminEscape($detail['device_model'] ?: '—') ?></strong></div><div><span class="muted">Android 版本</span><strong><?= adminEscape($detail['android_version'] ?: '—') ?></strong></div>
                            <div><span class="muted">设备编号</span><strong class="mono"><?= adminEscape($detail['device_id'] ?: '—') ?></strong></div><div><span class="muted">应用版本</span><strong><?= adminEscape($detail['app_version'] ?: '—') ?></strong></div>
                        </div>
                        <?php if (adminCan('user_control')): ?><div class="actions detail-heading"><form method="post" class="inline-form"><?= adminHidden($csrf, 'user.save', 'users') ?><input type="hidden" name="user_id" value="<?= (int) $detail['id'] ?>"><select name="status"><option value="1" <?= (int) $detail['status'] === 1 ? 'selected' : '' ?>>启用</option><option value="0" <?= (int) $detail['status'] === 0 ? 'selected' : '' ?>>停用</option></select><input name="remark" maxlength="100" placeholder="用户备注" value="<?= adminEscape($detail['remark'] ?? '') ?>"><input name="reason" maxlength="500" placeholder="状态/备注操作原因" required><button class="btn primary">保存用户</button></form><form method="post" class="inline-form"><?= adminHidden($csrf, 'user.password.reset', 'users') ?><input type="hidden" name="user_id" value="<?= (int) $detail['id'] ?>"><input name="new_password" type="password" minlength="12" maxlength="200" placeholder="新密码至少 12 位" required><input name="reason" maxlength="500" placeholder="密码重置原因" required><button class="btn">重置密码</button></form></div><?php endif; ?>
                        <?php if (adminCan('wallet_address_control')): ?><div class="actions detail-heading"><form method="post" class="inline-form"><?= adminHidden($csrf, 'user.wallet.update', 'users') ?><input type="hidden" name="request_id" value="<?= bin2hex(random_bytes(16)) ?>"><input type="hidden" name="user_id" value="<?= (int) $detail['id'] ?>"><input name="wallet_address" maxlength="42" pattern="0x[0-9a-fA-F]{40}" placeholder="新的 BSC 钱包地址" value="<?= adminEscape($detail['bsc_wallet_address'] ?? '') ?>" required><input name="reason" maxlength="500" placeholder="修改钱包地址原因" required><button class="btn primary">修改绑定钱包</button></form></div><?php endif; ?>
                        <?php if (adminCan('wallets')): ?>
                            <div class="section-head detail-heading"><h2>钱包资产</h2></div>
                            <div class="table-wrap"><table><thead><tr><th>资产</th><th>当前余额</th><th>可质押余额</th><th>更新时间</th><th>余额操作</th></tr></thead><tbody>
                                <?php foreach (($data['user_assets'] ?? []) as $asset): ?><tr><td><?= adminEscape($asset['symbol']) ?> / <?= adminEscape($asset['chain']) ?></td><td class="mono"><?= ($asset['symbol']==='SPX001'?mallAdminMoney($asset['balance']):adminAmount4($asset['balance'])) ?></td><td class="mono"><?= adminEscape($asset['symbol']) === 'SPX001' ? adminAmount4($asset['stakeable_balance'] ?? '0') : '—' ?></td><td><?= adminEscape($asset['updated_at']) ?></td><td><form method="post" class="inline-form"><?= adminHidden($csrf, 'wallet.adjust', 'users') ?><input type="hidden" name="request_id" value="<?= bin2hex(random_bytes(16)) ?>"><input type="hidden" name="user_id" value="<?= (int) $detail['id'] ?>"><input type="hidden" name="symbol" value="<?= adminEscape($asset['symbol']) ?>"><select name="operation"><option value="add">增加</option><option value="subtract">扣减</option><option value="set">设置为</option></select><input name="amount" inputmode="decimal" placeholder="金额 / 目标余额" required><input name="reason" maxlength="500" placeholder="必填：调整原因" required><button class="btn primary">提交</button></form></td></tr><?php endforeach; ?>
                                <?= empty($data['user_assets']) ? adminTableEmpty(5) : '' ?>
                            </tbody></table></div>
                            <div class="section-head detail-heading"><h2>最近钱包流水</h2></div>
                            <div class="table-wrap"><table><thead><tr><th>类型</th><th>资产</th><th>金额</th><th>状态</th><th>哈希</th><th>时间</th></tr></thead><tbody>
                                 <?php foreach (($data['user_activity'] ?? []) as $activity): ?><tr><td><?= adminEscape(adminTransactionLabel((string) $activity['type'])) ?></td><td><?= adminEscape($activity['symbol']) ?> / <?= adminEscape($activity['chain']) ?></td><td><?= ($activity['symbol']==='SPX001'?mallAdminMoney($activity['amount']):adminAmount4($activity['amount'])) ?></td><td><?= adminEscape(adminStatusLabel((string) $activity['status'])) ?></td><td class="mono"><?= adminEscape($activity['tx_hash'] ?: '无') ?></td><td><?= adminEscape($activity['created_at']) ?></td></tr><?php endforeach; ?>
                                <?= empty($data['user_activity']) ? adminTableEmpty(6) : '' ?>
                            </tbody></table></div>
                        <?php endif; ?>
                    </div></section></div></div>
                <?php elseif (isset($_GET['detail_id'])): ?>
                    <div class="load-error">用户不存在。</div>
                <?php endif; ?>
                <section class="panel"><div class="table-wrap"><table><thead><tr><th>ID / 账号</th><th>SPX ID / 邮箱</th><th>绑定 BSC 钱包</th><th>状态</th><th>注册时间</th><th>管理</th></tr></thead><tbody>
                    <?php foreach (($data['rows'] ?? []) as $row): ?>
                        <tr>
                            <td><a href="admin.php?section=users&amp;detail_id=<?= (int) $row['id'] ?>">#<?= (int) $row['id'] ?> · <?= adminEscape($row['username']) ?></a><span class="sub"><?= adminEscape($row['nickname']) ?><?= $row['remark'] ? ' · ' . adminEscape($row['remark']) : '' ?></span></td>
                            <td><?= adminEscape($row['spx_id']) ?><span class="sub"><?= adminEscape($row['email'] ?: '无邮箱') ?></span></td>
                            <td class="mono"><?= adminEscape($row['bsc_wallet_address'] ?: '未绑定') ?></td>
                            <td><span class="status <?= (int) $row['status'] === 1 ? 'active' : 'inactive' ?>"><?= (int) $row['status'] === 1 ? '正常' : '停用' ?></span></td>
                            <td><?= adminEscape($row['created_at']) ?></td>
                            <td><a class="btn" href="admin.php?section=users&amp;detail_id=<?= (int) $row['id'] ?>">查看详情</a></td>
                        </tr>
                    <?php endforeach; ?>
                    <?= empty($data['rows']) ? adminTableEmpty(6) : '' ?>
                </tbody></table></div></section>
            <?php elseif ($section === 'recharges'): ?>
                <div class="section-head"><h2>充值记录 <span class="muted">失败充值可核实链上到账后人工补记</span></h2></div>
                <section class="panel"><div class="table-wrap"><table><thead><tr><th>用户</th><th>币种 / 金额</th><th>状态</th><th>交易哈希</th><th>用户钱包</th><th>收款地址</th><th>提交时间</th><th>失败原因 / 处理</th></tr></thead><tbody>
                    <?php foreach (($data['rows'] ?? []) as $row): ?><tr><td><?= adminEscape($row['username']) ?><span class="sub"><?= adminEscape($row['nickname']) ?></span></td><td><?= adminEscape($row['currency']) ?><span class="sub"><?= adminAmount4($row['amount']) ?></span></td><td><span class="status <?= adminEscape($row['status']) ?>"><?= adminEscape(adminStatusLabel((string) $row['status'])) ?></span></td><td class="mono"><?= adminEscape($row['tx_hash'] ?: '无') ?></td><td class="mono"><?= adminEscape($row['wallet_address'] ?: '无') ?></td><td class="mono"><?= adminEscape($row['deposit_address'] ?: '无') ?></td><td><?= adminEscape($row['created_at']) ?></td><td><?= adminEscape($row['error_message'] ?: '无') ?><?php if ($row['status'] === 'failed' && strtoupper((string) $row['currency']) === 'USDT' && adminCan('recharges')): ?><form method="post" class="inline-form" onsubmit="return confirm('请先确认区块链浏览器显示该交易已成功并到达平台收款地址。确定后将立即给用户 USDT 余额入账，且不可重复操作。')"><?= adminHidden($csrf, 'recharge.manual.complete', 'recharges') ?><input type="hidden" name="record_id" value="<?= (int) $row['id'] ?>"><input type="hidden" name="request_id" value="<?= bin2hex(random_bytes(16)) ?>"><input name="reason" maxlength="500" placeholder="链上核验依据 / 处理原因" required><button class="btn primary">核验后补记到账</button></form><?php endif; ?><?php if (adminCan('wallets')): ?><form method="post" class="inline-form"><?= adminHidden($csrf, 'wallet.status.update', 'recharges') ?><input type="hidden" name="record_type" value="recharge"><input type="hidden" name="record_id" value="<?= (int) $row['id'] ?>"><select name="status"><option value="pending" <?= $row['status'] === 'pending' ? 'selected' : '' ?>>待处理</option><option value="completed" <?= $row['status'] === 'completed' ? 'selected' : '' ?>>已完成</option><option value="failed" <?= $row['status'] === 'failed' ? 'selected' : '' ?>>失败</option><option value="rejected" <?= $row['status'] === 'rejected' ? 'selected' : '' ?>>已拒绝</option><option value="cancelled" <?= $row['status'] === 'cancelled' ? 'selected' : '' ?>>已取消</option></select><input name="reason" maxlength="500" placeholder="仅改状态原因" required><button class="btn">仅改状态</button></form><?php endif; ?></td></tr><?php endforeach; ?>
                    <?= empty($data['rows']) ? adminTableEmpty(8) : '' ?>
                </tbody></table></div></section>
            <?php elseif ($section === 'withdrawals'): ?>
                <div class="section-head"><h2>提现审核 <span class="muted">通过后由 Python 提现服务自动打币；拒绝时退回全部冻结金额</span></h2></div>
                <?php if (adminCan('withdrawals')): ?><section class="panel"><div class="panel-body"><form id="batch-withdraw-approve" method="post" class="inline-form" onsubmit="return confirm('确认批量通过已勾选的提现提现吗？自动打币服务会逐笔发送链上转账。')"><?= adminHidden($csrf, 'withdraw.batch_approve', 'withdrawals') ?><input name="reason" maxlength="500" placeholder="批量审核原因" required><button class="btn primary">批量通过并自动打币</button></form></div></section><?php endif; ?>
                <section class="panel"><div class="table-wrap"><table><thead><tr><th><?php if (adminCan('withdrawals')): ?><input id="withdraw-select-all" type="checkbox" title="全选待处理提现"><?php endif; ?></th><th>用户</th><th>资产 / 金额</th><th>提现地址</th><th>状态</th><th>申请时间</th><th>审核操作</th></tr></thead><tbody>
                     <?php foreach (($data['rows'] ?? []) as $row): ?><tr><td><?php if ($row['status'] === 'pending' && adminCan('withdrawals')): ?><input class="withdraw-select" form="batch-withdraw-approve" type="checkbox" name="transaction_ids[]" value="<?= (int) $row['id'] ?>"><?php endif; ?></td><td>#<?= (int) $row['user_id'] ?> · <?= adminEscape($row['username']) ?><span class="sub"><?= adminEscape($row['nickname']) ?></span></td><td><?= adminEscape($row['symbol']) ?> / <?= adminEscape($row['chain']) ?><span class="sub">实际到账 <?= adminAmount4($row['amount']) ?><?php if (isset($row['fee_amount'])): ?> · 手续费 <?= adminAmount4($row['fee_amount']) ?><?php endif; ?></span></td><td class="mono"><?= adminEscape($row['address'] ?: '无') ?></td><td><span class="status <?= adminEscape($row['status']) ?>"><?= adminEscape(adminStatusLabel((string) $row['status'])) ?></span><span class="sub"><?= adminEscape($row['tx_hash'] ?: '无') ?></span><?php if (!empty($row['error_message'])): ?><span class="sub">失败原因：<?= adminEscape($row['error_message']) ?></span><?php endif; ?></td><td><?= adminEscape($row['created_at']) ?></td><td><?php if ($row['status'] === 'pending'): ?><form method="post" class="inline-form"><?= adminHidden($csrf, 'withdraw.process', 'withdrawals') ?><input type="hidden" name="transaction_id" value="<?= (int) $row['id'] ?>"><input name="reason" maxlength="500" placeholder="审核原因" required><button class="btn primary" name="decision" value="approve">通过并自动打币</button><button class="btn danger" name="decision" value="reject">拒绝并退款</button></form><?php endif; ?><?php if (adminCan('wallets')): ?><form method="post" class="inline-form"><?= adminHidden($csrf, 'wallet.status.update', 'withdrawals') ?><input type="hidden" name="record_type" value="withdraw"><input type="hidden" name="record_id" value="<?= (int) $row['id'] ?>"><select name="status"><option value="pending" <?= $row['status'] === 'pending' ? 'selected' : '' ?>>待处理</option><option value="processing" <?= $row['status'] === 'processing' ? 'selected' : '' ?>>处理中</option><option value="completed" <?= $row['status'] === 'completed' ? 'selected' : '' ?>>已完成</option><option value="failed" <?= $row['status'] === 'failed' ? 'selected' : '' ?>>失败</option><option value="rejected" <?= $row['status'] === 'rejected' ? 'selected' : '' ?>>已拒绝</option><option value="cancelled" <?= $row['status'] === 'cancelled' ? 'selected' : '' ?>>已取消</option></select><input name="reason" maxlength="500" placeholder="仅改状态原因" required><button class="btn">仅改状态</button></form><?php endif; ?></td></tr><?php endforeach; ?>
                    <?= empty($data['rows']) ? adminTableEmpty(8) : '' ?>
                </tbody></table></div></section>
                <script>
                    (function () {
                        var rows = <?= json_encode(array_values(array_map(static fn(array $row): array => ['id' => (int) $row['id']], $data['rows'] ?? [])), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
                        var tables = document.querySelectorAll('table');
                        var table = null;
                        for (var index = 0; index < tables.length; index++) {
                            if ((tables[index].textContent || '').indexOf('审核操作') !== -1) { table = tables[index]; break; }
                        }
                        if (!table) return;
                        var header = table.querySelector('thead tr');
                        if (header && header.children.length > 1) {
                            var heading = document.createElement('th');
                            heading.textContent = '提现 ID';
                            header.insertBefore(heading, header.children[1]);
                        }
                        table.querySelectorAll('tbody tr').forEach(function (row, rowIndex) {
                            if (!rows[rowIndex] || row.children.length < 2) return;
                            var cell = document.createElement('td');
                            cell.className = 'mono';
                            cell.textContent = '#' + rows[rowIndex].id;
                            row.insertBefore(cell, row.children[1]);
                        });
                    }());
                </script>
                 <script>document.addEventListener('DOMContentLoaded',function(){var all=document.getElementById('withdraw-select-all');if(all)all.addEventListener('change',function(){document.querySelectorAll('.withdraw-select').forEach(function(box){box.checked=all.checked;});});var rows=<?= json_encode(array_values(array_map(static fn(array $row): array => ['id'=>(int) $row['id'],'status'=>(string) $row['status']], $data['rows'] ?? [])), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;var csrf=<?= json_encode($csrf, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;document.querySelectorAll('.table-wrap tbody tr').forEach(function(row,index){if(!rows[index]||rows[index].status!=='failed')return;var cell=row.lastElementChild;if(!cell)return;var form=document.createElement('form');form.method='post';form.className='inline-form';form.onsubmit=function(){return confirm('请确认该提现原交易未到账，再重新发送。重复发送可能造成重复付款。');};[['csrf',csrf],['action','withdraw.retry'],['section','withdrawals'],['transaction_id',String(rows[index].id)]].forEach(function(item){var input=document.createElement('input');input.type='hidden';input.name=item[0];input.value=item[1];form.appendChild(input);});var reason=document.createElement('input');reason.name='reason';reason.maxLength=500;reason.placeholder='重试原因';reason.required=true;form.appendChild(reason);var button=document.createElement('button');button.type='submit';button.className='btn primary';button.textContent='重试发送';form.appendChild(button);cell.appendChild(form);});});</script>
            <?php elseif ($section === 'transactions'): ?>
                <div class="section-head"><h2>钱包流水 <span class="muted">每页 30 条</span></h2></div>
                <section class="panel"><div class="table-wrap"><table><thead><tr><th>用户</th><th>币种 / 链</th><th>类型</th><th>金额</th><th>状态</th><th>地址</th><th>交易哈希</th><th>时间</th></tr></thead><tbody>
                     <?php foreach (($data['rows'] ?? []) as $row): ?><tr><td><?= adminEscape($row['username']) ?><span class="sub"><?= adminEscape($row['nickname']) ?></span></td><td><?= adminEscape($row['symbol']) ?> / <?= adminEscape($row['chain']) ?></td><td><?= adminEscape(adminTransactionLabel((string) $row['type'])) ?></td><td><?= adminAmount4($row['amount']) ?></td><td><span class="status <?= adminEscape($row['status']) ?>"><?= adminEscape(adminStatusLabel((string) $row['status'])) ?></span></td><td class="mono"><?= adminEscape($row['address'] ?: '无') ?></td><td class="mono"><?= adminEscape($row['tx_hash'] ?: '无') ?></td><td><?= adminEscape($row['created_at']) ?></td></tr><?php endforeach; ?>
                    <?= empty($data['rows']) ? adminTableEmpty(8) : '' ?>
                </tbody></table></div></section>
            <?php elseif ($section === 'exchanges'): ?>
                <section class="panel"><div class="panel-head"><h2>兑换记录 <span class="muted">每页 30 条 · 只读</span></h2></div><div class="table-wrap"><table><thead><tr><th>用户</th><th>USDT</th><th>SPX001</th><th>成交价</th><th>费率</th><th>状态</th><th>时间</th></tr></thead><tbody>
                    <?php foreach (($data['rows'] ?? []) as $row): ?><tr><td><?= adminEscape($row['username']) ?><span class="sub"><?= adminEscape($row['nickname']) ?></span></td><td><?= adminAmount4($row['usdt_amount']) ?></td><td><?= adminAmount4($row['spx_amount']) ?></td><td><?= adminAmount4($row['exchange_price']) ?></td><td><?= adminAmount4($row['fee_rate']) ?></td><td><?= adminEscape(adminStatusLabel((string) $row['status'])) ?></td><td><?= adminEscape($row['created_at']) ?></td></tr><?php endforeach; ?>
                    <?= empty($data['rows']) ? adminTableEmpty(7) : '' ?>
                </tbody></table></div></section>
            <?php elseif ($section === 'staking'): ?>
                <?php $phase = $data['phase'] ?? null; $phaseRemaining = $phase['remaining_quota'] ?? '0'; ?>
                <?php $stakingStats = $data['staking_stats'] ?? ['active_people' => 0, 'active_amount' => '0', 'all_people' => 0, 'all_amount' => '0']; ?>
                <div class="stats">
                    <div class="stat"><div class="stat-label">当前质押人数</div><div class="stat-value"><?= number_format((int) $stakingStats['active_people']) ?></div><div class="sub">仍在质押中的用户</div></div>
                    <div class="stat"><div class="stat-label">当前质押总量</div><div class="stat-value"><?= adminAmount4($stakingStats['active_amount']) ?></div><div class="sub">SPX001</div></div>
                    <div class="stat"><div class="stat-label">历史参与人数</div><div class="stat-value"><?= number_format((int) $stakingStats['all_people']) ?></div><div class="sub">曾创建质押订单</div></div>
                    <div class="stat"><div class="stat-label">历史质押总量</div><div class="stat-value"><?= adminAmount4($stakingStats['all_amount']) ?></div><div class="sub">SPX001</div></div>
                </div>
                <?php if (adminCan('staking_plans')): ?><section class="panel"><div class="panel-head"><h2>质押奖励额度</h2><span class="muted">新质押创建时预分配分红和邀请奖励</span></div><div class="panel-body"><div class="detail-grid"><div><span class="muted">当前期数</span><strong><?= adminEscape($phase['phase_no'] ?? '未开启') ?></strong></div><div><span class="muted">总额度</span><strong><?= adminAmount4($phase['total_quota'] ?? '0') ?> SPX001 积分</strong></div><div><span class="muted">已预分配</span><strong><?= adminAmount4($phase['reserved_quota'] ?? '0') ?> SPX001 积分</strong></div><div><span class="muted">已发放</span><strong><?= adminAmount4($phase['paid_quota'] ?? '0') ?> SPX001 积分</strong></div><div><span class="muted">剩余额度</span><strong><?= adminAmount4($phaseRemaining) ?> SPX001 积分</strong></div><div><span class="muted">状态</span><strong><?= !empty($phase) && (int) ($phase['status'] ?? 0) === 1 ? '已开启' : '未开启' ?></strong></div></div><form method="post" class="form-grid" style="margin-top:18px"><?= adminHidden($csrf, 'staking.phase.save', 'staking') ?><div class="field"><label>期数</label><input name="phase_no" type="number" min="1" max="1000000" required value="<?= (int) ($phase['phase_no'] ?? 1) ?>"></div><div class="field"><label>期名称</label><input name="name" maxlength="100" required value="<?= adminEscape($phase['name'] ?? 'SPX001 第一期') ?>"></div><div class="field"><label>分红+邀请奖励总额度</label><input name="total_quota" inputmode="decimal" required value="<?= adminEscape($phase['total_quota'] ?? '20000000') ?>"></div><div class="field"><label>状态</label><select name="status"><option value="1" <?= !empty($phase) && (int) ($phase['status'] ?? 0) === 1 ? 'selected' : '' ?>>开启</option><option value="0" <?= empty($phase) || (int) ($phase['status'] ?? 0) !== 1 ? 'selected' : '' ?>>未开启</option></select></div><div><button class="btn primary">保存质押期配置</button></div></form></div></section><?php endif; ?>
                <?php if (adminCan('staking_plans')): ?>
                    <section class="panel"><div class="panel-head"><h2>质押方案设置 <span class="muted">App 展示与服务端最低金额校验使用同一配置</span></h2></div><div class="panel-body"><form method="post">
                        <?= adminHidden($csrf, 'staking.plans.save', 'staking') ?>
                        <div class="table-wrap"><table><thead><tr><th>方案名称</th><th>锁仓天数</th><th>年化利率 %</th><th>最低 SPX001</th><th>状态</th></tr></thead><tbody>
                            <?php foreach (($data['plans'] ?? []) as $planIndex => $plan): ?><tr><td><input name="plans[<?= (int) $planIndex ?>][name]" maxlength="100" required value="<?= adminEscape($plan['name']) ?>"><input type="hidden" name="plans[<?= (int) $planIndex ?>][id]" value="<?= (int) $plan['id'] ?>"></td><td><input name="plans[<?= (int) $planIndex ?>][plan_days]" type="number" min="1" max="3650" required value="<?= (int) $plan['plan_days'] ?>"></td><td><input name="plans[<?= (int) $planIndex ?>][apy]" inputmode="decimal" required value="<?= adminEscape($plan['apy']) ?>"></td><td><input name="plans[<?= (int) $planIndex ?>][minimum_amount]" inputmode="decimal" required value="<?= adminEscape($plan['minimum_amount']) ?>"></td><td><select name="plans[<?= (int) $planIndex ?>][status]"><option value="1" <?= (int) $plan['status'] === 1 ? 'selected' : '' ?>>启用</option><option value="0" <?= (int) $plan['status'] === 0 ? 'selected' : '' ?>>下架</option></select></td></tr><?php endforeach; ?>
                            <?php $newPlanIndex = count($data['plans'] ?? []); ?><tr><td><input name="plans[<?= $newPlanIndex ?>][name]" maxlength="100" placeholder="新增方案名称"><input type="hidden" name="plans[<?= $newPlanIndex ?>][id]" value="0"></td><td><input name="plans[<?= $newPlanIndex ?>][plan_days]" type="number" min="1" max="3650" placeholder="天数"></td><td><input name="plans[<?= $newPlanIndex ?>][apy]" inputmode="decimal" placeholder="例如 8.2"></td><td><input name="plans[<?= $newPlanIndex ?>][minimum_amount]" inputmode="decimal" placeholder="最低金额"></td><td><select name="plans[<?= $newPlanIndex ?>][status]"><option value="1">启用</option><option value="0">下架</option></select></td></tr>
                        </tbody></table></div><button class="btn primary">保存质押方案</button>
                    </form></div></section>
                <?php endif; ?>
                <section class="panel"><div class="panel-head"><h2>质押订单 <span class="muted">每页 30 条 · 点击订单查看详情</span></h2><a class="btn" href="admin.php?export=staking">导出质押订单 CSV</a></div><div class="table-wrap"><table><thead><tr><th>订单</th><th>用户</th><th>方案 / 周期</th><th>金额</th><th>APY</th><th>状态</th><th>时间</th><th>操作</th></tr></thead><tbody>
                    <?php foreach (($data['rows'] ?? []) as $row): ?><tr><td>#<?= (int) $row['id'] ?><span class="sub">期数 <?= (int) ($row['phase_id'] ?? 0) ?></span></td><td><?= adminEscape($row['username']) ?><span class="sub"><?= adminEscape($row['nickname']) ?> · <?= adminEscape($row['spx_id'] ?? '') ?></span></td><td><?= adminEscape($row['plan_name'] ?: '质押方案') ?><span class="sub"><?= (int) $row['plan_days'] ?> 天 · <?= adminEscape($row['phase_name'] ?? '未分期') ?></span></td><td><?= adminAmount4($row['amount']) ?> <span class="sub">SPX001</span></td><td><?= adminAmount4($row['apy']) ?>%</td><td><span class="status <?= adminEscape($row['status']) ?>"><?= adminEscape(adminStatusLabel((string) $row['status'])) ?></span></td><td><?= adminEscape($row['created_at']) ?></td><td><a class="btn" href="admin.php?section=staking&amp;detail_id=<?= (int) $row['id'] ?>">查看详情</a></td></tr><?php endforeach; ?>
                    <?= empty($data['rows']) ? adminTableEmpty(8) : '' ?>
                </tbody></table></div></section>
                <?php if (!empty($data['staking_detail'])): $detail = $data['staking_detail']; ?>
                    <div class="modal-overlay" id="staking-detail-modal" role="dialog" aria-modal="true" aria-labelledby="staking-detail-title"><div class="modal-dialog"><section class="panel"><div class="panel-head"><h2 id="staking-detail-title">质押订单详情 · #<?= (int) $detail['id'] ?></h2><a class="modal-close" href="admin.php?section=staking" aria-label="关闭质押详情">×</a></div><div class="panel-body"><div class="detail-grid">
                        <div><span class="muted">用户</span><strong><?= adminEscape($detail['username']) ?> · <?= adminEscape($detail['nickname']) ?></strong></div><div><span class="muted">邮箱</span><strong><?= adminEscape($detail['email'] ?? '') ?></strong></div><div><span class="muted">SPX ID</span><strong><?= adminEscape($detail['spx_id'] ?? '') ?></strong></div><div><span class="muted">状态</span><strong><?= adminEscape(adminStatusLabel((string) $detail['status'])) ?></strong></div>
                        <div><span class="muted">质押方案</span><strong><?= adminEscape($detail['plan_name'] ?? '质押方案') ?></strong></div><div><span class="muted">质押期数</span><strong><?= adminEscape($detail['phase_name'] ?? '未分期') ?></strong></div><div><span class="muted">锁仓期限</span><strong><?= (int) $detail['plan_days'] ?> 天</strong></div><div><span class="muted">年化收益率</span><strong><?= adminAmount4($detail['apy']) ?>%</strong></div>
                        <div><span class="muted">质押数量</span><strong><?= adminAmount4($detail['amount']) ?> SPX001</strong></div><div><span class="muted">预计分红</span><strong><?= adminAmount4($detail['expected_reward']) ?> SPX001</strong></div><div><span class="muted">已支付分红</span><strong><?= adminAmount4($detail['paid_dividend']) ?> SPX001</strong></div><div><span class="muted">邀请奖励</span><strong><?= adminAmount4($detail['referral_reward']) ?> SPX001</strong></div>
                        <div><span class="muted">创建时间</span><strong><?= adminEscape($detail['created_at']) ?></strong></div>
                    </div><div class="section-head detail-heading"><h2>分红明细</h2></div><div class="table-wrap"><table><thead><tr><th>期数</th><th>分红数量</th><th>发放时间</th></tr></thead><tbody><?php foreach (($data['staking_detail_dividends'] ?? []) as $dividend): ?><tr><td>第 <?= (int) $dividend['period_no'] ?> 期</td><td><?= adminAmount4($dividend['amount']) ?> SPX001</td><td><?= adminEscape($dividend['created_at']) ?></td></tr><?php endforeach; ?><?= empty($data['staking_detail_dividends']) ? adminTableEmpty(3) : '' ?></tbody></table></div></div></section></div></div>
                <?php endif; ?>
            <?php elseif ($section === 'referrals'): ?>
                <section class="panel"><div class="panel-head"><h2>推荐奖励 <span class="muted">每页 30 条 · 只读</span></h2></div><div class="table-wrap"><table><thead><tr><th>推荐人</th><th>被推荐人</th><th>质押金额</th><th>奖励金额</th><th>时间</th></tr></thead><tbody>
                    <?php foreach (($data['rows'] ?? []) as $row): ?><tr><td><?= adminEscape($row['referrer_username']) ?><span class="sub"><?= adminEscape($row['referrer_nickname']) ?></span></td><td><?= adminEscape($row['staker_username']) ?><span class="sub"><?= adminEscape($row['staker_nickname']) ?></span></td><td><?= adminAmount4($row['staked_amount']) ?></td><td><?= adminAmount4($row['reward_amount']) ?></td><td><?= adminEscape($row['created_at']) ?></td></tr><?php endforeach; ?>
                    <?= empty($data['rows']) ? adminTableEmpty(5) : '' ?>
                </tbody></table></div></section>
            <?php elseif ($section === 'merchants'): ?>
                <?php mallAdminRender($pdo, $csrf); ?>
            <?php elseif ($section === 'products'): ?>
                <?php $edit = $data['edit'] ?? null; ?>
                <section class="panel"><div class="panel-head"><h2><?= $edit ? '编辑商品' : '新增商品' ?></h2><?php if ($edit): ?><a class="btn" href="admin.php?section=products">新建商品</a><?php endif; ?></div><div class="panel-body">
                    <form method="post" class="form-grid" enctype="multipart/form-data">
                        <?= adminHidden($csrf, 'product.save', 'products') ?>
                        <input type="hidden" name="id" value="<?= (int) ($edit['id'] ?? 0) ?>">
                        <div class="field"><label for="name">商品名称</label><input id="name" name="name" maxlength="150" required value="<?= adminEscape($edit['name'] ?? '') ?>"></div>
                        <div class="field"><label for="product_type">商品类型</label><select id="product_type" name="product_type"><option value="digital" <?= ($edit['product_type'] ?? 'digital') === 'digital' ? 'selected' : '' ?>>数字商品</option><option value="physical" <?= ($edit['product_type'] ?? '') === 'physical' ? 'selected' : '' ?>>实物商品（需收货地址和物流）</option></select></div>
                        <div class="field"><label for="price">SPX 价格</label><input id="price" name="spx_price" inputmode="decimal" required value="<?= adminEscape($edit['spx_price'] ?? '0') ?>"></div>
                        <div class="field"><label for="stock">总库存（有规格时自动汇总）</label><input id="stock" name="stock" type="number" min="0" step="1" required value="<?= (int) ($edit['stock'] ?? 0) ?>"></div>
                        <div class="field"><label for="sort_order">排序值</label><input id="sort_order" name="sort_order" type="number" step="1" value="<?= (int) ($edit['sort_order'] ?? 0) ?>"></div>
                        <div class="field"><label for="image_url">主图 URL（可选）</label><input id="image_url" name="image_url" type="url" maxlength="500" value="<?= adminEscape($edit['image_url'] ?? '') ?>"></div>
                        <div class="field"><label for="images">上传商品图片（每张不超过 5 MB，最多保留 8 张）</label><input id="images" name="images[]" type="file" accept="image/jpeg,image/png,image/webp,image/gif" multiple><div id="image-preview" class="image-preview"></div></div>
                        <div class="field span-2"><label for="variants">商品规格（每行：规格名称|SPX价格|库存；没有规格可留空）</label><textarea id="variants" name="variants" maxlength="5000" placeholder="红色 M|120|8&#10;蓝色 L|125|5"><?= adminEscape(adminVariantLines($edit['variants'] ?? '')) ?></textarea></div>
                        <?php if (!empty($data['edit_images'])): ?><div class="field span-2"><label>现有图库（勾选移除）</label><div class="image-list"><?php foreach ($data['edit_images'] as $image): ?><label class="image-item"><img src="<?= adminEscape($image['image_url']) ?>" alt="商品图片"><span><input type="checkbox" name="remove_image_ids[]" value="<?= (int) $image['id'] ?>"> 移除此图</span></label><?php endforeach; ?></div></div><?php endif; ?>
                        <div class="field"><label for="status">状态</label><select id="status" name="status"><option value="1" <?= (int) ($edit['status'] ?? 1) === 1 ? 'selected' : '' ?>>上架</option><option value="0" <?= (int) ($edit['status'] ?? 1) === 0 ? 'selected' : '' ?>>下架</option></select></div>
                        <div class="field span-2"><label for="description">商品描述</label><textarea id="description" name="description" maxlength="10000"><?= adminEscape($edit['description'] ?? '') ?></textarea></div>
                        <div><button class="btn primary" type="submit">保存商品</button></div>
                    </form>
                </div></section>
                <section class="panel"><div class="panel-head"><h2>商品列表</h2></div><div class="table-wrap"><table><thead><tr><th>ID</th><th>名称</th><th>价格</th><th>库存</th><th>状态</th><th>排序</th><th>操作</th></tr></thead><tbody>
                    <?php foreach (($data['rows'] ?? []) as $row): ?><tr><td><?= (int) $row['id'] ?></td><td><?php if (!empty($row['image_url'])): ?><img src="<?= adminEscape($row['image_url']) ?>" alt="" style="width:42px;height:42px;object-fit:cover;vertical-align:middle;margin-right:8px;border-radius:3px"><?php endif; ?><?= adminEscape($row['name']) ?></td><td><?= mallAdminMoney($row['spx_price']) ?></td><td><?= (int) $row['stock'] ?></td><td><span class="status <?= (int) $row['status'] === 1 ? 'active' : 'inactive' ?>"><?= (int) $row['status'] === 1 ? '上架' : '下架' ?></span></td><td><?= (int) $row['sort_order'] ?></td><td><a class="btn" href="admin.php?section=products&amp;edit=<?= (int) $row['id'] ?>">编辑</a></td></tr><?php endforeach; ?>
                    <?= empty($data['rows']) ? adminTableEmpty(7) : '' ?>
                </tbody></table></div></section>
            <?php elseif ($section === 'orders'): ?>
                <div class="section-head"><h2>商城订单 <span class="muted">实物订单可登记承运商和物流单号，用户订单页同步可见</span></h2></div>
                <section class="panel"><div class="table-wrap"><table><thead><tr><th>订单</th><th>用户</th><th>商品 / 规格</th><th>数量</th><th>SPX 金额</th><th>收货地址 / 物流</th><th>状态</th><th>处理</th></tr></thead><tbody>
                    <?php foreach (($data['rows'] ?? []) as $row): $shipping = json_decode((string) ($row['shipping_address'] ?? ''), true) ?: []; ?><tr>
                        <td>#<?= (int) $row['id'] ?><span class="sub"><?= adminEscape($row['created_at']) ?></span></td>
                        <td><?= adminEscape($row['username']) ?><span class="sub"><?= adminEscape($row['nickname']) ?> · <?= $row['order_type'] === 'physical' ? '实物' : '数字商品' ?></span></td>
                        <td><?= adminEscape($row['product_name']) ?><span class="sub"><?= adminEscape($row['variant_name'] ?: '标准规格') ?></span></td>
                        <td><?= (int) $row['quantity'] ?></td><td><?= mallAdminMoney($row['total_spx']) ?></td>
                        <td class="ticket-content"><?php if ($row['order_type'] === 'physical'): ?><?= adminEscape(($shipping['name'] ?? '') . ' · ' . ($shipping['phone'] ?? '')) ?><span class="sub"><?= adminEscape(($shipping['province'] ?? '') . ($shipping['city'] ?? '') . ($shipping['district'] ?? '') . ($shipping['detail'] ?? '')) ?></span><?php if (!empty($row['tracking_number'])): ?><span class="sub"><?= adminEscape($row['carrier']) ?> · <?= adminEscape($row['tracking_number']) ?></span><?php endif; ?><?php else: ?>无需配送<?php endif; ?></td>
                        <td><span class="status <?= adminEscape($row['status']) ?>"><?= adminEscape(adminStatusLabel((string) $row['status'])) ?></span><span class="sub"><?= adminEscape($row['shipped_at'] ?: '') ?></span></td>
                        <td><?php if ($row['status'] === 'pending' && $row['order_type'] === 'physical'): ?><form method="post" class="inline-form"><?= adminHidden($csrf, 'order.ship', 'orders') ?><input type="hidden" name="order_id" value="<?= (int) $row['id'] ?>"><input name="carrier" maxlength="100" placeholder="承运商" required><input name="tracking_number" maxlength="120" placeholder="物流单号" required><input name="reason" maxlength="500" placeholder="发货备注/原因" required><button class="btn primary">确认发货</button></form><form method="post" class="inline-form"><?= adminHidden($csrf, 'order.process', 'orders') ?><input type="hidden" name="order_id" value="<?= (int) $row['id'] ?>"><input name="reason" maxlength="500" placeholder="取消原因" required><button class="btn danger" name="decision" value="cancel">取消退款</button></form><?php elseif ($row['status'] === 'pending'): ?><form method="post" class="inline-form"><?= adminHidden($csrf, 'order.process', 'orders') ?><input type="hidden" name="order_id" value="<?= (int) $row['id'] ?>"><input name="reason" maxlength="500" placeholder="处理原因" required><button class="btn primary" name="decision" value="complete">完成</button><button class="btn danger" name="decision" value="cancel">取消退款</button></form><?php else: ?>已处理<?php endif; ?></td>
                    </tr><?php endforeach; ?>
                    <?= empty($data['rows']) ? adminTableEmpty(8) : '' ?>
                </tbody></table></div></section>
            <?php elseif ($section === 'tickets'): ?>
                <div class="section-head"><h2>客服工单 <span class="muted">每页 30 条</span></h2><a class="btn" href="admin.php?export=tickets">导出工单 CSV</a></div>
                <section class="panel"><div class="table-wrap"><table><thead><tr><th>用户</th><th>主题 / 内容</th><th>状态</th><th>回复与处理</th></tr></thead><tbody>
                    <?php foreach (($data['rows'] ?? []) as $row): ?><tr><td><?= adminEscape($row['username']) ?><span class="sub"><?= adminEscape($row['created_at']) ?></span></td><td class="ticket-content"><strong><?= adminEscape($row['subject']) ?></strong><div><?= nl2br(adminEscape($row['content'])) ?></div></td><td><span class="status <?= adminEscape($row['status']) ?>"><?= adminEscape(adminStatusLabel((string) $row['status'])) ?></span></td><td><form method="post" class="inline-form"><?= adminHidden($csrf, 'ticket.save', 'tickets') ?><input type="hidden" name="ticket_id" value="<?= (int) $row['id'] ?>"><textarea name="admin_reply" maxlength="10000" required placeholder="填写回复"><?= adminEscape($row['admin_reply'] ?? '') ?></textarea><select name="status"><option value="open" <?= $row['status'] === 'open' ? 'selected' : '' ?>>待处理</option><option value="processing" <?= $row['status'] === 'processing' ? 'selected' : '' ?>>处理中</option><option value="resolved" <?= $row['status'] === 'resolved' ? 'selected' : '' ?>>已解决</option><option value="closed" <?= $row['status'] === 'closed' ? 'selected' : '' ?>>已关闭</option></select><button class="btn primary">保存</button></form></td></tr><?php endforeach; ?>
                    <?= empty($data['rows']) ? adminTableEmpty(4) : '' ?>
                </tbody></table></div></section>
            <?php elseif ($section === 'questions'): ?>
                <section class="panel"><div class="panel-head"><h2>用户问题 <span class="muted">每页 30 条</span></h2></div><div class="table-wrap"><table><thead><tr><th>用户 / 问题</th><th>时间</th><th>状态</th><th>答复</th></tr></thead><tbody>
                    <?php foreach (($data['rows'] ?? []) as $row): ?><tr><td><?= adminEscape($row['username']) ?><span class="sub"><?= adminEscape($row['nickname']) ?></span><div class="ticket-content"><?= nl2br(adminEscape($row['question'])) ?></div></td><td><?= adminEscape($row['created_at']) ?></td><td><?= adminEscape(adminStatusLabel((string) $row['status'])) ?></td><td><form method="post" class="inline-form"><?= adminHidden($csrf, 'question.save', 'questions') ?><input type="hidden" name="question_id" value="<?= (int) $row['id'] ?>"><textarea name="answer" maxlength="10000" required placeholder="答复内容"><?= adminEscape($row['answer'] ?? '') ?></textarea><select name="status"><option value="pending" <?= $row['status'] === 'pending' ? 'selected' : '' ?>>待处理</option><option value="answered" <?= $row['status'] === 'answered' ? 'selected' : '' ?>>已答复</option><option value="closed" <?= $row['status'] === 'closed' ? 'selected' : '' ?>>关闭</option></select><button class="btn primary">保存</button></form></td></tr><?php endforeach; ?>
                    <?= empty($data['rows']) ? adminTableEmpty(4) : '' ?>
                </tbody></table></div></section>
            <?php elseif ($section === 'feedback'): ?>
                <section class="panel"><div class="panel-head"><h2>用户反馈 <span class="muted">每页 30 条</span></h2></div><div class="table-wrap"><table><thead><tr><th>用户</th><th>反馈内容</th><th>联系方式</th><th>状态</th><th>处理</th></tr></thead><tbody>
                    <?php foreach (($data['rows'] ?? []) as $row): ?><tr><td><?= adminEscape($row['username']) ?><span class="sub"><?= adminEscape($row['nickname']) ?> · <?= adminEscape($row['created_at']) ?></span></td><td class="ticket-content"><?= nl2br(adminEscape($row['content'])) ?></td><td><?= adminEscape($row['contact'] ?: '—') ?></td><td><?= adminEscape(adminStatusLabel((string) $row['status'])) ?></td><td><form method="post" class="inline-form"><?= adminHidden($csrf, 'feedback.save', 'feedback') ?><input type="hidden" name="feedback_id" value="<?= (int) $row['id'] ?>"><select name="status"><option value="pending" <?= $row['status'] === 'pending' ? 'selected' : '' ?>>待处理</option><option value="reviewed" <?= $row['status'] === 'reviewed' ? 'selected' : '' ?>>已查看</option><option value="resolved" <?= $row['status'] === 'resolved' ? 'selected' : '' ?>>已解决</option></select><button class="btn primary">更新</button></form></td></tr><?php endforeach; ?>
                    <?= empty($data['rows']) ? adminTableEmpty(5) : '' ?>
                </tbody></table></div></section>
            <?php elseif ($section === 'faqs'): ?>
                <?php $editFaq = $data['edit_faq'] ?? null; ?>
                <section class="panel"><div class="panel-head"><h2><?= $editFaq ? '编辑 FAQ' : '新增 FAQ' ?></h2><?php if ($editFaq): ?><a class="btn" href="admin.php?section=faqs">新增</a><?php endif; ?></div><div class="panel-body"><form method="post" class="form-grid">
                    <?= adminHidden($csrf, 'faq.save', 'faqs') ?><input type="hidden" name="faq_id" value="<?= (int) ($editFaq['id'] ?? 0) ?>">
                    <div class="field"><label>分类</label><input name="category" maxlength="50" required value="<?= adminEscape($editFaq['category'] ?? '') ?>"></div>
                    <div class="field"><label>排序</label><input name="sort_order" type="number" step="1" value="<?= (int) ($editFaq['sort_order'] ?? 0) ?>"></div>
                    <div class="field"><label>问题</label><input name="question" maxlength="255" required value="<?= adminEscape($editFaq['question'] ?? '') ?>"></div>
                    <div class="field"><label>状态</label><select name="status"><option value="1" <?= (int) ($editFaq['status'] ?? 1) === 1 ? 'selected' : '' ?>>启用</option><option value="0" <?= (int) ($editFaq['status'] ?? 1) === 0 ? 'selected' : '' ?>>隐藏</option></select></div>
                    <div class="field span-2"><label>答案</label><textarea name="answer" maxlength="10000" required><?= adminEscape($editFaq['answer'] ?? '') ?></textarea></div><div><button class="btn primary">保存 FAQ</button></div>
                </form></div></section>
                <section class="panel"><div class="table-wrap"><table><thead><tr><th>分类</th><th>问题</th><th>状态</th><th>排序</th><th>操作</th></tr></thead><tbody>
                    <?php foreach (($data['rows'] ?? []) as $row): ?><tr><td><?= adminEscape($row['category']) ?></td><td><?= adminEscape($row['question']) ?></td><td><?= (int) $row['status'] === 1 ? '启用' : '隐藏' ?></td><td><?= (int) $row['sort_order'] ?></td><td><a class="btn" href="admin.php?section=faqs&amp;faq_id=<?= (int) $row['id'] ?>">编辑</a></td></tr><?php endforeach; ?>
                    <?= empty($data['rows']) ? adminTableEmpty(5) : '' ?>
                </tbody></table></div></section>
            <?php elseif ($section === 'groups'): ?>
                <section class="panel"><div class="panel-head"><h2>群组管理 <span class="muted">修改群名、公告和成员</span></h2></div><div class="table-wrap"><table><thead><tr><th>ID / 群号</th><th>群组</th><th>人数</th><th>公告</th><th>保存修改</th><th>成员</th></tr></thead><tbody>
                    <?php foreach (($data['rows'] ?? []) as $row): ?><tr><td>#<?= (int) $row['id'] ?><span class="sub"><?= adminEscape($row['group_code'] ?: '—') ?></span></td><td><?= adminEscape($row['name']) ?><span class="sub"><?= adminEscape($row['created_at']) ?></span></td><td><?= (int) $row['member_count'] ?></td><td class="ticket-content"><?= nl2br(adminEscape($row['announcement'] ?? '')) ?></td><td><form method="post" class="inline-form"><?= adminHidden($csrf, 'group.save', 'groups') ?><input type="hidden" name="group_id" value="<?= (int) $row['id'] ?>"><input name="name" maxlength="100" required value="<?= adminEscape($row['name']) ?>"><textarea name="announcement" maxlength="5000" placeholder="群公告"><?= adminEscape($row['announcement'] ?? '') ?></textarea><button class="btn primary">保存</button></form></td><td><a class="btn" href="admin.php?section=groups&amp;group_id=<?= (int) $row['id'] ?>">查看成员</a></td></tr><?php endforeach; ?>
                    <?= empty($data['rows']) ? adminTableEmpty(6) : '' ?>
                </tbody></table></div></section>
                <?php if (!empty($data['selected_group'])): ?>
                    <section class="panel"><div class="panel-head"><h2>群成员 · <?= adminEscape($data['selected_group']['name']) ?> <span class="muted"><?= adminEscape($data['selected_group']['group_code']) ?></span></h2><a class="btn" href="admin.php?section=groups">返回群组</a></div><div class="table-wrap"><table><thead><tr><th>用户</th><th>角色</th><th>状态</th><th>加入时间</th><th>管理操作</th></tr></thead><tbody>
                        <?php foreach (($data['members'] ?? []) as $member): ?><tr><td>#<?= (int) $member['user_id'] ?> · <?= adminEscape($member['username']) ?><span class="sub"><?= adminEscape($member['nickname']) ?> · <?= adminEscape($member['spx_id']) ?></span></td><td><?= adminEscape(adminStatusLabel((string) $member['role'])) ?></td><td><?= (int) $member['mute'] === 1 ? '已禁言' : '正常' ?></td><td><?= adminEscape($member['joined_at']) ?></td><td><?php if ($member['role'] !== 'owner'): ?><form method="post" class="inline-form"><?= adminHidden($csrf, 'group.member', 'groups') ?><input type="hidden" name="group_id" value="<?= (int) $data['selected_group']['id'] ?>"><input type="hidden" name="user_id" value="<?= (int) $member['user_id'] ?>"><input name="reason" maxlength="500" placeholder="操作原因" required><?php if ((int) $member['mute'] === 1): ?><button class="btn" name="operation" value="unmute">解除禁言</button><?php else: ?><button class="btn" name="operation" value="mute">禁言</button><?php endif; ?><button class="btn danger" name="operation" value="remove">移出群组</button></form><?php else: ?>群主不可操作<?php endif; ?></td></tr><?php endforeach; ?>
                        <?= empty($data['members']) ? adminTableEmpty(5) : '' ?>
                    </tbody></table></div></section>
                    <?php if (!empty($data['member_pagination']) && $data['member_pagination']['pages'] > 1): $memberPagination = $data['member_pagination']; $memberQuery = $_GET; ?>
                        <nav class="pagination" aria-label="群成员分页"><span class="page-info">共 <?= number_format($memberPagination['total']) ?> 位成员</span><?php if ($memberPagination['page'] > 1): $memberQuery['member_page'] = $memberPagination['page'] - 1; ?><a href="admin.php?<?= adminEscape(http_build_query($memberQuery)) ?>">上一页</a><?php endif; ?><span class="current"><?= (int) $memberPagination['page'] ?> / <?= (int) $memberPagination['pages'] ?></span><?php if ($memberPagination['page'] < $memberPagination['pages']): $memberQuery['member_page'] = $memberPagination['page'] + 1; ?><a href="admin.php?<?= adminEscape(http_build_query($memberQuery)) ?>">下一页</a><?php endif; ?></nav>
                    <?php endif; ?>
                <?php endif; ?>
            <?php elseif ($section === 'reports'): ?>
                <section class="panel"><div class="panel-head"><h2>财务汇总 <span class="muted">按流水日期统计</span></h2></div><div class="panel-body">
                    <form method="get" class="search-form"><input type="hidden" name="section" value="reports"><label>开始日期 <input type="date" name="from" value="<?= adminEscape($data['report_from']) ?>"></label><label>结束日期 <input type="date" name="to" value="<?= adminEscape($data['report_to']) ?>"></label><button class="btn primary">查询</button></form>
                    <div class="stats" style="margin-top:18px"><div class="stat"><div class="stat-label">完成充值 USDT</div><div class="stat-value"><?= adminAmount4($data['totals']['recharge_usdt'] ?? '0') ?></div></div><div class="stat"><div class="stat-label">完成提现 USDT</div><div class="stat-value"><?= adminAmount4($data['totals']['withdraw_usdt'] ?? '0') ?></div></div><div class="stat"><div class="stat-label">钱包流水条数</div><div class="stat-value"><?= number_format((int) ($data['totals']['transaction_count'] ?? 0)) ?></div></div></div>
                    <div class="actions">
                        <a class="btn" href="admin.php?export=users">导出用户</a><a class="btn" href="admin.php?export=wallets">导出余额</a><a class="btn" href="admin.php?export=recharges">导出充值</a><a class="btn" href="admin.php?export=withdrawals">导出提现</a><a class="btn" href="admin.php?export=transactions">导出流水</a><a class="btn" href="admin.php?export=orders">导出订单</a>
                    </div>
                </div></section>
                <section class="panel"><div class="panel-head"><h2>每日 USDT 流水</h2></div><div class="table-wrap"><table><thead><tr><th>日期</th><th>流水数</th><th>完成充值</th><th>完成提现</th><th>管理员增加</th><th>管理员扣减</th></tr></thead><tbody>
                    <?php foreach (($data['rows'] ?? []) as $row): ?><tr><td><?= adminEscape($row['day']) ?></td><td><?= (int) $row['transaction_count'] ?></td><td><?= adminAmount4($row['recharge_usdt']) ?></td><td><?= adminAmount4($row['withdraw_usdt']) ?></td><td><?= adminAmount4($row['admin_credit_usdt']) ?></td><td><?= adminAmount4($row['admin_debit_usdt']) ?></td></tr><?php endforeach; ?>
                    <?= empty($data['rows']) ? adminTableEmpty(6) : '' ?>
                </tbody></table></div></section>
            <?php elseif ($section === 'logs'): ?>
                <section class="panel"><div class="panel-head"><h2>管理员操作审计 <span class="muted">每页 30 条，不提供删除</span></h2></div><div class="table-wrap"><table><thead><tr><th>时间</th><th>管理员</th><th>操作</th><th>对象</th><th>原因</th><th>变更前</th><th>变更后</th><th>来源 IP</th></tr></thead><tbody>
                    <?php foreach (($data['rows'] ?? []) as $row): ?><tr><td><?= adminEscape($row['created_at']) ?></td><td><?= adminEscape($row['admin_username']) ?></td><td><?= adminEscape(adminActionLabel((string) $row['action'])) ?></td><td><?= adminEscape(adminTargetLabel((string) $row['target_type'])) ?> #<?= adminEscape($row['target_id'] ?? '') ?></td><td class="ticket-content"><?= adminEscape($row['reason'] ?: '—') ?></td><td class="ticket-content mono"><?= adminEscape($row['before_data'] ?: '—') ?></td><td class="ticket-content mono"><?= adminEscape($row['after_data'] ?: '—') ?></td><td><?= adminEscape($row['ip_address'] ?: '—') ?></td></tr><?php endforeach; ?>
                    <?= empty($data['rows']) ? adminTableEmpty(8) : '' ?>
                </tbody></table></div></section>
            <?php elseif ($section === 'admins'): ?>
                <section class="panel"><div class="panel-head"><h2>新增管理员</h2></div><div class="panel-body"><form method="post" class="form-grid">
                    <?= adminHidden($csrf, 'admin.save', 'admins') ?><input type="hidden" name="admin_id" value="0">
                    <div class="field"><label>登录账号</label><input name="username" maxlength="64" required></div>
                    <div class="field"><label>初始密码（至少 12 位）</label><input name="new_password" type="password" minlength="12" maxlength="200" required></div>
                    <div class="field"><label>角色</label><select name="role"><option value="operator">运营</option><option value="support">客服</option><option value="finance">财务</option><option value="superadmin">超级管理员</option></select></div>
                    <div><button class="btn primary">创建管理员</button></div>
                </form></div></section>
                <section class="panel"><div class="panel-head"><h2>管理员账号与权限</h2></div><div class="table-wrap"><table><thead><tr><th>ID / 最近登录</th><th>账号</th><th>角色</th><th>状态</th><th>修改</th><th>启停</th></tr></thead><tbody>
                    <?php foreach (($data['rows'] ?? []) as $row): ?><tr><td>#<?= (int) $row['id'] ?><span class="sub"><?= adminEscape($row['last_login_at'] ?: '尚未登录') ?></span></td><td><?= adminEscape($row['username']) ?></td><td><?= adminEscape(adminRoleLabel((string) $row['role'])) ?></td><td><?= (int) $row['status'] === 1 ? '启用' : '停用' ?></td><td><form method="post" class="inline-form"><?= adminHidden($csrf, 'admin.save', 'admins') ?><input type="hidden" name="admin_id" value="<?= (int) $row['id'] ?>"><input name="username" maxlength="64" required value="<?= adminEscape($row['username']) ?>"><select name="role"><option value="operator" <?= $row['role'] === 'operator' ? 'selected' : '' ?>>运营</option><option value="support" <?= $row['role'] === 'support' ? 'selected' : '' ?>>客服</option><option value="finance" <?= $row['role'] === 'finance' ? 'selected' : '' ?>>财务</option><option value="superadmin" <?= $row['role'] === 'superadmin' ? 'selected' : '' ?>>超级管理员</option></select><input name="new_password" type="password" minlength="12" maxlength="200" placeholder="留空不改密码"><button class="btn">保存</button></form></td><td><?php if ((int) $row['id'] !== (int) $admin['id']): ?><form method="post"><?= adminHidden($csrf, 'admin.toggle', 'admins') ?><input type="hidden" name="admin_id" value="<?= (int) $row['id'] ?>"><button class="btn <?= (int) $row['status'] === 1 ? 'danger' : '' ?>"><?= (int) $row['status'] === 1 ? '停用' : '启用' ?></button></form><?php else: ?>当前账号<?php endif; ?></td></tr><?php endforeach; ?>
                    <?= empty($data['rows']) ? adminTableEmpty(6) : '' ?>
                </tbody></table></div></section>
            <?php elseif ($section === 'email_notifications'): ?>
                <section class="panel"><div class="panel-head"><h2>邮件通知</h2><span class="muted">充值到账、提现申请、提现失败</span></div><div class="panel-body"><div class="detail-grid"><div><span class="muted">SMTP 配置</span><strong>使用服务器环境变量</strong></div><div><span class="muted">默认收件人</span><strong>yishengzaidu@qq.com</strong></div><div><span class="muted">超级管理员</span><strong>管理收件人和模板</strong></div><div><span class="muted">运营账号</span><strong>仅发送测试</strong></div></div></div></section>
                <?php if (adminCan('email_notification_control')): ?><section class="panel"><div class="panel-head"><h2>新增收件人</h2><span class="muted">可按模板订阅</span></div><div class="panel-body"><form method="post" class="form-grid"><?= adminHidden($csrf, 'finance.recipient.save', 'email_notifications') ?><input type="hidden" name="recipient_id" value="0"><div class="field"><label>邮箱</label><input name="email" type="email" maxlength="190" required></div><div class="field"><label>状态</label><select name="status"><option value="1">启用</option><option value="0">停用</option></select></div><div class="field span-2"><label>订阅模板</label><div class="actions"><?php foreach (($data['email_templates'] ?? []) as $template): ?><label><input type="checkbox" name="template_ids[]" value="<?= (int) $template['id'] ?>" checked> <?= adminEscape($template['name']) ?></label><?php endforeach; ?></div></div><div><button class="btn primary">添加收件人</button></div></form></div></section><?php endif; ?>
                <section class="panel"><div class="panel-head"><h2>收件人列表</h2></div><div class="table-wrap"><table><thead><tr><th>邮箱</th><th>状态</th><th>订阅模板</th><th>操作</th></tr></thead><tbody><?php foreach (($data['email_recipients'] ?? []) as $recipient): ?><tr><td><?= adminEscape($recipient['email']) ?></td><td><?= (int) $recipient['status'] === 1 ? '启用' : '停用' ?></td><td><?php $subscriptions = $data['email_subscriptions'][(int) $recipient['id']] ?? []; ?><form method="post" class="inline-form"><?= adminHidden($csrf, 'finance.recipient.save', 'email_notifications') ?><input type="hidden" name="recipient_id" value="<?= (int) $recipient['id'] ?>"><input name="email" type="email" value="<?= adminEscape($recipient['email']) ?>" maxlength="190" required><select name="status"><option value="1" <?= (int) $recipient['status'] === 1 ? 'selected' : '' ?>>启用</option><option value="0" <?= (int) $recipient['status'] === 0 ? 'selected' : '' ?>>停用</option></select><?php foreach (($data['email_templates'] ?? []) as $template): ?><label><input type="checkbox" name="template_ids[]" value="<?= (int) $template['id'] ?>" <?= in_array((int) $template['id'], $subscriptions, true) ? 'checked' : '' ?>><?= adminEscape($template['name']) ?></label><?php endforeach; ?><button class="btn">保存</button></form></td><td><form method="post" onsubmit="return confirm('确认删除该收件人吗？');"><?= adminHidden($csrf, 'finance.recipient.delete', 'email_notifications') ?><input type="hidden" name="recipient_id" value="<?= (int) $recipient['id'] ?>"><button class="btn danger">删除</button></form></td></tr><?php endforeach; ?><?= empty($data['email_recipients']) ? adminTableEmpty(4) : '' ?></tbody></table></div></section>
                <section class="panel"><div class="panel-head"><h2>通知模板</h2><span class="muted">支持变量：{{username}} {{nickname}} {{user_id}} {{symbol}} {{amount}} {{fee}} {{net_amount}} {{reason}} {{status}} {{created_at}}</span></div><?php foreach (($data['email_templates'] ?? []) as $template): ?><div class="panel-body" style="border-bottom:1px solid #e5ebe7"><div class="section-head"><h3><?= adminEscape($template['name']) ?></h3><span class="muted"><?= adminEscape($template['event_key']) ?></span></div><form method="post"><input type="hidden" name="csrf" value="<?= adminEscape($csrf) ?>"><input type="hidden" name="action" value="finance.template.save"><input type="hidden" name="section" value="email_notifications"><input type="hidden" name="template_id" value="<?= (int) $template['id'] ?>"><div class="field"><label>邮件标题</label><input name="subject" maxlength="255" value="<?= adminEscape($template['subject']) ?>" required></div><div class="field"><label>HTML 正文</label><textarea name="body_html" maxlength="50000" style="min-height:150px" required><?= adminEscape($template['body_html']) ?></textarea></div><?php if (adminCan('email_notification_control')): ?><div class="actions"><button class="btn primary">保存模板</button></form><form method="post"><?= adminHidden($csrf, 'finance.template.reset', 'email_notifications') ?><input type="hidden" name="template_id" value="<?= (int) $template['id'] ?>"><button class="btn">恢复默认</button></form><?php else: ?></form><?php endif; ?><form method="post" class="inline-form"><?= adminHidden($csrf, 'finance.email.test', 'email_notifications') ?><input type="hidden" name="template_id" value="<?= (int) $template['id'] ?>"><input name="reason" maxlength="500" placeholder="测试原因" required><button class="btn">测试发送</button></form><?php if (adminCan('email_notification_control')): ?></div><?php endif; ?></div><?php endforeach; ?></section>
                <section class="panel"><div class="panel-head"><h2>发送记录 <span class="muted">最近 50 条</span></h2></div><div class="table-wrap"><table><thead><tr><th>时间</th><th>模板</th><th>收件人</th><th>状态</th><th>错误原因</th></tr></thead><tbody><?php foreach (($data['email_logs'] ?? []) as $log): ?><tr><td><?= adminEscape($log['created_at']) ?></td><td><?= adminEscape($log['event_key']) ?></td><td><?= adminEscape($log['recipient_email']) ?></td><td><span class="status <?= adminEscape($log['status']) ?>"><?= $log['status'] === 'sent' ? '成功' : '失败' ?></span></td><td><?= adminEscape($log['error_message'] ?: '—') ?></td></tr><?php endforeach; ?><?= empty($data['email_logs']) ? adminTableEmpty(5) : '' ?></tbody></table></div></section>
            <?php elseif ($section === 'settings'): ?>
                <section class="panel"><div class="panel-head"><h2>Android 热更新</h2><span class="muted">上传并发布后，原生 Android App 会自动检查新版本</span></div><div class="panel-body">
                    <?php $activeRelease = null; foreach (($data['releases'] ?? []) as $release): if ((int) $release['is_active'] === 1) { $activeRelease = $release; break; } endforeach; ?>
                    <p class="muted">当前发布：<?= $activeRelease ? 'v' . adminEscape($activeRelease['version_name']) . '（版本代码 ' . (int) $activeRelease['version_code'] . '）· 已下载 ' . number_format((int) $activeRelease['download_count']) . ' 次' : '尚未发布 APK' ?></p>
                    <form method="post" class="form-grid" enctype="multipart/form-data">
                        <?= adminHidden($csrf, 'app.release.upload', 'settings') ?>
                        <div class="field"><label for="release_version_name">版本名称</label><input id="release_version_name" name="version_name" maxlength="32" placeholder="例如 1.1" pattern="[A-Za-z0-9][A-Za-z0-9._+-]{0,31}" required></div>
                        <div class="field"><label for="release_version_code">Android 版本代码</label><input id="release_version_code" name="version_code" type="number" min="1" step="1" placeholder="必须大于当前代码" required></div>
                        <div class="field span-2"><label for="release_notes">更新说明</label><textarea id="release_notes" name="release_notes" maxlength="10000" placeholder="填写本次版本更新内容" required></textarea></div>
                        <div class="field span-2"><label for="release_apk">APK 文件（最大 500 MB）</label><input id="release_apk" name="apk" type="file" accept=".apk,application/vnd.android.package-archive" required><span class="muted">必须使用与已安装版本相同的 Android 包名和签名证书；版本代码必须递增。</span></div>
                        <div><button class="btn primary" type="submit">上传并发布</button></div>
                    </form>
                </div></section>
                <section class="panel"><div class="panel-head"><h2>邀请链接域名</h2><span class="muted">用于生成注册邀请链接</span></div><div class="panel-body">
                    <form method="post" class="settings-form"><?= adminHidden($csrf, 'settings.invite_base.save', 'settings') ?><div class="field"><label for="invite_base_url">公网根地址</label><input id="invite_base_url" name="invite_base_url" value="<?= adminEscape($data['invite_base_url'] ?? 'http://spx001.top') ?>" placeholder="http://spx001.top" required></div><button class="btn primary">保存邀请域名</button></form>
                </div></section>
                <section class="panel"><div class="panel-head"><h2>已发布版本 <span class="muted">最近 20 个版本 · 下载次数按版本累计</span></h2></div><div class="table-wrap"><table><thead><tr><th>版本</th><th>状态</th><th>文件大小</th><th>下载次数</th><th>SHA-256</th><th>发布时间</th></tr></thead><tbody>
                    <?php foreach (($data['releases'] ?? []) as $release): ?><tr><td>v<?= adminEscape($release['version_name']) ?><span class="sub">版本代码 <?= (int) $release['version_code'] ?> · <?= nl2br(adminEscape($release['release_notes'])) ?></span></td><td><span class="status <?= (int) $release['is_active'] === 1 ? 'active' : 'inactive' ?>"><?= (int) $release['is_active'] === 1 ? '当前发布' : '历史版本' ?></span></td><td><?= number_format((int) $release['apk_size'] / 1048576, 2) ?> MB</td><td><?= number_format((int) $release['download_count']) ?></td><td class="mono"><?= adminEscape(substr((string) $release['apk_sha256'], 0, 16)) ?>…</td><td><?= adminEscape($release['created_at']) ?></td></tr><?php endforeach; ?>
                    <?= empty($data['releases']) ? adminTableEmpty(6) : '' ?>
                </tbody></table></div></section>
                <section class="panel"><div class="panel-head"><h2>BSC USDT 收款设置</h2></div><div class="panel-body">
                    <form method="post" class="settings-form"><?= adminHidden($csrf, 'settings.deposit.save', 'settings') ?><div class="field"><label for="deposit_address">平台收款钱包地址</label><input id="deposit_address" name="deposit_address" class="address-box" maxlength="42" required pattern="0x[0-9a-fA-F]{40}" value="<?= adminEscape($data['deposit_address'] ?? '') ?>"></div><button class="btn primary">保存收款地址</button></form>
                </div></section>
                <section class="panel"><div class="panel-head"><h2>API 节点分流</h2><span class="muted">固定路径 /spxchat/api.php，按权重选择启用节点</span></div><div class="panel-body">
                    <form method="post" class="settings-form">
                        <?= adminHidden($csrf, 'settings.api_nodes.save', 'settings') ?>
                        <div class="field"><label for="api_nodes">节点列表</label><textarea id="api_nodes" name="api_nodes" rows="7" spellcheck="false" placeholder="https://70.39.201.191|10|on&#10;http://备用IP|1|on&#10;https://故障节点|1|off"><?= adminEscape($data['api_nodes_text'] ?? '') ?></textarea><span class="muted">每行格式：地址 | 权重 | on/off。地址可填写根地址、/spxchat 或 /spxchat/api.php，保存时会统一为根地址。HTTPS 自签证书必须随 App 内置并匹配对应节点。</span></div>
                        <div><button class="btn primary">保存节点分流</button></div>
                    </form>
                </div></section>
            <?php elseif ($section === 'profile'): ?>
                <section class="panel"><div class="panel-head"><h2>修改管理员密码</h2></div><div class="panel-body">
                    <form method="post" class="form-grid"><?= adminHidden($csrf, 'password.save', 'profile') ?><div class="field"><label for="current_password">当前密码</label><input id="current_password" name="current_password" type="password" autocomplete="current-password" required></div><div class="field"><label for="new_password">新密码（至少 12 位）</label><input id="new_password" name="new_password" type="password" minlength="12" maxlength="200" autocomplete="new-password" required></div><div><button class="btn primary">更新密码</button></div></form>
                </div></section>
            <?php endif; ?>
            <?php if (!empty($data['pagination']) && $data['pagination']['pages'] > 1): $pagination = $data['pagination']; $query = $_GET; unset($query['page']); $startPage = max(1, $pagination['page'] - 2); $endPage = min($pagination['pages'], $pagination['page'] + 2); ?>
                <nav class="pagination" aria-label="列表分页"><span class="page-info">共 <?= number_format($pagination['total']) ?> 条，第 <?= (int) $pagination['page'] ?> / <?= (int) $pagination['pages'] ?> 页</span><?php if ($pagination['page'] > 1): $query['page'] = $pagination['page'] - 1; ?><a href="admin.php?<?= adminEscape(http_build_query($query)) ?>" aria-label="上一页">上一页</a><?php endif; ?><?php for ($pageNumber = $startPage; $pageNumber <= $endPage; $pageNumber++): ?><?php if ($pageNumber === $pagination['page']): ?><span class="current" aria-current="page"><?= $pageNumber ?></span><?php else: $query['page'] = $pageNumber; ?><a href="admin.php?<?= adminEscape(http_build_query($query)) ?>"><?= $pageNumber ?></a><?php endif; ?><?php endfor; ?><?php if ($pagination['page'] < $pagination['pages']): $query['page'] = $pagination['page'] + 1; ?><a href="admin.php?<?= adminEscape(http_build_query($query)) ?>" aria-label="下一页">下一页</a><?php endif; ?></nav>
            <?php endif; ?>
        </div>
    </main>
</div>
<script>
const productImageInput=document.getElementById('images');
const productImagePreview=document.getElementById('image-preview');
if(productImageInput&&productImagePreview){productImageInput.addEventListener('change',()=>{productImagePreview.replaceChildren();for(const file of Array.from(productImageInput.files||[])){if(!file.type.startsWith('image/'))continue;const image=document.createElement('img');image.alt=file.name;image.src=URL.createObjectURL(file);image.onload=()=>URL.revokeObjectURL(image.src);productImagePreview.append(image);}});}
const userDetailModal=document.getElementById('user-detail-modal');
if(userDetailModal){userDetailModal.addEventListener('click',event=>{if(event.target===userDetailModal)window.location.href='admin.php?section=users';});document.addEventListener('keydown',event=>{if(event.key==='Escape')window.location.href='admin.php?section=users';});}
document.querySelectorAll('.trend-panel').forEach(panel=>{const tooltip=panel.querySelector('.trend-tooltip');const hide=()=>tooltip.classList.remove('visible');const show=(marker,x,y)=>{tooltip.textContent=marker.dataset.tooltip||'';tooltip.classList.add('visible');const bounds=panel.getBoundingClientRect();const left=Math.max(8,Math.min(x-bounds.left+10,panel.clientWidth-tooltip.offsetWidth-8));let top=y-bounds.top-tooltip.offsetHeight-10;if(top<8)top=Math.min(panel.clientHeight-tooltip.offsetHeight-8,y-bounds.top+14);tooltip.style.left=left+'px';tooltip.style.top=Math.max(8,top)+'px';};panel.addEventListener('pointermove',event=>{const marker=event.target.closest?.('.trend-marker');if(marker)show(marker,event.clientX,event.clientY);else hide();});panel.addEventListener('pointerdown',event=>{const marker=event.target.closest?.('.trend-marker');if(marker)show(marker,event.clientX,event.clientY);});panel.addEventListener('pointerleave',hide);panel.addEventListener('focusin',event=>{const marker=event.target.closest?.('.trend-marker');if(marker){const bounds=marker.getBoundingClientRect();show(marker,bounds.left+bounds.width/2,bounds.top);}});panel.addEventListener('focusout',hide);});
</script>
</body>
</html>
