<?php
declare(strict_types=1);
function installChatSchema(PDO $pdo): void
{
    foreach (['messages','chat_group_messages'] as $table) {
        $q=$pdo->query("SHOW COLUMNS FROM $table LIKE 'message_origin'");
        if (!$q->fetch()) $pdo->exec("ALTER TABLE $table ADD COLUMN message_origin VARCHAR(20) NOT NULL DEFAULT 'human'");
    }
    $pdo->exec("CREATE TABLE IF NOT EXISTS chat_scheduled_messages (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id BIGINT UNSIGNED NOT NULL,
        scope VARCHAR(10) NOT NULL, target_id BIGINT UNSIGNED NOT NULL, request_id VARCHAR(36) NOT NULL,
        message_type VARCHAR(20) NOT NULL, content TEXT NOT NULL, media_url VARCHAR(500) NULL,
        send_at DATETIME NOT NULL, status VARCHAR(20) NOT NULL DEFAULT 'pending', error_message VARCHAR(500) NULL,
        delivered_message_id BIGINT UNSIGNED NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, sent_at DATETIME NULL,
        UNIQUE KEY uq_schedule_request (user_id,request_id), INDEX idx_schedule_due(status,send_at), INDEX(user_id,id),
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $pdo->exec("CREATE TABLE IF NOT EXISTS chat_reply_rules (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, owner_user_id BIGINT UNSIGNED NOT NULL,
        group_id BIGINT UNSIGNED NOT NULL DEFAULT 0, keyword VARCHAR(100) NOT NULL DEFAULT '',
        match_mode VARCHAR(12) NOT NULL DEFAULT 'contains', reply_text TEXT NOT NULL,
        enabled TINYINT NOT NULL DEFAULT 1, cooldown_seconds INT NOT NULL DEFAULT 60,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX(owner_user_id,group_id), INDEX(group_id,enabled),
        FOREIGN KEY(owner_user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $pdo->exec("CREATE TABLE IF NOT EXISTS chat_reply_cooldowns (
        rule_id BIGINT UNSIGNED NOT NULL, conversation_key VARCHAR(64) NOT NULL, replied_at DATETIME NOT NULL,
        PRIMARY KEY(rule_id,conversation_key), FOREIGN KEY(rule_id) REFERENCES chat_reply_rules(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}
