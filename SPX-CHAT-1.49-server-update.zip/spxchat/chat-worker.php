<?php
declare(strict_types=1);
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require_once __DIR__.'/db.php';
require_once __DIR__.'/mall.php';
require_once __DIR__.'/ws-event.php';
require_once __DIR__.'/chat_automation.php';
try { echo json_encode(chatRunDue(db()),JSON_UNESCAPED_UNICODE).PHP_EOL; }
catch(Throwable $e) { error_log('Chat schedule worker: '.$e->getMessage()); exit(1); }
