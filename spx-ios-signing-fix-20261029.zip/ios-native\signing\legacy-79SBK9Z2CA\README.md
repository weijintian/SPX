# 归档：team 79SBK9Z2CA 的历史签名材料

这里存放的是**旧签名材料**，仅作留档，不参与任何构建。

| 文件 | 说明 |
|---|---|
| `5d5b2e930ea93ac67f7182269ab97cb5.p12` | 分发证书（含私钥） |
| `描述文件.mobileprovision` | App Store 描述文件，`application-identifier` = `79SBK9Z2CA.ce4c475e-98c7-45a1-a039-f25e31da8cbb`，到期 2027-06-23 |

## 为什么闲置

- 团队是 `79SBK9Z2CA`，而本项目自有账号团队是 `VX2SVTNSZ3`；
- 绑定的 App ID 是 `ce4c475e-98c7-45a1-a039-f25e31da8cbb`（UUID），不是项目的 `com.spx.chat.ios`；
- 因此无法为当前工程签名。

## 处理建议

1. 走自动签名（`SPX_SIGNING_MODE: "automatic"`）后可长期闲置，也可以直接删除；
2. 走手工签名时需要换成自有团队的新 `.p12` + 新描述文件。

一致性检查脚本会跳过 `legacy-*` 目录，并在输出里标注归档。

**注意**：`.p12` 口令不在本文件内，请勿在此记录任何口令、Key 或 Team Secret。
