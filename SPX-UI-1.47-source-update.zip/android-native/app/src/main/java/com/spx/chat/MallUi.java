package com.spx.chat;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

/** Shared presentation only; prices, eligibility and orders remain server controlled. */
final class MallUi {
    static final int BACKGROUND = Color.rgb(246, 248, 252);
    static final int INK = Color.rgb(24, 31, 51);
    static final int SECONDARY = Color.rgb(103, 113, 135);
    static final int PRIMARY = Color.rgb(45, 78, 207);
    static final int TINT = Color.rgb(235, 240, 255);
    static final int GOLD = Color.rgb(145, 95, 20);
    static final int GOLD_TINT = Color.rgb(255, 247, 226);
    static final int LINE = Color.rgb(226, 231, 241);

    private MallUi() {}

    static int dp(Context context, float value) {
        return Math.round(value * context.getResources().getDisplayMetrics().density);
    }

    static GradientDrawable surface(Context context, int color, int radius, boolean border) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setCornerRadius(dp(context, radius));
        if (border) shape.setStroke(dp(context, 1), LINE);
        return shape;
    }

    static GradientDrawable primaryButton(Context context) {
        GradientDrawable shape = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(66, 106, 232), Color.rgb(40, 70, 194)});
        shape.setCornerRadius(dp(context, 14));
        return shape;
    }

    static void touch(View view, int radius) {
        view.setForeground(new RippleDrawable(ColorStateList.valueOf(0x18355AEA), null, surface(view.getContext(), Color.WHITE, radius, false)));
        view.setFocusable(true);
    }

    static TextView badge(Context context, String label, boolean gold) {
        TextView badge = new TextView(context);
        badge.setText(label);
        badge.setTextSize(10);
        badge.setTextColor(gold ? GOLD : PRIMARY);
        badge.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        badge.setIncludeFontPadding(false);
        badge.setGravity(Gravity.CENTER);
        badge.setSingleLine(true);
        badge.setPadding(dp(context, 7), dp(context, 4), dp(context, 7), dp(context, 4));
        badge.setBackground(surface(context, gold ? GOLD_TINT : TINT, 5, false));
        return badge;
    }

    static View icon(Context context, String name, int color) {
        return new Icon(context, name, color);
    }

    static final class RatioFrame extends FrameLayout {
        private final float ratio;
        RatioFrame(Context context, float ratio) {
            super(context);
            this.ratio = ratio;
        }
        @Override protected void onMeasure(int widthSpec, int heightSpec) {
            int width = MeasureSpec.getSize(widthSpec);
            if (width > 0) heightSpec = MeasureSpec.makeMeasureSpec(Math.round(width * ratio), MeasureSpec.EXACTLY);
            super.onMeasure(widthSpec, heightSpec);
        }
    }

    private static final class Icon extends View {
        private final String name;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        Icon(Context context, String name, int color) {
            super(context);
            this.name = name;
            paint.setColor(color);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(1.7f);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeJoin(Paint.Join.ROUND);
            setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
        }
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float size = Math.min(getWidth(), getHeight());
            canvas.save();
            canvas.translate((getWidth() - size) / 2f, (getHeight() - size) / 2f);
            canvas.scale(size / 24f, size / 24f);
            if ("search".equals(name)) {
                canvas.drawCircle(10.5f, 10.5f, 6.2f, paint);
                canvas.drawLine(15, 15, 20, 20, paint);
            } else if ("store".equals(name)) {
                canvas.drawRoundRect(new RectF(4, 10, 20, 21), 1.5f, 1.5f, paint);
                Path roof = new Path(); roof.moveTo(3, 10); roof.lineTo(5, 4); roof.lineTo(19, 4); roof.lineTo(21, 10); roof.close();
                canvas.drawPath(roof, paint);
                canvas.drawLine(8, 5, 7, 10, paint); canvas.drawLine(16, 5, 17, 10, paint);
                canvas.drawRect(10, 14, 15, 21, paint);
            } else if ("pin".equals(name)) {
                Path pin = new Path(); pin.moveTo(12, 22); pin.cubicTo(8, 17, 4, 13, 4, 9); pin.cubicTo(4, 0, 20, 0, 20, 9); pin.cubicTo(20, 13, 16, 17, 12, 22);
                canvas.drawPath(pin, paint); canvas.drawCircle(12, 9, 2.7f, paint);
            } else if ("order".equals(name)) {
                canvas.drawRoundRect(new RectF(5, 3, 19, 21), 2, 2, paint);
                canvas.drawLine(9, 8, 15, 8, paint); canvas.drawLine(9, 12, 15, 12, paint); canvas.drawLine(9, 16, 13, 16, paint);
            } else if ("gift".equals(name)) {
                canvas.drawRect(4, 11, 20, 21, paint); canvas.drawRoundRect(new RectF(3, 7, 21, 11), 1, 1, paint);
                canvas.drawLine(12, 7, 12, 21, paint);
                canvas.drawOval(new RectF(6, 2, 12, 7), paint); canvas.drawOval(new RectF(12, 2, 18, 7), paint);
            } else if ("grid".equals(name)) {
                for (int y = 4; y <= 14; y += 10) for (int x = 4; x <= 14; x += 10) canvas.drawRoundRect(new RectF(x, y, x + 6, y + 6), 1, 1, paint);
            } else if ("arrow".equals(name)) {
                canvas.drawLine(5, 12, 19, 12, paint); canvas.drawLine(14, 7, 19, 12, paint); canvas.drawLine(14, 17, 19, 12, paint);
            } else {
                canvas.drawRoundRect(new RectF(4, 7, 20, 21), 2, 2, paint);
                canvas.drawArc(new RectF(8, 2, 16, 12), 180, 180, false, paint);
            }
            canvas.restore();
        }
    }
}
