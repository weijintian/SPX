package com.spx.chat;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

public final class ChatCache extends SQLiteOpenHelper {
    private static final String NAME = "spx_chat_cache.db";
    private static final int VERSION = 2;
    private static ChatCache instance;
    private final Context context;

    public static synchronized ChatCache get(Context context) {
        if (instance == null) instance = new ChatCache(context.getApplicationContext());
        return instance;
    }

    private ChatCache(Context context) {
        super(context, NAME, null, VERSION);
        this.context = context;
    }

    private String sessionScope(String scope) {
        // A different server or login must never reuse another session's messages.
        try {
            String identity = ApiClient.baseUrl(context) + "\n" + ApiClient.token(context);
            byte[] hash = MessageDigest.getInstance("SHA-256").digest(identity.getBytes(StandardCharsets.UTF_8));
            StringBuilder key = new StringBuilder(scope).append(":");
            for (byte value : hash) key.append(String.format(java.util.Locale.US, "%02x", value & 255));
            return key.toString();
        } catch (java.security.NoSuchAlgorithmException impossible) {
            throw new IllegalStateException(impossible);
        }
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE messages (scope TEXT NOT NULL, conversation_id INTEGER NOT NULL, message_id INTEGER NOT NULL, payload TEXT NOT NULL, PRIMARY KEY(scope, conversation_id, message_id))");
        db.execSQL("CREATE TABLE hidden_messages (scope TEXT NOT NULL, conversation_id INTEGER NOT NULL, message_id INTEGER NOT NULL, PRIMARY KEY(scope, conversation_id, message_id))");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) db.execSQL("CREATE TABLE IF NOT EXISTS hidden_messages (scope TEXT NOT NULL, conversation_id INTEGER NOT NULL, message_id INTEGER NOT NULL, PRIMARY KEY(scope, conversation_id, message_id))");
    }

    public synchronized void put(String scope, int conversationId, JSONObject message) {
        int id = message.optInt("id");
        if (id <= 0) return;
        ContentValues values = new ContentValues();
        values.put("scope", sessionScope(scope));
        values.put("conversation_id", conversationId);
        values.put("message_id", id);
        values.put("payload", message.toString());
        getWritableDatabase().insertWithOnConflict("messages", null, values, SQLiteDatabase.CONFLICT_REPLACE);
    }

    public synchronized JSONArray list(String scope, int conversationId) {
        JSONArray result = new JSONArray();
        ArrayList<JSONObject> newest = new ArrayList<>();
        try (Cursor cursor = getReadableDatabase().query("messages", new String[]{"payload"}, "scope=? AND conversation_id=?", new String[]{sessionScope(scope), String.valueOf(conversationId)}, null, null, "message_id DESC", "200")) {
            while (cursor.moveToNext()) newest.add(new JSONObject(cursor.getString(0)));
        } catch (Exception ignored) { }
        for (int i = newest.size() - 1; i >= 0; i--) result.put(newest.get(i));
        return result;
    }

    public synchronized void clear(String scope, int conversationId) {
        getWritableDatabase().delete("messages", "scope=? AND conversation_id=?", new String[]{sessionScope(scope), String.valueOf(conversationId)});
    }

    public synchronized void remove(String scope, int conversationId, int messageId) {
        getWritableDatabase().delete("messages", "scope=? AND conversation_id=? AND message_id=?", new String[]{sessionScope(scope), String.valueOf(conversationId), String.valueOf(messageId)});
    }

    public synchronized void hide(String scope, int conversationId, int messageId) {
        ContentValues values = new ContentValues();
        values.put("scope", sessionScope(scope));
        values.put("conversation_id", conversationId);
        values.put("message_id", messageId);
        getWritableDatabase().insertWithOnConflict("hidden_messages", null, values, SQLiteDatabase.CONFLICT_IGNORE);
        remove(scope, conversationId, messageId);
    }

    public synchronized boolean isHidden(String scope, int conversationId, int messageId) {
        try (Cursor cursor = getReadableDatabase().query("hidden_messages", new String[]{"message_id"}, "scope=? AND conversation_id=? AND message_id=?", new String[]{sessionScope(scope), String.valueOf(conversationId), String.valueOf(messageId)}, null, null, null, "1")) {
            return cursor.moveToFirst();
        }
    }
}
