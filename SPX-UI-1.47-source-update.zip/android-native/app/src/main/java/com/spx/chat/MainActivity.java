package com.spx.chat;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.ClipboardManager;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.provider.MediaStore;
import android.provider.Settings;
import android.os.Bundle;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Button;
import android.widget.NumberPicker;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.LinearLayout;
import android.widget.HorizontalScrollView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;
import android.widget.MediaController;
import android.widget.ProgressBar;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.media.MediaMetadataRetriever;
import android.media.ToneGenerator;
import android.view.MotionEvent;
import android.text.InputType;
import android.text.TextWatcher;
import android.text.Editable;

import java.io.InputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.Locale;
import java.security.MessageDigest;
import org.json.JSONArray;
import org.json.JSONObject;

import androidx.core.content.FileProvider;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.DecodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.RGBLuminanceSource;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.common.HybridBinarizer;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

public class MainActivity extends Activity {
    private static final long UPDATE_CHECK_INTERVAL_MS = 60_000L;
    private static final long PRESENCE_HEARTBEAT_INTERVAL_MS = 30_000L;
    private static final int NOTIFICATION_PERMISSION_REQUEST = 4101;
    private static final int CAMERA_PERMISSION_REQUEST = 4102;
    private static final int RECORD_AUDIO_PERMISSION_REQUEST = 4103;
    private static final int PICK_SCAN_IMAGE = 4104;
    private static final int CAMERA_CHAT_PHOTO = 3001;
    private static final int CAMERA_CHAT_VIDEO = 3002;
    private static final int CAMERA_AVATAR = 3003;
    private static final String CHAT_NOTIFICATION_CHANNEL = "spx_chat_messages";
    private static final int BLUE = Color.rgb(45, 78, 207);
    private static final int TEXT = Color.rgb(24, 31, 51);
    private static final int MUTED = Color.rgb(103, 113, 135);
    private static final int BG = Color.rgb(246, 248, 252);
    private FrameLayout content;
    private LinearLayout bottomNav;
    private int activeTab = 0;
    private boolean chatWindowOpen = false;
    private boolean focusChatListTopAfterRefresh = false;
    private ListView activeChatListView;
    private LinearLayout activeChatRows;
    private ViewRowsAdapter activeChatRowsAdapter;
    private EditText activeChatSearchField;
    private int savedChatListPosition = 0;
    private int savedChatListOffset = 0;
    private String openedChatListSnapshot = "";
    private boolean restoreChatListPosition = false;
    private boolean askWindowOpen = false;
    private boolean subPageOpen = false;
    private boolean walletAssetDetailOpen = false;
    private int previousTab = 0;
    private String userName = "";
    private String userEmail = "";
    private String appLanguage = "zh-CN";
    private int currentUserId = 0;
    private String currentUserSpxId = "";
    private String addressName = "";
    private String addressPhone = "";
    private String addressDetail = "";
    private String addressProvince = "福建省";
    private String addressCity = "泉州市";
    private String addressDistrict = "石狮市";
    private JSONArray areaData;
    private int productColumns = 2;
    private String mallSearchQuery = "";
    private String mallProductFilter = "all";
    private int mallProductsPage=1;
    private int mallProductsCount=0;
    private JSONArray[] mallLoadedPages;
    private MallCommerce commerce;
    private MallCommerce commerce(){if(commerce==null)commerce=new MallCommerce(this);return commerce;}
    private boolean showingCommerce;
    void mallShow(LinearLayout root){showingCommerce=true;try{openSubPage(root,2);}finally{showingCommerce=false;}}
    void mallExit(){subPageOpen=false;setBottomNavVisible(true);renderTab(2);}
    int mallUserId(){return currentUserId;}
    void mallContact(JSONObject shop){openMerchantContact(shop);}
    void mallPin(LinearLayout body,View button){
        View scroll=(View)body.getParent();
        if(scroll.getParent() instanceof LinearLayout){body.removeView(button);LinearLayout root=(LinearLayout)scroll.getParent();LinearLayout bar=new LinearLayout(this);bar.setPadding(dp(14),dp(8),dp(14),dp(14));bar.setBackgroundColor(Color.WHITE);bar.addView(button,new LinearLayout.LayoutParams(-1,dp(52)));root.addView(bar);}
    }

    private Uri userAvatarUri;
    private Uri groupAvatarUri;
    private String activeGroupName = "";
    private Uri chatBackgroundUri;
    private int chatBackgroundPreset = 0;
    private int pendingPicker = 0;
    private SharedPreferences preferences;
    private boolean authRegisterMode = false;
    private boolean splashFinished = false;
    private ChatWebSocket chatSocket;
    private int activeChatId = 0;
    private int activePeerUserId = 0;
    private int activeGroupId = 0;
    private int activeDetailGroupId = 0;
    private boolean activeGroupCanManage = false;
    private boolean activeGroupCanViewMemberDetails = true;
    private int lastMessageId = 0;
    private int chatSocketGeneration = 0;
    private int pendingMediaChatId = 0;
    private int pendingMediaGroupId = 0;
    private View pendingMediaBubble;
    private String pendingMediaClientId = "";
    private final Set<String> renderedMessageIds = new HashSet<>();
    private final ArrayList<Integer> activeMentionUserIds = new ArrayList<>();
    private final Map<String, View> renderedMessageViews = new HashMap<>();
    private LinearLayout activeMessageList;
    private ScrollView activeMessageScroll;
    private TextView newMessagesButton;
    private String activeChatName = "";
    private String activeChatAvatar = "";
    private String activeChatC1 = "#A8C0FF";
    private String activeChatC2 = "#3F5EFB";
    private boolean sendingMessage = false;
    private String remoteAvatarUrl = "";
    private ToneGenerator messageTone;
    private View incomingMessageBanner;
    private final Handler incomingBannerHandler = new Handler(Looper.getMainLooper());
    private final Runnable hideIncomingBanner = () -> {
        if (incomingMessageBanner != null && incomingMessageBanner.getParent() instanceof ViewGroup) {
            ((ViewGroup) incomingMessageBanner.getParent()).removeView(incomingMessageBanner);
        }
        incomingMessageBanner = null;
    };
    private boolean realtimeReady = false;
    private int pendingChatUnread = 0;
    private EditText activeMessageInput;
    private ChatCache chatCache;
    private String deviceId;
    private boolean appInForeground = true;
    private final Handler updateCheckHandler = new Handler(Looper.getMainLooper());
    private final Handler presenceHandler = new Handler(Looper.getMainLooper());
    private final Runnable presenceHeartbeat = new Runnable() {
        @Override public void run() {
            if (appInForeground && currentUserId > 0) {
                updatePresence(true);
                presenceHandler.postDelayed(this, PRESENCE_HEARTBEAT_INTERVAL_MS);
            }
        }
    };
    private final Runnable periodicUpdateCheck = new Runnable() {
        @Override public void run() {
            if (appInForeground) {
                checkAppUpdate(false);
                updateCheckHandler.postDelayed(this, UPDATE_CHECK_INTERVAL_MS);
            }
        }
    };
    private int pendingCameraRequest;
    private Uri pendingCaptureUri;
    private MediaRecorder voiceRecorder;
    private MediaPlayer activeVoicePlayer;
    private TextView activeVoiceBubble;
    private String activeVoiceLabel = "";
    private File voiceRecordingFile;
    private long voiceRecordingStartedAt;
    private boolean voiceRecordingCancelled;
    private int pendingVoiceDurationSeconds;
    private boolean updateCheckInProgress = false;
    private boolean updatePromptShown = false;
    private boolean updateRequired = false;
    private boolean waitingForInstallPermission = false;
    private JSONObject availableRelease;
    private File pendingUpdateApk;
    private int pendingSharedProductId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.WHITE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        preferences = getSharedPreferences("spx_profile", MODE_PRIVATE);
        appLanguage = resolveAppLanguage();
        activeChatName = t("default_chat_name");
        activeChatAvatar = t("ui_chat_avatar");
        createChatNotificationChannel();
        chatCache = ChatCache.get(this);
        deviceId = preferences.getString("device_id", "");
        if (deviceId.isEmpty()) {
            deviceId = UUID.randomUUID().toString();
            preferences.edit().putString("device_id", deviceId).apply();
        }
        userName = preferences.getString("user_name", t("default_user_name"));
        userEmail = preferences.getString("user_email", "");
        currentUserId = preferences.getInt("current_user_id", 0);
        addressName = preferences.getString("address_name", "");
        addressPhone = preferences.getString("address_phone", "");
        addressDetail = preferences.getString("address_detail", "");
        addressProvince = preferences.getString("address_province", "福建省");
        addressCity = preferences.getString("address_city", "泉州市");
        addressDistrict = preferences.getString("address_district", "石狮市");
        String avatarUri = preferences.getString("avatar_uri", "");
        if (!avatarUri.isEmpty()) userAvatarUri = Uri.parse(avatarUri);
        remoteAvatarUrl = preferences.getString("avatar_url", "");
        String backgroundUri = preferences.getString("chat_background_uri", "");
        if (!backgroundUri.isEmpty()) chatBackgroundUri = Uri.parse(backgroundUri);
        chatBackgroundPreset = preferences.getInt("chat_background_preset", 0);
        if (savedInstanceState == null) readSharedProduct(getIntent());
        else pendingSharedProductId = savedInstanceState.getInt("pending_shared_product_id", 0);
        showSplashPage();
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        outState.putInt("pending_shared_product_id", pendingSharedProductId);
        super.onSaveInstanceState(outState);
    }

    private void readSharedProduct(Intent intent) {
        Uri link = intent == null ? null : intent.getData();
        if (link == null || !"spx".equals(link.getScheme()) || !"product".equals(link.getHost())) return;
        try { int id = Integer.parseInt(link.getQueryParameter("id")); if (id > 0) pendingSharedProductId = id; } catch (Exception ignored) { }
    }
    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent); setIntent(intent); readSharedProduct(intent);
        if (bottomNav != null && !ApiClient.token(this).isEmpty()) openPendingSharedProduct();
    }
    private void openPendingSharedProduct() {
        if (pendingSharedProductId <= 0 || updateRequired || ApiClient.token(this).isEmpty()) return;
        int id = pendingSharedProductId; pendingSharedProductId = 0;
        if (chatWindowOpen) closeChatWindow();
        if (commerce != null) commerce.reset();
        openProductDetail(id, "", "", "", "");
    }

    private void showSplashPage() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);
        ImageView splash = new ImageView(this);
        splash.setImageResource(com.spx.chat.R.drawable.spx_im_splash);
        splash.setScaleType(ImageView.ScaleType.FIT_XY);
        splash.setContentDescription(t("ui_splash_desc"));
        root.addView(splash, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        new Handler(Looper.getMainLooper()).postDelayed(this::continueAfterSplash, 2000);
    }

    private void continueAfterSplash() {
        if (splashFinished) return;
        splashFinished = true;
        ApiClient.refreshConfig(this, () -> {
            if (ApiClient.token(this).isEmpty()) {
                showAuthenticationPage();
            } else {
                buildApp();
                ApiClient.get(this, "me", null, new ApiClient.Callback() {
                    @Override public void onSuccess(Object data) {
                        if (data instanceof JSONObject) {
                            JSONObject user = (JSONObject) data;
                            userName = user.optString("nickname", userName);
                            currentUserId = user.optInt("id", currentUserId);
                            currentUserSpxId = user.optString("spx_id", currentUserSpxId);
                            remoteAvatarUrl = user.optString("avatar_url", remoteAvatarUrl);
                            userEmail = user.optString("email", userEmail);
                            String serverAvatar = user.optString("avatar_url", "");
                            if (!serverAvatar.isEmpty()) saveRemoteAvatar(serverAvatar, false);
                            preferences.edit().putString("user_name", userName).putString("user_email", userEmail).putInt("current_user_id", currentUserId).apply();
                            syncDeviceInfo();
                        }
                    }
                    @Override public void onError(String message) {
                        ApiClient.clearToken(MainActivity.this);
                        showAuthenticationPage();
                    }
                });
            }
        });
    }

    private void showAuthLoading() {
        LinearLayout page = column();
        page.setGravity(Gravity.CENTER);
        page.setBackgroundColor(BG);
        page.addView(bodyText(t("app_loading"), 15, MUTED));
        setContentView(page);
    }

    private void showAuthenticationPage() {
        bottomNav = null;
        chatWindowOpen = false;
        askWindowOpen = false;
        subPageOpen = false;
        renderAuthenticationPage();
        checkAppUpdate(false);
    }

    private void renderAuthenticationPage() {
        LinearLayout root = column();
        root.setBackgroundColor(BG);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout page = column();
        page.setPadding(dp(28), dp(42), dp(28), dp(36));

        TextView brand = bodyText("SPX IM", 17, BLUE);
        brand.setTypeface(null, android.graphics.Typeface.BOLD);
        page.addView(brand, new LinearLayout.LayoutParams(-1, dp(34)));
        TextView title = bodyText(t(authRegisterMode ? "create_account" : "welcome_back"), 30, TEXT);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(-1, dp(48));
        titleParams.setMargins(0, dp(26), 0, 0);
        page.addView(title, titleParams);
        page.addView(bodyText(t(authRegisterMode ? "register_subtitle" : "login_subtitle"), 14, MUTED));

        LinearLayout tabs = row();
        tabs.setPadding(dp(4), dp(4), dp(4), dp(4));
        tabs.setBackground(round(Color.rgb(232, 236, 244), 14));
        TextView loginTab = centeredText(t("login"), 15, authRegisterMode ? MUTED : TEXT);
        TextView registerTab = centeredText(t("register"), 15, authRegisterMode ? Color.WHITE : MUTED);
        loginTab.setBackground(authRegisterMode ? round(Color.TRANSPARENT, 11) : round(Color.WHITE, 11));
        registerTab.setBackground(authRegisterMode ? round(BLUE, 11) : round(Color.TRANSPARENT, 11));
        tabs.addView(loginTab, new LinearLayout.LayoutParams(0, dp(44), 1));
        tabs.addView(registerTab, new LinearLayout.LayoutParams(0, dp(44), 1));
        LinearLayout.LayoutParams tabsParams = new LinearLayout.LayoutParams(-1, dp(52));
        tabsParams.setMargins(0, dp(28), 0, dp(24));
        page.addView(tabs, tabsParams);
        loginTab.setOnClickListener(v -> { authRegisterMode = false; renderAuthenticationPage(); });
        registerTab.setOnClickListener(v -> { authRegisterMode = true; renderAuthenticationPage(); });

        TextView status = bodyText("", 13, Color.rgb(207, 67, 67));
        if (authRegisterMode) buildRegisterForm(page, status);
        else buildLoginForm(page, status);
        scroll.addView(page, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

    private void buildLoginForm(LinearLayout page, TextView status) {
        EditText account = formInput(t("username_or_email"), "");
        account.setSingleLine(true);
        EditText password = formInput(t("password"), "");
        password.setInputType(129);
        page.addView(account);
        page.addView(password);
        addAuthStatus(page, status);
        TextView submit = authPrimaryButton(t("login"));
        page.addView(submit, authButtonParams());
        submit.setOnClickListener(v -> {
            String login = account.getText().toString().trim();
            String secret = password.getText().toString();
            if (login.isEmpty() || secret.isEmpty()) { showAuthError(status, t("login_fields_required")); return; }
            submit.setEnabled(false);
            JSONObject body = new JSONObject();
            try { body.put("username", login); body.put("password", secret); addDeviceInfo(body); } catch (Exception ignored) { }
            ApiClient.post(this, "auth.login", body, authCallback(submit, status));
        });
        TextView forgot = centeredText(t("forgot_password"), 14, BLUE);
        forgot.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        forgot.setOnClickListener(v -> openForgotPasswordPage());
        page.addView(forgot, new LinearLayout.LayoutParams(-1, dp(42)));
    }

    private void openForgotPasswordPage() {
        LinearLayout root = subPageRoot(t("forgot_password_title"), t("forgot_password_subtitle"));
        LinearLayout body = column();
        body.setPadding(dp(20), dp(24), dp(20), dp(20));
        EditText email = formInput(t("registered_email"), "");
        email.setInputType(33);
        EditText code = formInput(t("email_code"), "");
        code.setInputType(2);
        LinearLayout codeRow = row();
        codeRow.setGravity(Gravity.CENTER_VERTICAL);
        codeRow.addView(code, new LinearLayout.LayoutParams(0, dp(56), 1));
        TextView sendCode = centeredText(t("get_code"), 13, BLUE);
        sendCode.setBackground(round(Color.rgb(238, 242, 255), 12));
        LinearLayout.LayoutParams codeParams = new LinearLayout.LayoutParams(dp(112), dp(56));
        codeParams.setMargins(dp(8), 0, 0, 0);
        codeRow.addView(sendCode, codeParams);
        EditText newPassword = formInput(t("new_password"), "");
        newPassword.setInputType(129);
        TextView status = bodyText("", 13, Color.rgb(207, 67, 67));
        body.addView(email);
        LinearLayout.LayoutParams codeRowParams = new LinearLayout.LayoutParams(-1, dp(56));
        codeRowParams.bottomMargin = dp(12);
        body.addView(codeRow, codeRowParams);
        body.addView(newPassword);
        body.addView(status, new LinearLayout.LayoutParams(-1, dp(38)));
        sendCode.setOnClickListener(v -> {
            String address = email.getText().toString().trim();
            if (!android.util.Patterns.EMAIL_ADDRESS.matcher(address).matches()) { status.setText(t("email_invalid")); return; }
            sendCode.setEnabled(false);
            JSONObject request = new JSONObject();
            try { request.put("email", address); request.put("purpose", "password_reset"); } catch (Exception ignored) { }
            ApiClient.post(this, "auth.email.code", request, new ApiClient.Callback() {
                @Override public void onSuccess(Object data) { status.setText(t("code_sent_check")); startCodeCountdown(sendCode, 60); }
                @Override public void onError(String message) { sendCode.setEnabled(true); status.setText(message); }
            });
        });
        TextView submit = centeredText(t("reset_password"), 15, Color.WHITE);
        submit.setBackground(round(BLUE, 14));
        submit.setOnClickListener(v -> {
            String address = email.getText().toString().trim();
            String verificationCode = code.getText().toString().trim();
            String secret = newPassword.getText().toString();
            if (!android.util.Patterns.EMAIL_ADDRESS.matcher(address).matches()) { status.setText(t("email_invalid")); return; }
            if (verificationCode.length() != 6) { status.setText(t("code_invalid")); return; }
            if (secret.length() < 6) { status.setText(t("password_short")); return; }
            submit.setEnabled(false);
            JSONObject request = new JSONObject();
            try { request.put("email", address); request.put("code", verificationCode); request.put("new_password", secret); } catch (Exception ignored) { submit.setEnabled(true); return; }
            ApiClient.post(this, "auth.password.reset", request, new ApiClient.Callback() {
                @Override public void onSuccess(Object data) { submit.setEnabled(true); toast(t("password_reset_login")); authRegisterMode = false; showAuthenticationPage(); }
                @Override public void onError(String message) { submit.setEnabled(true); status.setText(message); }
            });
        });
        LinearLayout.LayoutParams submitParams = new LinearLayout.LayoutParams(-1, dp(50));
        submitParams.setMargins(0, dp(8), 0, 0);
        body.addView(submit, submitParams);
        root.addView(body, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

    private void buildRegisterForm(LinearLayout page, TextView status) {
        EditText email = formInput(t("email_address"), "");
        email.setInputType(33);
        email.setSingleLine(true);
        EditText code = formInput(t("email_code"), "");
        code.setInputType(2);
        LinearLayout codeRow = row();
        codeRow.setGravity(Gravity.CENTER_VERTICAL);
        codeRow.addView(code, new LinearLayout.LayoutParams(0, dp(56), 1));
        TextView sendCode = centeredText(t("send_code"), 13, BLUE);
        sendCode.setBackground(stroke(Color.WHITE, Color.rgb(211, 220, 239), 12, 1));
        LinearLayout.LayoutParams sendParams = new LinearLayout.LayoutParams(dp(112), dp(56));
        sendParams.setMargins(dp(8), 0, 0, 0);
        codeRow.addView(sendCode, sendParams);
        EditText username = formInput(t("set_username"), "");
        username.setSingleLine(true);
        EditText password = formInput(t("set_password"), "");
        password.setInputType(129);
        EditText invite = formInput(t("invite_spx_id_optional"), "");
        invite.setSingleLine(true);
        page.addView(email);
        LinearLayout.LayoutParams codeRowParams = new LinearLayout.LayoutParams(-1, dp(56));
        codeRowParams.bottomMargin = dp(12);
        page.addView(codeRow, codeRowParams);
        page.addView(username);
        page.addView(password);
        page.addView(invite);

        sendCode.setOnClickListener(v -> {
            String address = email.getText().toString().trim();
            if (!android.util.Patterns.EMAIL_ADDRESS.matcher(address).matches()) { showAuthError(status, t("email_invalid")); return; }
            sendCode.setEnabled(false);
            JSONObject body = new JSONObject();
            try { body.put("email", address); } catch (Exception ignored) { }
            ApiClient.post(this, "auth.email.code", body, new ApiClient.Callback() {
                @Override public void onSuccess(Object data) {
                    showAuthError(status, t("code_sent_view"));
                    startCodeCountdown(sendCode, 60);
                }
                @Override public void onError(String message) { sendCode.setEnabled(true); sendCode.setText(t("send_code")); showAuthError(status, message); }
            });
        });

        addAuthStatus(page, status);
        TextView submit = authPrimaryButton(t("verify_register"));
        page.addView(submit, authButtonParams());
        submit.setOnClickListener(v -> {
            String address = email.getText().toString().trim();
            String verifyCode = code.getText().toString().trim();
            String account = username.getText().toString().trim();
            String secret = password.getText().toString();
            if (!android.util.Patterns.EMAIL_ADDRESS.matcher(address).matches()) { showAuthError(status, t("email_invalid")); return; }
            if (verifyCode.length() != 6) { showAuthError(status, t("email_code_invalid")); return; }
            if (account.isEmpty()) { showAuthError(status, t("username_required")); return; }
            if (secret.length() < 6) { showAuthError(status, t("password_short")); return; }
            submit.setEnabled(false);
            JSONObject body = new JSONObject();
            try {
                body.put("email", address);
                body.put("code", verifyCode);
                body.put("username", account);
                body.put("password", secret);
                addDeviceInfo(body);
                String inviteCode = invite.getText().toString().trim();
                if (!inviteCode.isEmpty()) body.put("invite_code", inviteCode);
            } catch (Exception ignored) { }
            ApiClient.post(this, "auth.register", body, authCallback(submit, status));
        });
    }

    private ApiClient.Callback authCallback(View submit, TextView status) {
        return new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                submit.setEnabled(true);
                if (!(data instanceof JSONObject)) { showAuthError(status, t("server_format_invalid")); return; }
                JSONObject result = (JSONObject) data;
                String token = result.optString("token", "");
                if (token.isEmpty()) { showAuthError(status, t("login_token_missing")); return; }
                ApiClient.saveToken(MainActivity.this, token);
                JSONObject user = result.optJSONObject("user");
                if (user != null) {
                    currentUserId = user.optInt("id", currentUserId);
                    userName = user.optString("nickname", user.optString("username", userName));
                    currentUserSpxId = user.optString("spx_id", currentUserSpxId);
                    userEmail = user.optString("email", userEmail);
                    preferences.edit().putString("user_name", userName).putString("user_email", userEmail).putInt("current_user_id", currentUserId).apply();
                }
                getWindow().setStatusBarColor(Color.WHITE);
                getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
                toast(t(authRegisterMode ? "register_success" : "login_success"));
                buildApp();
            }
            @Override public void onError(String message) {
                submit.setEnabled(true);
                showAuthError(status, message);
            }
        };
    }

    private void startCodeCountdown(TextView button, int seconds) {
        Handler handler = new Handler(Looper.getMainLooper());
        int[] remaining = {seconds};
        Runnable[] tick = new Runnable[1];
        tick[0] = () -> {
            remaining[0]--;
            if (remaining[0] <= 0) {
                button.setEnabled(true);
                button.setText(t("resend"));
            } else {
                button.setText(remaining[0] + " " + t("seconds_retry"));
                handler.postDelayed(tick[0], 1000);
            }
        };
        button.setText(seconds + " " + t("seconds_retry"));
        handler.postDelayed(tick[0], 1000);
    }

    private void addDeviceInfo(JSONObject body) throws Exception {
        body.put("device_id", deviceId);
        body.put("device_model", android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL);
        body.put("android_version", android.os.Build.VERSION.RELEASE);
        body.put("app_version", getPackageManager().getPackageInfo(getPackageName(), 0).versionName);
    }

    private void syncDeviceInfo() {
        JSONObject body = new JSONObject();
        try {
            addDeviceInfo(body);
        } catch (Exception ignored) {
            return;
        }
        ApiClient.post(this, "profile.update", body, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) { }
            @Override public void onError(String message) { }
        });
    }

    private void startPresenceTracking() {
        if (currentUserId <= 0 || ApiClient.token(this).isEmpty()) return;
        presenceHandler.removeCallbacks(presenceHeartbeat);
        updatePresence(true);
        presenceHandler.postDelayed(presenceHeartbeat, PRESENCE_HEARTBEAT_INTERVAL_MS);
    }

    private void updatePresence(boolean online) {
        if (currentUserId <= 0 || ApiClient.token(this).isEmpty()) return;
        JSONObject request = new JSONObject();
        try { request.put("device_id", deviceId); request.put("online", online); }
        catch (Exception ignored) { return; }
        ApiClient.post(this, "presence.update", request, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) { }
            @Override public void onError(String message) { }
        });
    }

    private void addAuthStatus(LinearLayout page, TextView status) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, dp(38));
        params.setMargins(0, dp(2), 0, dp(4));
        page.addView(status, params);
    }

    private void showAuthError(TextView status, String message) {
        status.setText(message);
        status.setTextColor(message.contains(t("code_sent_check")) ? Color.rgb(37, 145, 103) : Color.rgb(207, 67, 67));
    }

    private TextView authPrimaryButton(String label) {
        TextView button = centeredText(label, 16, Color.WHITE);
        button.setTypeface(null, android.graphics.Typeface.BOLD);
        button.setBackground(round(BLUE, 14));
        return button;
    }

    private LinearLayout.LayoutParams authButtonParams() {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, dp(52));
        params.setMargins(0, dp(8), 0, dp(18));
        return params;
    }

    @Override
    public void onBackPressed() {
        if (updateRequired) {
            toast(t("update_required"));
            return;
        }
        if (chatWindowOpen) {
            closeChatWindow();
            return;
        }
        if (askWindowOpen) {
            closeAskWindow();
            return;
        }
        if (subPageOpen) {
            closeSubPage();
            return;
        }
        super.onBackPressed();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (merchantForm != null && merchantForm.activityResult(requestCode,resultCode,data)) return;
        if(commerce!=null&&commerce.activityResult(requestCode,resultCode,data))return;
        if (requestCode == PICK_MALL_IMAGE) {
            final EditText target = mallUploadTarget;
            mallUploadTarget = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null && target != null) {
                toast("正在上传图片…");
                ApiClient.upload(this, "merchant.media.upload", data.getData(), new ApiClient.Callback() {
                    @Override public void onSuccess(Object value) {
                        if (!(value instanceof JSONObject)) return;
                        String url = ((JSONObject) value).optString("url");
                        String previous = target.getText().toString().trim();
                        target.setText(previous.isEmpty() ? url : previous + "\n" + url);
                        toast("图片已上传");
                    }
                    @Override public void onError(String message) { toast(message); }
                });
            }
            return;
        }
        IntentResult scanResult = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (scanResult != null) {
            String scanned = scanResult.getContents();
            if (scanned != null) handleScannedCode(scanned);
            return;
        }
        if (requestCode == PICK_SCAN_IMAGE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) decodeQrFromImage(data.getData());
            return;
        }
        if (requestCode == CAMERA_CHAT_PHOTO || requestCode == CAMERA_CHAT_VIDEO || requestCode == CAMERA_AVATAR) {
            Uri captured = pendingCaptureUri;
            pendingCaptureUri = null;
            if (resultCode == RESULT_OK && captured != null) {
                if (requestCode == CAMERA_AVATAR) uploadAvatar(captured);
                else uploadChatMedia(captured);
            } else {
                if (captured != null) getContentResolver().delete(captured, null, null);
                if (requestCode != CAMERA_AVATAR) sendingMessage = false;
            }
            return;
        }
        if ((requestCode == 1001 || requestCode == 1002) && resultCode == RESULT_OK && data != null && data.getData() != null) {
            if (requestCode == 1002) {
                chatBackgroundUri = data.getData();
                chatBackgroundPreset = 0;
                preferences.edit().putString("chat_background_uri", chatBackgroundUri.toString()).apply();
                preferences.edit().putInt("chat_background_preset", 0).apply();
                toast(t("background_updated"));
                return;
            }
            uploadAvatar(data.getData());
        }
        if ((requestCode == 2001 || requestCode == 2002) && resultCode == RESULT_OK && data != null && data.getData() != null) {
            uploadChatMedia(data.getData());
        }
        if ((requestCode == 2001 || requestCode == 2002) && resultCode != RESULT_OK) sendingMessage = false;
        if (requestCode == 1003 && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri selectedAvatar = data.getData();
            ApiClient.upload(this, "upload.message", selectedAvatar, new ApiClient.Callback() {
                @Override public void onSuccess(Object result) {
                    if (!(result instanceof JSONObject)) { toast(t("group_avatar_upload_failed")); return; }
                    String url = ((JSONObject) result).optString("url", "");
                    JSONObject request = new JSONObject();
                    try { request.put("group_id", activeDetailGroupId); request.put("avatar_url", url); } catch (Exception ignored) { return; }
                    ApiClient.post(MainActivity.this, "groups.update", request, new ApiClient.Callback() {
                        @Override public void onSuccess(Object value) {
                            preferences.edit().putString("group_avatar_" + activeGroupName, url).apply();
                            JSONArray snapshot = readChatSnapshot();
                            for (int i = 0; i < snapshot.length(); i++) {
                                JSONObject group = snapshot.optJSONObject(i);
                                if (group == null || !"group".equals(group.optString("kind")) || group.optInt("id") != activeDetailGroupId) continue;
                                try { group.put("avatar_url", url); } catch (Exception ignored) { }
                            }
                            storeChatSnapshot(snapshot);
                            toast(t("group_avatar_updated"));
                            openGroupDetailPage(activeGroupName, t("ui_group_avatar"), "#5B7CFA", "#9B5DE5");
                        }
                        @Override public void onError(String message) { toast(message); }
                    });
                }
                @Override public void onError(String message) { toast(message); }
            });
        }
    }

    private void handleScannedCode(String value) {
        String scanned = value == null ? "" : value.trim();
        if (scanned.startsWith("SPXGROUP:")) {
            joinGroupByCode(scanned.substring("SPXGROUP:".length()).trim());
        } else if (scanned.matches("(?i)[a-z0-9]{6}")) {
            joinGroupByCode(scanned);
        } else {
            String spxId = scanned.startsWith("SPXUSER:") ? scanned.substring("SPXUSER:".length()).trim() : scanned;
            if (spxId.startsWith("http://") || spxId.startsWith("https://")) {
                try {
                    String invite = Uri.parse(spxId).getQueryParameter("invite");
                    if (invite != null) spxId = invite;
                } catch (Exception ignored) { }
            }
            if (spxId.isEmpty()) toast(t("qr_unrecognized"));
            else openScannedUser(spxId);
        }
    }

    private void openScannedUser(String spxId) {
        final String lookupId = spxId;
        Map<String, String> params = new HashMap<>();
        params.put("q", lookupId);
        ApiClient.get(this, "contacts.search", params, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                if (!(data instanceof JSONArray)) { toast(t("qr_user_not_found")); return; }
                JSONArray matches = (JSONArray) data;
                JSONObject match = null;
                for (int i = 0; i < matches.length(); i++) {
                    JSONObject candidate = matches.optJSONObject(i);
                    if (candidate != null && (candidate.optString("spx_id").equalsIgnoreCase(lookupId)
                            || String.valueOf(candidate.optInt("id")).equals(lookupId))) { match = candidate; break; }
                }
                if (match == null) { toast(t("qr_user_not_found")); return; }
                int userId = match.optInt("id");
                loadUserProfile(userId, new UserProfileCallback() {
                    @Override public void onProfile(JSONObject profile) { openFriendProfilePage(profile); }
                    @Override public void onError(String message) { toast(t("ui_profile_load_failed", message)); }
                });
            }
            @Override public void onError(String message) { toast(t("ui_profile_load_failed", message)); }
        });
    }

    private void decodeQrFromImage(Uri uri) {
        new Thread(() -> {
            String decoded = null;
            try {
                BitmapFactory.Options bounds = new BitmapFactory.Options();
                bounds.inJustDecodeBounds = true;
                try (InputStream input = getContentResolver().openInputStream(uri)) { BitmapFactory.decodeStream(input, null, bounds); }
                int sample = 1;
                while (Math.max(bounds.outWidth, bounds.outHeight) / sample > 2048) sample *= 2;
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inSampleSize = sample;
                Bitmap bitmap;
                try (InputStream input = getContentResolver().openInputStream(uri)) { bitmap = BitmapFactory.decodeStream(input, null, options); }
                if (bitmap == null) throw new IllegalArgumentException("selected image could not be read");
                int width = bitmap.getWidth(), height = bitmap.getHeight();
                int[] pixels = new int[width * height];
                bitmap.getPixels(pixels, 0, width, 0, 0, width, height);
                MultiFormatReader reader = new MultiFormatReader();
                Map<DecodeHintType, Object> hints = new HashMap<>();
                hints.put(DecodeHintType.POSSIBLE_FORMATS, java.util.Collections.singletonList(BarcodeFormat.QR_CODE));
                decoded = reader.decode(new BinaryBitmap(new HybridBinarizer(new RGBLuminanceSource(width, height, pixels))), hints).getText();
                bitmap.recycle();
            } catch (Exception ignored) { }
            String result = decoded;
            runOnUiThread(() -> {
                if (result == null || result.trim().isEmpty()) toast(t("qr_image_empty"));
                else handleScannedCode(result);
            });
        }).start();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == RECORD_AUDIO_PERMISSION_REQUEST) {
            if (grantResults.length == 0 || grantResults[0] != android.content.pm.PackageManager.PERMISSION_GRANTED)
                toast(t("microphone_required"));
            return;
        }
        if (requestCode != CAMERA_PERMISSION_REQUEST) return;
        boolean granted = grantResults.length > 0;
        for (int result : grantResults) granted &= result == android.content.pm.PackageManager.PERMISSION_GRANTED;
        int cameraRequest = pendingCameraRequest;
        pendingCameraRequest = 0;
        if (granted) launchCamera(cameraRequest);
        else {
            if (cameraRequest != CAMERA_AVATAR) sendingMessage = false;
            toast(t("camera_required"));
        }
    }

    private void uploadAvatar(Uri uri) {
        ApiClient.upload(this, "upload.avatar", uri, new ApiClient.Callback() {
            @Override public void onSuccess(Object result) {
                if (result instanceof JSONObject) {
                    String url = ((JSONObject) result).optString("url", "");
                    if (!url.isEmpty()) saveRemoteAvatar(url, true);
                    else { toast(t("avatar_url_missing")); return; }
                }
                toast(t("avatar_saved"));
            }
            @Override public void onError(String message) { toast(message); }
        });
    }

    private void uploadChatMedia(Uri uri) {
        pendingMediaBubble = showPendingMediaBubble(uri);
        ApiClient.upload(this, "upload.message", uri, new ApiClient.Callback() {
            @Override public void onSuccess(Object result) { sendUploadedMedia(result instanceof JSONObject ? (JSONObject) result : null); }
            @Override public void onError(String message) {
                sendingMessage = false;
                if (pendingMediaBubble instanceof TextView) ((TextView) pendingMediaBubble).setText(t("send_failed"));
                toast(message);
            }
        });
    }

    private View showPendingMediaBubble(Uri uri) {
        if (activeMessageList == null || activeMessageScroll == null) return null;
        String mime = getContentResolver().getType(uri);
        boolean video = mime != null && mime.startsWith("video/");
        FrameLayout bubble = new FrameLayout(this);
        bubble.setBackground(round(Color.WHITE, 12));
        TextView label = centeredText(video ? t("ui_media_uploading_video") : t("ui_media_uploading_image"), 13, MUTED);
        bubble.addView(label, new FrameLayout.LayoutParams(-1, -1));
        ProgressBar spinner = new ProgressBar(this);
        FrameLayout.LayoutParams spinnerParams = new FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER);
        spinnerParams.bottomMargin = dp(28);
        bubble.addView(spinner, spinnerParams);
        LinearLayout line = row();
        line.setGravity(Gravity.RIGHT);
        line.addView(bubble, new LinearLayout.LayoutParams(dp(210), dp(100)));
        activeMessageList.addView(line, new LinearLayout.LayoutParams(-1, -2));
        return label;
    }

    private void removePendingMediaBubble() {
        if (pendingMediaBubble == null) return;
        View label = pendingMediaBubble;
        View bubble = label.getParent() instanceof View ? (View) label.getParent() : null;
        View line = bubble != null && bubble.getParent() instanceof View ? (View) bubble.getParent() : null;
        if (line != null && line.getParent() instanceof ViewGroup) ((ViewGroup) line.getParent()).removeView(line);
        pendingMediaBubble = null;
    }

    private void requestCamera(int requestCode) {
        pendingCameraRequest = requestCode;
        java.util.ArrayList<String> required = new java.util.ArrayList<>();
        if (checkSelfPermission(android.Manifest.permission.CAMERA) != android.content.pm.PackageManager.PERMISSION_GRANTED)
            required.add(android.Manifest.permission.CAMERA);
        if (Build.VERSION.SDK_INT <= 28 && checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != android.content.pm.PackageManager.PERMISSION_GRANTED)
            required.add(android.Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if (required.isEmpty()) launchCamera(requestCode);
        else requestPermissions(required.toArray(new String[0]), CAMERA_PERMISSION_REQUEST);
    }

    private void launchCamera(int requestCode) {
        boolean video = requestCode == CAMERA_CHAT_VIDEO;
        boolean avatar = requestCode == CAMERA_AVATAR;
        String mime = video ? "video/mp4" : "image/jpeg";
        ContentValues values = new ContentValues();
        values.put(MediaStore.MediaColumns.DISPLAY_NAME, "spx_" + System.currentTimeMillis() + (video ? ".mp4" : ".jpg"));
        values.put(MediaStore.MediaColumns.MIME_TYPE, mime);
        if (Build.VERSION.SDK_INT >= 29) values.put(MediaStore.MediaColumns.RELATIVE_PATH, video ? "Movies/SPX IM" : "Pictures/SPX IM");
        Uri collection = video ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        try {
            pendingCaptureUri = getContentResolver().insert(collection, values);
            if (pendingCaptureUri == null) throw new IllegalStateException("media file could not be created");
            Intent intent = new Intent(video ? MediaStore.ACTION_VIDEO_CAPTURE : MediaStore.ACTION_IMAGE_CAPTURE);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, pendingCaptureUri);
            intent.setClipData(ClipData.newRawUri("SPX media capture", pendingCaptureUri));
            intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            if (video) intent.putExtra(MediaStore.EXTRA_VIDEO_QUALITY, 1);
            startActivityForResult(intent, requestCode);
        } catch (Exception exception) {
            if (pendingCaptureUri != null) getContentResolver().delete(pendingCaptureUri, null, null);
            pendingCaptureUri = null;
            if (!avatar) sendingMessage = false;
            toast(t("camera_start_failed"));
        }
    }

    private boolean startVoiceRecording() {
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO}, RECORD_AUDIO_PERMISSION_REQUEST);
            toast(t("record_permission_retry"));
            return false;
        }
        try {
            voiceRecordingFile = new File(getCacheDir(), "voice_" + UUID.randomUUID() + ".3gp");
            voiceRecorder = Build.VERSION.SDK_INT >= 31 ? new MediaRecorder(this) : new MediaRecorder();
            voiceRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            voiceRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
            voiceRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
            voiceRecorder.setMaxDuration(60000);
            voiceRecorder.setOutputFile(voiceRecordingFile.getAbsolutePath());
            voiceRecorder.setOnInfoListener((recorder, what, extra) -> {
                if (what == MediaRecorder.MEDIA_RECORDER_INFO_MAX_DURATION_REACHED) finishVoiceRecording(true);
            });
            voiceRecorder.prepare();
            voiceRecorder.start();
            voiceRecordingStartedAt = System.currentTimeMillis();
            voiceRecordingCancelled = false;
            return true;
        } catch (Exception exception) {
            releaseVoiceRecorder();
            if (voiceRecordingFile != null) voiceRecordingFile.delete();
            toast(t("record_start_failed"));
            return false;
        }
    }

    private void finishVoiceRecording(boolean send) {
        if (voiceRecorder == null) return;
        File recording = voiceRecordingFile;
        long durationMs = System.currentTimeMillis() - voiceRecordingStartedAt;
        try { voiceRecorder.stop(); } catch (Exception ignored) { send = false; }
        releaseVoiceRecorder();
        voiceRecordingFile = null;
        if (!send || voiceRecordingCancelled || recording == null || !recording.isFile() || durationMs < 700) {
            if (recording != null) recording.delete();
            if (send && durationMs < 700) toast(t("record_too_short"));
            return;
        }
        pendingMediaChatId = activeChatId;
        pendingMediaGroupId = activeGroupId;
        pendingMediaClientId = UUID.randomUUID().toString();
        pendingVoiceDurationSeconds = Math.max(1, (int) Math.ceil(durationMs / 1000.0));
        sendingMessage = true;
        ApiClient.upload(this, "upload.message", Uri.fromFile(recording), new ApiClient.Callback() {
            @Override public void onSuccess(Object result) {
                recording.delete();
                sendUploadedMedia(result instanceof JSONObject ? (JSONObject) result : null);
            }
            @Override public void onError(String message) { recording.delete(); sendingMessage = false; toast(message); }
        });
    }

    private void releaseVoiceRecorder() {
        if (voiceRecorder == null) return;
        try { voiceRecorder.reset(); } catch (Exception ignored) { }
        try { voiceRecorder.release(); } catch (Exception ignored) { }
        voiceRecorder = null;
    }

    private void buildApp() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BG);

        content = new FrameLayout(this);
        content.setBackgroundColor(BG);
        root.addView(content, new FrameLayout.LayoutParams(-1, -1));

        bottomNav = new LinearLayout(this);
        bottomNav.setOrientation(LinearLayout.HORIZONTAL);
        bottomNav.setGravity(Gravity.CENTER_VERTICAL);
        bottomNav.setPadding(dp(8), dp(6), dp(8), dp(10));
        bottomNav.setBackground(stroke(Color.WHITE, MallUi.LINE, 24, 1));
        bottomNav.setElevation(dp(5));
        FrameLayout.LayoutParams navParams = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        bottomNav.setMinimumHeight(dp(76));
        navParams.setMargins(dp(18), 0, dp(18), dp(12));
        root.addView(bottomNav, navParams);

        String[] labels = {t("chats"), t("contacts"), t("explore"), t("me")};
        String[] icons = {"◉", "♙", "◇", "●"};
        for (int i = 0; i < labels.length; i++) {
            final int tab = i;
            TextView item = navItem(icons[i], labels[i]);
            item.setText(labels[i]);
            AppNavIcon navigationIcon = new AppNavIcon(i, dp(23), MUTED);
            item.setCompoundDrawablesWithIntrinsicBounds(null, navigationIcon, null, null);
            item.setCompoundDrawablePadding(dp(4));
            item.setContentDescription(labels[i]);
            item.setOnClickListener(v -> switchTab(tab));
            bottomNav.addView(item, new LinearLayout.LayoutParams(0, -2, 1));
        }
        bottomNav.addOnLayoutChangeListener((v, left, top, right, bottom, oldLeft, oldTop, oldRight, oldBottom) -> {
            int height = bottom - top + dp(24);
            if (bottomNav.getVisibility() == View.VISIBLE && content.getPaddingBottom() != height)
                content.setPadding(0, 0, 0, height);
        });
        setContentView(root);
        switchTab(0);
        startRealtimeSocket();
        requestChatNotificationPermission();
        startPresenceTracking();
        checkAppUpdate(false);
        openPendingSharedProduct();
    }

    @Override protected void onResume() {
        super.onResume();
        boolean returnedToForeground = !appInForeground;
        appInForeground = true;
        updateCheckHandler.removeCallbacks(periodicUpdateCheck);
        updateCheckHandler.postDelayed(periodicUpdateCheck, UPDATE_CHECK_INTERVAL_MS);
        if (waitingForInstallPermission) {
            waitingForInstallPermission = false;
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O || getPackageManager().canRequestPackageInstalls()) {
                if (pendingUpdateApk != null && pendingUpdateApk.isFile()) installDownloadedApk(pendingUpdateApk);
            } else {
                toast(t("install_permission_missing"));
            }
        }
        if (currentUserId > 0) startPresenceTracking();
        if (returnedToForeground) checkAppUpdate(false);
    }

    @Override protected void onPause() {
        appInForeground = false;
        updateCheckHandler.removeCallbacks(periodicUpdateCheck);
        presenceHandler.removeCallbacks(presenceHeartbeat);
        if (currentUserId > 0) updatePresence(false);
        super.onPause();
    }

    @Override protected void onStop() {
        stopActiveVoicePlayback();
        super.onStop();
    }

    private void createChatNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationChannel channel = new NotificationChannel(CHAT_NOTIFICATION_CHANNEL, t("new_message"), NotificationManager.IMPORTANCE_HIGH);
        channel.setDescription(t("ui_chat_notification_desc"));
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) manager.createNotificationChannel(channel);
    }

    private void requestChatNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION_REQUEST);
        }
    }

    private void showChatNotification(JSONObject message, int chatId, int groupId) {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) return;
        String sender = message.optString("nickname", t("new_message"));
        String content = message.optString("content", t("ui_received_message"));
        if ("image".equals(message.optString("message_type"))) content = t("ui_image_placeholder");
        else if ("video".equals(message.optString("message_type"))) content = t("ui_video_placeholder");
        Intent intent = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pending = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHAT_NOTIFICATION_CHANNEL)
                : new Notification.Builder(this);
        boolean mentioned = isCurrentUserMentioned(message);
        builder.setSmallIcon(android.R.drawable.sym_action_chat)
                .setContentTitle(mentioned ? t("mentioned_you") : (groupId > 0 ? sender + " · " + t("chat_group") : sender))
                .setContentText(content)
                .setPriority(mentioned ? Notification.PRIORITY_MAX : Notification.PRIORITY_DEFAULT)
                .setAutoCancel(true)
                .setContentIntent(pending);
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) manager.notify((groupId > 0 ? groupId : chatId) + 50000, builder.build());
    }

    private void showIncomingMessageBanner(JSONObject message, int chatId, int groupId) {
        if (content == null || isFinishing()) return;
        incomingBannerHandler.removeCallbacks(hideIncomingBanner);
        if (incomingMessageBanner != null && incomingMessageBanner.getParent() instanceof ViewGroup) {
            ((ViewGroup) incomingMessageBanner.getParent()).removeView(incomingMessageBanner);
        }
        boolean group = groupId > 0;
        String sender = normalizeOptionalText(message.optString(group ? "group_name" : "nickname", ""));
        if (group && sender.isEmpty()) sender = cachedGroupName(groupId);
        if (sender.isEmpty()) sender = group ? t("chat_group") : t("new_message");
        String preview = normalizeOptionalText(message.optString("content", t("ui_received_message")));
        String type = message.optString("message_type", "text");
        if ("image".equals(type)) preview = t("ui_image_placeholder");
        else if ("video".equals(type)) preview = t("ui_video_placeholder");
        else if ("voice".equals(type)) preview = t("ui_voice_placeholder");

        LinearLayout banner = row();
        banner.setGravity(Gravity.CENTER_VERTICAL);
        banner.setPadding(dp(16), dp(10), dp(16), dp(10));
        banner.setBackground(stroke(Color.WHITE, BLUE, 14, 1));
        final String bannerSender = sender;
        String avatarText = bannerSender.isEmpty() ? t("ui_new_avatar") : bannerSender.substring(0, 1);
        banner.addView(avatarWithRemoteImage(avatarText, message.optString("avatar_url", ""), "#A8C0FF", "#3F5EFB", 42));
        LinearLayout text = column();
        text.setPadding(dp(12), 0, dp(8), 0);
        TextView title = bodyText(sender, 15, TEXT);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setSingleLine(true);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        text.addView(title);
        TextView body = bodyText(preview, 13, MUTED);
        body.setSingleLine(true);
        body.setEllipsize(android.text.TextUtils.TruncateAt.END);
        text.addView(body);
        banner.addView(text, new LinearLayout.LayoutParams(0, -2, 1));
        banner.setOnClickListener(v -> {
            incomingBannerHandler.removeCallbacks(hideIncomingBanner);
            hideIncomingBanner.run();
            openChatWindow(chatId, groupId, bannerSender, avatarText, group ? "group" : "online", "#A8C0FF", "#3F5EFB");
        });
        incomingMessageBanner = banner;
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP);
        params.setMargins(dp(12), dp(10), dp(12), 0);
        content.addView(banner, params);
        incomingBannerHandler.postDelayed(hideIncomingBanner, 4500L);
    }

    private TextView navItem(String icon, String label) {
        TextView view = new TextView(this);
        view.setGravity(Gravity.CENTER);
        view.setSingleLine(true);
        view.setEllipsize(android.text.TextUtils.TruncateAt.END);
        view.setText(icon + "\n" + label);
        view.setTextSize(12);
        view.setTextColor(MUTED);
        view.setTypeface(android.graphics.Typeface.create("sans-serif-medium", 0));
        view.setPadding(0, dp(4), 0, dp(4));
        view.setLineSpacing(dp(3), 1f);
        return view;
    }

    private void setBottomNavVisible(boolean visible) {
        bottomNav.setVisibility(visible ? View.VISIBLE : View.GONE);
        content.setPadding(0, 0, 0, visible ? bottomNav.getHeight() + dp(24) : 0);
    }

    private void switchTab(int tab) {
        if(commerce!=null)commerce.reset();
        activeTab = tab;
        for (int i = 0; i < bottomNav.getChildCount(); i++) {
            TextView item = (TextView) bottomNav.getChildAt(i);
            item.setTextColor(i == tab ? BLUE : MUTED);
            item.setBackground(round(i == tab ? MallUi.TINT : Color.TRANSPARENT, 18));
            item.setSelected(i == tab);
            if (item.getCompoundDrawables()[1] instanceof AppNavIcon)
                ((AppNavIcon)item.getCompoundDrawables()[1]).color(i == tab ? BLUE : MUTED);
        }
        renderTab(tab);
    }

    private void renderTab(int tab) {
        content.removeAllViews();
        if (tab == 0) buildChatPage();
        else if (tab == 1) buildContactsPage();
        else if (tab == 2) buildEcoPage();
        else buildProfilePage();
    }

    private View userAvatarView(int size) {
        TextView fallback = avatar(userName.substring(0, 1), "#3F5EFB", "#9B5DE5", size);
        if (!remoteAvatarUrl.isEmpty()) {
            ImageView image = new ImageView(this);
            image.setScaleType(ImageView.ScaleType.CENTER_CROP);
            image.setBackground(round(Color.WHITE, 50));
            image.setClipToOutline(true);
            image.setLayoutParams(new LinearLayout.LayoutParams(dp(size), dp(size)));
            loadAvatarInto(image, remoteAvatarUrl);
            return image;
        }
        if (userAvatarUri != null) {
            ImageView image = new ImageView(this);
            image.setScaleType(ImageView.ScaleType.CENTER_CROP);
            GradientDrawable border = new GradientDrawable();
            border.setColor(Color.WHITE);
            border.setCornerRadius(dp(50));
            border.setStroke(dp(3), Color.WHITE);
            image.setBackground(border);
            image.setClipToOutline(true);
            image.setLayoutParams(new LinearLayout.LayoutParams(dp(size), dp(size)));
            image.post(() -> {
                java.io.InputStream input = null;
                try {
                    input = getContentResolver().openInputStream(userAvatarUri);
                    android.graphics.drawable.Drawable drawable = android.graphics.drawable.Drawable.createFromStream(input, userAvatarUri.toString());
                    image.setImageDrawable(drawable);
                } catch (Exception ignored) {
                } finally {
                    if (input != null) {
                        try {
                            input.close();
                        } catch (Exception ignored) {
                        }
                    }
                }
            });
            return image;
        }
        return fallback;
    }

    private void saveRemoteAvatar(String url, boolean refresh) {
        remoteAvatarUrl = url;
        preferences.edit().putString("avatar_url", url).apply();
        invalidateAvatarCache(url);
        if (refresh && bottomNav != null) runOnUiThread(() -> renderTab(3));
    }

    private File avatarCacheFile(String url) {
        return new File(new File(getFilesDir(), "avatar-cache"), Integer.toHexString(url.hashCode()));
    }

    private void invalidateAvatarCache(String url) {
        if (url == null || url.isEmpty()) return;
        avatarCacheFile(url).delete();
    }

    private String resolveAssetUrl(String value) {
        String url = normalizeOptionalText(value);
        if (url.isEmpty()) return url;
        if (url.matches("(?i)^https?://.*$")) {
            try {
                URL parsed = new URL(url);
                String path = parsed.getPath();
                if (path.startsWith("/uploads/") || path.startsWith("/avatars/")) {
                    return parsed.getProtocol() + "://" + parsed.getAuthority() + "/spxchat" + path;
                }
            } catch (Exception ignored) { }
            return url;
        }
        String base = ApiClient.connectionBaseUrl(this).replaceAll("/+$", "");
        if (url.startsWith("/spxchat/")) return base.endsWith("/spxchat") ? base + url.substring("/spxchat".length()) : base + url;
        if (url.startsWith("/")) return (base.endsWith("/spxchat") ? base : base + "/spxchat") + url;
        return (base.endsWith("/spxchat") ? base : base + "/spxchat") + "/" + url;
    }

    private void loadAvatarInto(ImageView image, String url) {
        final String assetUrl = resolveAssetUrl(url);
        if (assetUrl.isEmpty()) return;
        File cache = avatarCacheFile(assetUrl);
        boolean cacheFresh = cache.isFile() && System.currentTimeMillis() - cache.lastModified() < 5 * 60 * 1000L;
        if (cache.isFile()) {
            Bitmap cached = BitmapFactory.decodeFile(cache.getAbsolutePath());
            if (cached != null) {
                image.setImageBitmap(cached);
                image.setVisibility(View.VISIBLE);
                if (cacheFresh) return;
            }
        }
        new Thread(() -> {
            HttpURLConnection connection = null;
            File temporary = new File(cache.getParentFile(), cache.getName() + "." + UUID.randomUUID() + ".part");
            try {
                connection = ApiClient.openConnection(this, assetUrl);
                connection.setConnectTimeout(8000);
                connection.setReadTimeout(15000);
                File directory = cache.getParentFile();
                if (directory != null && !directory.exists()) directory.mkdirs();
                try (InputStream input = connection.getInputStream(); FileOutputStream output = new FileOutputStream(temporary)) {
                    byte[] buffer = new byte[8192];
                    int count;
                    while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
                }
                if (!temporary.renameTo(cache)) {
                    cache.delete();
                    if (!temporary.renameTo(cache)) throw new IllegalStateException("avatar cache write failed");
                }
                Bitmap bitmap = BitmapFactory.decodeFile(cache.getAbsolutePath());
                if (bitmap != null) runOnUiThread(() -> { image.setImageBitmap(bitmap); image.setVisibility(View.VISIBLE); });
            } catch (Exception ignored) { }
            finally {
                temporary.delete();
                if (connection != null) connection.disconnect();
            }
        }).start();
    }

    private void chooseAvatar() {
        new AlertDialog.Builder(this).setTitle(t("choose_avatar")).setItems(new String[]{t("gallery"), t("take_photo")}, (dialog, which) -> {
            if (which == 1) requestCamera(CAMERA_AVATAR);
            else openImagePicker(1001);
        }).show();
    }

    private void openImagePicker(int requestCode) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        startActivityForResult(intent, requestCode);
    }

    private void chooseChatBackground() {
        pendingPicker = 1002;
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        startActivityForResult(intent, 1002);
    }

    private JSONArray loadAreaData() {
        if (areaData != null) return areaData;
        try {
            InputStream input = getAssets().open("area.json");
            java.io.ByteArrayOutputStream output = new java.io.ByteArrayOutputStream();
            byte[] buffer = new byte[4096];
            int length;
            while ((length = input.read(buffer)) != -1) output.write(buffer, 0, length);
            input.close();
            areaData = new JSONArray(new String(output.toByteArray(), "UTF-8"));
        } catch (Exception ignored) {
            areaData = new JSONArray();
        }
        return areaData;
    }

    private String[] areaNames(JSONArray items) {
        String[] names = new String[items.length()];
        for (int i = 0; i < items.length(); i++) names[i] = items.optJSONObject(i).optString("name");
        return names;
    }

    private JSONArray areaChildren(JSONArray items, int index) {
        JSONObject item = items.optJSONObject(index);
        if (item == null || item.optJSONArray("children") == null) return new JSONArray();
        return item.optJSONArray("children");
    }

    private int areaIndex(JSONArray items, String name) {
        for (int i = 0; i < items.length(); i++) {
            if (name.equals(items.optJSONObject(i).optString("name"))) return i;
        }
        return 0;
    }

    private void showQrDialog(String value) {
        LinearLayout box = column();
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(dp(24), dp(24), dp(24), dp(28));
        TextView title = centeredText(t("ui_qr_title"), 19, TEXT);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        box.addView(title, new LinearLayout.LayoutParams(-1, dp(38)));
        ImageView qr = new ImageView(this);
        qr.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        qr.setPadding(dp(18), dp(18), dp(18), dp(18));
        qr.setBackgroundColor(Color.WHITE);
        try {
            BitMatrix matrix = new MultiFormatWriter().encode("SPXUSER:" + value, BarcodeFormat.QR_CODE, dp(230), dp(230));
            Bitmap bitmap = Bitmap.createBitmap(matrix.getWidth(), matrix.getHeight(), Bitmap.Config.ARGB_8888);
            for (int x = 0; x < matrix.getWidth(); x++) {
                for (int y = 0; y < matrix.getHeight(); y++) {
                    bitmap.setPixel(x, y, matrix.get(x, y) ? Color.BLACK : Color.WHITE);
                }
            }
            qr.setImageBitmap(bitmap);
        } catch (Exception ignored) {
            qr.setImageResource(android.R.drawable.ic_menu_help);
        }
        box.addView(qr, new LinearLayout.LayoutParams(dp(260), dp(260)));
        box.addView(centeredText(t("ui_qr_hint"), 14, MUTED));
        box.addView(centeredText(value, 13, BLUE));
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(box);
        dialog.setCanceledOnTouchOutside(true);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(round(Color.WHITE, 22));
            dialog.getWindow().setGravity(Gravity.CENTER);
        }
        dialog.show();
        if (dialog.getWindow() != null) dialog.getWindow().setLayout(dp(320), WindowManager.LayoutParams.WRAP_CONTENT);
    }

    private void openProfileEditPage() {
        LinearLayout root = subPageRoot(t("profile_edit"), t("ui_profile_edit_subtitle"));
        LinearLayout body = column();
        body.setGravity(Gravity.CENTER_HORIZONTAL);
        body.setPadding(dp(20), dp(24), dp(20), dp(20));
        View editAvatar = userAvatarView(96);
        editAvatar.setOnClickListener(v -> chooseAvatar());
        body.addView(editAvatar, new LinearLayout.LayoutParams(dp(96), dp(96)));
        TextView avatarHint = centeredText(t("change_avatar"), 13, MUTED);
        body.addView(avatarHint, new LinearLayout.LayoutParams(-1, dp(34)));
        TextView fixedId = bodyText(t("ui_profile_id_fixed", currentUserSpxId), 14, BLUE);
        fixedId.setPadding(dp(14), dp(12), dp(14), dp(12));
        fixedId.setBackground(round(Color.rgb(238, 242, 255), 12));
        fixedId.setOnClickListener(v -> copyText(currentUserSpxId, "SPX ID"));
        body.addView(fixedId);
        EditText nameInput = new EditText(this);
        nameInput.setText(userName);
        nameInput.setHint(t("nickname_input"));
        nameInput.setTextSize(16);
        nameInput.setSingleLine(true);
        nameInput.setPadding(dp(14), 0, dp(14), 0);
        nameInput.setBackground(round(Color.WHITE, 14));
        body.addView(nameInput, new LinearLayout.LayoutParams(-1, dp(54)));
        TextView save = centeredText(t("save_profile"), 15, Color.WHITE);
        save.setTypeface(null, android.graphics.Typeface.BOLD);
        save.setBackground(round(BLUE, 14));
        save.setOnClickListener(v -> {
            String name = nameInput.getText().toString().trim();
            JSONObject request = new JSONObject();
            try { if (!name.isEmpty()) request.put("nickname", name); }
            catch (Exception ignored) { return; }
            ApiClient.post(this, "profile.update", request, new ApiClient.Callback() {
                @Override public void onSuccess(Object data) {
                    if (data instanceof JSONObject) {
                        currentUserSpxId = ((JSONObject) data).optString("spx_id", currentUserSpxId);
                        userName = ((JSONObject) data).optString("nickname", userName);
                        preferences.edit().putString("user_name", userName).apply();
                    }
                    closeSubPage();
                    toast(t("profile_saved"));
                }
                @Override public void onError(String message) { toast(message); }
            });
        });
        LinearLayout.LayoutParams saveParams = new LinearLayout.LayoutParams(-1, dp(48));
        saveParams.setMargins(0, dp(16), 0, 0);
        body.addView(save, saveParams);
        root.addView(body, new LinearLayout.LayoutParams(-1, 0, 1));
        openSubPage(root, 3);
    }

    private void copyText(String value, String label) {
        if (value == null || value.isEmpty()) { toast(t("ui_copy_unavailable", label)); return; }
        ClipboardManager manager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        manager.setPrimaryClip(ClipData.newPlainText(label, value));
        toast(t("ui_copied", label));
    }

    private void openEmailRegisterPage() {
        LinearLayout root = subPageRoot(t("email_register_title"), t("email_register_subtitle"));
        LinearLayout form = column();
        form.setPadding(dp(20), dp(24), dp(20), dp(20));
        EditText email = formInput(t("email_address"), "");
        email.setInputType(33);
        EditText code = formInput(t("email_code"), "");
        code.setInputType(2);
        LinearLayout codeRow = row();
        codeRow.setGravity(Gravity.CENTER_VERTICAL);
        codeRow.addView(code, new LinearLayout.LayoutParams(0, dp(56), 1));
        TextView sendCode = centeredText(t("send_code"), 13, BLUE);
        sendCode.setBackground(round(Color.rgb(238, 242, 255), 12));
        LinearLayout.LayoutParams sendParams = new LinearLayout.LayoutParams(dp(112), dp(56));
        sendParams.setMargins(dp(8), 0, 0, 0);
        codeRow.addView(sendCode, sendParams);
        EditText username = formInput(t("username"), "");
        username.setSingleLine(true);
        EditText nickname = formInput(t("nickname_optional"), "");
        nickname.setSingleLine(true);
        EditText password = formInput(t("password_minimum"), "");
        password.setInputType(129);
        EditText invite = formInput(t("invite_spx_id_optional"), "");
        TextView submit = centeredText(t("verify_register"), 15, Color.WHITE);
        submit.setTypeface(null, android.graphics.Typeface.BOLD);
        submit.setBackground(round(BLUE, 14));

        sendCode.setOnClickListener(v -> {
            String address = email.getText().toString().trim();
            if (address.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(address).matches()) {
                toast(t("email_invalid"));
                return;
            }
            sendCode.setEnabled(false);
            JSONObject body = new JSONObject();
            try { body.put("email", address); } catch (Exception ignored) { }
            ApiClient.post(this, "auth.email.code", body, new ApiClient.Callback() {
                @Override public void onSuccess(Object data) {
                    sendCode.setEnabled(true);
                    toast(t("code_sent_check"));
                }
                @Override public void onError(String message) {
                    sendCode.setEnabled(true);
                    toast(message);
                }
            });
        });

        submit.setOnClickListener(v -> {
            String address = email.getText().toString().trim();
            String verifyCode = code.getText().toString().trim();
            String account = username.getText().toString().trim();
            String secret = password.getText().toString();
            if (!android.util.Patterns.EMAIL_ADDRESS.matcher(address).matches()) { toast(t("email_invalid")); return; }
            if (verifyCode.length() != 6) { toast(t("email_code_invalid")); return; }
            if (account.isEmpty()) { toast(t("username_required")); return; }
            if (secret.length() < 6) { toast(t("password_short")); return; }
            submit.setEnabled(false);
            JSONObject body = new JSONObject();
            try {
                body.put("email", address);
                body.put("code", verifyCode);
                body.put("username", account);
                body.put("nickname", nickname.getText().toString().trim());
                body.put("password", secret);
                addDeviceInfo(body);
                String inviteCode = invite.getText().toString().trim();
                if (!inviteCode.isEmpty()) body.put("invite_code", inviteCode);
            } catch (Exception ignored) { }
            ApiClient.post(this, "auth.register", body, new ApiClient.Callback() {
                @Override public void onSuccess(Object data) {
                    submit.setEnabled(true);
                    if (data instanceof JSONObject) {
                        JSONObject result = (JSONObject) data;
                        ApiClient.saveToken(MainActivity.this, result.optString("token"));
                        JSONObject user = result.optJSONObject("user");
                        if (user != null) {
                            userName = user.optString("nickname", account);
                            currentUserId = user.optInt("id", currentUserId);
                            currentUserSpxId = user.optString("spx_id", currentUserSpxId);
                            preferences.edit().putString("user_name", userName).putInt("current_user_id", currentUserId).apply();
                        }
                    }
                    closeSubPage();
                    renderTab(3);
                    toast(t("register_success"));
                }
                @Override public void onError(String message) {
                    submit.setEnabled(true);
                    toast(message);
                }
            });
        });

        form.addView(email);
        LinearLayout.LayoutParams codeRowParams = new LinearLayout.LayoutParams(-1, dp(56));
        codeRowParams.bottomMargin = dp(12);
        form.addView(codeRow, codeRowParams);
        form.addView(username);
        form.addView(nickname);
        form.addView(password);
        form.addView(invite);
        LinearLayout.LayoutParams submitParams = new LinearLayout.LayoutParams(-1, dp(50));
        submitParams.setMargins(0, dp(8), 0, 0);
        form.addView(submit, submitParams);
        root.addView(form, new LinearLayout.LayoutParams(-1, 0, 1));
        openSubPage(root, 3);
    }

    private ScrollView pageScroll(LinearLayout page) {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.addView(page, new ScrollView.LayoutParams(-1, -2));
        content.addView(scroll, new FrameLayout.LayoutParams(-1, -1));
        return scroll;
    }

    private LinearLayout page() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(0, dp(10), 0, dp(16));
        page.setBackgroundColor(BG);
        return page;
    }

    private class ViewRowsAdapter extends BaseAdapter {
        private final ArrayList<View> rows = new ArrayList<>();

        void replaceRows(LinearLayout source) {
            rows.clear();
            appendRows(source);
        }

        void appendRows(LinearLayout source) {
            while (source.getChildCount() > 0) {
                View child = source.getChildAt(0);
                source.removeViewAt(0);
                rows.add(child);
            }
            notifyDataSetChanged();
        }

        @Override public int getCount() { return rows.size(); }
        @Override public Object getItem(int position) { return rows.get(position); }
        @Override public long getItemId(int position) { return position; }

        @Override public View getView(int position, View convertView, ViewGroup parent) {
            View item = rows.get(position);
            if (item.getParent() instanceof ViewGroup) ((ViewGroup) item.getParent()).removeView(item);
            return item;
        }
    }

    private ListView createPageList(LinearLayout page, ViewRowsAdapter adapter) {
        ListView list = new ListView(this);
        list.setAdapter(adapter);
        list.setTranscriptMode(ListView.TRANSCRIPT_MODE_DISABLED);
        list.setStackFromBottom(false);
        list.setDivider(null);
        list.setBackgroundColor(Color.WHITE);
        list.setCacheColorHint(Color.WHITE);
        list.setClipToPadding(false);
        list.setPadding(0, 0, 0, dp(16));
        page.addView(list, new LinearLayout.LayoutParams(-1, 0, 1));
        return list;
    }

    private void scrollChatListToTop() {
        if (activeChatListView == null) return;
        activeChatListView.post(() -> {
            if (activeChatListView == null) return;
            if (activeChatRowsAdapter != null) {
                activeChatListView.setAdapter(null);
                activeChatListView.setAdapter(activeChatRowsAdapter);
            }
            activeChatListView.setSelection(0);
            activeChatListView.setSelectionFromTop(0, 0);
            activeChatListView.scrollTo(0, 0);
            activeChatListView.postDelayed(() -> {
                if (activeChatListView != null) {
                    if (activeChatRowsAdapter != null) {
                        activeChatListView.setAdapter(null);
                        activeChatListView.setAdapter(activeChatRowsAdapter);
                    }
                    activeChatListView.setSelection(0);
                    activeChatListView.setSelectionFromTop(0, 0);
                    activeChatListView.scrollTo(0, 0);
                }
            }, 80L);
        });
    }

    private void buildChatPage() {
        LinearLayout page = page();
        page.setPadding(0, dp(8), 0, 0);
        page.setBackgroundColor(Color.WHITE);
        LinearLayout header = row();
        header.setPadding(dp(18), dp(8), dp(18), dp(6));
        LinearLayout heading = column();
        heading.addView(title(t("chats")));
        heading.addView(bodyText(t("ui_chat_search"), 12, MUTED));
        header.addView(heading, new LinearLayout.LayoutParams(0, -2, 1));
        TextView add = circleButton("+");
        add.setOnClickListener(v -> showActionSheet());
        header.addView(add);
        page.addView(header);
        EditText searchField = search(t("ui_chat_search"));
        page.addView(searchField);
        LinearLayout rows = column();
        ViewRowsAdapter rowsAdapter = new ViewRowsAdapter();
        ListView list = createPageList(page, rowsAdapter);
        activeChatListView = list;
        activeChatRows = rows;
        activeChatRowsAdapter = rowsAdapter;
        activeChatSearchField = searchField;
        String cacheKey = "chat_snapshot_" + currentUserId;
        String cachedJson = preferences.getString(cacheKey, "");
        JSONArray cached = new JSONArray();
        try { if (!cachedJson.isEmpty()) cached = new JSONArray(cachedJson); } catch (Exception ignored) { }
        JSONArray[] currentSnapshot = {cached};
        if (cached.length() > 0) renderChatSnapshot(rows, cached, false, "", rowsAdapter);
        else { rows.addView(note(t("ui_chat_loading"))); rowsAdapter.replaceRows(rows); }
        restoreChatListStateIfUnchanged();
        int[] searchGeneration = {0};
        Handler searchHandler = new Handler(Looper.getMainLooper());
        Runnable[] pendingSearch = {null};
        searchField.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                String keyword = s.toString().trim();
                renderChatSnapshot(rows, currentSnapshot[0], true, keyword, rowsAdapter);
                int generation = ++searchGeneration[0];
                if (pendingSearch[0] != null) searchHandler.removeCallbacks(pendingSearch[0]);
                if (keyword.length() < 2) return;
                pendingSearch[0] = () -> {
                    Map<String, String> params = new HashMap<>();
                    params.put("q", keyword);
                    ApiClient.get(MainActivity.this, "messages.search", params, new ApiClient.Callback() {
                        @Override public void onSuccess(Object data) {
                            if (generation != searchGeneration[0] || !keyword.contentEquals(searchField.getText().toString().trim()) || !(data instanceof JSONArray)) return;
                            JSONArray matches = (JSONArray) data;
                            if (matches.length() == 0) return;
                            rows.addView(section(t("ui_message_results")));
                            for (int i = 0; i < matches.length(); i++) {
                                JSONObject item = matches.optJSONObject(i);
                                if (item == null) continue;
                                TextView result = bodyText(item.optString("conversation_name", t("ui_conversation")) + "  ·  " + item.optString("content", ""), 14, TEXT);
                                result.setPadding(dp(18), dp(12), dp(18), dp(12));
                                result.setBackgroundColor(Color.WHITE);
                                result.setOnClickListener(v -> openChatWindow(item.optInt("chat_id"), item.optInt("group_id"), item.optString("conversation_name", t("ui_conversation")), t("ui_chat_avatar"), item.optInt("group_id") > 0 ? "group" : "online", "#A8C0FF", "#3F5EFB"));
                                rows.addView(result);
                                rows.addView(separator());
                            }
                            rowsAdapter.appendRows(rows);
                        }
                        @Override public void onError(String message) { }
                    });
                    ApiClient.get(MainActivity.this, "contacts.search", params, new ApiClient.Callback() {
                        @Override public void onSuccess(Object data) {
                            if (generation != searchGeneration[0] || !keyword.contentEquals(searchField.getText().toString().trim()) || !(data instanceof JSONArray)) return;
                            JSONArray users = (JSONArray) data;
                            if (users.length() == 0) return;
                            rows.addView(section(t("ui_contact_results")));
                            for (int i = 0; i < users.length(); i++) {
                                JSONObject user = users.optJSONObject(i);
                                if (user == null) continue;
                                int id = user.optInt("id");
                                String display = normalizeOptionalText(preferences.getString("remark_user_" + id, ""));
                                if (display.isEmpty()) display = normalizeOptionalText(user.optString("remark", ""));
                                if (display.isEmpty()) display = normalizeOptionalText(user.optString("nickname", ""));
                                if (display.isEmpty()) display = t("ui_contact");
                                boolean isOnline = user.optInt("is_online") == 1;
                                addContact(rows, id, display.isEmpty() ? t("ui_contact").substring(0, 1) : display.substring(0, 1), display, t("ui_spx_status", user.optString("spx_id"), isOnline ? t("ui_online") : t("ui_offline")), isOnline ? "online" : "offline", "#A8C0FF", "#3F5EFB", user.optString("spx_id"), user.optString("avatar_url"), false);
                            }
                            rowsAdapter.appendRows(rows);
                        }
                        @Override public void onError(String message) { }
                    });
                };
                searchHandler.postDelayed(pendingSearch[0], 300);
            }
            @Override public void afterTextChanged(Editable s) { }
        });
        JSONArray cachedChats = new JSONArray();
        JSONArray cachedGroups = new JSONArray();
        for (int i = 0; i < cached.length(); i++) {
            JSONObject item = cached.optJSONObject(i);
            if (item == null) continue;
            if ("group".equals(item.optString("kind"))) cachedGroups.put(item);
            else cachedChats.put(item);
        }
        JSONArray[] chatRows = {cachedChats};
        JSONArray[] groupRows = {cachedGroups};
        String[] syncErrors = {"", ""};
        boolean[] syncFinished = {false, false};
        Runnable finishSnapshot = () -> {
            if (!syncFinished[0] || !syncFinished[1]) return;
            JSONArray snapshot = new JSONArray();
            for (int i = 0; i < chatRows[0].length(); i++) {
                JSONObject item = chatRows[0].optJSONObject(i);
                if (item == null) continue;
                try { JSONObject row = new JSONObject(item.toString()); row.put("kind", "chat"); snapshot.put(row); }
                catch (Exception ignored) { }
            }
            for (int i = 0; i < groupRows[0].length(); i++) {
                JSONObject item = groupRows[0].optJSONObject(i);
                if (item == null) continue;
                try { JSONObject row = new JSONObject(item.toString()); row.put("kind", "group"); snapshot.put(row); }
                catch (Exception ignored) { }
            }
            String value = snapshot.toString();
            String oldValue = preferences.getString(cacheKey, "");
            currentSnapshot[0] = snapshot;
            if (!value.equals(oldValue) || snapshot.length() == 0) renderChatSnapshot(rows, snapshot, true, searchField.getText().toString().trim(), rowsAdapter);
            if (focusChatListTopAfterRefresh) scrollChatListToTop();
            focusChatListTopAfterRefresh = false;
            long syncedAt = syncErrors[0].isEmpty() && syncErrors[1].isEmpty() ? System.currentTimeMillis() : 0;
            preferences.edit().putString(cacheKey, value).putLong("chat_snapshot_sync_" + currentUserId, syncedAt).apply();
            if (snapshot.length() == 0) { rows.addView(note(syncErrors[0].isEmpty() && syncErrors[1].isEmpty() ? t("ui_chat_empty") : t("ui_chat_unavailable"))); rowsAdapter.replaceRows(rows); }
            else if (!syncErrors[0].isEmpty() || !syncErrors[1].isEmpty()) { rows.addView(note(t("ui_partial_chat_failed"))); rowsAdapter.appendRows(rows); }
        };
        ApiClient.get(this, "chats", null, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) { if (data instanceof JSONArray) chatRows[0] = (JSONArray) data; syncFinished[0] = true; finishSnapshot.run(); }
            @Override public void onError(String message) { syncErrors[0] = message; syncFinished[0] = true; finishSnapshot.run(); }
        });
        ApiClient.get(this, "groups", null, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) { if (data instanceof JSONArray) groupRows[0] = (JSONArray) data; syncFinished[1] = true; finishSnapshot.run(); }
            @Override public void onError(String message) { syncErrors[1] = message; syncFinished[1] = true; finishSnapshot.run(); }
        });
        content.addView(page, new FrameLayout.LayoutParams(-1, -1));
    }

    private void renderChatSnapshot(LinearLayout page, JSONArray items, boolean replace, String filter, ViewRowsAdapter adapter) {
        if (replace) {
            page.removeAllViews();
        } else if (page.getChildCount() > 0) {
            page.removeAllViews();
        }
        ArrayList<JSONObject> pinnedChats = new ArrayList<>();
        ArrayList<JSONObject> normalChats = new ArrayList<>();
        for (int i = 0; i < items.length(); i++) {
            JSONObject item = items.optJSONObject(i);
            if (item == null) continue;
            if (item.optInt("pinned", 0) == 1) pinnedChats.add(item);
            else normalChats.add(item);
        }
        Comparator<JSONObject> newestFirst = (left, right) -> conversationTime(right).compareTo(conversationTime(left));
        pinnedChats.sort(newestFirst);
        normalChats.sort(newestFirst);
        ArrayList<JSONObject> sorted = new ArrayList<>(pinnedChats.size() + normalChats.size());
        sorted.addAll(pinnedChats);
        sorted.addAll(normalChats);
        int unreadTotal = 0;
        for (JSONObject item : sorted) {
            if (item == null) continue;
            int unread = item.optInt("unread_count", 0);
            unreadTotal += unread;
            boolean group = "group".equals(item.optString("kind"));
            String name = normalizeOptionalText(item.optString(group ? "name" : "nickname", ""));
            if (name.isEmpty()) name = normalizeOptionalText(item.optString(group ? "name" : "display_name", ""));
            if (name.isEmpty()) name = normalizeOptionalText(item.optString("title", ""));
            if (name.isEmpty()) name = group ? t("chat_group") : t("ui_conversation");
            String remark = group ? "" : normalizeOptionalText(item.optString("contact_remark", ""));
            if (remark.isEmpty() && !group) remark = normalizeOptionalText(preferences.getString("remark_user_" + item.optInt("peer_user_id"), ""));
            if (!group && !remark.isEmpty()) name = remark;
            String last = normalizeOptionalText(item.optString("last_message", ""));
            if (last.isEmpty()) last = t("ui_no_messages");
            String searchValue = (name + " " + remark + " " + item.optString("nickname", "") + " " + last + " " + item.optString("spx_id", "") + " " + item.optString("peer_user_id", "") + " " + item.optString("id", "")).toLowerCase(java.util.Locale.ROOT);
            if (!filter.isEmpty() && !searchValue.contains(filter.toLowerCase(java.util.Locale.ROOT))) continue;
            String time = shortChatTime(conversationTime(item));
            String presenceStatus = item.optInt("is_online") == 1 ? "online" : "offline";
            addChat(page, group ? 0 : item.optInt("id"), group ? item.optInt("id") : 0,
                    name, group ? t("ui_group_avatar") : (name.isEmpty() ? t("ui_chat_avatar") : name.substring(0, 1)), last, time,
                    group ? "group" : presenceStatus, unread > 0 ? String.valueOf(unread) : "",
                    group ? "#5B7CFA" : "#A8C0FF", group ? "#9B5DE5" : "#3F5EFB", item.optInt("pinned", 0) == 1,
                    item.optInt("mute", 0) == 1, item.optString("avatar_url", ""), "");
        }
        adapter.replaceRows(page);
        if (focusChatListTopAfterRefresh) scrollChatListToTop();
        pendingChatUnread = unreadTotal;
        updateChatNavUnread();
    }

    private String conversationTime(JSONObject item) {
        if (item == null) return "";
        String latest = normalizeOptionalText(item.optString("last_message_at", ""));
        String updated = normalizeOptionalText(item.optString("updated_at", ""));
        return latest.compareTo(updated) >= 0 ? latest : updated;
    }

    private String cachedGroupName(int groupId) {
        if (groupId <= 0) return "";
        JSONArray snapshot = readChatSnapshot();
        for (int i = 0; i < snapshot.length(); i++) {
            JSONObject item = snapshot.optJSONObject(i);
            if (item != null && "group".equals(item.optString("kind")) && item.optInt("id") == groupId) {
                String name = normalizeOptionalText(item.optString("name", ""));
                if (!name.isEmpty()) return name;
            }
        }
        try {
            JSONObject detail = new JSONObject(preferences.getString(groupDetailCacheKey(groupId), "{}"));
            return normalizeOptionalText(detail.optString("name", ""));
        } catch (Exception ignored) {
            return "";
        }
    }

    private void refreshVisibleChatList() {
        if (activeTab != 0 || subPageOpen || chatWindowOpen || activeChatRows == null || activeChatRowsAdapter == null) return;
        focusChatListTopAfterRefresh = true;
        renderChatSnapshot(activeChatRows, readChatSnapshot(), true,
                activeChatSearchField == null ? "" : activeChatSearchField.getText().toString().trim(), activeChatRowsAdapter);
        focusChatListTopAfterRefresh = false;
    }

    private void saveChatListStateBeforeOpen() {
        openedChatListSnapshot = chatListSortSignature(readChatSnapshot());
        if (activeChatListView == null || activeChatListView.getAdapter() == null) return;
        savedChatListPosition = Math.max(0, activeChatListView.getFirstVisiblePosition());
        View first = activeChatListView.getChildAt(0);
        savedChatListOffset = first == null ? 0 : first.getTop();
    }

    private void restoreChatListStateIfUnchanged() {
        if (!restoreChatListPosition || activeChatListView == null) return;
        restoreChatListPosition = false;
        activeChatListView.post(() -> {
            if (activeChatListView != null) activeChatListView.setSelectionFromTop(savedChatListPosition, savedChatListOffset);
        });
    }

    private String chatListSortSignature(JSONArray snapshot) {
        JSONArray signature = new JSONArray();
        for (int i = 0; i < snapshot.length(); i++) {
            JSONObject item = snapshot.optJSONObject(i);
            if (item == null) continue;
            JSONObject row = new JSONObject();
            try {
                row.put("kind", item.optString("kind", "chat"));
                row.put("id", item.optInt("id"));
                row.put("pinned", item.optInt("pinned"));
                row.put("name", item.optString("name", item.optString("nickname", "")));
                row.put("last_message", item.optString("last_message", ""));
                row.put("last_message_at", conversationTime(item));
                signature.put(row);
            } catch (Exception ignored) { }
        }
        return signature.toString();
    }

    private String normalizeOptionalText(String value) {
        if (value == null) return "";
        String normalized = value.trim();
        if (normalized.isEmpty() || "null".equalsIgnoreCase(normalized) || "undefined".equalsIgnoreCase(normalized)) return "";
        return normalized;
    }

    private JSONArray readCachedArray(String key) {
        try { return new JSONArray(preferences.getString(key, "[]")); }
        catch (Exception ignored) { return new JSONArray(); }
    }

    private void updateCachedContactRemark(int userId, String remark) {
        String key = "contacts_cache_" + currentUserId;
        JSONArray contacts = readCachedArray(key);
        for (int i = 0; i < contacts.length(); i++) {
            JSONObject contact = contacts.optJSONObject(i);
            if (contact == null || contact.optInt("id") != userId) continue;
            try { contact.put("remark", remark); } catch (Exception ignored) { }
        }
        preferences.edit().putString(key, contacts.toString()).apply();
    }

    private void updateCachedPresence(int userId, boolean online) {
        JSONArray contacts = readCachedArray("contacts_cache_" + currentUserId);
        for (int i = 0; i < contacts.length(); i++) {
            JSONObject contact = contacts.optJSONObject(i);
            if (contact != null && contact.optInt("id") == userId) {
                try { contact.put("is_online", online ? 1 : 0); } catch (Exception ignored) { }
            }
        }
        preferences.edit().putString("contacts_cache_" + currentUserId, contacts.toString()).apply();
        JSONArray snapshot = readChatSnapshot();
        for (int i = 0; i < snapshot.length(); i++) {
            JSONObject conversation = snapshot.optJSONObject(i);
            if (conversation != null && conversation.optInt("peer_user_id") == userId) {
                try { conversation.put("is_online", online ? 1 : 0); } catch (Exception ignored) { }
            }
        }
        storeChatSnapshot(snapshot);
        if (activeTab == 1 && !subPageOpen) renderTab(1);
        else if (activeTab == 0 && !subPageOpen && !chatWindowOpen) renderTab(0);
    }

    private void removeCachedContact(int userId) {
        String key = "contacts_cache_" + currentUserId;
        JSONArray contacts = readCachedArray(key);
        for (int i = contacts.length() - 1; i >= 0; i--) {
            JSONObject contact = contacts.optJSONObject(i);
            if (contact != null && contact.optInt("id") == userId) contacts.remove(i);
        }
        preferences.edit().putString(key, contacts.toString()).apply();
    }

    private String userProfileCacheKey(int userId) {
        return "user_profile_" + currentUserId + "_" + userId;
    }

    private JSONObject readCachedUserProfile(int userId) {
        try {
            String value = preferences.getString(userProfileCacheKey(userId), "");
            return value.isEmpty() ? null : new JSONObject(value);
        } catch (Exception ignored) { return null; }
    }

    private void cacheUserProfile(JSONObject profile) {
        if (profile == null || profile.optInt("id") <= 0) return;
        preferences.edit().putString(userProfileCacheKey(profile.optInt("id")), profile.toString()).apply();
    }

    private interface UserProfileCallback {
        void onProfile(JSONObject profile);
        void onError(String message);
    }

    private void loadUserProfile(int userId, UserProfileCallback callback) {
        if (userId <= 0) { callback.onError(t("ui_profile_unavailable")); return; }
        JSONObject cached = readCachedUserProfile(userId);
        long cachedAt = preferences.getLong(userProfileCacheKey(userId) + "_time", 0);
        if (cached != null && System.currentTimeMillis() - cachedAt < 5 * 60 * 1000L) {
            callback.onProfile(cached);
            return;
        }
        Map<String, String> params = new HashMap<>();
        params.put("id", String.valueOf(userId));
        ApiClient.get(this, "user.profile", params, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                if (!(data instanceof JSONObject)) { callback.onError(t("ui_profile_invalid")); return; }
                JSONObject profile = (JSONObject) data;
                cacheUserProfile(profile);
                preferences.edit().putLong(userProfileCacheKey(userId) + "_time", System.currentTimeMillis()).apply();
                callback.onProfile(profile);
            }
            @Override public void onError(String message) { callback.onError(message); }
        });
    }

    private void removeLoadingNote(LinearLayout page) {
        if (page.getChildCount() > 0) page.removeViewAt(page.getChildCount() - 1);
    }

    private String shortChatTime(String value) {
        if (value.length() >= 16) return value.substring(11, 16);
        if (value.length() >= 10) return value.substring(5, 10);
        return value;
    }

    private String formatBeijingMessageTime(String value) {
        String raw = normalizeOptionalText(value);
        if (raw.isEmpty()) return "";
        java.util.TimeZone zone = java.util.TimeZone.getTimeZone("Asia/Shanghai");
        try {
            java.text.SimpleDateFormat parser = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.ROOT);
            parser.setLenient(false);
            parser.setTimeZone(zone);
            java.util.Date sent = parser.parse(raw);
            if (sent == null) return raw;
            java.text.SimpleDateFormat dayFormat = new java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.ROOT);
            dayFormat.setTimeZone(zone);
            java.text.SimpleDateFormat timeFormat = new java.text.SimpleDateFormat("HH:mm", java.util.Locale.ROOT);
            timeFormat.setTimeZone(zone);
            String sentDay = dayFormat.format(sent);
            String today = dayFormat.format(new java.util.Date());
            if (sentDay.equals(today)) return timeFormat.format(sent);
            java.util.Calendar yesterday = java.util.Calendar.getInstance(zone);
            yesterday.add(java.util.Calendar.DAY_OF_YEAR, -1);
            if (sentDay.equals(dayFormat.format(yesterday.getTime()))) return t("ui_yesterday", timeFormat.format(sent));
            java.text.SimpleDateFormat dateTimeFormat = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.ROOT);
            dateTimeFormat.setTimeZone(zone);
            return dateTimeFormat.format(sent);
        } catch (Exception ignored) {
            return raw;
        }
    }

    private String formatAmount(String value) {
        try {
            return new java.math.BigDecimal(value == null || value.isEmpty() ? "0" : value)
                    .setScale(2, java.math.RoundingMode.HALF_UP).toPlainString();
        } catch (Exception ignored) { return "0.00"; }
    }

    private String formatUsd(java.math.BigDecimal value) {
        return value.setScale(2, java.math.RoundingMode.HALF_UP).toPlainString();
    }

    private String formatUsdPrice(double value) {
        return formatPrice6(String.valueOf(value));
    }

    private String formatPrice6(String value) {
        try { return new java.math.BigDecimal(value).setScale(6, java.math.RoundingMode.HALF_UP).toPlainString(); }
        catch (Exception ignored) { return "0"; }
    }

    private interface UsdPriceCallback { void onPrice(double price, String error); }

    private void loadSpx001UsdPrice(UsdPriceCallback callback) {
        ApiClient.get(this, "wallet.exchange.quote", null, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                double price = data instanceof JSONObject ? ((JSONObject) data).optDouble("api_price_usd", 0) : 0;
                callback.onPrice(price > 0 ? price : 0, price > 0 ? "" : t("ui_quote_invalid"));
            }
            @Override public void onError(String message) { callback.onPrice(0, message); }
        });
    }

    private void addChat(LinearLayout parent, String avatar, String name, String message, String time, String status, String unread, String c1, String c2) {
        addChat(parent, 0, 0, name, avatar, message, time, status, unread, c1, c2);
    }

    private void addChat(LinearLayout parent, int chatId, int groupId, String name, String avatar, String message, String time, String status, String unread, String c1, String c2) {
        addChat(parent, chatId, groupId, name, avatar, message, time, status, unread, c1, c2, false);
    }

    private void addChat(LinearLayout parent, int chatId, int groupId, String name, String avatar, String message, String time, String status, String unread, String c1, String c2, boolean pinned) {
        addChat(parent, chatId, groupId, name, avatar, message, time, status, unread, c1, c2, pinned, false, "", "");
    }

    private void addChat(LinearLayout parent, int chatId, int groupId, String name, String avatar, String message, String time, String status, String unread, String c1, String c2, boolean pinned, boolean muted, String avatarUrl, String remark) {
        parent.addView(createChatRow(chatId, groupId, name, avatar, message, time, status, unread, c1, c2, pinned, muted, avatarUrl, remark), new LinearLayout.LayoutParams(-1, dp(76)));
        parent.addView(separator());
    }

    private LinearLayout createChatRow(int chatId, int groupId, String name, String avatar, String message, String time, String status, String unread, String c1, String c2, boolean pinned, boolean muted, String avatarUrl, String remark) {
        LinearLayout item = row();
        item.setPadding(dp(18), dp(15), dp(18), dp(15));
        item.setBackground(pinned ? stroke(MallUi.TINT, MallUi.LINE, 16, 1) : round(Color.WHITE, 16));
        MallUi.touch(item, 16);
        View avatarView = avatarWithRemoteImage(avatar, avatarUrl, c1, c2, 52);
        item.addView(avatarView);
        LinearLayout info = column();
        info.setPadding(dp(14), 0, 0, 0);
        LinearLayout top = row();
         TextView nameView = bodyText(name + (status.equals("group") ? "  · " + t("chat_group") : ""), 16, TEXT);
        nameView.setTypeface(null, android.graphics.Typeface.BOLD);
        nameView.setSingleLine(true);
        nameView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        top.addView(nameView, new LinearLayout.LayoutParams(0, -2, 1));
        if (pinned) top.addView(statusTag(t("ui_pinned"), BLUE));
        if (muted) top.addView(statusTag(t("ui_muted"), MUTED));
        top.addView(bodyText(time, 12, MUTED));
        info.addView(top);
        LinearLayout messageRow = row();
        String preview = remark.isEmpty() ? message : t("ui_remark", remark) + " · " + message;
        TextView msg = bodyText(preview, 13, Color.rgb(91, 104, 124));
        msg.setSingleLine(true);
        msg.setEllipsize(android.text.TextUtils.TruncateAt.END);
        messageRow.addView(msg, new LinearLayout.LayoutParams(0, -2, 1));
        if (!unread.isEmpty() && !"0".equals(unread)) messageRow.addView(badge(unread));
        info.addView(messageRow);
        item.addView(info, new LinearLayout.LayoutParams(0, -2, 1));
        item.setOnClickListener(v -> {
            if (chatId > 0 || groupId > 0) {
                openChatWindow(chatId, groupId, name, avatar, status, c1, c2);
            } else {
                openChatWindow(name, avatar, status, status.equals("group"), c1, c2);
            }
        });
        if (chatId > 0 || groupId > 0) item.setOnLongClickListener(v -> {
            showConversationQuickActions(chatId, groupId, name, avatar, status, c1, c2, pinned, muted);
            return true;
        });
        return item;
    }

    private TextView statusTag(String label, int color) {
        TextView tag = centeredText(label, 10, color);
        tag.setPadding(dp(5), dp(2), dp(5), dp(2));
        tag.setBackground(round(Color.rgb(242, 244, 247), 6));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-2, dp(20));
        params.setMargins(0, 0, dp(4), 0);
        tag.setLayoutParams(params);
        return tag;
    }

    private void showConversationQuickActions(int chatId, int groupId, String name, String avatar, String status, String c1, String c2, boolean pinned, boolean muted) {
        String[] actions = {t(pinned ? "ui_unpin" : "ui_pin"), t(muted ? "ui_mute_off" : "ui_mute_on"), t("ui_open_chat")};
        new AlertDialog.Builder(this).setTitle(name).setItems(actions, (dialog, which) -> {
            if (which == 2) {
                openChatWindow(chatId, groupId, name, avatar, status, c1, c2);
                return;
            }
            String key = which == 0 ? "pinned" : "mute";
            boolean value = which == 0 ? !pinned : !muted;
            JSONObject request = new JSONObject();
            try { request.put(groupId > 0 ? "group_id" : "chat_id", groupId > 0 ? groupId : chatId); request.put(key, value ? 1 : 0); }
            catch (Exception ignored) { return; }
            ApiClient.post(this, groupId > 0 ? "groups.settings" : "chats.settings", request, new ApiClient.Callback() {
                @Override public void onSuccess(Object data) {
                    JSONArray snapshot = readChatSnapshot();
                    for (int i = 0; i < snapshot.length(); i++) {
                        JSONObject item = snapshot.optJSONObject(i);
                        if (item == null || item.optInt("id") != (groupId > 0 ? groupId : chatId)) continue;
                        if ((groupId > 0) != "group".equals(item.optString("kind"))) continue;
                        try { item.put(key, value ? 1 : 0); } catch (Exception ignored) { }
                    }
                    storeChatSnapshot(snapshot);
                    invalidateChatSnapshot();
                    if (activeTab == 0 && !chatWindowOpen) renderTab(0);
                     toast(t(which == 0 ? (value ? "ui_pinned_done" : "ui_unpinned_done") : (value ? "ui_mute_enabled" : "ui_mute_disabled")));
                }
                @Override public void onError(String error) { toast(error); }
            });
        }).show();
    }

    private void buildContactsPage() {
        LinearLayout page = page();
        page.setPadding(0, dp(8), 0, 0);
        page.setBackgroundColor(Color.WHITE);
        LinearLayout header = row();
        header.setPadding(dp(18), dp(8), dp(18), dp(6));
        header.addView(title(t("contacts")), new LinearLayout.LayoutParams(0, dp(48), 1));
        TextView friend = circleButton("+");
        friend.setOnClickListener(v -> showActionSheet());
        header.addView(friend);
        page.addView(header);
        EditText searchField = search(t("ui_contacts_search"));
        page.addView(searchField);
        LinearLayout rows = column();
        rows.addView(note(t("ui_contacts_loading")));
        ViewRowsAdapter rowsAdapter = new ViewRowsAdapter();
        ListView list = createPageList(page, rowsAdapter);
        rowsAdapter.replaceRows(rows);
        String contactsCacheKey = "contacts_cache_" + currentUserId;
        String groupsCacheKey = "groups_cache_" + currentUserId;
        boolean hasCachedLists = preferences.contains(contactsCacheKey) || preferences.contains(groupsCacheKey);
        JSONArray[] allContacts = {readCachedArray(contactsCacheKey)};
        JSONArray[] myGroups = {readCachedArray(groupsCacheKey)};
        boolean[] contactsLoaded = {hasCachedLists};
        Runnable renderContacts = () -> {
            rows.removeAllViews();
            rows.addView(section(t("ui_my_contacts")));
            String filter = searchField.getText().toString().trim().toLowerCase(java.util.Locale.ROOT);
            int count = 0;
            for (int i = 0; i < allContacts[0].length(); i++) {
                JSONObject contact = allContacts[0].optJSONObject(i);
                if (contact == null) continue;
                int contactId = contact.optInt("id");
                String nickname = normalizeOptionalText(contact.optString("nickname", ""));
                if (nickname.isEmpty()) nickname = t("ui_contact");
                String remoteRemark = normalizeOptionalText(contact.optString("remark", ""));
                preferences.edit().putString("remark_user_" + contactId, remoteRemark).apply();
                String searchable = (nickname + " " + remoteRemark + " " + contact.optString("spx_id", "") + " " + contactId).toLowerCase(java.util.Locale.ROOT);
                if (!filter.isEmpty() && !searchable.contains(filter)) continue;
                boolean isOnline = contact.optInt("is_online") == 1;
                addContact(rows, contactId, nickname.isEmpty() ? t("ui_contact").substring(0, 1) : nickname.substring(0, 1), nickname, isOnline ? t("ui_online") : t("ui_offline"), isOnline ? "online" : "offline", "#A8C0FF", "#3F5EFB", contact.optString("spx_id", ""), contact.optString("avatar_url", ""), true, remoteRemark);
                count++;
            }
            if (count == 0 && !filter.isEmpty()) rows.addView(note(t("ui_no_contact_match")));
            rows.addView(section(t("ui_my_groups")));
            int visibleGroups = 0;
            for (int i = 0; i < myGroups[0].length(); i++) {
                JSONObject group = myGroups[0].optJSONObject(i);
                if (group == null) continue;
                String groupName = group.optString("name", t("chat_group"));
                if (!filter.isEmpty() && !groupName.toLowerCase(java.util.Locale.ROOT).contains(filter)) continue;
                addContactGroupRow(rows, group);
                visibleGroups++;
            }
            if (visibleGroups == 0) rows.addView(note(filter.isEmpty() ? t("ui_no_groups") : t("ui_no_group_match")));
             TextView total = centeredText(t("ui_contact_total", allContacts[0].length()), 13, MUTED);
            total.setPadding(0, dp(20), 0, dp(12));
            rows.addView(total, new LinearLayout.LayoutParams(-1, dp(48)));
            rowsAdapter.replaceRows(rows);
        };
        if (hasCachedLists) renderContacts.run();
        int[] generation = {0};
        Handler searchHandler = new Handler(Looper.getMainLooper());
        Runnable[] pendingSearch = {null};
        searchField.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                renderContacts.run();
                String keyword = s.toString().trim();
                int requestId = ++generation[0];
                if (pendingSearch[0] != null) searchHandler.removeCallbacks(pendingSearch[0]);
                if (keyword.length() < 2) return;
                pendingSearch[0] = () -> {
                    Map<String, String> params = new HashMap<>();
                    params.put("q", keyword);
                    ApiClient.get(MainActivity.this, "contacts.search", params, new ApiClient.Callback() {
                        @Override public void onSuccess(Object data) {
                            if (requestId != generation[0] || !keyword.contentEquals(searchField.getText().toString().trim()) || !(data instanceof JSONArray)) return;
                            JSONArray matches = (JSONArray) data;
                            ArrayList<JSONObject> remote = new ArrayList<>();
                            for (int i = 0; i < matches.length(); i++) {
                                JSONObject result = matches.optJSONObject(i);
                                if (result == null) continue;
                                boolean exists = false;
                                for (int j = 0; j < allContacts[0].length(); j++) {
                                    JSONObject contact = allContacts[0].optJSONObject(j);
                                    if (contact != null && contact.optInt("id") == result.optInt("id")) { exists = true; break; }
                                }
                                if (!exists) remote.add(result);
                            }
                            if (remote.isEmpty()) return;
                            rows.addView(section(t("ui_user_results")));
                            for (JSONObject user : remote) {
                                String nickname = normalizeOptionalText(user.optString("nickname", ""));
                                if (nickname.isEmpty()) nickname = t("ui_user");
                                String remark = normalizeOptionalText(user.optString("remark", ""));
                                boolean isOnline = user.optInt("is_online") == 1;
                                addContact(rows, user.optInt("id"), nickname.isEmpty() ? t("ui_user").substring(0, 1) : nickname.substring(0, 1), nickname, t("ui_spx_status", user.optString("spx_id"), isOnline ? t("ui_online") : t("ui_offline")), isOnline ? "online" : "offline", "#A8C0FF", "#3F5EFB", user.optString("spx_id", ""), user.optString("avatar_url", ""), false, remark);
                            }
                            rowsAdapter.appendRows(rows);
                        }
                        @Override public void onError(String message) { }
                    });
                };
                searchHandler.postDelayed(pendingSearch[0], 300);
            }
            @Override public void afterTextChanged(Editable s) { }
        });
        ApiClient.get(this, "contacts", null, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                allContacts[0] = data instanceof JSONArray ? (JSONArray) data : new JSONArray();
                preferences.edit().putString(contactsCacheKey, allContacts[0].toString()).apply();
                contactsLoaded[0] = true;
                for (int i = 0; i < allContacts[0].length(); i++) {
                    JSONObject contact = allContacts[0].optJSONObject(i);
                    if (contact == null) continue;
                    try {
                        JSONObject profile = new JSONObject(contact.toString());
                        profile.put("contact_remark", normalizeOptionalText(contact.optString("remark", "")));
                        profile.put("is_contact", 1);
                        cacheUserProfile(profile);
                        preferences.edit().putLong(userProfileCacheKey(contact.optInt("id")) + "_time", System.currentTimeMillis()).apply();
                    } catch (Exception ignored) { }
                }
                renderContacts.run();
            }
            @Override public void onError(String message) {
                if (!hasCachedLists) { rows.removeAllViews(); rows.addView(note(message)); rowsAdapter.replaceRows(rows); }
            }
        });
        ApiClient.get(this, "groups", null, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                myGroups[0] = data instanceof JSONArray ? (JSONArray) data : new JSONArray();
                preferences.edit().putString(groupsCacheKey, myGroups[0].toString()).apply();
                if (contactsLoaded[0]) renderContacts.run();
            }
            @Override public void onError(String message) {
                if (!preferences.contains(groupsCacheKey)) myGroups[0] = new JSONArray();
                if (contactsLoaded[0]) renderContacts.run();
            }
        });
        content.addView(page, new FrameLayout.LayoutParams(-1, -1));
    }

    private void addContactGroupRow(LinearLayout parent, JSONObject group) {
        int groupId = group.optInt("id");
        String name = group.optString("name", t("chat_group"));
        LinearLayout item = row();
        item.setPadding(dp(18), dp(15), dp(18), dp(15));
        item.setBackgroundColor(Color.WHITE);
        item.addView(avatarWithRemoteImage(t("chat_group"), group.optString("avatar_url", ""), "#5B7CFA", "#9B5DE5", 50));
        LinearLayout info = column();
        info.setPadding(dp(14), 0, 0, 0);
        TextView title = bodyText(name, 16, TEXT);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        info.addView(title);
        info.addView(bodyText(t("ui_member_count", group.optInt("member_count")), 12, MUTED));
        item.addView(info, new LinearLayout.LayoutParams(0, -2, 1));
        item.addView(bodyText("›", 24, Color.rgb(176, 190, 208)));
        item.setOnClickListener(v -> {
            JSONArray snapshot = readChatSnapshot();
            for (int i = snapshot.length() - 1; i >= 0; i--) {
                JSONObject existing = snapshot.optJSONObject(i);
                if (existing != null && "group".equals(existing.optString("kind")) && existing.optInt("id") == groupId) snapshot.remove(i);
            }
            try {
                JSONObject row = new JSONObject(group.toString());
                row.put("kind", "group");
                snapshot.put(row);
                storeChatSnapshot(snapshot);
            } catch (Exception ignored) { }
            openChatWindow(0, groupId, name, t("chat_group"), "group", "#5B7CFA", "#9B5DE5");
        });
        parent.addView(item, new LinearLayout.LayoutParams(-1, dp(74)));
        parent.addView(separator());
    }

    private void addContact(LinearLayout parent, String avatarText, String name, String statusText, String status, String c1, String c2) {
        addContact(parent, 0, avatarText, name, statusText, status, c1, c2, "", "", false);
    }

    private void addContact(LinearLayout parent, int userId, String avatarText, String name, String statusText, String status, String c1, String c2, String spxId, String avatarUrl, boolean isContact) {
        addContact(parent, userId, avatarText, name, statusText, status, c1, c2, spxId, avatarUrl, isContact, "");
    }

    private void addContact(LinearLayout parent, int userId, String avatarText, String name, String statusText, String status, String c1, String c2, String spxId, String avatarUrl, boolean isContact, String contactRemark) {
        LinearLayout item = row();
        item.setPadding(dp(18), dp(15), dp(18), dp(15));
        item.setBackgroundColor(Color.WHITE);
        View avatarView = avatarWithRemoteImage(avatarText, avatarUrl, c1, c2, 50);
        avatarView.setOnClickListener(v -> showContactDetail(userId, name, spxId, avatarUrl, isContact));
        item.addView(avatarView);
        LinearLayout info = column();
        info.setPadding(dp(14), 0, 0, 0);
        TextView nameView = bodyText(name, 16, TEXT);
        nameView.setTypeface(null, android.graphics.Typeface.BOLD);
        info.addView(nameView);
        info.addView(bodyText("●  " + statusText, 13, statusColor(status)));
        if (!contactRemark.trim().isEmpty()) info.addView(bodyText(t("ui_remark", contactRemark), 12, MUTED));
        item.addView(info, new LinearLayout.LayoutParams(0, -2, 1));
        TextView details = centeredText(t("ui_details"), 13, BLUE);
        details.setPadding(dp(8), 0, 0, 0);
        details.setOnClickListener(v -> showContactDetail(userId, name, spxId, avatarUrl, isContact));
        item.addView(details, new LinearLayout.LayoutParams(dp(48), dp(48)));
        item.setOnClickListener(v -> {
            if (userId > 0) {
                JSONObject body = new JSONObject();
                try { body.put("peer_user_id", userId); } catch (Exception ignored) { }
                ApiClient.post(MainActivity.this, "chats.create", body, new ApiClient.Callback() {
                    @Override public void onSuccess(Object data) {
                        invalidateChatSnapshot();
                        openChatWindow(data instanceof JSONObject ? ((JSONObject) data).optInt("chat_id") : 0, 0, name, avatarText, status, c1, c2, userId);
                    }
                    @Override public void onError(String message) { toast(message); }
                });
            } else openChatWindow(name, avatarText, status, false, c1, c2);
        });
        parent.addView(item, new LinearLayout.LayoutParams(-1, dp(contactRemark.trim().isEmpty() ? 74 : 88)));
        parent.addView(separator());
    }

    private void showContactDetail(int userId, String nickname, String spxId, String avatarUrl, boolean isContact) {
        if (userId <= 0) { toast(t("ui_profile_unavailable")); return; }
        loadUserProfile(userId, new UserProfileCallback() {
            @Override public void onProfile(JSONObject profile) { openFriendProfilePage(profile); }
            @Override public void onError(String message) { toast(t("ui_profile_load_failed", message)); }
        });
    }

    private void openFriendProfilePage(JSONObject profile) {
        int userId = profile.optInt("id");
        if (userId <= 0) { toast(t("ui_profile_unavailable")); return; }
        cacheUserProfile(profile);
        String nickname = normalizeOptionalText(profile.optString("nickname", ""));
        if (nickname.isEmpty()) nickname = t("ui_spx_user");
        final String displayName = nickname;
        String spxId = normalizeOptionalText(profile.optString("spx_id", ""));
        String avatarUrl = normalizeOptionalText(profile.optString("avatar_url", ""));
        boolean isContact = profile.optInt("is_contact") == 1;
        String remark = normalizeOptionalText(profile.optString("contact_remark", ""));

        LinearLayout root = subPageRoot(t("ui_profile"), t("ui_profile_card"));
        root.setTag("friend-profile:" + userId);
        ScrollView scroll = new ScrollView(this);
        LinearLayout body = column();
        body.setPadding(dp(18), dp(18), dp(18), dp(24));

        LinearLayout identity = column();
        identity.setGravity(Gravity.CENTER_HORIZONTAL);
        identity.setPadding(dp(18), dp(24), dp(18), dp(22));
        identity.setBackground(round(Color.WHITE, 12));
        View avatar = avatarWithRemoteImage(displayName.substring(0, 1), avatarUrl, "#A8C0FF", "#3F5EFB", 92);
        identity.addView(avatar, new LinearLayout.LayoutParams(dp(92), dp(92)));
        TextView name = bodyText(displayName, 23, TEXT);
        name.setTypeface(null, android.graphics.Typeface.BOLD);
        name.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams nameParams = new LinearLayout.LayoutParams(-1, -2);
        nameParams.setMargins(0, dp(14), 0, dp(5));
        identity.addView(name, nameParams);
        TextView spxIdLine = centeredText("SPX ID  " + spxId, 13, MUTED);
        spxIdLine.setOnClickListener(v -> copyText(spxId, "SPX ID"));
        identity.addView(spxIdLine, new LinearLayout.LayoutParams(-1, dp(26)));
        TextView relation = centeredText(isContact ? t("ui_added_friend") : t("ui_spx_user"), 12, isContact ? Color.rgb(31, 126, 86) : BLUE);
        relation.setPadding(dp(10), 0, dp(10), 0);
        relation.setBackground(round(isContact ? Color.rgb(232, 246, 238) : Color.rgb(238, 242, 255), 20));
        LinearLayout.LayoutParams relationParams = new LinearLayout.LayoutParams(-2, dp(30));
        relationParams.topMargin = dp(8);
        identity.addView(relation, relationParams);
        body.addView(identity);

        LinearLayout details = column();
        details.setPadding(dp(16), dp(4), dp(16), dp(4));
        details.setBackground(round(Color.WHITE, 12));
        addProfileFact(details, "SPX ID", spxId.isEmpty() ? t("ui_not_set") : spxId, () -> copyText(spxId, "SPX ID"));
        if (isContact) {
            TextView remarkValue = addProfileFact(details, t("ui_remark_label"), remark.isEmpty() ? t("ui_set_remark") : remark, null);
            remarkValue.setTextColor(BLUE);
            remarkValue.setOnClickListener(v -> showRemarkDialog(remark, remarkValue, "remark_user_" + userId, userId, false));
        }
        LinearLayout.LayoutParams detailsParams = new LinearLayout.LayoutParams(-1, -2);
        detailsParams.setMargins(0, dp(12), 0, 0);
        body.addView(details, detailsParams);

        if (isContact) {
            LinearLayout callActions = row();
            TextView voiceCall = centeredText(t("ui_voice_call"), 14, TEXT);
            TextView videoCall = centeredText(t("ui_video_call"), 14, TEXT);
            voiceCall.setBackground(round(Color.WHITE, 10));
            videoCall.setBackground(round(Color.WHITE, 10));
            LinearLayout.LayoutParams callParams = new LinearLayout.LayoutParams(0, dp(68), 1);
            callParams.setMargins(0, dp(12), dp(6), 0);
            callActions.addView(voiceCall, callParams);
            LinearLayout.LayoutParams videoParams = new LinearLayout.LayoutParams(0, dp(68), 1);
            videoParams.setMargins(dp(6), dp(12), 0, 0);
            callActions.addView(videoCall, videoParams);
            voiceCall.setOnClickListener(v -> toast(t("ui_voice_call_unavailable")));
            videoCall.setOnClickListener(v -> toast(t("ui_video_call_unavailable")));
            body.addView(callActions);

            LinearLayout clearHistory = settingRow("⌫", t("ui_clear_friend_history"), true);
            clearHistory.setOnClickListener(v -> new AlertDialog.Builder(this)
                    .setTitle(t("clear_history"))
                    .setMessage(t("clear_history_warning"))
                    .setNegativeButton(t("cancel"), null)
                    .setPositiveButton(t("clear_records"), (dialog, which) -> clearFriendConversationHistory(userId))
                    .show());
            body.addView(clearHistory, new LinearLayout.LayoutParams(-1, -2));

            LinearLayout deleteFriend = settingRow("−", t("ui_delete_friend"), false);
            ((TextView) deleteFriend.getChildAt(1)).setTextColor(Color.rgb(190, 55, 55));
            deleteFriend.setOnClickListener(v -> new AlertDialog.Builder(this)
                    .setTitle(t("delete_friend"))
                    .setMessage(t("delete_friend_warning"))
                    .setNegativeButton(t("cancel"), null)
                    .setPositiveButton(t("delete_friend"), (dialog, which) -> deleteFriend(userId))
                    .show());
            body.addView(deleteFriend, new LinearLayout.LayoutParams(-1, -2));
        }

        scroll.addView(body, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        TextView action = centeredText(isContact ? t("ui_send_message") : t("ui_add_contact"), 16, Color.WHITE);
        action.setTypeface(null, android.graphics.Typeface.BOLD);
        action.setBackground(round(BLUE, 10));
        LinearLayout.LayoutParams actionParams = new LinearLayout.LayoutParams(-1, dp(52));
        actionParams.setMargins(dp(18), dp(10), dp(18), dp(18));
        root.addView(action, actionParams);
        action.setOnClickListener(v -> {
            if (!isContact) {
                JSONObject request = new JSONObject();
                try { request.put("spx_id", spxId); } catch (Exception ignored) { return; }
                action.setEnabled(false);
                ApiClient.post(this, "contacts.add", request, new ApiClient.Callback() {
                    @Override public void onSuccess(Object data) {
                        toast(t("ui_added_to_contacts"));
                        try { profile.put("is_contact", 1); } catch (Exception ignored) { }
                        cacheUserProfile(profile);
                        preferences.edit().putLong(userProfileCacheKey(userId) + "_time", System.currentTimeMillis()).apply();
                        loadUserProfile(userId, new UserProfileCallback() {
                            @Override public void onProfile(JSONObject refreshed) { openFriendProfilePage(refreshed); }
                            @Override public void onError(String message) { action.setEnabled(true); toast(message); }
                        });
                    }
                    @Override public void onError(String message) { action.setEnabled(true); toast(message); }
                });
                return;
            }
            JSONObject request = new JSONObject();
            try { request.put("peer_user_id", userId); } catch (Exception ignored) { return; }
            action.setEnabled(false);
            ApiClient.post(this, "chats.create", request, new ApiClient.Callback() {
                @Override public void onSuccess(Object data) {
                    int chatId = data instanceof JSONObject ? ((JSONObject) data).optInt("chat_id") : 0;
                    invalidateChatSnapshot();
                    closeSubPage();
                    openChatWindow(chatId, 0, remark.isEmpty() ? displayName : remark, displayName.substring(0, 1), "online", "#A8C0FF", "#3F5EFB", userId);
                }
                @Override public void onError(String message) { action.setEnabled(true); toast(message); }
            });
        });
        openSubPage(root, activeTab);
    }

    private TextView addProfileFact(LinearLayout parent, String label, String value, Runnable action) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(13), 0, dp(13));
        TextView key = bodyText(label, 13, MUTED);
        row.addView(key, new LinearLayout.LayoutParams(dp(88), -2));
        TextView content = bodyText(value, 14, TEXT);
        if (action != null) content.setTextColor(BLUE);
        row.addView(content, new LinearLayout.LayoutParams(0, -2, 1));
        if (action != null) row.setOnClickListener(v -> action.run());
        parent.addView(row);
        View divider = new View(this);
        divider.setBackgroundColor(Color.rgb(235, 239, 245));
        parent.addView(divider, new LinearLayout.LayoutParams(-1, dp(1)));
        return content;
    }

    private void clearFriendConversationHistory(int peerId) {
        JSONObject request = new JSONObject();
        try { request.put("peer_user_id", peerId); } catch (Exception ignored) { return; }
        ApiClient.post(this, "messages.clear.both", request, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                JSONArray chatIds = data instanceof JSONObject ? ((JSONObject) data).optJSONArray("deleted_chat_ids") : null;
                if (chatIds != null) for (int i = 0; i < chatIds.length(); i++) removeRealtimeConversation(chatIds.optInt(i), "history_cleared");
                invalidateChatSnapshot();
                toast(t("ui_history_cleared"));
            }
            @Override public void onError(String message) { toast(message); }
        });
    }

    private void deleteFriend(int peerId) {
        JSONObject request = new JSONObject();
        try { request.put("contact_user_id", peerId); } catch (Exception ignored) { return; }
        ApiClient.post(this, "contacts.delete", request, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                removeCachedContact(peerId);
                preferences.edit().remove(userProfileCacheKey(peerId)).remove(userProfileCacheKey(peerId) + "_time").remove("remark_user_" + peerId).apply();
                JSONArray chatIds = data instanceof JSONObject ? ((JSONObject) data).optJSONArray("deleted_chat_ids") : null;
                if (chatIds != null) for (int i = 0; i < chatIds.length(); i++) removeRealtimeConversation(chatIds.optInt(i), "friend_removed");
                invalidateChatSnapshot();
                toast(t("ui_friend_deleted"));
                loadUserProfile(peerId, new UserProfileCallback() {
                    @Override public void onProfile(JSONObject refreshed) { openFriendProfilePage(refreshed); }
                    @Override public void onError(String message) { renderTab(1); }
                });
            }
            @Override public void onError(String message) { toast(message); }
        });
    }

    private void renderContactDetail(JSONObject profileData) {
        openFriendProfilePage(profileData);
    }

    private void buildEcoPage() {
        LinearLayout page = page();
        page.addView(headerTitle(t("eco_title"), t("eco_subtitle")));
        addEcoCard(page, "◇", t("store"), t("store_desc"), t("open_store"), BLUE, () -> openStorePage());
        addEcoCard(page, "▣", t("staking"), t("staking_desc"), t("view_staking"), Color.rgb(243, 156, 18), () -> openStakingPage());
        addEcoCard(page, "▶", t("video_reward"), t("video_reward_desc"), t("developing"), Color.rgb(32, 154, 112), () -> openAdRewardPage());
        pageScroll(page);
    }

    private void openAdRewardPage() {
        LinearLayout root = subPageRoot(t("video_reward"), t("ad_reward_subtitle"));
        LinearLayout body = column();
        body.setGravity(Gravity.CENTER_HORIZONTAL);
        body.setPadding(dp(24), dp(54), dp(24), dp(30));
        ImageView icon = new ImageView(this);
        icon.setImageResource(com.spx.chat.R.drawable.wallet_spx001);
        icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        icon.setBackground(round(Color.rgb(232, 248, 241), 28));
        body.addView(icon, new LinearLayout.LayoutParams(dp(112), dp(112)));
        TextView title = bodyText(t("ad_reward_title"), 21, TEXT);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(28), 0, dp(10));
        body.addView(title);
        TextView status = bodyText(t("loading_ad_points"), 15, MUTED);
        status.setGravity(Gravity.CENTER);
        body.addView(status);
        ProgressBar progress = new ProgressBar(this);
        progress.setIndeterminate(true);
        LinearLayout.LayoutParams progressParams = new LinearLayout.LayoutParams(dp(42), dp(42));
        progressParams.setMargins(0, dp(22), 0, dp(18));
        body.addView(progress, progressParams);
        TextView developing = bodyText(t("ad_reward_developing"), 15, Color.rgb(32, 154, 112));
        developing.setGravity(Gravity.CENTER);
        developing.setLineSpacing(dp(6), 1f);
        developing.setPadding(dp(20), dp(16), dp(20), dp(16));
        developing.setBackground(round(Color.rgb(238, 249, 244), 14));
        body.addView(developing, new LinearLayout.LayoutParams(-1, -2));
        root.addView(body, new LinearLayout.LayoutParams(-1, 0, 1));
        openSubPage(root, 2);
        final String[] dots = {"", ".", "..", "..."};
        Handler handler = new Handler(Looper.getMainLooper());
        Runnable[] tick = {null};
        tick[0] = new Runnable() {
            int index = 0;
            @Override public void run() {
                if (status.getParent() == null) return;
                status.setText(t("loading_ad_points") + dots[index++ % dots.length]);
                handler.postDelayed(this, 600L);
            }
        };
        handler.post(tick[0]);
    }

    private void addEcoCard(LinearLayout parent, String icon, String title, String desc, String badge, int color, Runnable action) {
        LinearLayout card = row();
        card.setPadding(dp(20), dp(18), dp(16), dp(18));
        card.setBackground(round(Color.WHITE, 20));
        ImageView iconView;
        if (title.equals(t("video_reward"))) {
            iconView = new ImageView(this);
            iconView.setImageResource(com.spx.chat.R.drawable.reward_video);
            iconView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        } else {
            String imageUrl = title.equals(t("store"))
                    ? "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=900"
                    : "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=900";
            iconView = productImage(imageUrl);
        }
        iconView.setBackground(round(Color.argb(30, Color.red(color), Color.green(color), Color.blue(color)), 16));
        card.addView(iconView, new LinearLayout.LayoutParams(dp(82), dp(82)));
        LinearLayout info = column();
        info.setPadding(dp(16), 0, dp(8), 0);
        TextView titleView = bodyText(title, 19, TEXT);
        titleView.setTypeface(null, android.graphics.Typeface.BOLD);
        info.addView(titleView);
        info.addView(bodyText(desc, 13, Color.rgb(108, 122, 142)));
        TextView badgeView = bodyText(badge, 12, color);
        badgeView.setPadding(dp(8), dp(3), dp(8), dp(3));
        badgeView.setBackground(round(Color.argb(24, Color.red(color), Color.green(color), Color.blue(color)), 20));
        info.addView(badgeView);
        card.addView(info, new LinearLayout.LayoutParams(0, -2, 1));
        card.addView(bodyText("›", 28, Color.LTGRAY));
        card.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.setMargins(dp(18), dp(8), dp(18), dp(8));
        parent.addView(card, params);
    }

    private void buildProfilePage() {
        LinearLayout page = page();
        LinearLayout profile = row();
        profile.setPadding(dp(20), dp(22), dp(20), dp(20));
        profile.setBackground(gradient("#182647", "#324D82", 24));
        LinearLayout.LayoutParams profileParams = new LinearLayout.LayoutParams(-1, -2);
        profileParams.setMargins(dp(16), dp(10), dp(16), dp(8));
        profile.setLayoutParams(profileParams);
        View profileAvatar = userAvatarView(80);
        profileAvatar.setOnClickListener(v -> chooseAvatar());
        profile.addView(profileAvatar, new LinearLayout.LayoutParams(dp(80), dp(80)));
        LinearLayout info = column();
        info.setPadding(dp(18), 0, 0, 0);
        TextView name = bodyText(userName, 23, Color.WHITE);
        name.setMaxLines(2);
        name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        name.setTypeface(null, android.graphics.Typeface.BOLD);
        info.addView(name);
        TextView id = bodyText("▦  " + (currentUserSpxId.isEmpty() ? t("spx_id_loading") : currentUserSpxId), 13, BLUE);
        id.setPadding(dp(10), dp(6), dp(10), dp(6));
        id.setBackground(round(Color.rgb(238, 242, 255), 24));
        id.setOnClickListener(v -> copyText(currentUserSpxId, "SPX ID"));
        info.addView(id);
        TextView qr = bodyText(t("my_qr"), 12, Color.rgb(211, 223, 255));
        qr.setPadding(0, dp(6), 0, 0);
        qr.setOnClickListener(v -> showQrDialog(currentUserSpxId));
        info.addView(qr);
        profile.addView(info, new LinearLayout.LayoutParams(0, -2, 1));
        TextView edit = centeredText(t("edit"), 14, Color.WHITE);
        edit.setBackground(round(0x243F67A0, 12));
        edit.setTypeface(null, android.graphics.Typeface.BOLD);
        edit.setOnClickListener(v -> openProfileEditPage());
        profile.addView(edit, new LinearLayout.LayoutParams(dp(54), dp(40)));
        page.addView(profile);
        page.addView(section(t("account_assets")));
        addProfileMenu(page, "wallet", t("wallet"), t("wallet_menu_desc"), () -> openWalletPage());
        addProfileMenu(page, "orders", t("orders"), t("orders_menu_desc"), () -> openOrdersPage());
        addProfileMenu(page, "orders", "商家中心", "申请开店、保证金、商品与订单", () -> openMerchantCenter());
        String addressSummary = addressName.isEmpty() ? t("address_add_summary") : addressName + " · " + addressPhone + " · " + addressProvince + addressCity + addressDistrict;
        addProfileMenu(page, "address", t("my_address"), addressSummary, () -> openAddressPage());
        addProfileMenu(page, "stake", t("staking_records"), t("staking_records_desc"), () -> openStakingPage());
        page.addView(section(t("spx_services")));
        addProfileMenu(page, "invite", t("invite"), t("invite_menu_desc"), () -> openInvitePage());
        addProfileMenu(page, "help", t("ask_title"), t("ask_menu_desc"), () -> openAskWindow());
        addProfileMenu(page, "support", t("support"), t("support_menu_desc"), () -> openHelpPage());
        page.addView(section(t("general")));
        addProfileMenu(page, "settings", t("general_settings"), t("settings_menu_desc"), () -> openSettingsPage());
        try { page.addView(note(t("version_format", getPackageManager().getPackageInfo(getPackageName(), 0).versionName))); } catch (Exception ignored) { }
        pageScroll(page);
    }

    private void addProfileMenu(LinearLayout parent, String icon, String title, String desc, Runnable action) {
        LinearLayout item = row();
        item.setPadding(dp(20), dp(14), dp(20), dp(14));
        item.setBackground(MallUi.surface(this, Color.WHITE, 18, true));
        MallUi.touch(item, 18);
        SimpleIconView iconView = new SimpleIconView(this, icon);
        item.addView(iconView, new LinearLayout.LayoutParams(dp(38), dp(38)));
        LinearLayout text = column();
        text.setPadding(dp(14), 0, 0, 0);
        TextView titleView = bodyText(title, 16, TEXT);
        titleView.setTypeface(null, android.graphics.Typeface.BOLD);
        text.addView(titleView);
        text.addView(bodyText(desc, 12, MUTED));
        item.addView(text, new LinearLayout.LayoutParams(0, -2, 1));
        item.addView(bodyText("›", 26, Color.rgb(176, 190, 208)));
        item.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams menuParams = new LinearLayout.LayoutParams(-1, -2);
        menuParams.setMargins(dp(16), 0, dp(16), dp(8));
        parent.addView(item, menuParams);
    }

    private void openChatWindow(String name, String avatarText, String status, boolean group, String c1, String c2) {
        closeChatSocket();
        activeChatId = 0;
        activePeerUserId = 0;
        activeGroupId = 0;
        chatWindowOpen = true;
        setBottomNavVisible(false);
        content.removeAllViews();

        LinearLayout root = column();
        root.setBackgroundColor(BG);

        LinearLayout header = row();
        header.setPadding(dp(16), dp(8), dp(16), dp(8));
        header.setBackgroundColor(Color.WHITE);
        TextView back = centeredText("‹", 34, TEXT);
        back.setOnClickListener(v -> closeChatWindow());
        header.addView(back, new LinearLayout.LayoutParams(dp(42), dp(48)));
        LinearLayout headerInfo = column();
        headerInfo.setPadding(dp(6), 0, 0, 0);
        TextView titleView = bodyText(name, 18, TEXT);
        titleView.setTypeface(null, android.graphics.Typeface.BOLD);
        headerInfo.addView(titleView);
        headerInfo.addView(bodyText(group ? t("chat_group") : statusLabel(status), 12, statusColor(status)));
        header.addView(headerInfo, new LinearLayout.LayoutParams(0, -2, 1));
        TextView detailButton = centeredText("⋯", 26, TEXT);
        detailButton.setOnClickListener(v -> {
            if (group) openGroupDetailPage(name, avatarText, c1, c2);
            else openConversationDetail(name, avatarText, status, false, c1, c2);
        });
        header.addView(detailButton, new LinearLayout.LayoutParams(dp(42), dp(48)));
        root.addView(header);

        ScrollView messages = new ScrollView(this);
        LinearLayout messageList = column();
        messageList.setPadding(dp(16), dp(18), dp(16), dp(18));
        messageList.addView(centeredText(t("demo_time"), 12, MUTED));
        addMessage(messageList, name, avatarText, c1, c2, t("demo_message_incoming"), false);
        addMessage(messageList, t("self_label"), t("self_label"), "#3F5EFB", "#9B5DE5", t("demo_message_reply"), true);
        addMessage(messageList, name, avatarText, c1, c2, t("demo_message_latest"), false);
        applyChatBackground(messages);
        messages.addView(messageList, new ScrollView.LayoutParams(-1, -2));
        root.addView(messages, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout composer = row();
        composer.setPadding(dp(10), dp(8), dp(10), dp(8));
        composer.setBackgroundColor(Color.WHITE);
        TextView composerMore = centeredText("＋", 24, BLUE);
        composerMore.setOnClickListener(v -> showActionSheet());
        composer.addView(composerMore, new LinearLayout.LayoutParams(dp(40), dp(46)));
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint(t("message_input"));
        input.setTextSize(15);
        input.setPadding(dp(14), 0, dp(14), 0);
        input.setBackground(round(Color.rgb(240, 242, 245), 24));
        composer.addView(input, new LinearLayout.LayoutParams(0, dp(46), 1));
        activeMessageInput = input;
        TextView send = centeredText(t("send"), 14, BLUE);
        send.setTypeface(null, android.graphics.Typeface.BOLD);
        send.setOnClickListener(v -> {
            String text = input.getText().toString().trim();
            if (text.isEmpty()) return;
            addMessage(messageList, t("self_label"), t("self_label"), "#3F5EFB", "#9B5DE5", text, true);
            input.setText("");
            messages.post(() -> messages.fullScroll(View.FOCUS_DOWN));
        });
        composer.addView(send, new LinearLayout.LayoutParams(dp(54), dp(46)));
        root.addView(composer);
        content.addView(root, new FrameLayout.LayoutParams(-1, -1));
    }

    private int findChatPeerUserId(int chatId) {
        JSONArray snapshot = readChatSnapshot();
        for (int i = 0; i < snapshot.length(); i++) {
            JSONObject item = snapshot.optJSONObject(i);
            if (item != null && !"group".equals(item.optString("kind")) && item.optInt("id") == chatId)
                return item.optInt("peer_user_id");
        }
        return 0;
    }

    private void openChatWindow(int chatId, int groupId, String name, String avatarText, String status, String c1, String c2) {
        openChatWindow(chatId, groupId, name, avatarText, status, c1, c2, findChatPeerUserId(chatId));
    }

    private void openChatWindow(int chatId, int groupId, String name, String avatarText, String status, String c1, String c2, int peerUserId) {
        saveChatListStateBeforeOpen();
        closeChatSocket();
        activeChatId = chatId;
        activePeerUserId = peerUserId;
        activeGroupId = groupId;
        pendingChatUnread = 0;
        updateChatNavUnread();
        lastMessageId = 0;
        renderedMessageIds.clear();
        renderedMessageViews.clear();
        activeMentionUserIds.clear();
        activeChatName = name;
        activeChatAvatar = avatarText;
        activeChatC1 = c1;
        activeChatC2 = c2;
        chatWindowOpen = true;
        setBottomNavVisible(false);
        content.removeAllViews();

        LinearLayout root = column();
        root.setBackgroundColor(BG);
        LinearLayout header = row();
        header.setPadding(dp(16), dp(8), dp(16), dp(8));
        header.setBackgroundColor(Color.WHITE);
        TextView back = centeredText("‹", 34, TEXT);
        back.setOnClickListener(v -> closeChatWindow());
        header.addView(back, new LinearLayout.LayoutParams(dp(42), dp(48)));
        LinearLayout headerInfo = column();
        headerInfo.setPadding(dp(6), 0, 0, 0);
        TextView titleView = bodyText(name, 18, TEXT);
        titleView.setTypeface(null, android.graphics.Typeface.BOLD);
        headerInfo.addView(titleView);
        headerInfo.addView(bodyText(groupId > 0 ? t("chat_group") : t("online_session"), 12, MUTED));
        header.addView(headerInfo, new LinearLayout.LayoutParams(0, -2, 1));
        TextView detail = centeredText("⋯", 26, TEXT);
        detail.setOnClickListener(v -> {
            if (groupId > 0) openGroupDetailPage(name, avatarText, c1, c2);
            else openConversationDetail(name, avatarText, status, false, c1, c2);
        });
        header.addView(detail, new LinearLayout.LayoutParams(dp(42), dp(48)));
        root.addView(header);

        ScrollView messages = new ScrollView(this);
        LinearLayout messageList = column();
        messageList.setPadding(dp(16), dp(18), dp(16), dp(18));
        activeMessageList = messageList;
        activeMessageScroll = messages;
        applyChatBackground(messages);
        messages.addView(messageList, new ScrollView.LayoutParams(-1, -2));
        FrameLayout messageFrame = new FrameLayout(this);
        messageFrame.addView(messages, new FrameLayout.LayoutParams(-1, -1));
        newMessagesButton = centeredText(t("new_messages_view"), 13, Color.WHITE);
        newMessagesButton.setTypeface(null, android.graphics.Typeface.BOLD);
        newMessagesButton.setBackground(round(BLUE, 22));
        newMessagesButton.setVisibility(View.GONE);
        newMessagesButton.setOnClickListener(v -> scrollMessagesToBottom());
        FrameLayout.LayoutParams newMessagesParams = new FrameLayout.LayoutParams(-2, dp(42), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        newMessagesParams.setMargins(dp(12), 0, dp(12), dp(14));
        messageFrame.addView(newMessagesButton, newMessagesParams);
        messages.setOnScrollChangeListener((view, scrollX, scrollY, oldScrollX, oldScrollY) -> {
            if (isMessageScrollAtBottom()) hideNewMessagesButton();
        });
        root.addView(messageFrame, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout toolPanel = column();
        toolPanel.setPadding(dp(16), dp(10), dp(16), dp(10));
        toolPanel.setBackgroundColor(Color.rgb(247, 248, 250));
        toolPanel.setVisibility(View.GONE);
        root.addView(toolPanel);

        LinearLayout composer = row();
        composer.setGravity(Gravity.CENTER_VERTICAL);
        composer.setPadding(dp(8), dp(7), dp(8), dp(7));
        composer.setBackgroundColor(Color.WHITE);
        ImageView voiceMode = new ImageView(this);
        voiceMode.setImageResource(android.R.drawable.ic_btn_speak_now);
        voiceMode.setColorFilter(TEXT);
        voiceMode.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        voiceMode.setContentDescription(t("switch_voice_input"));
        composer.addView(voiceMode, new LinearLayout.LayoutParams(dp(42), dp(46)));
        EditText input = new EditText(this);
        input.setSingleLine(false);
        input.setMinLines(1);
        input.setMaxLines(4);
        input.setMaxHeight(dp(108));
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setGravity(Gravity.CENTER_VERTICAL);
        input.setHint(t("message_input"));
        input.setTextSize(15);
        input.setPadding(dp(14), dp(8), dp(14), dp(8));
        input.setBackground(stroke(Color.rgb(245, 247, 251), MallUi.LINE, 18, 1));
        composer.addView(input, new LinearLayout.LayoutParams(0, -2, 1));
        activeMessageInput = input;
        TextView holdToTalk = centeredText(t("voice_hold"), 15, TEXT);
        holdToTalk.setBackground(round(Color.rgb(240, 242, 245), 20));
        holdToTalk.setVisibility(View.GONE);
        composer.addView(holdToTalk, new LinearLayout.LayoutParams(0, dp(46), 1));
        TextView emoji = centeredText("😊", 25, TEXT);
        composer.addView(emoji, new LinearLayout.LayoutParams(dp(40), dp(46)));
        TextView more = centeredText("＋", 27, TEXT);
        composer.addView(more, new LinearLayout.LayoutParams(dp(40), dp(46)));
        TextView send = centeredText(t("send"), 14, BLUE);
        send.setTypeface(null, android.graphics.Typeface.BOLD);
        send.setOnClickListener(v -> {
            String text = input.getText().toString().trim();
            sendChatText(text, input, send, messageList, messages, name, avatarText, c1, c2);
        });
        composer.addView(send, new LinearLayout.LayoutParams(dp(54), dp(46)));
        Handler recordingTimer = new Handler(Looper.getMainLooper());
        Runnable[] recordingTick = {null};
        voiceMode.setOnClickListener(v -> {
            boolean voice = holdToTalk.getVisibility() != View.VISIBLE;
            input.setVisibility(voice ? View.GONE : View.VISIBLE);
            holdToTalk.setVisibility(voice ? View.VISIBLE : View.GONE);
            emoji.setVisibility(voice ? View.GONE : View.VISIBLE);
            send.setVisibility(voice ? View.GONE : View.VISIBLE);
            toolPanel.setVisibility(View.GONE);
            voiceMode.setImageResource(voice ? android.R.drawable.ic_menu_edit : android.R.drawable.ic_btn_speak_now);
            voiceMode.setContentDescription(voice ? t("switch_text_input") : t("switch_voice_input"));
        });
        holdToTalk.setOnTouchListener((view, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                voiceRecordingCancelled = false;
                if (startVoiceRecording()) {
                    holdToTalk.setText(t("recording") + " 00:00");
                    holdToTalk.setBackground(round(Color.rgb(210, 214, 220), 20));
                    recordingTick[0] = new Runnable() {
                        @Override public void run() {
                            if (voiceRecorder == null) return;
                            long seconds = (System.currentTimeMillis() - voiceRecordingStartedAt) / 1000L;
                            holdToTalk.setText(t(voiceRecordingCancelled ? "release_cancel_timer" : "recording_timer", String.format(java.util.Locale.ROOT, "%02d:%02d", seconds / 60, seconds % 60)));
                            recordingTimer.postDelayed(this, 200);
                        }
                    };
                    recordingTimer.post(recordingTick[0]);
                }
                return true;
            }
            if (event.getAction() == MotionEvent.ACTION_MOVE) {
                voiceRecordingCancelled = event.getY() < -dp(70);
                long seconds = Math.max(0, (System.currentTimeMillis() - voiceRecordingStartedAt) / 1000L);
                holdToTalk.setText(t(voiceRecordingCancelled ? "release_cancel_timer" : "continue_recording_timer", String.format(java.util.Locale.ROOT, "%02d:%02d", seconds / 60, seconds % 60)));
                return true;
            }
            if (event.getAction() == MotionEvent.ACTION_UP || event.getAction() == MotionEvent.ACTION_CANCEL) {
                boolean shouldSend = event.getAction() == MotionEvent.ACTION_UP && !voiceRecordingCancelled;
                if (recordingTick[0] != null) recordingTimer.removeCallbacks(recordingTick[0]);
                finishVoiceRecording(shouldSend);
                holdToTalk.setText(t("voice_hold"));
                holdToTalk.setBackground(round(Color.rgb(240, 242, 245), 20));
                return true;
            }
            return true;
        });
        emoji.setOnClickListener(v -> {
            if (toolPanel.getVisibility() == View.VISIBLE && "emoji".equals(toolPanel.getTag())) {
                toolPanel.setVisibility(View.GONE);
                return;
            }
            showEmojiPanel(toolPanel, value -> {
                int start = Math.max(input.getSelectionStart(), 0);
                int end = Math.max(input.getSelectionEnd(), 0);
                input.getText().replace(Math.min(start, end), Math.max(start, end), value);
                input.requestFocus();
            });
            toolPanel.setTag("emoji");
            toolPanel.setVisibility(View.VISIBLE);
        });
        more.setOnClickListener(v -> {
            if (toolPanel.getVisibility() == View.VISIBLE && "more".equals(toolPanel.getTag())) {
                toolPanel.setVisibility(View.GONE);
                return;
            }
            showChatMorePanel(toolPanel);
            toolPanel.setTag("more");
            toolPanel.setVisibility(View.VISIBLE);
        });
        root.addView(composer);
        content.addView(root, new FrameLayout.LayoutParams(-1, -1));
        JSONArray cachedMessages = chatCache.list(chatId > 0 ? "chat" : "group", chatId > 0 ? chatId : groupId);
        for (int i = 0; i < cachedMessages.length(); i++) {
            JSONObject cached = cachedMessages.optJSONObject(i);
            if (cached != null) renderChatMessage(cached, messageList, messages, name, avatarText, c1, c2);
        }
        messages.post(() -> messages.fullScroll(View.FOCUS_DOWN));
        markConversationRead(chatId, groupId);
        if (groupId > 0) showGroupAnnouncementOnEntry(groupId);
        connectChatSocket(messageList, messages, name, avatarText, c1, c2);
    }

    private void connectChatSocket(LinearLayout list, ScrollView scroll, String name, String avatarText, String c1, String c2) {
        activeMessageList = list;
        activeMessageScroll = scroll;
        if (chatSocket != null) {
            if (realtimeReady) loadChatHistory(list, scroll, name, avatarText, c1, c2, chatSocketGeneration);
            return;
        }
        startRealtimeSocket();
        if (realtimeReady) loadChatHistory(list, scroll, name, avatarText, c1, c2, chatSocketGeneration);
    }

    private void startRealtimeSocket() {
        if (chatSocket != null || ApiClient.token(this).isEmpty()) return;
        try {
            int generation = ++chatSocketGeneration;
            Uri base = Uri.parse(ApiClient.connectionBaseUrl(this));
            boolean secure = "https".equalsIgnoreCase(base.getScheme());
            String scheme = secure ? "wss" : "ws";
            String host = base.getHost() == null ? "70.39.201.191" : base.getHost();
            int port = base.getPort();
            String path = "/ws";
            String url = scheme + "://" + host + (port > 0 ? ":" + port : "") + path;
            chatSocket = new ChatWebSocket(url, ApiClient.token(this), new ChatWebSocket.Listener() {
                @Override public void onConnected() {
                    runOnUiThread(() -> {
                        if (generation != chatSocketGeneration) return;
                        realtimeReady = true;
                        if (chatWindowOpen && activeMessageList != null && activeMessageScroll != null)
                            loadChatHistory(activeMessageList, activeMessageScroll, activeChatName, activeChatAvatar, activeChatC1, activeChatC2, generation);
                    });
                }
                @Override public void onMessage(JSONObject event) {
                    runOnUiThread(() -> {
                        if (generation != chatSocketGeneration) return;
                        int eventChatId = event.optInt("chat_id");
                        int eventGroupId = event.optInt("group_id");
                        String eventType = event.optString("type", "message");
                        if ("presence.updated".equals(eventType)) { updateCachedPresence(event.optInt("peer_user_id"), event.optBoolean("is_online")); return; }
                        if ("profile.updated".equals(eventType)) { handleRemoteProfileUpdate(event); return; }
                        if ("conversation.deleted".equals(eventType)) { removeRealtimeConversation(eventChatId, event.optString("reason", "friend_removed")); return; }
                        if ("contact.deleted".equals(eventType)) {
                            int peerId = event.optInt("peer_user_id");
                            removeCachedContact(peerId);
                            preferences.edit().remove(userProfileCacheKey(peerId)).remove(userProfileCacheKey(peerId) + "_time").remove("remark_user_" + peerId).apply();
                            if (subPageOpen && content != null && content.getChildCount() > 0
                                    && ("friend-profile:" + peerId).equals(content.getChildAt(0).getTag())) {
                                loadUserProfile(peerId, new UserProfileCallback() {
                                    @Override public void onProfile(JSONObject profile) { openFriendProfilePage(profile); }
                                    @Override public void onError(String message) { closeSubPage(); }
                                });
                            }
                            if (activeTab == 1 && !subPageOpen) renderTab(1);
                            return;
                        }
                        if ("group.deleted".equals(eventType) || "group.member_removed".equals(eventType)) { removeRealtimeGroup(eventGroupId); return; }
                        if ("group.joined".equals(eventType)) {
                            invalidateChatSnapshot();
                            if (activeTab == 0 && !chatWindowOpen && !subPageOpen) renderTab(0);
                            return;
                        }
                        if ("message.deleted".equals(eventType)) { removeRealtimeMessage(event); return; }
                        if ("message.updated".equals(eventType)) { updateRealtimeMessage(event); return; }
                        JSONObject message = event.optJSONObject("message");
                        if (message == null) return;
                        if (message.optInt("sender_id") == currentUserId) return;
                        boolean viewing = chatWindowOpen && ((activeChatId > 0 && eventChatId == activeChatId) || (activeGroupId > 0 && eventGroupId == activeGroupId));
                        updateCachedConversation(event, message, !viewing);
                        if (viewing && activeMessageList != null && activeMessageScroll != null) {
                            boolean wasAtBottom = isMessageScrollAtBottom();
                            renderChatMessage(message, activeMessageList, activeMessageScroll, activeChatName, activeChatAvatar, activeChatC1, activeChatC2);
                            if (wasAtBottom) scrollMessagesToBottom();
                            else showNewMessagesButton();
                            if (isCurrentUserMentioned(message)) { playMessageTone(); toast(t("mentioned_you")); }
                            markConversationRead(activeChatId, activeGroupId);
                        } else {
                            pendingChatUnread++;
                            boolean mentionAlert = isCurrentUserMentioned(message);
                             if (mentionAlert || !isConversationMuted(eventChatId, eventGroupId)) {
                                 playMessageTone();
                                 if (!appInForeground) showChatNotification(message, eventChatId, eventGroupId);
                                 else showIncomingMessageBanner(message, eventChatId, eventGroupId);
                                 if (mentionAlert && appInForeground) toast(t("mentioned_you"));
                             }
                            updateChatNavUnread();
                            if (activeTab == 0 && !subPageOpen && !chatWindowOpen) {
                                invalidateChatSnapshot();
                                focusChatListTopAfterRefresh = true;
                                refreshVisibleChatList();
                            }
                        }
                    });
                }
                @Override public void onDisconnected() { realtimeReady = false; }
            });
            chatSocket.connect();
        } catch (Exception exception) {
            toast(t("realtime_unavailable"));
        }
    }

    private void markChatRead(int chatId) {
        JSONObject body = new JSONObject();
        try { body.put("chat_id", chatId); } catch (Exception ignored) { return; }
        ApiClient.post(this, "messages.read", body, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) { }
            @Override public void onError(String message) { }
        });
    }

    private void markConversationRead(int chatId, int groupId) {
        setCachedConversationUnread(chatId, groupId, 0);
        JSONObject body = new JSONObject();
        String action;
        try {
            if (groupId > 0) {
                body.put("group_id", groupId);
                action = "groups.messages.read";
            } else if (chatId > 0) {
                body.put("chat_id", chatId);
                action = "messages.read";
            } else return;
        } catch (Exception ignored) { return; }
        ApiClient.post(this, action, body, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) { setCachedConversationUnread(chatId, groupId, 0); }
            @Override public void onError(String message) { }
        });
    }

    private String chatSnapshotKey() { return "chat_snapshot_" + currentUserId; }

    private void invalidateChatSnapshot() {
        preferences.edit().putLong("chat_snapshot_sync_" + currentUserId, 0).apply();
    }

    private void removeRealtimeConversation(int chatId, String reason) {
        if (chatId <= 0) return;
        chatCache.clear("chat", chatId);
        JSONArray snapshot = readChatSnapshot();
        for (int i = snapshot.length() - 1; i >= 0; i--) {
            JSONObject item = snapshot.optJSONObject(i);
            if (item != null && !"group".equals(item.optString("kind")) && item.optInt("id") == chatId) snapshot.remove(i);
        }
        storeChatSnapshot(snapshot);
        invalidateChatSnapshot();
        if (chatWindowOpen && activeChatId == chatId) {
            closeChatWindow();
            toast(t("history_cleared".equals(reason) ? "history_cleared_short" : "friend_deleted_short"));
        } else if (activeTab == 0 && !subPageOpen) renderTab(0);
    }

    private void removeRealtimeGroup(int groupId) {
        if (groupId <= 0) return;
        chatCache.clear("group", groupId);
        clearGroupDetailCache(groupId);
        JSONArray snapshot = readChatSnapshot();
        for (int i = snapshot.length() - 1; i >= 0; i--) {
            JSONObject item = snapshot.optJSONObject(i);
            if (item != null && "group".equals(item.optString("kind")) && item.optInt("id") == groupId) snapshot.remove(i);
        }
        storeChatSnapshot(snapshot);
        invalidateChatSnapshot();
        if (chatWindowOpen && activeGroupId == groupId) {
            closeChatWindow();
            toast(t("removed_from_group"));
            return;
        }
        if (subPageOpen && activeDetailGroupId == groupId) closeSubPage();
        if (activeTab == 0 && !subPageOpen) renderTab(0);
    }

    private void handleRemoteProfileUpdate(JSONObject event) {
        int peerId = event.optInt("peer_user_id");
        String avatarUrl = event.optString("avatar_url", "");
        invalidateAvatarCache(avatarUrl);
        JSONObject cachedProfile = readCachedUserProfile(peerId);
        if (cachedProfile != null) {
            try { cachedProfile.put("avatar_url", avatarUrl); } catch (Exception ignored) { }
            cacheUserProfile(cachedProfile);
            preferences.edit().putLong(userProfileCacheKey(peerId) + "_time", System.currentTimeMillis()).apply();
        }
        JSONArray snapshot = readChatSnapshot();
        for (int i = 0; i < snapshot.length(); i++) {
            JSONObject item = snapshot.optJSONObject(i);
            if (item == null || item.optInt("peer_user_id") != peerId) continue;
            try { item.put("avatar_url", avatarUrl); } catch (Exception ignored) { }
        }
        storeChatSnapshot(snapshot);
        String contactKey = "contacts_cache_" + currentUserId;
        JSONArray contacts = readCachedArray(contactKey);
        for (int i = 0; i < contacts.length(); i++) {
            JSONObject contact = contacts.optJSONObject(i);
            if (contact != null && contact.optInt("id") == peerId) {
                try { contact.put("avatar_url", avatarUrl); } catch (Exception ignored) { }
            }
        }
        preferences.edit().putString(contactKey, contacts.toString()).apply();
        invalidateChatSnapshot();
        if (activeTab == 0 && !chatWindowOpen && !subPageOpen) renderTab(0);
        else if (activeTab == 1 && !subPageOpen) renderTab(1);
        if (!chatWindowOpen || activeChatId <= 0 || peerId <= 0) return;
        boolean activePeer = false;
        for (int i = 0; i < snapshot.length(); i++) {
            JSONObject item = snapshot.optJSONObject(i);
            if (item != null && item.optInt("id") == activeChatId && item.optInt("peer_user_id") == peerId) { activePeer = true; break; }
        }
        if (!activePeer) return;
        refreshActiveChatAvatars(activeChatId);
    }

    private void refreshActiveChatAvatars(int chatId) {
        int generation = chatSocketGeneration;
        Map<String, String> params = new HashMap<>();
        params.put("chat_id", String.valueOf(chatId));
        ApiClient.get(this, "messages", params, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                if (!(data instanceof JSONArray) || !chatWindowOpen || activeChatId != chatId || generation != chatSocketGeneration) return;
                JSONArray messages = (JSONArray) data;
                activeMessageList.removeAllViews();
                renderedMessageIds.clear();
                renderedMessageViews.clear();
                lastMessageId = 0;
                chatCache.clear("chat", chatId);
                for (int i = 0; i < messages.length(); i++) {
                    JSONObject message = messages.optJSONObject(i);
                    if (message == null) continue;
                    chatCache.put("chat", chatId, message);
                    renderChatMessage(message, activeMessageList, activeMessageScroll, activeChatName, activeChatAvatar, activeChatC1, activeChatC2);
                }
                activeMessageScroll.post(() -> activeMessageScroll.fullScroll(View.FOCUS_DOWN));
            }
            @Override public void onError(String message) { }
        });
    }

    private JSONArray readChatSnapshot() {
        try { return new JSONArray(preferences.getString(chatSnapshotKey(), "[]")); }
        catch (Exception ignored) { return new JSONArray(); }
    }

    private void storeChatSnapshot(JSONArray snapshot) {
        int unread = 0;
        for (int i = 0; i < snapshot.length(); i++) {
            JSONObject item = snapshot.optJSONObject(i);
            if (item != null) unread += item.optInt("unread_count", 0);
        }
        pendingChatUnread = unread;
        preferences.edit().putString(chatSnapshotKey(), snapshot.toString()).apply();
        updateChatNavUnread();
    }

    private void setCachedConversationUnread(int chatId, int groupId, int unread) {
        JSONArray snapshot = readChatSnapshot();
        for (int i = 0; i < snapshot.length(); i++) {
            JSONObject item = snapshot.optJSONObject(i);
            if (item == null) continue;
            boolean group = "group".equals(item.optString("kind"));
            int id = group ? item.optInt("id") : item.optInt("id");
            if ((group && id == groupId) || (!group && id == chatId)) {
                try { item.put("unread_count", unread); } catch (Exception ignored) { }
            }
        }
        storeChatSnapshot(snapshot);
    }

    private void updateCachedConversation(JSONObject event, JSONObject message, boolean incrementUnread) {
        int chatId = event.optInt("chat_id");
        int groupId = event.optInt("group_id");
        boolean group = groupId > 0;
        JSONArray snapshot = readChatSnapshot();
        JSONObject target = null;
        for (int i = 0; i < snapshot.length(); i++) {
            JSONObject item = snapshot.optJSONObject(i);
            if (item == null) continue;
            if ((group && "group".equals(item.optString("kind")) && item.optInt("id") == groupId)
                    || (!group && !"group".equals(item.optString("kind")) && item.optInt("id") == chatId)) {
                target = item;
                break;
            }
        }
        if (target == null) {
            target = new JSONObject();
            try {
                target.put("kind", group ? "group" : "chat");
                target.put("id", group ? groupId : chatId);
                target.put("peer_user_id", message.optInt("sender_id"));
                target.put("nickname", message.optString("nickname", t("new_message")));
                target.put("display_name", message.optString("nickname", t("new_message")));
                String groupName = normalizeOptionalText(message.optString("group_name", ""));
                if (groupName.isEmpty()) groupName = cachedGroupName(groupId);
                target.put("name", groupName.isEmpty() ? t("chat_group") : groupName);
                target.put("unread_count", 0);
                snapshot.put(target);
            } catch (Exception ignored) { return; }
        }
        String type = message.optString("message_type", "text");
        String preview = "image".equals(type) ? t("ui_image_placeholder") : ("video".equals(type) ? t("ui_video_placeholder") : ("voice".equals(type) ? t("ui_voice_placeholder") : message.optString("content", "")));
        try {
            target.put("last_message", preview);
            String now = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).format(new java.util.Date());
            target.put("last_message_at", now);
            target.put("updated_at", now);
            if (group) {
                String eventGroupName = normalizeOptionalText(message.optString("group_name", ""));
                if (!eventGroupName.isEmpty()) target.put("name", eventGroupName);
            }
            if (incrementUnread) target.put("unread_count", target.optInt("unread_count", 0) + 1);
        } catch (Exception ignored) { }
        storeChatSnapshot(snapshot);
    }

    private boolean isConversationMuted(int chatId, int groupId) {
        JSONArray snapshot = readChatSnapshot();
        for (int i = 0; i < snapshot.length(); i++) {
            JSONObject item = snapshot.optJSONObject(i);
            if (item == null) continue;
            if (groupId > 0 && "group".equals(item.optString("kind")) && item.optInt("id") == groupId) return item.optInt("mute") == 1;
            if (chatId > 0 && item.optInt("id") == chatId && !"group".equals(item.optString("kind"))) return item.optInt("mute") == 1;
        }
        return false;
    }

    private void updateRealtimeMessage(JSONObject event) {
        JSONObject message = event == null ? null : event.optJSONObject("message");
        if (message == null) return;
        boolean eventGroup = event.optInt("group_id") > 0;
        if ((eventGroup && activeGroupId != event.optInt("group_id")) || (!eventGroup && activeChatId != event.optInt("chat_id"))) {
            invalidateChatSnapshot();
            refreshChatListIfVisible();
            return;
        }
        String key = (activeGroupId > 0 ? "g" : "c") + message.optInt("id");
        View view = renderedMessageViews.get(key);
        if (view instanceof TextView) ((TextView) view).setText(message.optString("content", ""));
        chatCache.put(activeGroupId > 0 ? "group" : "chat", activeGroupId > 0 ? activeGroupId : activeChatId, message);
    }

    private void removeRealtimeMessage(JSONObject event) {
        int id = event.optInt("message_id");
        boolean eventGroup = event.optInt("group_id") > 0;
        if ((eventGroup && activeGroupId != event.optInt("group_id")) || (!eventGroup && activeChatId != event.optInt("chat_id"))) {
            invalidateChatSnapshot();
            refreshChatListIfVisible();
            return;
        }
        String key = (activeGroupId > 0 ? "g" : "c") + id;
        View view = renderedMessageViews.remove(key);
        renderedMessageIds.remove(key);
        if (view != null && view.getParent() instanceof ViewGroup) {
            View row = (View) view.getParent();
            if (row.getParent() instanceof ViewGroup) ((ViewGroup) row.getParent()).removeView(row);
        }
        chatCache.remove(activeGroupId > 0 ? "group" : "chat", activeGroupId > 0 ? activeGroupId : activeChatId, id);
        invalidateChatSnapshot();
        refreshChatListIfVisible();
    }

    private void refreshChatListIfVisible() {
        if (activeTab == 0 && !subPageOpen && !chatWindowOpen && bottomNav != null) refreshVisibleChatList();
    }

    private void updateChatNavUnread() {
        if (bottomNav == null || bottomNav.getChildCount() == 0) return;
        TextView tab = (TextView) bottomNav.getChildAt(0);
        tab.setText(t("chats") + (pendingChatUnread > 0 ? " " + Math.min(99, pendingChatUnread) : ""));
        int navColor = pendingChatUnread > 0 ? Color.rgb(205, 56, 78) : (activeTab == 0 ? BLUE : MUTED);
        tab.setTextColor(navColor);
        if (tab.getCompoundDrawables()[1] instanceof AppNavIcon)
            ((AppNavIcon)tab.getCompoundDrawables()[1]).color(navColor);
    }

    private void loadChatHistory(LinearLayout list, ScrollView scroll, String name, String avatarText, String c1, String c2, int generation) {
        if (!chatWindowOpen || (activeChatId <= 0 && activeGroupId <= 0)) return;
        Map<String, String> params = new HashMap<>();
        params.put(activeGroupId > 0 ? "group_id" : "chat_id", String.valueOf(activeGroupId > 0 ? activeGroupId : activeChatId));
        params.put("after_id", String.valueOf(lastMessageId));
        ApiClient.get(this, activeGroupId > 0 ? "groups.messages" : "messages", params, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                if (generation != chatSocketGeneration) return;
        if (data instanceof JSONArray) {
                    JSONArray messages = (JSONArray) data;
                    for (int i = 0; i < messages.length(); i++) {
                        JSONObject message = messages.optJSONObject(i);
                        if (message == null) continue;
                        chatCache.put(activeGroupId > 0 ? "group" : "chat", activeGroupId > 0 ? activeGroupId : activeChatId, message);
                        renderChatMessage(message, list, scroll, name, avatarText, c1, c2);
                    }
                }
            }
            @Override public void onError(String message) { toast(message); }
        });
    }

    private void renderChatMessage(JSONObject message, LinearLayout list, ScrollView scroll, String name, String avatarText, String c1, String c2) {
        int id = message.optInt("id");
        int conversationId = activeGroupId > 0 ? activeGroupId : activeChatId;
        String scope = activeGroupId > 0 ? "group" : "chat";
        if (chatCache != null && conversationId > 0 && id > 0 && chatCache.isHidden(scope, conversationId, id)) return;
        String key = (activeGroupId > 0 ? "g" : "c") + id;
        if (!renderedMessageIds.add(key)) return;
        if (chatCache != null && (activeChatId > 0 || activeGroupId > 0)) chatCache.put(activeGroupId > 0 ? "group" : "chat", activeGroupId > 0 ? activeGroupId : activeChatId, message);
        lastMessageId = Math.max(lastMessageId, id);
        String sender = message.optString("nickname", name);
        int senderId = message.optInt("sender_id");
        if (activeChatId > 0 && senderId > 0 && senderId != currentUserId) activePeerUserId = senderId;
        boolean mine = currentUserId > 0 ? message.optInt("sender_id") == currentUserId : sender.equals(userName);
        String timestamp = formatBeijingMessageTime(message.optString("created_at", ""));
        if (!timestamp.isEmpty()) {
            TextView timeLabel = centeredText(timestamp, 11, MUTED);
            LinearLayout.LayoutParams timeParams = new LinearLayout.LayoutParams(-1, dp(24));
            timeParams.setMargins(0, dp(8), 0, dp(3));
            list.addView(timeLabel, timeParams);
        }
        String type = message.optString("message_type", "text");
        View messageView;
        String content = message.optString("content", "");
        if ("text".equals(type) && content.startsWith("SPXGROUP:")) {
            String[] parts = content.split("\\n", 2);
            String code = parts[0].substring("SPXGROUP:".length()).trim();
            JSONObject invite = new JSONObject();
            try {
                if (parts.length > 1) invite = new JSONObject(parts[1]);
                invite.put("group_code", code);
            } catch (Exception ignored) { }
            messageView = addGroupShareCard(list, mine, sender, message.optString("avatar_url", ""), invite);
        } else if ("voice".equals(type)) {
            messageView = addVoiceMessage(list, message.optString("media_url", ""), message.optString("content", t("ui_voice_placeholder")), mine, message.optString("avatar_url", ""));
        } else if ("image".equals(type) || "video".equals(type)) {
            messageView = addMediaMessage(list, message.optString("media_url", ""), type, mine, sender, avatarText, c1, c2, message.optString("avatar_url", ""));
        } else {
            TextView text = addMessage(list, mine ? t("self_label") : sender, mine ? t("self_label") : avatarText, c1, c2, content, mine, message.optString("avatar_url", ""));
            applyQuoteHighlight(text, content);
            messageView = text;
        }
        renderedMessageViews.put(key, messageView);
        if ("text".equals(type) && content.startsWith("SPXGROUP:")) messageView.setOnLongClickListener(v -> true);
        else messageView.setOnLongClickListener(v -> { showMessageActions(message, messageView, mine, "voice".equals(type) || "image".equals(type) || "video".equals(type)); return true; });
        if (activeGroupId > 0 && !mine && senderId > 0 && messageView.getParent() instanceof ViewGroup) {
            ViewGroup line = (ViewGroup) messageView.getParent();
            if (line.getChildCount() > 0) {
                View avatar = line.getChildAt(0);
                avatar.setOnClickListener(v -> showGroupMemberInfo(activeGroupId, senderId));
                avatar.setOnLongClickListener(v -> {
                if (activeMessageInput != null) {
                    if (!activeMentionUserIds.contains(senderId)) activeMentionUserIds.add(senderId);
                    int position = Math.max(activeMessageInput.getSelectionStart(), 0);
                    activeMessageInput.getText().insert(position, "@" + sender + " ");
                    activeMessageInput.requestFocus();
                    toast(t("mentioned_prefix") + sender);
                }
                return true;
                });
            }
        }
    }

    private boolean isCurrentUserMentioned(JSONObject message) {
        JSONArray ids = message == null ? null : message.optJSONArray("mention_user_ids");
        if (ids == null) return false;
        for (int i = 0; i < ids.length(); i++) if (ids.optInt(i) == currentUserId) return true;
        return false;
    }

    private void applyQuoteHighlight(TextView view, String content) {
        if (!content.startsWith(t("quote_prefix"))) return;
        int end = content.indexOf(t("quote_separator"));
        if (end < 0) end = content.indexOf('\n');
        if (end <= 0) return;
        android.text.SpannableString styled = new android.text.SpannableString(content);
        styled.setSpan(new android.text.style.BackgroundColorSpan(Color.rgb(227, 231, 238)), 0, end, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        styled.setSpan(new android.text.style.ForegroundColorSpan(Color.rgb(69, 78, 92)), 0, end, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        view.setText(styled);
    }

    private View addGroupShareCard(LinearLayout parent, boolean mine, String senderName, String senderAvatarUrl, JSONObject group) {
        String code = group.optString("group_code", "");
        String groupName = group.optString("name", t("chat_group"));
        String avatarUrl = group.optString("avatar_url", "");
        int memberCount = group.optInt("member_count");
        LinearLayout line = row();
        line.setGravity(mine ? Gravity.RIGHT : Gravity.LEFT);
        if (!mine) line.addView(avatarWithRemoteImage(senderName.isEmpty() ? t("ui_chat_avatar") : senderName.substring(0, 1), senderAvatarUrl, "#A8C0FF", "#3F5EFB", 36));

        LinearLayout card = column();
        card.setPadding(dp(12), dp(12), dp(12), dp(10));
        card.setBackground(stroke(Color.WHITE, Color.rgb(218, 224, 235), 12, 1));
        LinearLayout details = row();
        details.setGravity(Gravity.CENTER_VERTICAL);
        details.addView(avatarWithRemoteImage(t("ui_group_avatar"), avatarUrl, "#5B7CFA", "#9B5DE5", 50));
        LinearLayout text = column();
        text.setPadding(dp(11), 0, 0, 0);
        TextView title = bodyText(groupName, 16, TEXT);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setMaxWidth(dp(190));
        title.setSingleLine(true);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        text.addView(title);
        text.addView(bodyText(t("group_member_code", memberCount, code), 12, MUTED));
        details.addView(text, new LinearLayout.LayoutParams(0, -2, 1));
        card.addView(details);
        View divider = new View(this);
        divider.setBackgroundColor(Color.rgb(235, 238, 243));
        LinearLayout.LayoutParams dividerParams = new LinearLayout.LayoutParams(-1, dp(1));
        dividerParams.setMargins(0, dp(10), 0, dp(8));
        card.addView(divider, dividerParams);
        TextView action = bodyText(t("view_join_group") + "  ›", 13, BLUE);
        action.setTypeface(null, android.graphics.Typeface.BOLD);
        card.addView(action);
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(Math.min(dp(310), getResources().getDisplayMetrics().widthPixels - dp(108)), -2);
        cardParams.setMargins(mine ? dp(52) : dp(9), dp(5), mine ? 0 : dp(52), dp(5));
        line.addView(card, cardParams);
        card.setOnClickListener(v -> joinGroupByCode(code));
        parent.addView(line, new LinearLayout.LayoutParams(-1, -2));
        return card;
    }

    private void closeChatSocket() {
        activeMessageInput = null;
        activeMessageList = null;
        activeMessageScroll = null;
        newMessagesButton = null;
        incomingBannerHandler.removeCallbacks(hideIncomingBanner);
        hideIncomingBanner.run();
    }

    private boolean isMessageScrollAtBottom() {
        if (activeMessageScroll == null || activeMessageScroll.getChildCount() == 0) return true;
        View child = activeMessageScroll.getChildAt(0);
        int distance = child.getBottom() - (activeMessageScroll.getScrollY() + activeMessageScroll.getHeight());
        return distance <= dp(80);
    }

    private void showNewMessagesButton() {
        if (newMessagesButton != null) newMessagesButton.setVisibility(View.VISIBLE);
    }

    private void hideNewMessagesButton() {
        if (newMessagesButton != null) newMessagesButton.setVisibility(View.GONE);
    }

    private void scrollMessagesToBottom() {
        if (activeMessageScroll == null) return;
        activeMessageScroll.post(() -> {
            if (activeMessageScroll == null) return;
            activeMessageScroll.fullScroll(View.FOCUS_DOWN);
            hideNewMessagesButton();
        });
    }

    private void playMessageTone() {
        try {
            if (messageTone == null) messageTone = new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 75);
            messageTone.startTone(ToneGenerator.TONE_PROP_BEEP, 120);
        } catch (Exception ignored) { }
    }

    private TextView addVoiceMessage(LinearLayout parent, String url, String label, boolean mine, String avatarUrl) {
        LinearLayout line = row();
        line.setGravity(mine ? Gravity.RIGHT : Gravity.LEFT);
        String duration = label.replaceAll("[^0-9]", "");
        if (duration.isEmpty()) duration = "1";
        final String durationLabel = duration;
        final String idleLabel = "◖))   " + durationLabel + "″";
        TextView bubble = centeredText("◖))   " + durationLabel + "″", 15, TEXT);
        bubble.setPadding(dp(16), dp(11), dp(16), dp(11));
        bubble.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
        bubble.setBackground(round(mine ? Color.rgb(218, 243, 211) : Color.rgb(239, 241, 244), 12));
        int width = Math.min(190, Math.max(84, 70 + Integer.parseInt(duration) * 2));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(dp(width), dp(44));
        params.setMargins(mine ? dp(52) : dp(8), dp(5), mine ? 0 : dp(52), dp(5));
        if (!mine) line.addView(avatarWithRemoteImage(t("ui_chat_avatar"), avatarUrl, "#A8C0FF", "#3F5EFB", 36));
        line.addView(bubble, params);
        parent.addView(line, new LinearLayout.LayoutParams(-1, -2));
        boolean[] playerReady = {false};
        boolean[] loading = {false};
        String path = Uri.parse(url).getLastPathSegment();
        String extension = path != null && path.matches(".*\\.[A-Za-z0-9]{2,5}") ? path.substring(path.lastIndexOf('.')) : ".3gp";
        File voiceCache = new File(new File(new File(getFilesDir(), "media-cache"), "voice"), Integer.toHexString(url.hashCode()) + extension);
        bubble.setOnClickListener(v -> {
            if (url.isEmpty()) return;
            if (loading[0]) return;
            if (activeVoicePlayer != null && activeVoiceBubble == bubble) {
                if (!playerReady[0]) return;
                try {
                    if (activeVoicePlayer.isPlaying()) {
                        activeVoicePlayer.pause();
                        bubble.setText("▶))   " + durationLabel + "″");
                    } else {
                        activeVoicePlayer.start();
                        bubble.setText("Ⅱ))   " + durationLabel + "″");
                    }
                } catch (Exception ignored) { stopActiveVoicePlayback(); }
                return;
            }
            stopActiveVoicePlayback();
            playerReady[0] = false;
            if (voiceCache.isFile() && voiceCache.length() > 0) {
                startVoicePlayback(bubble, voiceCache, durationLabel, playerReady);
                return;
            }
            loading[0] = true;
            activeVoiceBubble = bubble;
            activeVoiceLabel = idleLabel;
            bubble.setText("◉ " + t("loading_voice"));
            downloadVoiceFile(url, voiceCache, bubble, durationLabel, playerReady, loading);
        });
        return bubble;
    }

    private void downloadVoiceFile(String url, File destination, TextView bubble, String durationLabel, boolean[] playerReady, boolean[] loading) {
        new Thread(() -> {
            HttpURLConnection connection = null;
            File parent = destination.getParentFile();
            File partial = new File(destination.getAbsolutePath() + ".part");
            try {
                if (parent != null && !parent.exists() && !parent.mkdirs() && !parent.isDirectory()) throw new IllegalStateException("voice cache directory creation failed");
                connection = ApiClient.openConnection(this, url);
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(15000);
                connection.setReadTimeout(60000);
                int status = connection.getResponseCode();
                if (status < 200 || status >= 300) throw new IllegalStateException("voice download failed (HTTP " + status + ")");
                try (InputStream input = connection.getInputStream(); FileOutputStream output = new FileOutputStream(partial)) {
                    byte[] buffer = new byte[16384];
                    int count;
                    while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
                    output.getFD().sync();
                }
                if (partial.length() <= 0) throw new IllegalStateException("voice file is empty");
                if (destination.exists() && !destination.delete()) throw new IllegalStateException("voice cache replacement failed");
                if (!partial.renameTo(destination)) throw new IllegalStateException("voice cache save failed");
                runOnUiThread(() -> {
                    loading[0] = false;
                    if (activeVoiceBubble != bubble) return;
                    startVoicePlayback(bubble, destination, durationLabel, playerReady);
                });
            } catch (Exception exception) {
                partial.delete();
                String message = t("voice_download_failed");
                runOnUiThread(() -> {
                    loading[0] = false;
                    if (activeVoiceBubble == bubble) {
                        activeVoiceBubble = null;
                        activeVoiceLabel = "";
                        bubble.setText("◖))   " + durationLabel + "″");
                        toast(message);
                    }
                });
            } finally {
                if (connection != null) connection.disconnect();
            }
        }, "spx-voice-download").start();
    }

    private void startVoicePlayback(TextView bubble, File file, String durationLabel, boolean[] playerReady) {
        try {
            MediaPlayer player = new MediaPlayer();
            activeVoicePlayer = player;
            activeVoiceBubble = bubble;
            activeVoiceLabel = "◖))   " + durationLabel + "″";
            playerReady[0] = false;
            player.setAudioStreamType(AudioManager.STREAM_MUSIC);
            player.setDataSource(file.getAbsolutePath());
            player.setOnPreparedListener(prepared -> {
                if (activeVoicePlayer != prepared) return;
                playerReady[0] = true;
                bubble.setText("Ⅱ))   " + durationLabel + "″");
                prepared.start();
            });
            player.setOnCompletionListener(done -> {
                if (activeVoicePlayer == done) {
                    activeVoicePlayer = null;
                    activeVoiceBubble = null;
                    activeVoiceLabel = "";
                }
                done.release();
                bubble.setText("◖))   " + durationLabel + "″");
            });
            player.setOnErrorListener((failed, what, extra) -> {
                if (activeVoicePlayer == failed) {
                    activeVoicePlayer = null;
                    activeVoiceBubble = null;
                    activeVoiceLabel = "";
                }
                try { failed.reset(); } catch (Exception ignored) { }
                failed.release();
                bubble.setText("◖))   " + durationLabel + "″");
                toast(t("voice_invalid"));
                return true;
            });
            player.prepareAsync();
            bubble.setText("◉ " + t("loading_voice"));
        } catch (Exception exception) {
            stopActiveVoicePlayback();
            bubble.setText("◖))   " + durationLabel + "″");
            toast(t("voice_play_failed"));
        }
    }

    private void stopActiveVoicePlayback() {
        MediaPlayer player = activeVoicePlayer;
        TextView bubble = activeVoiceBubble;
        String label = activeVoiceLabel;
        activeVoicePlayer = null;
        activeVoiceBubble = null;
        activeVoiceLabel = "";
        if (bubble != null && !label.isEmpty()) bubble.setText(label);
        if (player == null) return;
        try { if (player.isPlaying()) player.stop(); } catch (Exception ignored) { }
        try { player.reset(); } catch (Exception ignored) { }
        try { player.release(); } catch (Exception ignored) { }
    }

    private void showMessageActions(JSONObject message, View messageView, boolean mine, boolean media) {
        ArrayList<String> actions = new ArrayList<>();
        if (!media) { actions.add(t("copy")); actions.add(t("reply")); }
        if (mine && "text".equals(message.optString("message_type", "text"))) actions.add(t("edit_message"));
        if (mine) actions.add(t("delete_everyone"));
        if (!mine) actions.add(t("delete"));
        if (actions.isEmpty()) return;
        new AlertDialog.Builder(this).setItems(actions.toArray(new String[0]), (dialog, which) -> {
            String action = actions.get(which);
            if (t("copy").equals(action)) copyText(message.optString("content", ""), t("message_label"));
            else if (t("reply").equals(action) && activeMessageInput != null) {
                String quote = t("quote_template", message.optString("nickname", t("message_label")), message.optString("content", ""));
                int position = Math.max(activeMessageInput.getSelectionStart(), 0);
                activeMessageInput.getText().insert(position, quote);
                activeMessageInput.requestFocus();
            } else if (t("edit_message").equals(action)) editChatMessage(message, messageView);
            else if (t("delete_everyone").equals(action)) deleteChatMessage(message, messageView);
            else if (t("delete").equals(action)) hideLocalMessage(message, messageView);
        }).show();
    }

    private void hideLocalMessage(JSONObject message, View messageView) {
        int conversationId = activeGroupId > 0 ? activeGroupId : activeChatId;
        String scope = activeGroupId > 0 ? "group" : "chat";
        int messageId = message.optInt("id");
        if (conversationId <= 0 || messageId <= 0 || chatCache == null) return;
        chatCache.hide(scope, conversationId, messageId);
        String key = (activeGroupId > 0 ? "g" : "c") + messageId;
        renderedMessageIds.remove(key);
        renderedMessageViews.remove(key);
        if (messageView.getParent() instanceof ViewGroup) {
            View row = (View) messageView.getParent();
            if (row.getParent() instanceof ViewGroup) ((ViewGroup) row.getParent()).removeView(row);
        }
        toast(t("deleted"));
    }

    private void editChatMessage(JSONObject message, View messageView) {
        EditText editor = new EditText(this);
        editor.setText(message.optString("content", ""));
        editor.setMinLines(2);
        new AlertDialog.Builder(this).setTitle(t("edit_message")).setView(editor).setNegativeButton(t("cancel"), null).setPositiveButton(t("save"), (dialog, which) -> {
            JSONObject request = new JSONObject();
            try {
                request.put(activeGroupId > 0 ? "group_id" : "chat_id", activeGroupId > 0 ? activeGroupId : activeChatId);
                request.put("message_id", message.optInt("id"));
                request.put("content", editor.getText().toString().trim());
            } catch (Exception ignored) { return; }
            ApiClient.post(this, activeGroupId > 0 ? "groups.messages.edit" : "messages.edit", request, new ApiClient.Callback() {
                @Override public void onSuccess(Object data) {
                    String updated = editor.getText().toString().trim();
                    try { message.put("content", updated); } catch (Exception ignored) { }
                    if (messageView instanceof TextView) ((TextView) messageView).setText(updated);
                    chatCache.put(activeGroupId > 0 ? "group" : "chat", activeGroupId > 0 ? activeGroupId : activeChatId, message);
                    invalidateChatSnapshot();
                    toast(t("message_edited"));
                }
                @Override public void onError(String error) { toast(error); }
            });
        }).show();
    }

    private void deleteChatMessage(JSONObject message, View messageView) {
        new AlertDialog.Builder(this).setMessage(t("delete_message_confirm")).setNegativeButton(t("cancel"), null).setPositiveButton(t("delete"), (dialog, which) -> {
            JSONObject request = new JSONObject();
            try {
                request.put(activeGroupId > 0 ? "group_id" : "chat_id", activeGroupId > 0 ? activeGroupId : activeChatId);
                request.put("message_id", message.optInt("id"));
            } catch (Exception ignored) { return; }
            ApiClient.post(this, activeGroupId > 0 ? "groups.messages.delete" : "messages.delete", request, new ApiClient.Callback() {
                @Override public void onSuccess(Object data) {
                    String key = (activeGroupId > 0 ? "g" : "c") + message.optInt("id");
                    renderedMessageIds.remove(key);
                    renderedMessageViews.remove(key);
                    if (messageView.getParent() instanceof ViewGroup) {
                        View row = (View) messageView.getParent();
                        if (row.getParent() instanceof ViewGroup) ((ViewGroup) row.getParent()).removeView(row);
                    }
                    chatCache.remove(activeGroupId > 0 ? "group" : "chat", activeGroupId > 0 ? activeGroupId : activeChatId, message.optInt("id"));
                    invalidateChatSnapshot();
                    toast(t("message_deleted_everyone"));
                }
                @Override public void onError(String error) { toast(error); }
            });
        }).show();
    }

    private interface EmojiAction { void onPick(String value); }

    private void sendChatText(String text, EditText input, TextView send, LinearLayout list, ScrollView scroll,
                              String name, String avatarText, String c1, String c2) {
        if (sendingMessage || text.isEmpty()) return;
        sendingMessage = true;
        send.setEnabled(false);
        int sendChatId = activeChatId;
        int sendGroupId = activeGroupId;
        String clientMessageId = UUID.randomUUID().toString();
        JSONObject body = new JSONObject();
        try {
            body.put(sendGroupId > 0 ? "group_id" : "chat_id", sendGroupId > 0 ? sendGroupId : sendChatId);
            body.put("content", text);
            body.put("message_type", "text");
            body.put("client_message_id", clientMessageId);
            if (sendGroupId > 0 && !activeMentionUserIds.isEmpty()) {
                JSONArray mentions = new JSONArray();
                for (Integer mentionedId : activeMentionUserIds) mentions.put(mentionedId);
                body.put("mention_user_ids", mentions);
            }
        } catch (Exception ignored) { sendingMessage = false; send.setEnabled(true); return; }
        ApiClient.post(this, sendGroupId > 0 ? "groups.messages.send" : "messages.send", body, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                sendingMessage = false;
                send.setEnabled(true);
                invalidateChatSnapshot();
                if (activeChatId == sendChatId && activeGroupId == sendGroupId
                        && input != null && input == activeMessageInput
                        && input.getText().toString().trim().equals(text)) {
                    input.setText("");
                    activeMentionUserIds.clear();
                }
                        if (activeChatId == sendChatId && activeGroupId == sendGroupId && data instanceof JSONObject) {
                    JSONObject sent = (JSONObject) data;
                    JSONObject message = new JSONObject();
                    try {
                        message.put("id", sent.optInt("id"));
                        message.put("chat_id", activeChatId);
                        message.put("group_id", activeGroupId);
                        message.put("sender_id", currentUserId);
                        message.put("nickname", userName);
                        message.put("avatar_url", remoteAvatarUrl);
                         message.put("content", text);
                         message.put("message_type", "text");
                         message.put("client_message_id", clientMessageId);
                         renderChatMessage(message, list, scroll, name, avatarText, c1, c2);
                         scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
                         } catch (Exception ignored) { }
                    }
            }
            @Override public void onError(String message) { sendingMessage = false; send.setEnabled(true); toast(message); }
        });
    }

    private void showEmojiPanel(LinearLayout panel, EmojiAction action) {
        panel.removeAllViews();
        ScrollView scroll = new ScrollView(this);
        LinearLayout rows = column();
        String[] emojis = {"😀","😃","😄","😁","😆","😅","😂","🤣","😊","😇","🙂","🙃","😉","😍","🥰","😘","😗","😙","😚","😋","😛","😜","🤪","😝","🤑","🤗","🤭","🤫","🤔","🤐","🤨","😐","😑","😶","🙄","😏","😣","😥","😮","🤐","😯","😪","😫","🥱","😴","😌","😛","😜","😓","😔","😕","🙃","🫠","😲","☹️","🙁","😖","😞","😟","😤","😢","😭","😦","😧","😨","😩","🤯","😬","😰","😱","🥵","🥶","😳","🤪","😵","😡","😠","🤬","😷","🤒","🤕","🤢","🤮","🤧","🥳","😎","🤓","🧐","😕","😟","👍","👎","👌","🤌","🤏","✌️","🤞","🫰","🤟","🤘","🤙","👈","👉","👆","👇","☝️","✋","🤚","🖐️","🖖","👋","🤏","👏","🙌","👐","🤲","🙏","💪","❤️","🧡","💛","💚","💙","💜","🖤","🤍","💔","💕","💞","💓","💗","💖","💘","💝","💟","❣️","💌","💤","🎉","🎊","✨","🔥","🌹","🌷","🌞","🌈","☀️","⭐","🌟","☕","🍰","🍻","⚽","🎁"};
        for (int start = 0; start < emojis.length; start += 8) {
            LinearLayout row = row();
            for (int i = start; i < Math.min(start + 8, emojis.length); i++) {
                final String value = emojis[i];
                TextView item = centeredText(value, 24, TEXT);
                item.setOnClickListener(v -> { panel.setVisibility(View.GONE); action.onPick(value); });
                row.addView(item, new LinearLayout.LayoutParams(0, dp(42), 1));
            }
            rows.addView(row, new LinearLayout.LayoutParams(-1, dp(42)));
        }
        scroll.addView(rows);
        panel.addView(scroll, new LinearLayout.LayoutParams(-1, dp(210)));
    }

    private void showChatMorePanel(LinearLayout panel) {
        panel.removeAllViews();
        LinearLayout choices = row();
        choices.setGravity(Gravity.CENTER_VERTICAL);
        addChatMoreAction(choices, panel, t("gallery"), "gallery", this::chooseChatMedia);
        addChatMoreAction(choices, panel, t("take_photo"), "camera", () -> {
            panel.setVisibility(View.GONE);
            if (sendingMessage) return;
            sendingMessage = true;
            pendingMediaChatId = activeChatId;
            pendingMediaGroupId = activeGroupId;
            pendingMediaClientId = UUID.randomUUID().toString();
            requestCamera(CAMERA_CHAT_PHOTO);
        });
        addChatMoreAction(choices, panel, t("call"), "phone", () -> toast(t("voice_call_unavailable")));
        addChatMoreAction(choices, panel, t("video_call"), "video", () -> toast(t("video_call_unavailable")));
        panel.addView(choices, new LinearLayout.LayoutParams(-1, dp(82)));
    }

    private void addChatMoreAction(LinearLayout parent, LinearLayout panel, String label, String icon, Runnable action) {
        LinearLayout item = column();
        item.setGravity(Gravity.CENTER);
        SimpleIconView image = new SimpleIconView(this, icon);
        item.addView(image, new LinearLayout.LayoutParams(dp(42), dp(42)));
        TextView text = centeredText(label, 11, Color.rgb(75, 87, 104));
        item.addView(text, new LinearLayout.LayoutParams(-1, dp(24)));
        item.setOnClickListener(v -> { panel.setVisibility(View.GONE); action.run(); });
        parent.addView(item, new LinearLayout.LayoutParams(0, dp(76), 1));
    }

    private void chooseChatMedia() {
        if (sendingMessage) return;
        sendingMessage = true;
        pendingMediaChatId = activeChatId;
        pendingMediaGroupId = activeGroupId;
        pendingMediaClientId = UUID.randomUUID().toString();
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/*", "video/*"});
        startActivityForResult(intent, 2001);
    }

    private FrameLayout addMediaMessage(LinearLayout parent, String url, String type, boolean mine, String sender, String avatarText, String c1, String c2, String avatarUrl) {
        LinearLayout line = row();
        line.setGravity(mine ? Gravity.RIGHT : Gravity.LEFT);
        if (!mine) line.addView(avatarWithRemoteImage(avatarText, avatarUrl, c1, c2, 36));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(dp(210), dp(160));
        params.setMargins(mine ? dp(52) : dp(10), dp(6), mine ? 0 : dp(52), dp(6));
        FrameLayout preview = new FrameLayout(this);
        preview.setBackground(round(Color.WHITE, 12));
        TextView placeholder = centeredText(type.equals("video") ? t("preparing_video") : t("loading_image"), 13, MUTED);
        placeholder.setGravity(Gravity.CENTER);
        preview.addView(placeholder, new FrameLayout.LayoutParams(-1, -1));
        ProgressBar progress = new ProgressBar(this);
        FrameLayout.LayoutParams progressParams = new FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER);
        progressParams.bottomMargin = dp(28);
        preview.addView(progress, progressParams);
        line.addView(preview, params);
        parent.addView(line, new LinearLayout.LayoutParams(-1, -2));
        if (url.isEmpty()) return preview;
        String path = Uri.parse(url).getLastPathSegment();
        String extension = path != null && path.matches(".*\\.[A-Za-z0-9]{2,5}") ? path.substring(path.lastIndexOf('.')) : ("video".equals(type) ? ".mp4" : ".jpg");
        File cache = new File(new File(new File(getFilesDir(), "media-cache"), "chat"), Integer.toHexString(url.hashCode()) + extension);
        if (cache.isFile() && cache.length() > 0) {
            progress.setVisibility(View.GONE);
            showCachedMedia(preview, placeholder, cache, type, url);
            return preview;
        }
        new Thread(() -> {
            File directory = cache.getParentFile();
            if (directory != null && !directory.exists()) directory.mkdirs();
            HttpURLConnection connection = null;
            File temporary = new File(cache.getAbsolutePath() + ".part");
            try {
                connection = ApiClient.openConnection(this, url);
                connection.setConnectTimeout(10000);
                connection.setReadTimeout(30000);
                int responseCode = connection.getResponseCode();
                if (responseCode < 200 || responseCode >= 300) throw new IllegalStateException("HTTP " + responseCode);
                String contentType = connection.getContentType();
                if (contentType != null && !contentType.startsWith("video/") && !contentType.startsWith("image/") && !contentType.startsWith("application/octet-stream"))
                    throw new IllegalStateException("invalid media response type");
                long totalBytes = connection.getContentLengthLong();
                long downloaded = 0;
                long lastUpdate = 0;
                try (InputStream input = connection.getInputStream(); FileOutputStream output = new FileOutputStream(temporary)) {
                    byte[] buffer = new byte[16384];
                    int count;
                    while ((count = input.read(buffer)) != -1) {
                        output.write(buffer, 0, count);
                        downloaded += count;
                        long now = System.currentTimeMillis();
                        if (now - lastUpdate > 120) {
                            int percent = totalBytes > 0 ? (int) (downloaded * 100 / totalBytes) : -1;
                            String label = percent >= 0 ? t("download_percent", Math.min(100, percent)) : t("downloading");
                            runOnUiThread(() -> placeholder.setText(label));
                            lastUpdate = now;
                        }
                    }
                }
                if (!temporary.renameTo(cache)) throw new IllegalStateException("cache file save failed");
                runOnUiThread(() -> progress.setVisibility(View.GONE));
                runOnUiThread(() -> showCachedMedia(preview, placeholder, cache, type, url));
            } catch (Exception ignored) {
                temporary.delete();
                runOnUiThread(() -> {
                    progress.setVisibility(View.GONE);
                    placeholder.setText(type.equals("video") ? t("video_load_failed_retry") : t("image_load_failed"));
                });
            } finally {
                if (connection != null) connection.disconnect();
            }
        }).start();
        return preview;
    }

    private void showCachedMedia(FrameLayout preview, TextView placeholder, File file, String type, String url) {
        if (!preview.isAttachedToWindow()) return;
        if ("image".equals(type)) {
            Bitmap bitmap = decodeBitmap(file, dp(440), dp(340));
            if (bitmap != null) {
                ImageView image = new ImageView(this);
                image.setScaleType(ImageView.ScaleType.CENTER_CROP);
                image.setImageBitmap(bitmap);
                preview.removeAllViews();
                preview.addView(image, new FrameLayout.LayoutParams(-1, -1));
            }
        } else if ("video".equals(type)) {
            placeholder.setText(t("reading_video_frame"));
            new Thread(() -> {
                Bitmap frame = null;
                MediaMetadataRetriever retriever = new MediaMetadataRetriever();
                try {
                    retriever.setDataSource(file.getAbsolutePath());
                    frame = retriever.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
                } catch (Exception ignored) { }
                finally { try { retriever.release(); } catch (Exception ignored) { } }
                Bitmap firstFrame = frame;
                preview.post(() -> {
                    if (!preview.isAttachedToWindow()) return;
                    preview.removeAllViews();
                    if (firstFrame != null) {
                        ImageView image = new ImageView(this);
                        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
                        image.setImageBitmap(firstFrame);
                        preview.addView(image, new FrameLayout.LayoutParams(-1, -1));
                        TextView play = centeredText("▶", 28, Color.WHITE);
                        play.setBackground(round(Color.argb(150, 20, 20, 20), 30));
                        FrameLayout.LayoutParams playParams = new FrameLayout.LayoutParams(dp(52), dp(52), Gravity.CENTER);
                        preview.addView(play, playParams);
                    } else {
                        TextView failed = centeredText("▶ " + t("tap_to_play"), 14, MUTED);
                        preview.addView(failed, new FrameLayout.LayoutParams(-1, -1));
                    }
                });
            }).start();
        }
        preview.setOnClickListener(v -> {
            if ("video".equals(type)) {
                VideoView video = new VideoView(this);
                video.setVideoPath(file.getAbsolutePath());
                MediaController controls = new MediaController(this);
                controls.setAnchorView(video);
                video.setMediaController(controls);
                FrameLayout playerRoot = new FrameLayout(this);
                playerRoot.setBackgroundColor(Color.BLACK);
                playerRoot.addView(video, new FrameLayout.LayoutParams(-1, -1));
                TextView back = centeredText("‹", 34, Color.WHITE);
                back.setBackground(round(Color.argb(190, 25, 25, 25), 28));
                FrameLayout.LayoutParams backParams = new FrameLayout.LayoutParams(dp(48), dp(48), Gravity.TOP | Gravity.LEFT);
                backParams.setMargins(dp(16), dp(26), 0, 0);
                playerRoot.addView(back, backParams);
                TextView playToggle = centeredText("▶", 30, Color.WHITE);
                playToggle.setBackground(round(Color.argb(170, 20, 20, 20), 32));
                FrameLayout.LayoutParams playParams = new FrameLayout.LayoutParams(dp(64), dp(64), Gravity.CENTER);
                playerRoot.addView(playToggle, playParams);
                Dialog viewer = new Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
                viewer.setContentView(playerRoot);
                back.setOnClickListener(ignored -> { video.stopPlayback(); viewer.dismiss(); });
                playToggle.setOnClickListener(ignored -> {
                    if (video.isPlaying()) { video.pause(); playToggle.setText("▶"); playToggle.setVisibility(View.VISIBLE); }
                    else { video.start(); playToggle.setVisibility(View.GONE); }
                });
                video.setOnClickListener(ignored -> {
                    if (video.isPlaying()) { video.pause(); playToggle.setText("▶"); playToggle.setVisibility(View.VISIBLE); }
                    else { if (video.getCurrentPosition() >= video.getDuration()) video.seekTo(0); video.start(); playToggle.setVisibility(View.GONE); }
                });
                video.setOnPreparedListener(player -> { player.setLooping(false); video.start(); playToggle.setVisibility(View.GONE); });
                video.setOnCompletionListener(player -> { playToggle.setText("↻"); playToggle.setVisibility(View.VISIBLE); });
                video.setOnErrorListener((player, what, extra) -> { toast(t("video_format_unsupported")); playToggle.setText("▶"); playToggle.setVisibility(View.VISIBLE); return true; });
                viewer.show();
                if (viewer.getWindow() != null) viewer.getWindow().setLayout(-1, -1);
            } else if ("image".equals(type)) {
                ImageView image = new ImageView(this);
                image.setImageBitmap(decodeBitmap(file, getResources().getDisplayMetrics().widthPixels, getResources().getDisplayMetrics().heightPixels));
                image.setScaleType(ImageView.ScaleType.FIT_CENTER);
                image.setBackgroundColor(Color.BLACK);
                Dialog viewer = new Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
                viewer.setContentView(image);
                image.setOnClickListener(ignored -> viewer.dismiss());
                viewer.show();
                if (viewer.getWindow() != null) viewer.getWindow().setLayout(-1, -1);
            }
        });
    }

    private Bitmap decodeBitmap(File file, int maxWidth, int maxHeight) {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(file.getAbsolutePath(), bounds);
        int sample = 1;
        while (bounds.outWidth / sample > maxWidth * 2 || bounds.outHeight / sample > maxHeight * 2) sample *= 2;
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = sample;
        return BitmapFactory.decodeFile(file.getAbsolutePath(), options);
    }

    private void sendUploadedMedia(JSONObject upload) {
        if (upload == null) { sendingMessage = false; removePendingMediaBubble(); return; }
        String url = upload.optString("url", "");
        String type = upload.optString("message_type", "image");
        int sendChatId = pendingMediaChatId;
        int sendGroupId = pendingMediaGroupId;
        if (url.isEmpty() || (sendChatId <= 0 && sendGroupId <= 0)) { sendingMessage = false; removePendingMediaBubble(); return; }
        JSONObject body = new JSONObject();
        try {
            body.put(sendGroupId > 0 ? "group_id" : "chat_id", sendGroupId > 0 ? sendGroupId : sendChatId);
            body.put("content", "voice".equals(type) ? t("ui_voice_duration", pendingVoiceDurationSeconds) : (type.equals("video") ? t("ui_video_placeholder") : t("ui_image_placeholder")));
            body.put("message_type", type);
            body.put("media_url", url);
            body.put("client_message_id", pendingMediaClientId);
        } catch (Exception ignored) { return; }
        ApiClient.post(this, sendGroupId > 0 ? "groups.messages.send" : "messages.send", body, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                sendingMessage = false;
                invalidateChatSnapshot();
                removePendingMediaBubble();
                 if (activeChatId == sendChatId && activeGroupId == sendGroupId && activeMessageList != null && activeMessageScroll != null && data instanceof JSONObject) {
                     ScrollView messageScroll = activeMessageScroll;
                     JSONObject message = new JSONObject();
                    try {
                        message.put("id", ((JSONObject) data).optInt("id"));
                        message.put("sender_id", currentUserId);
                        message.put("nickname", userName);
                        message.put("avatar_url", remoteAvatarUrl);
                        message.put("content", "voice".equals(type) ? t("ui_voice_duration", pendingVoiceDurationSeconds) : (type.equals("video") ? t("ui_video_placeholder") : t("ui_image_placeholder")));
                        message.put("message_type", type);
                         message.put("media_url", url);
                         message.put("client_message_id", pendingMediaClientId);
                         renderChatMessage(message, activeMessageList, activeMessageScroll, activeChatName, activeChatAvatar, activeChatC1, activeChatC2);
                         messageScroll.post(() -> messageScroll.fullScroll(View.FOCUS_DOWN));
                     } catch (Exception ignored) { }
                }
            }
            @Override public void onError(String message) { sendingMessage = false; removePendingMediaBubble(); toast(message); }
        });
    }

    private TextView addMessage(LinearLayout parent, String name, String avatarText, String c1, String c2, String message, boolean mine) {
        return addMessage(parent, name, avatarText, c1, c2, message, mine, "");
    }

    private TextView addMessage(LinearLayout parent, String name, String avatarText, String c1, String c2, String message, boolean mine, String avatarUrl) {
        LinearLayout line = row();
        line.setGravity(mine ? Gravity.RIGHT : Gravity.LEFT);
        if (!mine) {
            View messageAvatar = avatarWithRemoteImage(avatarText, avatarUrl, c1, c2, 36);
            messageAvatar.setOnClickListener(v -> {
                if (activePeerUserId > 0) showContactDetail(activePeerUserId, name, "", avatarUrl, true);
                else toast(t("conversation_profile_missing"));
            });
            line.addView(messageAvatar);
        }
        TextView bubble = bodyText(message, 15, mine ? Color.WHITE : TEXT);
        bubble.setPadding(dp(14), dp(10), dp(14), dp(10));
        bubble.setMaxWidth(dp(275));
        bubble.setBackground(mine ? MallUi.primaryButton(this) : MallUi.surface(this, Color.WHITE, 17, true));
        LinearLayout.LayoutParams bubbleParams = new LinearLayout.LayoutParams(-2, -2);
        bubbleParams.setMargins(mine ? dp(52) : dp(10), dp(6), mine ? 0 : dp(52), dp(6));
        line.addView(bubble, bubbleParams);
        if (mine) line.setGravity(Gravity.RIGHT);
        parent.addView(line, new LinearLayout.LayoutParams(-1, -2));
        return bubble;
    }

    private void applyChatBackground(ScrollView messages) {
        if (chatBackgroundPreset > 0) {
            int[] colors;
            if (chatBackgroundPreset == 1) {
                colors = new int[]{Color.rgb(218, 229, 232), Color.rgb(196, 217, 221)};
            } else if (chatBackgroundPreset == 2) {
                colors = new int[]{Color.rgb(226, 241, 248), Color.rgb(205, 229, 241)};
            } else {
                colors = new int[]{Color.rgb(239, 234, 226), Color.rgb(222, 215, 205)};
            }
            messages.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR, colors));
            return;
        }
        if (chatBackgroundUri == null) {
            messages.setBackgroundColor(BG);
            return;
        }
        try {
            InputStream input = getContentResolver().openInputStream(chatBackgroundUri);
            Bitmap bitmap = BitmapFactory.decodeStream(input);
            if (input != null) input.close();
            if (bitmap != null) {
                android.graphics.drawable.BitmapDrawable drawable = new android.graphics.drawable.BitmapDrawable(getResources(), bitmap);
                drawable.setTileModeX(android.graphics.Shader.TileMode.REPEAT);
                drawable.setTileModeY(android.graphics.Shader.TileMode.REPEAT);
                messages.setBackground(drawable);
            }
        } catch (Exception ignored) {
            messages.setBackgroundColor(BG);
        }
    }

    private void closeChatWindow() {
        restoreChatListPosition = !openedChatListSnapshot.isEmpty()
                && openedChatListSnapshot.equals(chatListSortSignature(readChatSnapshot()));
        closeChatSocket();
        activeChatId = 0;
        activePeerUserId = 0;
        activeGroupId = 0;
        chatWindowOpen = false;
        setBottomNavVisible(true);
        renderTab(activeTab);
    }

    private void openAskWindow() {
        askWindowOpen = true;
        setBottomNavVisible(false);
        content.removeAllViews();
        LinearLayout root = column();
        root.setBackgroundColor(BG);

        LinearLayout header = row();
        header.setPadding(dp(16), dp(8), dp(16), dp(8));
        header.setBackgroundColor(Color.WHITE);
        TextView back = centeredText("‹", 34, TEXT);
        back.setOnClickListener(v -> closeAskWindow());
        header.addView(back, new LinearLayout.LayoutParams(dp(42), dp(48)));
        TextView title = bodyText(t("ask_title"), 19, TEXT);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        header.addView(title, new LinearLayout.LayoutParams(0, dp(48), 1));
        header.addView(bodyText("?", 22, BLUE), new LinearLayout.LayoutParams(dp(42), dp(48)));
        root.addView(header);

        ScrollView scroll = new ScrollView(this);
        LinearLayout list = column();
        list.setPadding(dp(16), dp(18), dp(16), dp(18));
        TextView intro = bodyText(t("ask_intro"), 14, MUTED);
        intro.setPadding(dp(4), dp(4), dp(4), dp(16));
        list.addView(intro);
        ApiClient.get(this, "faq", null, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                if (!(data instanceof JSONArray)) return;
                JSONArray faq = (JSONArray) data;
                for (int i = 0; i < faq.length(); i++) {
                    JSONObject item = faq.optJSONObject(i);
                    if (item != null) addQuestion(list, item.optString("question"), item.optString("answer"), item.optString("category"));
                }
            }
            @Override public void onError(String message) { toast(message); }
        });
        TextView askTitle = bodyText(t("ask_no_answer"), 16, TEXT);
        askTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        list.addView(askTitle);
        EditText question = new EditText(this);
        question.setHint(t("question_input"));
        question.setTextSize(15);
        question.setPadding(dp(14), dp(10), dp(14), dp(10));
        question.setBackground(round(Color.WHITE, 14));
        list.addView(question, new LinearLayout.LayoutParams(-1, dp(52)));
        TextView submit = centeredText(t("submit_question"), 15, Color.WHITE);
        submit.setTypeface(null, android.graphics.Typeface.BOLD);
        submit.setBackground(round(BLUE, 14));
        submit.setOnClickListener(v -> {
            String text = question.getText().toString().trim();
            if (text.isEmpty()) {
                toast(t("question_required"));
            } else {
                JSONObject body = new JSONObject();
                try { body.put("question", text); } catch (Exception ignored) { return; }
                ApiClient.post(this, "questions.create", body, new ApiClient.Callback() {
                    @Override public void onSuccess(Object result) {
                        question.setText("");
                        toast(t("question_submitted"));
                        addQuestion(list, text, t("question_status", result instanceof JSONObject ? ((JSONObject) result).optString("status", "pending") : "pending"), t("my_question"));
                        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
                    }
                    @Override public void onError(String message) { toast(message); }
                });
            }
        });
        LinearLayout.LayoutParams submitParams = new LinearLayout.LayoutParams(-1, dp(46));
        submitParams.setMargins(0, dp(12), 0, dp(20));
        list.addView(submit, submitParams);
        scroll.addView(list, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        content.addView(root, new FrameLayout.LayoutParams(-1, -1));
    }

    private void addQuestion(LinearLayout parent, String question, String answer, String tag) {
        LinearLayout card = column();
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.setBackground(round(Color.WHITE, 16));
        TextView tagView = bodyText(tag, 11, BLUE);
        tagView.setTypeface(null, android.graphics.Typeface.BOLD);
        card.addView(tagView);
        TextView q = bodyText("Q  " + question, 15, TEXT);
        q.setTypeface(null, android.graphics.Typeface.BOLD);
        q.setPadding(0, dp(7), 0, dp(4));
        card.addView(q);
        card.addView(bodyText("A  " + answer, 14, Color.rgb(91, 104, 124)));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.setMargins(0, 0, 0, dp(12));
        parent.addView(card, params);
    }

    private void closeAskWindow() {
        askWindowOpen = false;
        setBottomNavVisible(true);
        renderTab(3);
    }

    private LinearLayout subPageRoot(String title, String subtitle) {
        LinearLayout root = column();
        root.setBackgroundColor(BG);
        LinearLayout header = row();
        header.setPadding(dp(16), dp(8), dp(16), dp(8));
        header.setBackgroundColor(Color.WHITE);
        TextView back = centeredText("‹", 34, TEXT);
        back.setOnClickListener(v -> {
            if (updateRequired) { toast(t("update_required")); return; }
            if (bottomNav == null) showAuthenticationPage();
            else closeSubPage();
        });
        header.addView(back, new LinearLayout.LayoutParams(dp(42), dp(52)));
        LinearLayout heading = column();
        heading.setPadding(dp(8), 0, 0, 0);
        TextView titleView = bodyText(title, 19, TEXT);
        titleView.setTypeface(null, android.graphics.Typeface.BOLD);
        heading.addView(titleView);
        if (!subtitle.isEmpty()) heading.addView(bodyText(subtitle, 12, MUTED));
        header.addView(heading, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(header);
        return root;
    }

    private void openSubPage(LinearLayout root, int tab) {
        if(commerce!=null&&!showingCommerce)commerce.externalPage();
        previousTab = tab;
        subPageOpen = true;
        setBottomNavVisible(false);
        content.setPadding(0, 0, 0, 0);
        content.removeAllViews();
        content.addView(root, new FrameLayout.LayoutParams(-1, -1));
    }

    private void closeSubPage() {
        if(commerce!=null&&commerce.back())return;
        if (walletAssetDetailOpen) {
            walletAssetDetailOpen = false;
            openWalletPage();
            return;
        }
        subPageOpen = false;
        setBottomNavVisible(true);
        content.setPadding(0, 0, 0, bottomNav.getHeight() + dp(24));
        renderTab(previousTab);
    }

    private String mallValue(JSONObject obj, String key) {
        return obj == null || obj.isNull(key) ? "" : obj.optString(key, "");
    }

    private TextView mallAction(LinearLayout parent, String label, Runnable action) {
        TextView button = centeredText(label, 15, BLUE);
        button.setPadding(dp(12), dp(13), dp(12), dp(13));
        button.setBackground(MallUi.surface(this, Color.WHITE, 14, true));
        MallUi.touch(button, 14);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(8), 0, dp(4));
        parent.addView(button, lp);
        button.setOnClickListener(v -> action.run());
        return button;
    }

    private EditText mallField(LinearLayout parent, String label, String value, boolean multiline) {
        parent.addView(bodyText(label, 13, MUTED));
        EditText input = formInput(label, value);
        if (multiline) {
            input.setSingleLine(false);
            input.setMinLines(3);
            input.setGravity(Gravity.TOP);
            input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
            input.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(112)));
        }
        parent.addView(input);
        return input;
    }

    private LinearLayout mallBody(LinearLayout page) {
        ScrollView scroll = new ScrollView(this);
        LinearLayout body = column();
        body.setPadding(dp(16), dp(16), dp(16), dp(28));
        scroll.addView(body, new ScrollView.LayoutParams(-1, -2));
        page.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        return body;
    }

    private void mallPost(String action, JSONObject request, TextView button, Runnable done) {
        if (button != null) button.setEnabled(false);
        ApiClient.post(this, action, request, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) { if (button != null) button.setEnabled(true); toast("操作成功"); done.run(); }
            @Override public void onError(String message) { if (button != null) button.setEnabled(true); toast(message); }
        });
    }

    private JSONObject mallRequest(String key, Object value) {
        JSONObject result = new JSONObject();
        try { result.put(key, value); } catch (Exception ignored) { }
        return result;
    }

    private String mallStatus(String status) {
        switch (status) {
            case "pending": return "待审核 / 待处理";
            case "awaiting_deposit": return "审核通过，待交保证金";
            case "active": return "营业中";
            case "suspended": return "暂停营业";
            case "rejected": return "已驳回";
            case "closing": return "关店处理中";
            case "closed": return "已关闭";
            case "approved": return "审核通过";
            case "shipped": return "已发货 / 已交付";
            case "delivered": return "已完成";
            case "refunded": return "已退款";
            case "cancelled": return "已取消";
            default: return status;
        }
    }

    private void openMerchantCenter() {
        LinearLayout page = subPageRoot("商家中心", "开店 · 商品 · 订单 · 保证金");
        LinearLayout body = mallBody(page);
        body.addView(note("正在读取店铺信息…"));
        openSubPage(page, 3);
        ApiClient.get(this, "merchant.me", null, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                if (!(data instanceof JSONObject)) return;
                body.removeAllViews();
                JSONObject payload = (JSONObject) data;
                JSONObject shop = payload.optJSONObject("merchant");
                body.addView(note("初级店铺保证金 100,000 SPX001；黄金店铺 1,000,000 SPX001。保证金冻结后不可消费或提现，黄金店铺享优先曝光。"));
                if (shop == null) { mallAction(body, "申请开店", () -> openMerchantForm(null, true)); return; }
                String state = shop.optString("status");
                body.addView(section(shop.optString("name")));
                body.addView(bodyText(("gold".equals(shop.optString("level")) ? "黄金店铺" : "初级店铺") + " · " + mallStatus(state), 16, TEXT));
                body.addView(bodyText("冻结保证金：" + formatAmount(shop.optString("deposit_frozen", "0")) + " SPX001", 16, BLUE));
                String reason = mallValue(shop, "review_reason");
                if (!reason.isEmpty()) body.addView(note("审核说明：" + reason));
                JSONObject stats = payload.optJSONObject("statistics");
                if (stats != null) body.addView(note("待结算货款：" + formatAmount(stats.optString("held_amount", "0")) + " SPX001\n已结算收入：" + formatAmount(stats.optString("settled_amount", "0")) + " SPX001\n订单数量：" + stats.optInt("order_count")));
                if ("rejected".equals(state) || "closed".equals(state)) mallAction(body, "修改资料并重新申请", () -> openMerchantForm(shop, true));
                if ("active".equals(state) || "awaiting_deposit".equals(state)) {
                    mallAction(body, "编辑店铺与门店位置", () -> openMerchantForm(shop, false));
                    if ("awaiting_deposit".equals(state)) mallAction(body, "缴纳保证金并开店", () -> confirmMerchantDeposit(shop.optString("level")));
                    if ("active".equals(state)) {
                        if (!"gold".equals(shop.optString("level"))) mallAction(body, "补交 900,000 SPX001，升级黄金店铺", () -> confirmMerchantDeposit("gold"));
                        mallAction(body, "查看我的店铺", () -> openShopPage(shop.optInt("id")));
                        mallAction(body, "发布商品", () -> openMerchantProductForm(null));
                    }
                }
                mallAction(body, "商品管理", () -> openMerchantProducts());
                mallAction(body, "订单与售后", () -> openMerchantOrders());
                if ("active".equals(state) || "awaiting_deposit".equals(state)) mallAction(body, "申请关店", () -> new AlertDialog.Builder(MainActivity.this)
                    .setTitle("申请关店").setMessage("申请后商品下架并停止接单。处理完订单、售后和结算，经过七天观察期后，由平台审核退还保证金。")
                    .setNegativeButton("返回", null).setPositiveButton("申请关店", (d, w) -> mallPost("merchant.close", new JSONObject(), null, () -> openMerchantCenter())).show());
                body.addView(section("保证金流水"));
                JSONArray ledger = payload.optJSONArray("deposit_ledger");
                if (ledger != null) for (int i = 0; i < ledger.length(); i++) {
                    JSONObject entry = ledger.optJSONObject(i);
                    if (entry != null) body.addView(note(("freeze".equals(entry.optString("type")) ? "冻结 " : "退还 ") + formatAmount(entry.optString("amount")) + " SPX001\n" + entry.optString("created_at")));
                }
            }
            @Override public void onError(String message) { body.removeAllViews(); body.addView(note(message)); mallAction(body, "重新加载", () -> openMerchantCenter()); }
        });
    }

    private void confirmMerchantDeposit(String level) {
        new AlertDialog.Builder(this).setTitle("确认冻结保证金")
            .setMessage("gold".equals(level) ? "黄金店铺需冻结合计 1,000,000 SPX001，系统只扣除尚未交齐的差额。" : "初级店铺需冻结 100,000 SPX001。")
            .setNegativeButton("返回", null).setPositiveButton("确认缴纳", (d, w) -> mallPost("merchant.deposit.pay", mallRequest("level", level), null, () -> openMerchantCenter())).show();
    }

    private MallMerchantForm merchantForm;
    private void openMerchantForm(JSONObject shop, boolean application) {
        merchantForm = new MallMerchantForm(this, shop, application);
    }
    LinearLayout mallMerchantPage(String title) {
        LinearLayout page = subPageRoot(title, "手机上传资料，地图选择门店");
        page.setBackgroundColor(MallUi.BACKGROUND);
        LinearLayout body = mallBody(page);
        openSubPage(page, 3);
        return body;
    }
    void mallMerchantDone() { merchantForm=null; openMerchantCenter(); }
    void mallMerchantMap(EditText lat, EditText lon, String[] systems, Runnable done) {
        openShopMapPicker(lat,lon,systems,done);
    }

    private void openShopMapPicker(EditText lat, EditText lon, String[] systems, Runnable done) {
        android.webkit.WebView map = new android.webkit.WebView(this);
        map.getSettings().setJavaScriptEnabled(true);
        map.getSettings().setUserAgentString(map.getSettings().getUserAgentString() + " SPXChat (com.spx.chat; shop-map)");
        map.getSettings().setAllowFileAccess(false);
        map.getSettings().setAllowContentAccess(false);
        map.setWebViewClient(new android.webkit.WebViewClient() {
            @Override public void onPageFinished(android.webkit.WebView view, String url) {
                try {
                    double[] gcj = MapNavigation.toGcj(Double.parseDouble(lat.getText().toString()), Double.parseDouble(lon.getText().toString()), systems[0]);
                    double[] wgs = MapNavigation.gcjToWgs(gcj[0], gcj[1]);
                    map.evaluateJavascript("setLocation(" + wgs[0] + "," + wgs[1] + ")", null);
                } catch (Exception ignored) { }
            }
            @Override public boolean shouldOverrideUrlLoading(android.webkit.WebView view, android.webkit.WebResourceRequest request) { return true; }
        });
        map.loadUrl("file:///android_asset/shop-map.html");
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("拖动地图标记门店")
            .setView(map).setNegativeButton("返回", null).setPositiveButton("使用中心位置", null).create();
        dialog.setOnShowListener(d -> {
            map.setLayoutParams(new FrameLayout.LayoutParams(-1, dp(410)));
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> map.evaluateJavascript("JSON.stringify(getLocation())", value -> {
                try {
                    String json = (String) new org.json.JSONTokener(value).nextValue();
                    JSONObject point = new JSONObject(json);
                    lat.setText(String.format(Locale.US, "%.7f", point.getDouble("latitude")));
                    lon.setText(String.format(Locale.US, "%.7f", point.getDouble("longitude")));
                    systems[0] = "wgs84"; done.run(); dialog.dismiss();
                } catch (Exception e) { toast("请等待地图加载后，拖动地图选择门店位置"); }
            }));
        });
        dialog.setOnDismissListener(d -> map.destroy());
        dialog.show();
    }

    private void openShopPage(int id) { openShopPage(id,1); }
    private void openShopPage(int id,int pageNo) {
        LinearLayout page = subPageRoot("店铺", "好物与门店，一起发现");
        page.setBackgroundColor(MallUi.BACKGROUND);
        LinearLayout body = mallBody(page);
        openSubPage(page, 2);
        Map<String, String> query = new HashMap<>(); query.put("id", String.valueOf(id));query.put("page",String.valueOf(pageNo));
        ApiClient.get(this, "shop", query, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                if (!(data instanceof JSONObject)) return;
                JSONObject payload = (JSONObject) data, shop = payload.optJSONObject("shop");
                if (shop == null) return;
                renderShopCard(body, shop, false);
                JSONArray products = payload.optJSONArray("products");
                if (products == null || products.length() == 0) mallEmptyState(body, "店铺正在准备好物", "商品上架后会在这里展示");
                LinearLayout productRow = null;
                int productCount = 0;
                if (products != null) for (int i = 0; i < products.length(); i++) {
                    JSONObject p = products.optJSONObject(i); if (p == null) continue;
                    if (productCount % 2 == 0) { productRow = row(); productRow.setGravity(Gravity.TOP); body.addView(productRow); }
                    addMallProduct(productRow, p, 2); productCount++;
                }
                if (productCount % 2 == 1 && productRow != null) {
                    LinearLayout.LayoutParams space = new LinearLayout.LayoutParams(0, 1, 1); space.setMargins(dp(4), 0, dp(4), 0);
                    productRow.addView(new View(MainActivity.this), space);
                }
                body.addView(mallText("第 "+pageNo+" 页",12,MallUi.SECONDARY,false));
                if(pageNo>1)mallAction(body,"上一页",()->openShopPage(id,pageNo-1));
                if(products!=null&&products.length()==60)mallAction(body,"下一页",()->openShopPage(id,pageNo+1));
            }
            @Override public void onError(String message) { body.addView(note(message)); }
        });
    }

    private void renderShopCard(LinearLayout body, JSONObject shop, boolean link) {
        LinearLayout card = column();
        card.setPadding(dp(12), dp(12), dp(12), dp(12));
        card.setBackground(MallUi.surface(this, Color.WHITE, 18, true));
        LinearLayout heading = mallShopTile(shop, false);
        if (link) heading.setOnClickListener(v -> openShopPage(shop.optInt("id")));
        card.addView(heading);
        if (!mallValue(shop, "description").isEmpty()) {
            TextView description = mallText(mallValue(shop, "description"), 13, MallUi.SECONDARY, false);
            description.setLineSpacing(dp(4), 1f); description.setPadding(dp(4), dp(12), dp(4), dp(4));
            card.addView(description);
        }
        if (!mallValue(shop, "business_hours").isEmpty()) {
            TextView hours = mallText("营业时间  " + mallValue(shop, "business_hours"), 12, MallUi.SECONDARY, false);
            hours.setPadding(dp(4), dp(8), dp(4), dp(6)); card.addView(hours);
        }
        if (link) mallAction(card, "进入店铺  ›", () -> openShopPage(shop.optInt("id"))).setBackground(MallUi.surface(this, MallUi.TINT, 12, false));
        if (!mallValue(shop, "address").isEmpty()) {
            LinearLayout location = row(); location.setPadding(dp(10), dp(12), dp(10), dp(12));
            location.setBackground(MallUi.surface(this, MallUi.BACKGROUND, 12, false));
            location.addView(MallUi.icon(this, "pin", MallUi.PRIMARY), new LinearLayout.LayoutParams(dp(22), dp(22)));
            LinearLayout address = column(); address.setPadding(dp(10), 0, dp(6), 0);
            TextView label = mallText(mallValue(shop, "address"), 13, MallUi.INK, true);
            label.setMaxLines(2); label.setEllipsize(android.text.TextUtils.TruncateAt.END); address.addView(label);
            TextView hint = mallText("导航到店  ›", 11, MallUi.PRIMARY, false); hint.setPadding(0, dp(5), 0, 0); address.addView(hint);
            location.addView(address, new LinearLayout.LayoutParams(0, -2, 1));
            location.setOnClickListener(v -> MapNavigation.open(this, shop)); MallUi.touch(location, 12);
            LinearLayout.LayoutParams locationParams = new LinearLayout.LayoutParams(-1, -2); locationParams.setMargins(0, dp(10), 0, 0); card.addView(location, locationParams);
            mallAction(card, "复制门店地址", () -> { ((ClipboardManager) getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("门店地址", mallValue(shop, "address"))); toast("地址已复制"); });
        }
        TextView contact = mallAction(card, "联系商家", () -> openMerchantContact(shop));
        contact.setBackground(MallUi.surface(this, MallUi.BACKGROUND, 12, false)); MallUi.touch(contact, 12);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2); params.setMargins(0, dp(10), 0, dp(10));
        body.addView(card, params);
    }

    private void openShopsPage() {
        LinearLayout page = subPageRoot("店铺广场", "发现好店，逛逛新生活");
        page.setBackgroundColor(MallUi.BACKGROUND);
        LinearLayout body = mallBody(page);
        LinearLayout searchBar = row(); searchBar.setPadding(dp(12), dp(4), dp(4), dp(4));
        searchBar.setBackground(MallUi.surface(this, Color.WHITE, 24, true));
        searchBar.addView(MallUi.icon(this, "search", MallUi.SECONDARY), new LinearLayout.LayoutParams(dp(19), dp(19)));
        EditText query = new EditText(this); query.setSingleLine(true); query.setTextSize(14);
        query.setTextColor(MallUi.INK); query.setHintTextColor(MallUi.SECONDARY); query.setHint("店铺名称或经营类目");
        query.setPadding(dp(8), 0, dp(8), 0); query.setBackgroundColor(Color.TRANSPARENT);
        query.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH);
        searchBar.addView(query, new LinearLayout.LayoutParams(0, dp(44), 1));
        LinearLayout results = column();
        TextView search = centeredText("搜索", 13, Color.WHITE); search.setBackground(MallUi.surface(this, MallUi.PRIMARY, 22, false));
        searchBar.addView(search, new LinearLayout.LayoutParams(dp(60), dp(40))); body.addView(searchBar);
        TextView label = mallText("全部店铺 · 黄金店铺优先展示", 12, MallUi.SECONDARY, false);
        label.setPadding(dp(4), dp(18), dp(4), dp(6)); body.addView(label);
        body.addView(results);
        int[] shopPage={1};Runnable[] loader={null};loader[0] = () -> {
            Object request = new Object(); results.setTag(request);
            results.removeAllViews(); mallProductSkeleton(results);
            Map<String, String> params = new HashMap<>(); params.put("q", query.getText().toString().trim());params.put("page",""+shopPage[0]);params.put("page_size","20");
            ApiClient.get(this, "shops", params, new ApiClient.Callback() {
                @Override public void onSuccess(Object data) {
                    if (results.getTag() != request) return;
                    if (!(data instanceof JSONArray)) { onError(""); return; }
                    results.removeAllViews();
                    JSONArray shops = (JSONArray) data;
                    if (shops.length() == 0) mallEmptyState(results, "暂时没有匹配的店铺", "换个关键词，再发现一些好店");
                    for (int i = 0; i < shops.length(); i++) {
                        JSONObject shop = shops.optJSONObject(i); if (shop == null) continue;
                        LinearLayout tile = mallShopTile(shop, false); tile.setOnClickListener(v -> openShopPage(shop.optInt("id")));
                        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2); params.setMargins(0, dp(10), 0, 0); results.addView(tile, params);
                    }
                    results.addView(mallText("第 "+shopPage[0]+" 页",12,MallUi.SECONDARY,false));
                    if(shopPage[0]>1)mallAction(results,"上一页",()->{shopPage[0]--;loader[0].run();});
                    if(shops.length()==20)mallAction(results,"下一页",()->{shopPage[0]++;loader[0].run();});
                }
                @Override public void onError(String message) {
                    if (results.getTag() != request) return;
                    results.removeAllViews(); mallEmptyState(results, "店铺服务暂不可用", "请稍后重试，或先浏览商城商品");
                }
            });
        };
        search.setOnClickListener(v -> {shopPage[0]=1;loader[0].run();});
        MallUi.touch(search, 22);
        query.setOnEditorActionListener((v, actionId, event) -> { if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH) { shopPage[0]=1;loader[0].run(); return true; } return false; });
        page.setFocusableInTouchMode(true); page.requestFocus();
        openSubPage(page, 2); loader[0].run();
    }

    private void openMerchantContact(JSONObject shop) {
        loadUserProfile(shop.optInt("owner_user_id"), new UserProfileCallback() {
            @Override public void onProfile(JSONObject profile) { openFriendProfilePage(profile); }
            @Override public void onError(String message) {
                String phone = mallValue(shop, "contact_phone");
                if (phone.isEmpty()) { toast(message); return; }
                try { startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(phone)))); } catch (Exception e) { toast(phone); }
            }
        });
    }

    private void openMerchantProducts() { commerce().merchantProducts(); }

    private JSONArray mallUrlLines(String text) {
        JSONArray urls = new JSONArray();
        for (String line : text.split("\\r?\\n")) if (!line.trim().isEmpty()) urls.put(line.trim());
        return urls;
    }

    private String mallLines(JSONArray list) {
        if (list == null) return "";
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < list.length(); i++) { if (i > 0) result.append('\n'); result.append(list.optString(i)); }
        return result.toString();
    }

    private void openMerchantProductForm(JSONObject product) { commerce().editProduct(product); }

    private EditText mallUploadTarget;
    private static final int PICK_MALL_IMAGE = 4201;

    private void pickMallImage(EditText target) {
        mallUploadTarget = target;
        Intent pick = new Intent(Intent.ACTION_GET_CONTENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(pick, PICK_MALL_IMAGE);
    }

    private void openMerchantOrders() { commerce().merchantOrders(); }

    private void merchantFulfillDialog(JSONObject order) {
        String type = order.optString("order_type");
        LinearLayout form = column(); form.setPadding(dp(16), dp(8), dp(16), dp(8));
        EditText first = mallField(form, "physical".equals(type) ? "承运商" : ("local".equals(type) ? "请输入买家出示的核销码" : "交付内容或领取说明"), "", !"physical".equals(type));
        EditText tracking = "physical".equals(type) ? mallField(form, "物流单号", "", false) : null;
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("订单 #" + order.optInt("id")).setView(form).setNegativeButton("返回", null).setPositiveButton("确认处理", null).create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            JSONObject request = mallRequest("order_id", order.optInt("id"));
            try {
                request.put("physical".equals(type) ? "carrier" : ("local".equals(type) ? "redeem_code" : "fulfillment_note"), first.getText().toString().trim());
                if (tracking != null) request.put("tracking_number", tracking.getText().toString().trim());
            } catch (Exception e) { return; }
            mallPost("physical".equals(type) ? "merchant.order.ship" : ("local".equals(type) ? "merchant.order.redeem" : "merchant.order.deliver"), request, null, () -> { dialog.dismiss(); openMerchantOrders(); });
        }));
        dialog.show();
    }

    private void addBuyerMallActions(LinearLayout body, JSONObject order) {
        if (order.isNull("merchant_id") || order.optInt("merchant_id") <= 0) return;
        if ("local".equals(order.optString("order_type")) && "pending".equals(order.optString("status"))) body.addView(note("到店核销码：" + order.optString("redeem_code") + "\n请到店接受服务时出示给商家。"));
        if (!mallValue(order, "fulfillment_note").isEmpty()) body.addView(note("交付说明：" + mallValue(order, "fulfillment_note")));
        if ("shipped".equals(order.optString("status"))) mallAction(body, "确认收货 / 确认交付完成", () -> new AlertDialog.Builder(this).setMessage("确认已收到商品或完成交付？确认后进入七天售后期。")
            .setNegativeButton("返回", null).setPositiveButton("确认完成", (d, w) -> mallPost("orders.receive", mallRequest("order_id", order.optInt("id")), null, () -> openOrdersPage())).show());
        if ("requested".equals(order.optString("after_sale_status"))) body.addView(note("售后处理中：" + mallValue(order, "after_sale_reason")));
        if (!mallValue(order, "after_sale_reply").isEmpty()) body.addView(note("平台售后答复：" + mallValue(order, "after_sale_reply")));
        if (!"requested".equals(order.optString("after_sale_status")) && "held".equals(order.optString("settlement_status")) && !"cancelled".equals(order.optString("status")) && !"refunded".equals(order.optString("status"))) mallAction(body, "申请售后", () -> {
            EditText reason = formInput("填写问题和退款原因", "");
            new AlertDialog.Builder(this).setTitle("申请售后").setView(reason).setNegativeButton("返回", null).setPositiveButton("提交", (d, w) -> {
                JSONObject request = mallRequest("order_id", order.optInt("id"));
                try { request.put("reason", reason.getText().toString().trim()); } catch (Exception e) { return; }
                mallPost("orders.after_sale", request, null, () -> openOrdersPage());
            }).show();
        });
    }

    private void openStorePage() {
        LinearLayout root = subPageRoot(t("store"), "发现好物 · 积分兑换");
        root.setBackgroundColor(MallUi.BACKGROUND);
        LinearLayout header = (LinearLayout) root.getChildAt(0);
        LinearLayout records = column();
        records.setGravity(Gravity.CENTER);
        records.addView(MallUi.icon(this, "order", MallUi.INK), new LinearLayout.LayoutParams(dp(21), dp(21)));
        TextView recordsLabel = mallText("订单", 10, MallUi.INK, false);
        recordsLabel.setPadding(0, dp(3), 0, 0);
        records.addView(recordsLabel);
        records.setContentDescription("查看兑换记录和订单");
        records.setOnClickListener(v -> openOrdersPage());
        MallUi.touch(records, 12);
        header.addView(records, new LinearLayout.LayoutParams(dp(48), dp(48)));

        LinearLayout searchBar = row();
        searchBar.setGravity(Gravity.CENTER_VERTICAL);
        searchBar.setPadding(dp(16), 0, dp(16), dp(12));
        searchBar.setBackgroundColor(Color.WHITE);
        LinearLayout searchBox = row();
        searchBox.setPadding(dp(12), dp(4), dp(4), dp(4));
        searchBox.setBackground(MallUi.surface(this, Color.rgb(244, 246, 250), 25, true));
        searchBox.addView(MallUi.icon(this, "search", MallUi.SECONDARY), new LinearLayout.LayoutParams(dp(18), dp(18)));
        EditText mallSearch = new EditText(this);
        mallSearch.setSingleLine(true);
        mallSearch.setTextSize(14);
        mallSearch.setTextColor(TEXT);
        mallSearch.setHintTextColor(MUTED);
        mallSearch.setHint("搜索商品或店铺名称");
        mallSearch.setContentDescription("搜索商品或店铺名称");
        mallSearch.setPadding(dp(9), 0, dp(6), 0);
        mallSearch.setBackgroundColor(Color.TRANSPARENT);
        mallSearch.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH);
        mallSearch.setText(mallSearchQuery);
        searchBox.addView(mallSearch, new LinearLayout.LayoutParams(0, dp(40), 1));
        TextView searchButton = centeredText("搜索", 13, Color.WHITE);
        searchButton.setBackground(MallUi.primaryButton(this));
        MallUi.touch(searchButton, 22);
        searchBox.addView(searchButton, new LinearLayout.LayoutParams(dp(60), dp(40)));
        searchBar.addView(searchBox, new LinearLayout.LayoutParams(-1, -2));
        root.addView(searchBar);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        LinearLayout list = column();
        list.setPadding(dp(12), dp(12), dp(12), dp(24));
        LinearLayout balanceCard = row();
        balanceCard.setGravity(Gravity.CENTER_VERTICAL);
        balanceCard.setPadding(dp(16), dp(16), dp(16), dp(16));
        balanceCard.setBackground(gradient("#182647", "#345491", 24));
        balanceCard.setElevation(dp(2));
        LinearLayout balanceHeading = column();
        balanceHeading.addView(mallText("SPX 好物商城", 20, Color.WHITE, true));
        TextView balanceLabel = mallText("让积分，遇见好物", 11, Color.rgb(202, 216, 255), false);
        balanceLabel.setPadding(0, dp(7), 0, 0);
        balanceHeading.addView(balanceLabel);
        balanceCard.addView(balanceHeading, new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout balanceInfo = column();
        balanceInfo.setGravity(Gravity.END);
        balanceInfo.addView(mallText("可用积分", 10, Color.rgb(202, 216, 255), false));
        TextView balance = mallText("读取中…", 23, Color.WHITE, true);
        balance.setSingleLine(true);
        androidx.core.widget.TextViewCompat.setAutoSizeTextTypeUniformWithConfiguration(balance, 12, 23, 1, android.util.TypedValue.COMPLEX_UNIT_SP);
        balanceInfo.addView(balance, new LinearLayout.LayoutParams(-1, dp(32)));
        balance.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        TextView unit = mallText("SPX001", 9, Color.rgb(202, 216, 255), false);
        balanceInfo.addView(unit);
        balanceCard.addView(balanceInfo, new LinearLayout.LayoutParams(0, -2, 1));
        list.addView(balanceCard, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout shortcuts = row();
        addMallShortcut(shortcuts, "店铺广场", "发现更多好店", false, () -> openShopsPage());
        addMallShortcut(shortcuts, "商家中心", "申请开店 / 管理店铺", true, () -> openMerchantCenter());
        LinearLayout.LayoutParams shortcutsParams = new LinearLayout.LayoutParams(-1, -2);
        shortcutsParams.setMargins(0, dp(10), 0, dp(4));
        list.addView(shortcuts, shortcutsParams);

        LinearLayout goldSection = column();
        goldSection.setVisibility(View.GONE);
        LinearLayout goldHeading = row();
        goldHeading.setPadding(dp(4), dp(14), dp(4), dp(8));
        goldHeading.addView(mallText("黄金好店", 16, TEXT, true), new LinearLayout.LayoutParams(0, -2, 1));
        goldHeading.addView(mallText("优先推荐", 11, Color.rgb(159, 111, 34), false));
        goldSection.addView(goldHeading);
        HorizontalScrollView goldScroll = new HorizontalScrollView(this);
        goldScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout goldShops = row();
        goldScroll.addView(goldShops);
        goldSection.addView(goldScroll);
        list.addView(goldSection);
        TextView shopStatus = mallText("", 12, MUTED, false);
        shopStatus.setPadding(dp(4), dp(10), dp(4), 0);
        shopStatus.setVisibility(View.GONE);
        list.addView(shopStatus);
        Map<String, String> goldQuery = new HashMap<>(); goldQuery.put("level", "gold");
        MallCatalogCache.get(this, "shops", goldQuery, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                if (!(data instanceof JSONArray)) return;
                JSONArray shops = (JSONArray) data;
                goldShops.removeAllViews(); shopStatus.setVisibility(View.GONE);
                for (int i = 0; i < Math.min(6, shops.length()); i++) {
                    JSONObject shop = shops.optJSONObject(i);
                    if (shop == null) continue;
                    LinearLayout card = mallShopTile(shop, true);
                    card.setOnClickListener(v -> openShopPage(shop.optInt("id")));
                    LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(dp(212), -2);
                    cardParams.setMargins(0, 0, dp(8), 0);
                    goldShops.addView(card, cardParams);
                }
                goldSection.setVisibility(goldShops.getChildCount() == 0 ? View.GONE : View.VISIBLE);
            }
            @Override public void onError(String message) {
                shopStatus.setText(message != null && message.contains("未知接口") ? "店铺服务升级中，商品仍可浏览" : "店铺推荐暂时无法加载");
                shopStatus.setVisibility(View.VISIBLE);
            }
        });

        LinearLayout productsHeading = row();
        productsHeading.setGravity(Gravity.CENTER_VERTICAL);
        productsHeading.setPadding(dp(4), dp(14), dp(4), dp(4));
        TextView productTitle = mallText(mallSearchQuery.isEmpty() ? "发现好物" : "搜索结果", 19, MallUi.INK, true);
        productsHeading.addView(productTitle, new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout modes = row();
        modes.setGravity(Gravity.CENTER);
        modes.addView(MallUi.icon(this, "grid", MallUi.SECONDARY), new LinearLayout.LayoutParams(dp(17), dp(17)));
        TextView modeLabel = mallText(productColumns + "列", 11, MallUi.SECONDARY, false);
        modeLabel.setPadding(dp(5), 0, 0, 0);
        modes.addView(modeLabel);
        modes.setContentDescription("切换商品排列方式");
        MallUi.touch(modes, 12);
        productsHeading.addView(modes, new LinearLayout.LayoutParams(dp(64), dp(44)));
        list.addView(productsHeading);
        LinearLayout filters = row();
        HorizontalScrollView filtersScroll = new HorizontalScrollView(this);
        filtersScroll.setHorizontalScrollBarEnabled(false);
        filtersScroll.addView(filters);
        list.addView(filtersScroll);
        LinearLayout productGrid = column();
        list.addView(productGrid);
        JSONArray[] loadedProducts = {null};
        modes.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("商品排列")
            .setSingleChoiceItems(new String[]{"大图 · 1列", "双列 · 2列", "紧凑 · 3列"}, productColumns - 1, (dialog, which) -> {
                productColumns = which + 1;
                modeLabel.setText(productColumns + "列");
                if (loadedProducts[0] != null) renderMallProductCards(productGrid, loadedProducts[0], productColumns);
                dialog.dismiss();
            }).show());
        String[] filterValues = {"all", "physical", "digital", "local"};
        String[] filterLabels = {"全部", "实物好物", "数字权益", "到店服务"};
        TextView[] filterButtons = new TextView[filterValues.length];
        for (int i = 0; i < filterValues.length; i++) {
            final String value = filterValues[i];
            TextView button = centeredText(filterLabels[i], 12, MallUi.SECONDARY);
            button.setPadding(dp(14), 0, dp(14), 0);
            styleMallFilter(button, value.equals(mallProductFilter));
            filterButtons[i] = button;
            LinearLayout.LayoutParams filterParams = new LinearLayout.LayoutParams(-2, dp(40));
            filterParams.setMargins(dp(4), 0, dp(4), dp(4));
            filters.addView(button, filterParams);
            button.setOnClickListener(v -> {
                mallProductFilter = value;
                for (int n = 0; n < filterButtons.length; n++) styleMallFilter(filterButtons[n], value.equals(filterValues[n]));
                loadMallProducts(productGrid, loadedProducts, mallSearchQuery);
            });
        }
        Runnable search = () -> {
            mallSearchQuery = mallSearch.getText().toString().trim();
            productTitle.setText(mallSearchQuery.isEmpty() ? "发现好物" : "搜索结果");
            android.view.inputmethod.InputMethodManager keyboard = (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (keyboard != null) keyboard.hideSoftInputFromWindow(mallSearch.getWindowToken(), 0);
            mallSearch.clearFocus();
            loadMallProducts(productGrid, loadedProducts, mallSearchQuery);
        };
        searchButton.setOnClickListener(v -> search.run());
        mallSearch.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH) { search.run(); return true; }
            return false;
        });
        loadMallProducts(productGrid, loadedProducts, mallSearchQuery);
        ApiClient.get(this, "wallet", null, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                if (!(data instanceof JSONArray)) { balance.setText("暂不可用"); unit.setVisibility(View.GONE); return; }
                JSONArray assets = (JSONArray) data;
                for (int i = 0; i < assets.length(); i++) {
                    JSONObject asset = assets.optJSONObject(i);
                    if (asset != null && "SPX001".equals(asset.optString("symbol")) && "BSC".equalsIgnoreCase(asset.optString("network", "BSC"))) {
                        balance.setText(formatAmount(asset.optString("balance", "0")));
                        return;
                    }
                }
                balance.setText("0.00");
            }
            @Override public void onError(String message) { balance.setText("暂不可用"); unit.setVisibility(View.GONE); }
        });
        scroll.addView(list, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        root.setFocusableInTouchMode(true);
        root.requestFocus();
        openSubPage(root, 2);
    }

    private TextView mallText(String text, int size, int color, boolean bold) {
        TextView view = bodyText(text, size, color);
        view.setPadding(0, 0, 0, 0);
        view.setMinHeight(0);
        view.setMinimumHeight(0);
        view.setIncludeFontPadding(false);
        if (bold) view.setTypeface(null, android.graphics.Typeface.BOLD);
        return view;
    }

    private void addMallShortcut(LinearLayout parent, String title, String subtitle, boolean merchant, Runnable action) {
        LinearLayout card = row();
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(10), dp(12), dp(8), dp(12));
        card.setBackground(MallUi.surface(this, Color.WHITE, 16, true));
        FrameLayout iconBox = new FrameLayout(this);
        iconBox.setBackground(MallUi.surface(this, merchant ? MallUi.TINT : Color.rgb(231, 246, 241), 12, false));
        iconBox.addView(MallUi.icon(this, merchant ? "bag" : "store", merchant ? MallUi.PRIMARY : Color.rgb(49, 128, 103)), new FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER));
        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(dp(38), dp(38));
        iconParams.setMargins(0, 0, dp(8), 0);
        card.addView(iconBox, iconParams);
        LinearLayout text = column();
        TextView heading = mallText(title, 14, MallUi.INK, true);
        heading.setSingleLine(true);
        heading.setEllipsize(android.text.TextUtils.TruncateAt.END);
        text.addView(heading);
        TextView detail = mallText(subtitle, 10, MUTED, false);
        detail.setPadding(0, dp(5), 0, 0);
        detail.setSingleLine(true);
        detail.setEllipsize(android.text.TextUtils.TruncateAt.END);
        text.addView(detail);
        card.addView(text, new LinearLayout.LayoutParams(0, -2, 1));
        card.setContentDescription(title + "，" + subtitle);
        card.setOnClickListener(v -> action.run());
        MallUi.touch(card, 16);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
        lp.setMargins(merchant ? dp(5) : 0, 0, merchant ? 0 : dp(5), 0);
        parent.addView(card, lp);
    }

    private void styleMallFilter(TextView button, boolean selected) {
        button.setSelected(selected);
        button.setTextColor(selected ? MallUi.PRIMARY : MallUi.SECONDARY);
        button.setTypeface(null, selected ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
        button.setTextColor(selected ? Color.WHITE : MallUi.SECONDARY);
        button.setBackground(selected ? MallUi.primaryButton(this) : MallUi.surface(this, Color.WHITE, 12, true));
        MallUi.touch(button, 12);
    }

    private LinearLayout mallShopTile(JSONObject shop, boolean compact) {
        boolean gold = "gold".equals(shop.optString("level"));
        LinearLayout tile = row();
        tile.setPadding(dp(12), dp(14), dp(12), dp(14));
        tile.setBackground(MallUi.surface(this, gold ? Color.rgb(255, 251, 241) : Color.WHITE, 16, true));
        String name = mallValue(shop, "name");
        FrameLayout logo = new FrameLayout(this);
        logo.setBackground(MallUi.surface(this, gold ? MallUi.GOLD_TINT : MallUi.TINT, 13, false));
        logo.setClipToOutline(true);
        if (!mallValue(shop, "logo_url").isEmpty()) {
            logo.addView(productImage(shop.optString("logo_url")), new FrameLayout.LayoutParams(-1, -1));
        } else {
            logo.addView(centeredText(name.isEmpty() ? "店" : name.substring(0, name.offsetByCodePoints(0, 1)), 21, gold ? MallUi.GOLD : MallUi.PRIMARY), new FrameLayout.LayoutParams(-1, -1));
        }
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(dp(46), dp(46));
        logoParams.setMargins(0, 0, dp(10), 0);
        tile.addView(logo, logoParams);
        LinearLayout text = column();
        TextView title = mallText(name, 14, MallUi.INK, true);
        title.setSingleLine(true); title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        text.addView(title);
        LinearLayout meta = row();
        meta.setPadding(0, dp(7), 0, 0);
        meta.addView(MallUi.badge(this, gold ? "黄金店铺" : "初级店铺", gold));
        if (!compact) {
            TextView category = mallText(mallValue(shop, "category"), 11, MallUi.SECONDARY, false);
            category.setPadding(dp(6), 0, 0, 0);
            category.setSingleLine(true); category.setEllipsize(android.text.TextUtils.TruncateAt.END);
            meta.addView(category, new LinearLayout.LayoutParams(0, -2, 1));
        }
        text.addView(meta);
        tile.addView(text, new LinearLayout.LayoutParams(0, -2, 1));
        if (!compact) tile.addView(centeredText("›", 23, MallUi.SECONDARY), new LinearLayout.LayoutParams(dp(22), dp(32)));
        tile.setContentDescription(name + (gold ? "，黄金店铺" : "，初级店铺") + "，查看店铺");
        MallUi.touch(tile, 16);
        return tile;
    }

    private String mallProductTypeLabel(String type) {
        if ("local".equals(type)) return "到店服务";
        if ("digital".equals(type)) return "数字权益";
        if ("physical".equals(type)) return "实物商品";
        return "商品";
    }

    private void mallEmptyState(LinearLayout target, String title, String description) {
        LinearLayout state = column();
        state.setGravity(Gravity.CENTER);
        state.setPadding(dp(24), dp(32), dp(24), dp(32));
        state.addView(MallUi.icon(this, "bag", Color.rgb(175, 187, 216)), new LinearLayout.LayoutParams(dp(42), dp(42)));
        TextView heading = mallText(title, 15, MallUi.INK, true);
        heading.setGravity(Gravity.CENTER); heading.setPadding(0, dp(14), 0, dp(7));
        state.addView(heading);
        TextView detail = mallText(description, 12, MallUi.SECONDARY, false);
        detail.setGravity(Gravity.CENTER); state.addView(detail);
        target.addView(state, new LinearLayout.LayoutParams(-1, -2));
    }

    private void mallProductSkeleton(LinearLayout target) {
        LinearLayout cards = row();
        for (int i = 0; i < 2; i++) {
            LinearLayout card = column();
            card.setPadding(dp(10), dp(10), dp(10), dp(14));
            card.setBackground(MallUi.surface(this, Color.WHITE, 16, false));
            View image = new View(this); image.setBackground(MallUi.surface(this, MallUi.LINE, 10, false));
            card.addView(image, new LinearLayout.LayoutParams(-1, dp(128)));
            for (int line = 0; line < 2; line++) {
                View bar = new View(this); bar.setBackground(MallUi.surface(this, MallUi.BACKGROUND, 5, false));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(line == 0 ? -1 : dp(64), dp(12));
                lp.setMargins(0, dp(12), 0, 0); card.addView(bar, lp);
            }
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
            lp.setMargins(dp(4), dp(8), dp(4), 0); cards.addView(card, lp);
        }
        cards.setContentDescription("正在加载商品");
        target.addView(cards);
    }

    private void loadMallProducts(LinearLayout target, JSONArray[] loaded, String query) {
        mallProductsPage=1;
        loadMallProductPage(target,loaded,query,1);
    }

    private void loadMallProductPage(LinearLayout target, JSONArray[] loaded, String query,int page) {
        Object request = new Object();
        target.setTag(request);
        loaded[0] = null;
        target.removeAllViews();
        mallProductSkeleton(target);
        Map<String, String> params = new HashMap<>(); params.put("q", query);params.put("page",String.valueOf(page));params.put("type",mallProductFilter);
        MallCatalogCache.get(this, "products", params, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                if (target.getTag() != request) return;
                if (!(data instanceof JSONArray)) { onError(""); return; }
                loaded[0] = (JSONArray) data;
                mallProductsPage=page;mallProductsCount=loaded[0].length();mallLoadedPages=loaded;
                renderMallProductCards(target, loaded[0], productColumns);
            }
            @Override public void onError(String message) {
                if (target.getTag() != request) return;
                target.removeAllViews();
                mallEmptyState(target, "商品暂时无法加载", "请检查网络后重试");
                mallAction(target, "重新加载", () -> loadMallProductPage(target, loaded, query,page));
            }
        });
    }

    private void renderMallProductCards(LinearLayout target, JSONArray products, int columns) {
        target.removeAllViews();
        LinearLayout currentRow = null;
        int count = 0;
        for (int i = 0; i < products.length(); i++) {
            JSONObject product = products.optJSONObject(i);
            if (product == null) continue;
            if (!"all".equals(mallProductFilter) && !mallProductFilter.equals(product.optString("product_type"))) continue;
            if (count % columns == 0) {
                currentRow = row();
                currentRow.setGravity(Gravity.TOP);
                target.addView(currentRow, new LinearLayout.LayoutParams(-1, -2));
            }
            addMallProduct(currentRow, product, columns);
            count++;
        }
        if (count == 0) {
            mallEmptyState(target, "暂时没有匹配的商品", mallSearchQuery.isEmpty() && "all".equals(mallProductFilter) ? "好物正在准备中，稍后再来看看" : "试试其他分类或搜索关键词");
        } else if (count % columns != 0 && currentRow != null) {
            for (int i = count % columns; i < columns; i++) {
                LinearLayout.LayoutParams space = new LinearLayout.LayoutParams(0, 1, 1);
                space.setMargins(dp(4), 0, dp(4), 0);
                currentRow.addView(new View(this), space);
            }
        }
        if(mallLoadedPages!=null && mallLoadedPages[0]==products){
            int shown=mallProductsPage;JSONArray[] pageData=mallLoadedPages;
            target.addView(note("第 "+shown+" 页"));
            if(shown>1)mallAction(target,"上一页",()->loadMallProductPage(target,pageData,mallSearchQuery,shown-1));
            if(mallProductsCount==60)mallAction(target,"下一页",()->loadMallProductPage(target,pageData,mallSearchQuery,shown+1));
        }
    }

    private void addProduct(LinearLayout parent, String name, String desc, String price, String actionText, String imageUrl, int columns) {
        addProduct(parent, 0, name, desc, price, actionText, imageUrl, columns);
    }

    private void addProduct(LinearLayout parent, int productId, String name, String desc, String price, String actionText, String imageUrl, int columns) {
        addProduct(parent, productId, name, desc, price, actionText, imageUrl, columns, null);
    }

    private void addMallProduct(LinearLayout parent, JSONObject product, int columns) {
        addProduct(parent, product.optInt("id"), product.optString("name"), product.optString("description"),
            MallMoney.show(product.optString("spx_price")) + " SPX001", "查看详情", product.optString("image_url"), columns, product);
    }

    private void addProduct(LinearLayout parent, int productId, String name, String desc, String price, String actionText, String imageUrl, int columns, JSONObject product) {
        LinearLayout card = column();
        card.setBackground(MallUi.surface(this, Color.WHITE, 20, true));
        card.setElevation(dp(1));
        card.setClipToOutline(true);
        MallUi.RatioFrame cover = new MallUi.RatioFrame(this, columns == 1 ? 0.72f : 1f);
        ImageView image = productImage(imageUrl);
        image.setContentDescription(name);
        image.setBackgroundColor(Color.rgb(236, 240, 247));
        cover.addView(image, new FrameLayout.LayoutParams(-1, -1));
        if (product != null) {
            String type = mallValue(product, "product_type");
            if (!type.isEmpty()) {
                TextView kind = MallUi.badge(this, mallProductTypeLabel(type), false);
                kind.setBackground(MallUi.surface(this, 0xEBFFFFFF, 6, false));
                kind.setTextColor(MallUi.INK);
                FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.START);
                lp.setMargins(dp(8), dp(8), dp(8), 0); cover.addView(kind, lp);
            }
        }
        card.addView(cover, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout info = column();
        info.setPadding(dp(columns == 3 ? 8 : 12), dp(10), dp(columns == 3 ? 8 : 12), dp(12));
        TextView productName = mallText(name, columns == 1 ? 17 : (columns == 2 ? 14 : 12), TEXT, true);
        productName.setMaxLines(2);
        productName.setEllipsize(android.text.TextUtils.TruncateAt.END);
        if (columns > 1) productName.setMinLines(2);
        info.addView(productName);
        String merchantName = product == null ? "" : mallValue(product, "merchant_name");
        TextView description = mallText(merchantName.isEmpty() ? desc.replace("\n", " · ").trim() : merchantName, columns == 1 ? 12 : 11, MallUi.SECONDARY, false);
        description.setSingleLine(true);
        description.setEllipsize(android.text.TextUtils.TruncateAt.END);
        description.setPadding(0, dp(5), 0, dp(8));
        info.addView(description);
        if (product != null && "gold".equals(product.optString("merchant_level"))) {
            TextView goldBadge = MallUi.badge(this, "黄金店铺", true);
            LinearLayout.LayoutParams goldParams = new LinearLayout.LayoutParams(-2, -2);
            goldParams.setMargins(0, 0, 0, dp(7)); info.addView(goldBadge, goldParams);
        }
        String amount = price.trim();
        int unitIndex = amount.indexOf("SPX001");
        if (unitIndex >= 0) amount = amount.substring(0, unitIndex).trim();
        LinearLayout priceRow = row();
        LinearLayout priceText = column();
        TextView priceView = mallText(amount, columns == 1 ? 25 : (columns == 2 ? 21 : 16), MallUi.PRIMARY, true);
        priceView.setSingleLine(true);
        androidx.core.widget.TextViewCompat.setAutoSizeTextTypeUniformWithConfiguration(priceView, 10, columns == 1 ? 25 : (columns == 2 ? 21 : 16), 1, android.util.TypedValue.COMPLEX_UNIT_SP);
        priceText.addView(priceView, new LinearLayout.LayoutParams(-1, dp(29)));
        TextView priceUnit = mallText("SPX001 积分", 10, MallUi.SECONDARY, false);
        priceText.addView(priceUnit);
        priceRow.addView(priceText, new LinearLayout.LayoutParams(0, -2, 1));
        if (columns == 2) {
            FrameLayout actionIcon = new FrameLayout(this);
            actionIcon.setBackground(MallUi.surface(this, MallUi.TINT, 12, false));
            actionIcon.addView(MallUi.icon(this, "arrow", MallUi.PRIMARY), new FrameLayout.LayoutParams(dp(18), dp(18), Gravity.CENTER));
            priceRow.addView(actionIcon, new LinearLayout.LayoutParams(dp(30), dp(30)));
        }
        info.addView(priceRow);
        if (columns == 1) {
            TextView action = centeredText(actionText, 13, BLUE);
            action.setBackground(MallUi.surface(this, MallUi.TINT, 12, false));
            MallUi.touch(action, 12);
            LinearLayout.LayoutParams actionParams = new LinearLayout.LayoutParams(-1, dp(40));
            actionParams.setMargins(0, dp(10), 0, 0);
            info.addView(action, actionParams);
            action.setOnClickListener(v -> openProductDetail(productId, name, desc, price, imageUrl));
        }
        card.addView(info);
        card.setContentDescription(name + "，" + price + "，查看详情");
        card.setOnClickListener(v -> openProductDetail(productId, name, desc, price, imageUrl));
        MallUi.touch(card, 18);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, -2, 1);
        params.setMargins(dp(4), dp(8), dp(4), 0);
        parent.addView(card, params);
    }

    private ImageView productImage(String imageUrl) {
        ImageView view=new ImageView(this);view.setScaleType(ImageView.ScaleType.CENTER_CROP);view.setBackground(round(Color.rgb(238,242,255),12));MallImages.bind(view,resolveAssetUrl(imageUrl),false);return view;
    }

    private void openProductDetail(String name, String desc, String price, String imageUrl) {
        openProductDetail(0, name, desc, price, imageUrl);
    }

    private void openProductDetail(int productId, String name, String desc, String price, String imageUrl) {
        if (productId <= 0) { toast(t("invalid_product")); return; }
        LinearLayout loading = subPageRoot(t("product_detail"), t("reading_product"));
        loading.addView(note(t("loading_product")), new LinearLayout.LayoutParams(-1, 0, 1));
        openSubPage(loading, 2);
        Map<String, String> params = new HashMap<>();
        params.put("id", String.valueOf(productId));
        ApiClient.get(this, "product", params, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                if (loading.getParent() != content || updateRequired) return;
                if (!(data instanceof JSONObject)) { toast(t("product_detail_failed")); return; }
                renderProductDetail((JSONObject) data);
            }
            @Override public void onError(String message) {
                if (loading.getParent() != content || updateRequired) return;
                toast(message); closeSubPage();
            }
        });
    }

    private void renderProductDetail(JSONObject product) { commerce().product(product); }

    private void loadCheckoutAddresses(TextView target, JSONObject[] selectedAddress) {
        ApiClient.get(this, "wallet.address", null, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                if (!(data instanceof JSONArray) || ((JSONArray) data).length() == 0) {
                    target.setText(t("checkout_no_address"));
                    target.setOnClickListener(v -> openAddressPage());
                    return;
                }
                JSONArray addresses = (JSONArray) data;
                ArrayList<JSONObject> options = new ArrayList<>();
                String[] labels = new String[addresses.length()];
                int selected = -1;
                for (int i = 0; i < addresses.length(); i++) {
                    JSONObject address = addresses.optJSONObject(i);
                    if (address == null) continue;
                    options.add(address);
                    labels[i] = address.optString("name") + " · " + address.optString("phone") + "\n"
                            + address.optString("province") + address.optString("city") + address.optString("district") + address.optString("detail");
                    if (address.optInt("is_default") == 1) selected = i;
                }
                if (selectedAddress[0] == null && selected >= 0) selectedAddress[0] = addresses.optJSONObject(selected);
                updateCheckoutAddressLabel(target, selectedAddress[0]);
                 target.setOnClickListener(v -> new AlertDialog.Builder(MainActivity.this).setTitle(t("select_address"))
                        .setSingleChoiceItems(labels, selectedAddress[0] == null ? -1 : addressIndex(options, selectedAddress[0].optInt("id")), (dialog, which) -> {
                            selectedAddress[0] = options.get(which);
                            updateCheckoutAddressLabel(target, selectedAddress[0]);
                            dialog.dismiss();
                          }).setNeutralButton(t("select_new_address"), (dialog, which) -> openAddressPage()).show());
            }
            @Override public void onError(String message) { target.setText(t("checkout_address_load_failed")); }
        });
    }

    private int addressIndex(ArrayList<JSONObject> addresses, int addressId) {
        for (int i = 0; i < addresses.size(); i++) if (addresses.get(i).optInt("id") == addressId) return i;
        return -1;
    }

    private void updateCheckoutAddressLabel(TextView target, JSONObject address) {
        if (address == null) return;
        target.setText(t("checkout_address_label", address.optString("name"), address.optString("phone"),
                address.optString("province"), address.optString("city"), address.optString("district"), address.optString("detail")));
    }

    private void openStakingPage() {
        LinearLayout root = subPageRoot(t("staking_title"), t("staking_subtitle"));
        ScrollView scroll = new ScrollView(this);
        LinearLayout list = column();
        list.setPadding(dp(16), dp(16), dp(16), dp(24));
        LinearLayout phaseSummary = roundCard();
        TextView phaseNumber = bodyText(t("reading"), 15, TEXT);
        TextView phaseQuota = bodyText(t("reading"), 14, TEXT);
        TextView phaseRemaining = bodyText(t("reading"), 14, TEXT);
        LinearLayout phaseMetrics = row();
        phaseMetrics.addView(stakingMetric(t("staking_periods"), phaseNumber), new LinearLayout.LayoutParams(0, -2, 1));
        phaseMetrics.addView(separator(), new LinearLayout.LayoutParams(dp(1), dp(42)));
        phaseMetrics.addView(stakingMetric(t("quota"), phaseQuota), new LinearLayout.LayoutParams(0, -2, 1));
        phaseMetrics.addView(separator(), new LinearLayout.LayoutParams(dp(1), dp(42)));
        phaseMetrics.addView(stakingMetric(t("remaining_quota"), phaseRemaining), new LinearLayout.LayoutParams(0, -2, 1));
        phaseSummary.addView(phaseMetrics);
        list.addView(phaseSummary, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout summary = column();
        summary.setPadding(dp(18), dp(18), dp(18), dp(18));
        summary.setBackground(gradient("#3F5EFB", "#6D4AFF", 18));
        summary.addView(bodyText(t("total_staking"), 13, Color.WHITE));
        TextView stakeTotal = bodyText(t("loading"), 28, Color.WHITE);
        summary.addView(stakeTotal);
        TextView stakeMeta = bodyText(t("staking_records_loading"), 13, Color.WHITE);
        summary.addView(stakeMeta);
        LinearLayout.LayoutParams summaryParams = new LinearLayout.LayoutParams(-1, -2);
        summaryParams.setMargins(0, dp(10), 0, 0);
        list.addView(summary, summaryParams);
        TextView stakeableBalance = bodyText(t("stakeable_balance_loading"), 14, Color.rgb(38, 115, 91));
        stakeableBalance.setPadding(dp(16), dp(12), dp(16), dp(12));
        stakeableBalance.setBackground(round(Color.rgb(237, 248, 243), 12));
        list.addView(stakeableBalance, new LinearLayout.LayoutParams(-1, -2));
        ApiClient.get(this, "wallet", null, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                if (!(data instanceof JSONArray)) return;
                JSONArray assets = (JSONArray) data;
                for (int i = 0; i < assets.length(); i++) {
                    JSONObject asset = assets.optJSONObject(i);
                    if (asset != null && "SPX001".equals(asset.optString("symbol"))) {
                        stakeableBalance.setText(t("stakeable_balance", formatAmount(asset.optString("stakeable_balance", "0"))));
                        return;
                    }
                }
                stakeableBalance.setText(t("stakeable_balance", "0.00"));
            }
            @Override public void onError(String message) { stakeableBalance.setText(t("stakeable_balance_unavailable")); }
        });
        LinearLayout rules = column();
        rules.setPadding(dp(16), dp(14), dp(16), dp(14));
        rules.setBackground(round(Color.WHITE, 14));
        rules.addView(bodyText(t("staking_rules"), 15, TEXT));
        TextView rulesText = bodyText(t("staking_plans_loading"), 13, MUTED);
        rules.addView(rulesText);
        LinearLayout.LayoutParams ruleParams = new LinearLayout.LayoutParams(-1, -2);
        ruleParams.setMargins(0, dp(12), 0, dp(8));
        list.addView(rules, ruleParams);
        list.addView(section(t("select_staking_plan")));
        LinearLayout planList = column();
        list.addView(planList, new LinearLayout.LayoutParams(-1, -2));
        ApiClient.get(this, "staking.plans", null, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                planList.removeAllViews();
                if (!(data instanceof JSONObject)) {
                    rulesText.setText(t("no_staking_plans"));
                    planList.addView(note(t("check_later")));
                    return;
                }
                JSONObject payload = (JSONObject) data;
                JSONArray plans = payload.optJSONArray("plans");
                JSONObject phase = payload.optJSONObject("phase");
                if (phase == null) {
                    phaseNumber.setText(t("not_started"));
                    phaseQuota.setText("0.00\nSPX001");
                    phaseRemaining.setText("0.00\nSPX001");
                } else {
                    phaseNumber.setText(t("staking_phase", phase.optString("phase_no", "-")));
                    phaseQuota.setText(formatAmount(phase.optString("total_quota", "0")) + "\nSPX001");
                    phaseRemaining.setText(formatAmount(phase.optString("remaining_quota", "0")) + "\nSPX001");
                }
                if (plans == null || plans.length() == 0) {
                    if (phase == null) rulesText.setText(t("no_staking_plans"));
                    planList.addView(note(t("no_staking_plans")));
                    return;
                }
                StringBuilder summaryText = new StringBuilder();
                for (int i = 0; i < plans.length(); i++) {
                    JSONObject plan = plans.optJSONObject(i);
                    if (plan == null) continue;
                    if (summaryText.length() > 0) summaryText.append('\n');
                    summaryText.append(t("staking_plan_summary", plan.optInt("plan_days"), plan.optString("apy"), formatAmount(plan.optString("minimum_amount"))));
                    addStakePlan(planList, plan);
                }
                summaryText.append("\n").append(t("staking_rule_description"));
                rulesText.setText(summaryText.toString());
            }
            @Override public void onError(String message) { rulesText.setText(t("staking_rules_load_failed")); }
        });
        list.addView(section(t("my_staking_records")));
        ApiClient.get(this, "staking", null, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                if (!(data instanceof JSONArray)) return;
                JSONArray records = (JSONArray) data;
                double total = 0;
                for (int i = 0; i < records.length(); i++) {
                    JSONObject record = records.optJSONObject(i);
                    if (record == null) continue;
                    total += record.optDouble("amount", 0);
                    String dailyIncome = t("staking_dividend_schedule");
                    try {
                        java.math.BigDecimal daily = new java.math.BigDecimal(record.optString("amount", "0"))
                                .multiply(new java.math.BigDecimal(record.optString("apy", "0")))
                                .divide(new java.math.BigDecimal("36500"), 8, java.math.RoundingMode.DOWN);
                        java.math.BigDecimal everyTenDays = new java.math.BigDecimal(record.optString("amount", "0"))
                                .multiply(new java.math.BigDecimal(record.optString("apy", "0")))
                                .multiply(new java.math.BigDecimal("10"))
                                .divide(new java.math.BigDecimal("36500"), 8, java.math.RoundingMode.DOWN);
                        dailyIncome = t("staking_income_summary", formatAmount(daily.toPlainString()), formatAmount(everyTenDays.toPlainString()), formatAmount(record.optString("paid_dividend", "0")));
                    } catch (Exception ignored) { }
                    addRecord(list, record, t("staking_lock_days", record.optString("plan_days")), t("points_amount", formatAmount(record.optString("amount"))), dailyIncome);
                }
                stakeTotal.setText(t("points_amount", formatAmount(String.valueOf(total))));
                stakeMeta.setText(t("staking_record_count", records.length()));
                if (records.length() == 0) list.addView(note(t("no_staking_records")));
            }
            @Override public void onError(String message) { stakeMeta.setText(message); }
        });
        scroll.addView(list, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        openSubPage(root, 2);
    }

    private void addStakePlan(LinearLayout parent, JSONObject plan) {
        String title = plan.optString("name", t("staking_lock_days", plan.optInt("plan_days")));
        String rate = plan.optString("apy", "0");
        String minimum = formatAmount(plan.optString("minimum_amount", "0"));
        LinearLayout card = column();
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.setBackground(round(Color.WHITE, 16));
        LinearLayout text = column();
        TextView titleView = bodyText(title, 17, TEXT);
        titleView.setTypeface(null, android.graphics.Typeface.BOLD);
        text.addView(titleView);
        text.addView(bodyText(t("staking_plan_detail", plan.optInt("plan_days"), minimum), 13, MUTED));
        card.addView(text, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout rateBox = column();
        rateBox.setGravity(Gravity.RIGHT);
        rateBox.addView(bodyText(rate, 19, Color.rgb(243, 156, 18)));
        TextView stake = bodyText(t("go_stake"), 12, BLUE);
        stake.setOnClickListener(v -> showStakeDialog(plan));
        rateBox.addView(stake);
        card.addView(rateBox, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.setMargins(dp(4), 0, dp(4), dp(10));
        parent.addView(card, params);
    }

    private void addRecord(LinearLayout parent, JSONObject record, String title, String amount, String income) {
        LinearLayout card = row();
        card.setPadding(dp(16), dp(13), dp(16), dp(13));
        card.setBackground(round(Color.WHITE, 14));
        LinearLayout text = column();
        text.addView(bodyText(title + "  ·  " + amount, 15, TEXT));
        text.addView(bodyText(income, 13, MUTED));
        card.addView(text, new LinearLayout.LayoutParams(0, -2, 1));
        String status = record.optString("status", "active");
        card.addView(bodyText("redeemed".equals(status) ? t("redeemed") : record.optInt("can_redeem") == 1 ? t("auto_processing") : "active".equals(status) ? t("locked") : status, 13,
                "redeemed".equals(status) ? MUTED : Color.rgb(46, 154, 111)));
        card.setOnClickListener(v -> showStakeRecordDetails(record));
        parent.addView(card, new LinearLayout.LayoutParams(-1, -2));
        if (record.optInt("can_redeem") != 1) return;
        TextView autoRedeem = centeredText(t("staking_auto_redeem"), 13, BLUE);
        autoRedeem.setPadding(dp(8), dp(8), dp(8), dp(8));
        parent.addView(autoRedeem, new LinearLayout.LayoutParams(-1, -2));
    }

    private void showStakeRecordDetails(JSONObject record) {
        String amount = formatAmount(record.optString("amount", "0"));
        String paid = formatAmount(record.optString("paid_dividend", "0"));
        String apy = formatAmount(record.optString("apy", "0"));
        String status = "redeemed".equals(record.optString("status")) ? t("redeemed") : "active".equals(record.optString("status")) ? t("locked") : record.optString("status", t("unknown"));
        java.math.BigDecimal daily = java.math.BigDecimal.ZERO;
        try { daily = new java.math.BigDecimal(record.optString("amount", "0")).multiply(new java.math.BigDecimal(record.optString("apy", "0"))).divide(new java.math.BigDecimal("36500"), 8, java.math.RoundingMode.DOWN); } catch (Exception ignored) { }
        String details = t("staking_record_details", status, record.optString("plan_days", "0"), amount, apy,
                formatAmount(daily.toPlainString()), formatAmount(daily.multiply(java.math.BigDecimal.TEN).toPlainString()), paid, record.optString("created_at", ""));
        new AlertDialog.Builder(this).setTitle(t("staking_detail")).setMessage(details).setPositiveButton(t("know"), null).show();
    }

    private void showStakeDialog(JSONObject plan) {
        ApiClient.get(this, "wallet", null, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                String stakeable = "0";
                if (data instanceof JSONArray) {
                    JSONArray assets = (JSONArray) data;
                    for (int i = 0; i < assets.length(); i++) {
                        JSONObject asset = assets.optJSONObject(i);
                        if (asset != null && "SPX001".equals(asset.optString("symbol"))) {
                            stakeable = asset.optString("stakeable_balance", "0");
                            break;
                        }
                    }
                }
                showStakeDialog(plan, stakeable);
            }
            @Override public void onError(String message) { toast(message); }
        });
    }

    private void showStakeDialog(JSONObject plan, String availableStakeable) {
        EditText amount = formInput(t("staking_amount"), "");
        amount.setInputType(InputType.TYPE_CLASS_NUMBER);
        amount.setHint(t("staking_amount_example"));
        int days = plan.optInt("plan_days");
        int planId = plan.optInt("id");
        String minimum = plan.optString("minimum_amount", "0");
        String apy = plan.optString("apy", "0");
        LinearLayout content = column();
        content.setPadding(dp(8), 0, dp(8), 0);
        content.addView(bodyText(t("staking_lock_period", days), 14, TEXT));
        content.addView(bodyText(t("staking_apy", apy), 14, TEXT));
        content.addView(bodyText(t("staking_amount_rule"), 13, MUTED));
        content.addView(bodyText(t("stakeable_balance", formatAmount(availableStakeable)), 13, Color.rgb(38, 115, 91)));
        content.addView(amount);
        TextView estimate = bodyText(t("staking_estimate_empty"), 14, Color.rgb(38, 115, 91));
        estimate.setPadding(dp(12), dp(12), dp(12), dp(12));
        estimate.setBackground(round(Color.rgb(237, 248, 243), 10));
        content.addView(estimate);
        content.addView(bodyText(t("staking_estimate_hint"), 12, MUTED));
        Runnable updateEstimate = () -> {
            try {
                java.math.BigDecimal principal = new java.math.BigDecimal(amount.getText().toString().trim());
                java.math.BigDecimal daily = principal.multiply(new java.math.BigDecimal(apy))
                        .divide(new java.math.BigDecimal("36500"), 8, java.math.RoundingMode.DOWN);
                java.math.BigDecimal total = daily.multiply(java.math.BigDecimal.valueOf(days));
                estimate.setText(t("staking_estimate", daily.stripTrailingZeros().toPlainString(), total.stripTrailingZeros().toPlainString()));
            } catch (Exception ignored) {
                estimate.setText(t("staking_estimate_empty"));
            }
        };
        amount.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { updateEstimate.run(); }
            @Override public void afterTextChanged(Editable s) { }
        });
        new AlertDialog.Builder(this).setTitle(t("confirm_staking")).setView(content).setNegativeButton(t("cancel"), null).setPositiveButton(t("confirm_staking"), (d, w) -> {
            String value = amount.getText().toString().trim();
            try {
                java.math.BigInteger principal = new java.math.BigInteger(value);
                java.math.BigInteger unit = java.math.BigInteger.valueOf(100000);
                if (principal.signum() <= 0 || principal.mod(unit).signum() != 0 || principal.compareTo(java.math.BigInteger.valueOf(10000000)) > 0) {
                    toast(t("staking_amount_invalid")); return;
                }
                if (principal.compareTo(new java.math.BigDecimal(availableStakeable).toBigInteger()) > 0) {
                    toast(t("stakeable_balance_insufficient")); return;
                }
            } catch (Exception ignored) { toast(t("staking_amount_integer_required")); return; }
            JSONObject body = new JSONObject();
            try { body.put("plan_id", planId); body.put("amount", value); } catch (Exception ignored) { return; }
            ApiClient.post(this, "staking.create", body, new ApiClient.Callback() {
                @Override public void onSuccess(Object data) { toast(t("staking_submitted")); openStakingPage(); }
                @Override public void onError(String message) { toast(message); }
            });
        }).show();
    }

    private void openWalletPage() {
        walletAssetDetailOpen = false;
        LinearLayout root = subPageRoot(t("wallet"), t("wallet_subtitle"));
        ScrollView scroll = new ScrollView(this);
        LinearLayout list = column();
        list.setPadding(dp(18), dp(16), dp(18), dp(28));
        LinearLayout overview = column();
        overview.setPadding(dp(22), dp(20), dp(22), dp(20));
        overview.setBackground(gradient("#173A3F", "#27645C", 18));
        overview.addView(bodyText(t("total_assets"), 13, Color.rgb(203, 225, 220)));
        TextView totalValue = bodyText("$ --", 34, Color.WHITE);
        totalValue.setTypeface(null, android.graphics.Typeface.BOLD);
        LinearLayout.LayoutParams totalParams = new LinearLayout.LayoutParams(-1, dp(58));
        totalParams.topMargin = dp(4);
        overview.addView(totalValue, totalParams);
        TextView valuationHint = bodyText(t("wallet_valuation_hint"), 12, Color.rgb(203, 225, 220));
        overview.addView(valuationHint);
        list.addView(overview);
        LinearLayout actions = row();
        actions.setPadding(0, dp(14), 0, dp(8));
        addWalletAction(actions, t("wallet_deposit_action"), BLUE, () -> showTransferDialog("deposit"));
        addWalletAction(actions, t("wallet_withdraw_action"), Color.rgb(35, 139, 105), () -> showTransferDialog("withdraw"));
        list.addView(actions);
        LinearLayout bindingCard = row();
        bindingCard.setGravity(Gravity.CENTER_VERTICAL);
        bindingCard.setPadding(dp(14), dp(12), dp(14), dp(12));
        bindingCard.setBackground(round(Color.WHITE, 12));
        LinearLayout bindingText = column();
        TextView bindingTitle = bodyText(t("wallet_binding"), 15, TEXT);
        bindingTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        TextView bindingAddress = bodyText(t("wallet_binding_loading"), 12, MUTED);
        String[] bindingState = {"loading"};
        bindingText.addView(bindingTitle);
        bindingText.addView(bindingAddress);
        bindingCard.addView(bindingText, new LinearLayout.LayoutParams(0, -2, 1));
        TextView bindAction = centeredText(t("reading"), 13, BLUE);
        bindingCard.setEnabled(false);
        bindAction.setEnabled(false);
        bindingCard.addView(bindAction, new LinearLayout.LayoutParams(-2, dp(42)));
        bindingCard.setOnClickListener(v -> {
            if ("unbound".equals(bindingState[0])) showBindBscWalletDialog();
            else if ("bound".equals(bindingState[0])) copyText(normalizeOptionalText(preferences.getString(walletBindingKey(), "")), t("bound_bsc_address"));
            else if ("error".equals(bindingState[0])) openWalletPage();
        });
        bindAction.setOnClickListener(v -> bindingCard.performClick());
        LinearLayout.LayoutParams bindingParams = new LinearLayout.LayoutParams(-1, -2);
        bindingParams.setMargins(dp(4), dp(2), dp(4), dp(8));
        list.addView(bindingCard, bindingParams);
        ApiClient.get(this, "wallet.binding", null, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                String address = data instanceof JSONObject ? normalizeOptionalText(((JSONObject) data).optString("bound_address", "")) : "";
                preferences.edit().putString(walletBindingKey(), address).apply();
                if (address.isEmpty()) {
                    bindingState[0] = "unbound";
                    bindingAddress.setText(t("wallet_unbound_hint"));
                    bindAction.setText(t("tap_to_bind"));
                } else {
                    bindingState[0] = "bound";
                    bindingAddress.setText(address);
                    bindAction.setText(t("bound_copy"));
                }
                bindingCard.setEnabled(true);
                bindAction.setEnabled(true);
            }
            @Override public void onError(String message) {
                bindingState[0] = "error";
                bindingAddress.setText(t("wallet_binding_unavailable"));
                bindAction.setText(t("retry_loading"));
                bindingCard.setEnabled(true);
                bindAction.setEnabled(true);
            }
        });
        TextView assetsTitle = bodyText(t("assets"), 17, TEXT);
        assetsTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        assetsTitle.setPadding(0, dp(18), 0, dp(8));
        list.addView(assetsTitle);
        ApiClient.get(this, "wallet", null, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                if (!(data instanceof JSONArray)) return;
                JSONArray assets = (JSONArray) data;
                loadSpx001UsdPrice((price, quoteError) -> {
                    java.math.BigDecimal total = java.math.BigDecimal.ZERO;
                    boolean hasSpxBalance = false;
                    int shown = 0;
                    for (int i = 0; i < assets.length(); i++) {
                        JSONObject asset = assets.optJSONObject(i);
                        if (asset == null) continue;
                        String symbol = asset.optString("symbol", "");
                        if (!"SPX001".equals(symbol) && !"USDT".equals(symbol)) continue;
                        java.math.BigDecimal amount;
                        try { amount = new java.math.BigDecimal(asset.optString("balance", "0")); }
                        catch (Exception ignored) { amount = java.math.BigDecimal.ZERO; }
                        java.math.BigDecimal unitPrice = "USDT".equals(symbol) ? java.math.BigDecimal.ONE : java.math.BigDecimal.valueOf(price);
                        String valuation = unitPrice.signum() > 0 ? "$" + formatUsd(amount.multiply(unitPrice)) : t("usd_quote_unavailable");
                        addToken(list, symbol, formatAmount(amount.toPlainString()), valuation, unitPrice.signum() > 0 ? t("wallet_unit_price", formatUsdPrice(unitPrice.doubleValue())) : t("bsc_mainnet"), asset.optString("stakeable_balance", "0"));
                        if ("SPX001".equals(symbol)) {
                            hasSpxBalance = amount.signum() > 0;
                            if (unitPrice.signum() > 0) total = total.add(amount.multiply(unitPrice));
                        } else total = total.add(amount);
                        shown++;
                    }
                    if (shown == 0) list.addView(note(t("no_bsc_assets")));
                    if (hasSpxBalance && price <= 0) {
                        totalValue.setText("$ --");
                        valuationHint.setText(t("spx_quote_unavailable_total") + (quoteError.isEmpty() ? "" : t("error_with_message", quoteError)));
                    } else {
                        totalValue.setText("$ " + formatUsd(total));
                        valuationHint.setText(price > 0 ? t("wallet_valuation_hint") : t("wallet_spx_quote_unavailable", quoteError));
                    }
                });
            }
            @Override public void onError(String message) { list.addView(note(message)); }
        });
        scroll.addView(list, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        openSubPage(root, 3);
    }

    private void openWalletTransactionsPage(String symbol) {
        walletAssetDetailOpen = true;
        String displaySymbol = displayAssetSymbol(symbol);
        LinearLayout root = subPageRoot(t("wallet_transaction_title", displaySymbol), t("wallet_transactions_subtitle"));
        TextView balanceSummary = bodyText(t("wallet_balance_loading"), 17, TEXT);
        balanceSummary.setTypeface(null, android.graphics.Typeface.BOLD);
        balanceSummary.setPadding(dp(18), dp(14), dp(18), dp(8));
        root.addView(balanceSummary);
        ApiClient.get(this, "wallet", null, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                if (!(data instanceof JSONArray)) { balanceSummary.setText(t("wallet_balance_unavailable")); return; }
                JSONArray assets = (JSONArray) data;
                for (int i = 0; i < assets.length(); i++) {
                    JSONObject asset = assets.optJSONObject(i);
                    if (asset != null && symbol.equals(asset.optString("symbol"))) {
                        if ("SPX001".equals(symbol)) {
                            balanceSummary.setText(t("available_balance_with_stakeable", formatAmount(asset.optString("balance", "0")), formatAmount(asset.optString("stakeable_balance", "0")), displaySymbol));
                        } else {
                            balanceSummary.setText(t("available_balance", formatAmount(asset.optString("balance", "0")), displaySymbol));
                        }
                        return;
                    }
                }
                balanceSummary.setText(t("available_balance", "0.00", displaySymbol));
            }
            @Override public void onError(String message) { balanceSummary.setText(t("wallet_balance_unavailable")); }
        });
        LinearLayout filters = row();
        filters.setPadding(dp(16), dp(10), dp(16), dp(10));
        String[] labels = {t("all"), t("transaction_increase"), t("transaction_decrease")};
        String[] selected = {t("all")};
        LinearLayout list = column();
        list.setPadding(dp(16), dp(8), dp(16), dp(24));
        JSONArray[] transactions = {new JSONArray()};
        Runnable[] render = new Runnable[1];
        render[0] = () -> {
            list.removeAllViews();
            int shown = 0;
            for (int i = 0; i < transactions[0].length(); i++) {
                JSONObject item = transactions[0].optJSONObject(i);
                if (item == null) continue;
                String type = item.optString("type");
                if (!symbol.equals(item.optString("symbol"))) continue;
                int direction = walletTransactionDirection(type);
                if (t("transaction_increase").equals(selected[0]) && direction <= 0) continue;
                if (t("transaction_decrease").equals(selected[0]) && direction >= 0) continue;
                String title = walletTransactionLabel(type);
                LinearLayout card = column();
                card.setPadding(dp(14), dp(12), dp(14), dp(12));
                card.setBackground(round(Color.WHITE, 12));
                LinearLayout top = row();
                top.addView(bodyText(title + " · " + displayAssetSymbol(item.optString("symbol")), 15, TEXT), new LinearLayout.LayoutParams(0, dp(30), 1));
                 String status = item.optString("status", "pending");
                 top.addView(bodyText(walletTransactionStatusLabel(status), 12, status.equals("completed") ? Color.rgb(37, 145, 103) : MUTED));
                card.addView(top);
                String sign = direction > 0 ? "+" : (direction < 0 ? "−" : "");
                card.addView(bodyText(sign + formatAmount(item.optString("amount", "0")) + " " + displaySymbol, 19,
                        direction > 0 ? Color.rgb(35, 139, 105) : (direction < 0 ? Color.rgb(190, 75, 70) : BLUE)));
                 String txHash = normalizeOptionalText(item.optString("tx_hash", ""));
                 card.addView(bodyText(t("transaction_hash", item.optString("created_at", ""), txHash.isEmpty() ? t("none") : txHash), 11, MUTED));
                if ("withdraw".equals(type) && status.equals("pending")) {
                    TextView cancel = bodyText(t("cancel_withdraw"), 13, Color.rgb(190, 55, 55));
                    cancel.setPadding(0, dp(8), 0, 0);
                    cancel.setOnClickListener(v -> {
                        JSONObject request = new JSONObject();
                        try { request.put("transaction_id", item.optInt("id")); } catch (Exception ignored) { return; }
                        ApiClient.post(MainActivity.this, "wallet.withdraw.cancel", request, new ApiClient.Callback() {
                            @Override public void onSuccess(Object result) { toast(t("withdraw_cancelled")); openWalletTransactionsPage(symbol); }
                            @Override public void onError(String message) { toast(message); }
                        });
                    });
                    card.addView(cancel);
                }
                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
                params.setMargins(0, 0, 0, dp(8));
                list.addView(card, params);
                shown++;
            }
            if (shown == 0) list.addView(note(t("no_transaction_records", t("all").equals(selected[0]) ? "" : selected[0])));
        };
        for (String label : labels) {
            TextView tab = centeredText(label, 14, label.equals(selected[0]) ? Color.WHITE : TEXT);
            tab.setBackground(round(label.equals(selected[0]) ? BLUE : Color.WHITE, 20));
            tab.setOnClickListener(v -> {
                selected[0] = label;
                for (int i = 0; i < filters.getChildCount(); i++) {
                    TextView button = (TextView) filters.getChildAt(i);
                    boolean active = labels[i].equals(label);
                    button.setBackground(round(active ? BLUE : Color.WHITE, 20));
                    button.setTextColor(active ? Color.WHITE : TEXT);
                }
                render[0].run();
            });
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(38), 1);
            p.setMargins(dp(4), 0, dp(4), 0);
            filters.addView(tab, p);
        }
        root.addView(filters);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        openSubPage(root, 3);
        ApiClient.get(this, "wallet.transactions", null, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                if (data instanceof JSONArray) transactions[0] = (JSONArray) data;
                render[0].run();
            }
            @Override public void onError(String message) { toast(message); }
        });
    }

    private int walletTransactionDirection(String type) {
        if ("deposit".equals(type) || "refund".equals(type) || "staking_redeem".equals(type) || "staking_interest".equals(type) || "staking_dividend".equals(type) || "referral_reward".equals(type) || "exchange_in".equals(type)) return 1;
        if ("withdraw".equals(type) || "staking".equals(type) || "redeem".equals(type) || "exchange_out".equals(type)) return -1;
        return 0;
    }

    private String displayAssetSymbol(String symbol) {
        return "SPX001".equals(symbol) ? t("points") : symbol;
    }

    private String walletTransactionLabel(String type) {
        if ("deposit".equals(type)) return t("deposit");
        if ("withdraw".equals(type)) return t("withdraw");
        if ("staking".equals(type)) return t("staking");
        if ("staking_redeem".equals(type)) return t("staking_redeem");
        if ("staking_interest".equals(type)) return t("staking_interest");
        if ("staking_dividend".equals(type)) return t("staking_dividend");
        if ("referral_reward".equals(type)) return t("referral_reward");
        if ("refund".equals(type)) return t("refund");
        if ("redeem".equals(type)) return t("redeem");
        if ("exchange_in".equals(type)) return t("exchange_in");
        if ("exchange_out".equals(type)) return t("exchange_out");
        if ("withdraw_refund".equals(type)) return t("withdraw_refund");
        if ("admin_adjustment".equals(type)) return t("admin_adjustment");
        return normalizeOptionalText(type).isEmpty() ? t("other") : type;
    }

    private String walletTransactionStatusLabel(String status) {
        if ("pending".equals(status)) return t("processing");
        if ("completed".equals(status)) return t("completed");
        if ("failed".equals(status)) return t("failed");
        if ("rejected".equals(status)) return t("rejected");
        if ("cancelled".equals(status)) return t("cancelled");
        if ("processing".equals(status)) return t("processing");
        return normalizeOptionalText(status).isEmpty() ? t("unknown_status") : status;
    }

    private void addWalletAction(LinearLayout parent, String label, int color, Runnable action) {
        TextView button = centeredText(label, 14, Color.WHITE);
        button.setTypeface(null, android.graphics.Typeface.BOLD);
        button.setBackground(round(color, 12));
        button.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, dp(48), 1);
        params.setMargins(dp(4), 0, dp(4), 0);
        parent.addView(button, params);
    }

    private String walletBindingKey() { return "wallet_bsc_binding_" + currentUserId; }

    private void showBindBscWalletDialog() {
        String existing = normalizeOptionalText(preferences.getString(walletBindingKey(), ""));
        if (!existing.isEmpty()) { toast(t("wallet_bound_immutable")); return; }
        EditText address = formInput(t("wallet_address"), "");
        EditText password = formInput(t("wallet_password"), "");
        password.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        LinearLayout content = column();
        content.setPadding(dp(6), 0, dp(6), 0);
        content.addView(bodyText(t("wallet_binding_warning"), 13, Color.rgb(190, 75, 70)));
        content.addView(address);
        content.addView(password);
        new AlertDialog.Builder(this).setTitle(t("binding_wallet_title")).setView(content).setNegativeButton(t("cancel"), null).setPositiveButton(t("confirm_bind"), (dialog, which) -> {
            String value = address.getText().toString().trim();
            if (!value.matches("(?i)^0x[0-9a-f]{40}$")) { toast(t("wallet_address_invalid")); return; }
            String currentPassword = password.getText().toString();
            if (currentPassword.isEmpty()) { toast(t("wallet_password_required")); return; }
            new AlertDialog.Builder(this).setMessage(t("binding_confirm"))
                    .setNegativeButton(t("return_check"), null).setPositiveButton(t("permanent_bind"), (confirm, selected) -> {
                        JSONObject body = new JSONObject();
                        try { body.put("address", value); body.put("password", currentPassword); } catch (Exception ignored) { return; }
                        ApiClient.post(this, "wallet.bind", body, new ApiClient.Callback() {
                            @Override public void onSuccess(Object data) {
                                String bound = data instanceof JSONObject ? normalizeOptionalText(((JSONObject) data).optString("bound_address", "")) : "";
                                if (bound.isEmpty()) { toast(t("wallet_bind_unconfirmed")); return; }
                                preferences.edit().putString(walletBindingKey(), bound).apply();
                                toast(t("wallet_bound_immutable"));
                                openWalletPage();
                            }
                            @Override public void onError(String message) { toast(message); }
                        });
                    }).show();
        }).show();
    }

    private void addToken(LinearLayout parent, String symbol, String amount, String value, String quote, String stakeableAmount) {
        LinearLayout card = row();
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.setBackground(round(Color.WHITE, 16));
        boolean isSpx = symbol.startsWith("SPX");
        ImageView coin = new ImageView(this);
        coin.setScaleType(ImageView.ScaleType.FIT_CENTER);
        coin.setContentDescription(isSpx ? t("spx_icon_description") : t("usdt_icon_description"));
        coin.setImageResource(isSpx ? com.spx.chat.R.drawable.wallet_spx001 : com.spx.chat.R.drawable.wallet_usdt);
        card.addView(coin, new LinearLayout.LayoutParams(dp(54), dp(54)));
        LinearLayout info = column();
        info.setPadding(dp(12), 0, 0, 0);
        String displaySymbol = displayAssetSymbol(symbol);
        TextView symbolView = bodyText(displaySymbol, 17, TEXT);
        symbolView.setTypeface(null, android.graphics.Typeface.BOLD);
        info.addView(symbolView);
        if (isSpx) info.addView(bodyText(t("stakeable_balance_short", formatAmount(stakeableAmount)), 12, Color.rgb(38, 115, 91)));
        info.addView(bodyText(quote + " · BSC", 12, MUTED));
        card.addView(info, new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout balance = column();
        balance.setGravity(Gravity.RIGHT);
        balance.addView(bodyText(amount, 16, TEXT));
        balance.addView(bodyText(value, 12, MUTED));
        card.addView(balance);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.setMargins(0, 0, 0, dp(10));
        parent.addView(card, params);
        card.setOnClickListener(v -> openWalletTransactionsPage(symbol));
        card.setContentDescription(t("wallet_asset_description", displaySymbol, amount, value, quote));
    }

    private void showExchangeDialog() {
        LinearLayout form = column();
        form.setPadding(dp(4), dp(6), dp(4), dp(4));
        LinearLayout pair = row();
        TextView from = centeredText(t("exchange_from"), 16, TEXT);
        from.setTypeface(null, android.graphics.Typeface.BOLD);
        from.setBackground(round(Color.rgb(243, 246, 248), 12));
        TextView arrow = centeredText("→", 22, MUTED);
        TextView to = centeredText(t("exchange_to"), 16, Color.rgb(37, 132, 102));
        to.setTypeface(null, android.graphics.Typeface.BOLD);
        to.setBackground(round(Color.rgb(232, 246, 239), 12));
        pair.addView(from, new LinearLayout.LayoutParams(0, dp(62), 1));
        pair.addView(arrow, new LinearLayout.LayoutParams(dp(42), dp(54)));
        pair.addView(to, new LinearLayout.LayoutParams(0, dp(62), 1));
        form.addView(pair);

        TextView priceInfo = bodyText(t("exchange_quote_loading"), 13, MUTED);
        priceInfo.setPadding(0, dp(12), 0, dp(8));
        form.addView(priceInfo);
        EditText amount = formInput(t("exchange_usdt_amount"), "");
        amount.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        form.addView(amount);
        LinearLayout availableRow = row();
        String[] availableAmount = {"0"};
        TextView available = bodyText(t("available_balance_loading"), 12, MUTED);
        availableRow.addView(available, new LinearLayout.LayoutParams(0, dp(30), 1));
        TextView max = bodyText(t("all"), 12, BLUE);
        max.setOnClickListener(v -> { amount.setText(availableAmount[0]); amount.setSelection(amount.length()); });
        availableRow.addView(max);
        form.addView(availableRow);
        TextView estimate = bodyText(t("exchange_estimate_empty"), 17, TEXT);
        estimate.setTypeface(null, android.graphics.Typeface.BOLD);
        estimate.setPadding(0, dp(10), 0, dp(2));
        form.addView(estimate);
        TextView feeHint = bodyText(t("exchange_fee_included"), 12, MUTED);
        form.addView(feeHint);

        String[] spxPerUsdt = {""};
        boolean[] quoteReady = {false};
        Runnable updateEstimate = () -> {
            String value = amount.getText().toString().trim();
            if (!quoteReady[0] || value.isEmpty()) { estimate.setText(t("exchange_estimate_empty")); return; }
            try {
                java.math.BigDecimal result = new java.math.BigDecimal(value).multiply(new java.math.BigDecimal(spxPerUsdt[0])).setScale(8, java.math.RoundingMode.DOWN);
                estimate.setText(t("exchange_estimate", result.stripTrailingZeros().toPlainString()));
            } catch (Exception ignored) { estimate.setText(t("exchange_estimate_empty")); }
        };
        amount.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { updateEstimate.run(); }
            @Override public void afterTextChanged(Editable s) { }
        });

        ApiClient.get(this, "wallet.exchange.quote", null, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                if (!(data instanceof JSONObject)) { priceInfo.setText(t("exchange_quote_unavailable")); return; }
                JSONObject quote = (JSONObject) data;
                String marketPrice = quote.optString("api_price_usd", "");
                String exchangePrice = quote.optString("exchange_price_usd", "");
                spxPerUsdt[0] = quote.optString("spx_per_usdt", "");
                String feeRate = quote.optString("fee_rate", "0.01");
                try {
                    quoteReady[0] = new java.math.BigDecimal(marketPrice).signum() > 0
                            && new java.math.BigDecimal(exchangePrice).signum() > 0
                            && new java.math.BigDecimal(spxPerUsdt[0]).signum() > 0;
                    String feePercent = new java.math.BigDecimal(feeRate).multiply(new java.math.BigDecimal("100")).stripTrailingZeros().toPlainString();
                    priceInfo.setText(t("exchange_quote_details", formatPrice6(marketPrice), feePercent, formatPrice6(exchangePrice), formatPrice6(spxPerUsdt[0])));
                    feeHint.setText(t("exchange_fee_validation_hint"));
                } catch (Exception ignored) { quoteReady[0] = false; priceInfo.setText(t("exchange_quote_invalid")); }
                updateEstimate.run();
            }
            @Override public void onError(String message) { priceInfo.setText(t("exchange_quote_failed", message)); }
        });
        ApiClient.get(this, "wallet", null, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                if (!(data instanceof JSONArray)) { available.setText(t("wallet_balance_unavailable")); return; }
                JSONArray assets = (JSONArray) data;
                for (int i = 0; i < assets.length(); i++) {
                    JSONObject asset = assets.optJSONObject(i);
                    if (asset != null && "USDT".equals(asset.optString("symbol"))) {
                        availableAmount[0] = asset.optString("balance", "0");
                        available.setText(t("available_balance", formatAmount(availableAmount[0]), "USDT"));
                        return;
                    }
                }
                available.setText(t("available_balance", "0.00", "USDT"));
            }
            @Override public void onError(String message) { available.setText(t("wallet_balance_unavailable")); }
        });

        ScrollView formScroll = new ScrollView(this);
        formScroll.addView(form, new ScrollView.LayoutParams(-1, -2));
        showWalletTransferSheet(t("exchange_title"), t("confirm_exchange"), formScroll, dialog -> {
            if (!quoteReady[0]) { toast(t("exchange_quote_not_ready")); return; }
            String rawAmount = amount.getText().toString().trim();
            java.math.BigDecimal input;
            try { input = new java.math.BigDecimal(rawAmount); }
            catch (Exception ignored) { toast(t("exchange_usdt_amount_invalid")); return; }
            if (input.signum() <= 0) { toast(t("exchange_amount_positive")); return; }
            if (input.compareTo(new java.math.BigDecimal(availableAmount[0])) > 0) { toast(t("exchange_insufficient_usdt")); return; }
            JSONObject request = new JSONObject();
            try {
                request.put("usdt_amount", input.stripTrailingZeros().toPlainString());
                request.put("request_id", UUID.randomUUID().toString());
            } catch (Exception ignored) { return; }
            ApiClient.post(this, "wallet.exchange", request, new ApiClient.Callback() {
                @Override public void onSuccess(Object data) {
                    dialog.dismiss();
                    String received = data instanceof JSONObject ? ((JSONObject) data).optString("spx_amount", "") : "";
                    toast(t("exchange_success", received));
                    openWalletPage();
                }
                @Override public void onError(String message) { toast(message); }
            });
        });
    }

    private void showTransferDialog(String action) {
        showTransferDialog(action, null);
    }

    private void showTransferDialog(String action, String initialAsset) {
        ApiClient.get(this, "wallet.binding", null, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                String boundAddress = data instanceof JSONObject ? normalizeOptionalText(((JSONObject) data).optString("bound_address", "")) : "";
                preferences.edit().putString(walletBindingKey(), boundAddress).apply();
                if (boundAddress.isEmpty()) {
                    toast(t("bind_wallet_first"));
                    showBindBscWalletDialog();
                    return;
                }
                showTransferDialog(action, initialAsset, boundAddress);
            }
            @Override public void onError(String message) { toast(t("wallet_binding_load_failed", message)); }
        });
    }

    private void showTransferDialog(String action, String initialAsset, String boundAddress) {
        LinearLayout form = column();
        form.setPadding(dp(14), dp(6), dp(14), dp(8));
        ScrollView formScroll = new ScrollView(this);
        formScroll.setFillViewport(false);
        formScroll.addView(form, new ScrollView.LayoutParams(-1, -2));
        TextView chain = bodyText(t("wallet_network"), 14, MUTED);
        chain.setPadding(0, dp(8), 0, dp(8));
        form.addView(chain);
        if (action.equals("deposit")) {
            String[] selectedAsset = {initialAsset == null ? "SPX001" : initialAsset};
            TextView assetPicker = bodyText(t("deposit_asset", displayAssetSymbol(selectedAsset[0])), 15, BLUE);
            assetPicker.setPadding(dp(12), dp(10), dp(12), dp(10));
            assetPicker.setBackground(stroke(Color.WHITE, Color.rgb(211, 222, 241), 10, 1));
            assetPicker.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle(t("select_deposit_asset")).setItems(new String[]{"USDT", t("points")}, (dialog, which) -> {
                selectedAsset[0] = which == 0 ? "USDT" : "SPX001";
                assetPicker.setText(t("deposit_asset", displayAssetSymbol(selectedAsset[0])));
            }).show());
            form.addView(assetPicker);
            TextView sourceAddress = bodyText(t("deposit_source_address", boundAddress), 13, TEXT);
            sourceAddress.setPadding(dp(12), dp(10), dp(12), dp(10));
            sourceAddress.setBackground(round(Color.rgb(245, 247, 250), 10));
            form.addView(sourceAddress);
            TextView platformAddress = bodyText(t("deposit_address_loading"), 14, TEXT);
            platformAddress.setPadding(dp(14), dp(12), dp(14), dp(12));
            platformAddress.setBackground(round(Color.rgb(245, 247, 250), 12));
            form.addView(platformAddress);
            TextView copy = centeredText(t("copy_deposit_address"), 14, BLUE);
            copy.setOnClickListener(v -> {
                String address = platformAddress.getText().toString();
                if (address.contains("0x")) {
                    ClipboardManager manager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                    manager.setPrimaryClip(ClipData.newPlainText(t("deposit_address"), address));
                    toast(t("deposit_address_copied"));
                } else toast(t("deposit_address_unconfigured"));
            });
            form.addView(copy, new LinearLayout.LayoutParams(-1, dp(44)));
            EditText hash = formInput(t("transfer_hash"), "");
            form.addView(hash);
            EditText amount = formInput(t("deposit_amount"), "");
            amount.setInputType(2 | 8192);
            form.addView(amount);
            ApiClient.get(this, "wallet.deposit.info", null, new ApiClient.Callback() {
                @Override public void onSuccess(Object data) {
                    if (data instanceof JSONObject) {
                        String address = ((JSONObject) data).optString("usdt_address", "");
                        platformAddress.setText(address.isEmpty() ? t("deposit_address_unconfigured") : address);
                    }
                }
                @Override public void onError(String message) { platformAddress.setText(t("deposit_address_unconfigured")); }
            });
            showWalletTransferSheet(t("deposit"), t("submit_deposit"), formScroll, depositDialog -> {
                String address = platformAddress.getText().toString();
                String txHash = hash.getText().toString().trim();
                String value = amount.getText().toString().trim();
                if (!address.startsWith("0x")) { toast(t("deposit_address_unconfigured")); return; }
                if (txHash.isEmpty() || value.isEmpty()) { toast(t("deposit_fields_required")); return; }
                JSONObject body = new JSONObject();
                try { body.put("symbol", selectedAsset[0]); body.put("chain", "BSC"); body.put("amount", value); body.put("tx_hash", txHash); } catch (Exception ignored) { }
                ApiClient.post(this, "wallet.deposit", body, new ApiClient.Callback() {
                    @Override public void onSuccess(Object data) { depositDialog.dismiss(); toast(t("deposit_submitted")); }
                    @Override public void onError(String message) { toast(message); }
                });
            });
            return;
        }
        String[] selectedAsset = {initialAsset == null ? "SPX001" : initialAsset};
        String[] availableBalance = {"0"};
        Runnable[] refreshBalance = {null};
        TextView[] withdrawEstimate = {null};
        TextView assetPicker = bodyText(t("withdraw_asset", displayAssetSymbol(selectedAsset[0])), 15, BLUE);
        assetPicker.setPadding(dp(12), dp(10), dp(12), dp(10));
        assetPicker.setBackground(stroke(Color.WHITE, Color.rgb(211, 222, 241), 10, 1));
        assetPicker.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle(t("select_withdraw_asset")).setItems(new String[]{"USDT", t("points")}, (dialog, which) -> {
            selectedAsset[0] = which == 0 ? "USDT" : "SPX001";
            assetPicker.setText(t("withdraw_asset", displayAssetSymbol(selectedAsset[0])));
            if (withdrawEstimate[0] != null) withdrawEstimate[0].setText(t("withdraw_estimate_empty", displayAssetSymbol(selectedAsset[0])));
            if (refreshBalance[0] != null) refreshBalance[0].run();
        }).show());
        form.addView(assetPicker);
        TextView address = bodyText(t("withdraw_address", boundAddress), 13, TEXT);
        address.setPadding(dp(12), dp(12), dp(12), dp(12));
        address.setBackground(round(Color.rgb(245, 247, 250), 10));
        address.setOnClickListener(v -> copyText(boundAddress, t("bound_withdraw_address")));
        form.addView(address);
        TextView assetTip = bodyText(t("withdraw_address_hint"), 12, Color.rgb(190, 75, 70));
        form.addView(assetTip);
        EditText amount = formInput(t("withdraw_amount"), "");
        amount.setInputType(2 | 8192);
        form.addView(amount);
        LinearLayout balanceRow = row();
        TextView balanceHint = bodyText(t("available_balance_loading"), 12, MUTED);
        balanceRow.addView(balanceHint, new LinearLayout.LayoutParams(0, dp(38), 1));
        TextView allButton = centeredText(t("all"), 13, BLUE);
        allButton.setOnClickListener(v -> amount.setText(availableBalance[0]));
        balanceRow.addView(allButton, new LinearLayout.LayoutParams(dp(52), dp(38)));
        form.addView(balanceRow);
        TextView actualAmountHint = bodyText(t("withdraw_estimate_empty", displayAssetSymbol(selectedAsset[0])), 13, Color.rgb(38, 115, 91));
        withdrawEstimate[0] = actualAmountHint;
        actualAmountHint.setPadding(dp(12), dp(10), dp(12), dp(10));
        actualAmountHint.setBackground(round(Color.rgb(237, 248, 243), 10));
        form.addView(actualAmountHint);
        Runnable updateWithdrawEstimate = () -> {
            try {
                java.math.BigDecimal requested = new java.math.BigDecimal(amount.getText().toString().trim());
                java.math.BigDecimal fee = requested.divide(new java.math.BigDecimal("100"), 18, java.math.RoundingMode.DOWN);
                java.math.BigDecimal net = requested.subtract(fee);
                actualAmountHint.setText(t("withdraw_estimate", formatAmount(requested.toPlainString()), formatAmount(fee.toPlainString()), formatAmount(net.toPlainString()), displayAssetSymbol(selectedAsset[0])));
            } catch (Exception ignored) {
                actualAmountHint.setText(t("withdraw_estimate_empty", displayAssetSymbol(selectedAsset[0])));
            }
        };
        amount.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { updateWithdrawEstimate.run(); }
            @Override public void afterTextChanged(Editable s) { }
        });
        updateWithdrawEstimate.run();
        refreshBalance[0] = () -> ApiClient.get(this, "wallet", null, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                availableBalance[0] = "0";
                if (data instanceof JSONArray) for (int i = 0; i < ((JSONArray) data).length(); i++) {
                    JSONObject asset = ((JSONArray) data).optJSONObject(i);
                    if (asset != null && selectedAsset[0].equals(asset.optString("symbol"))) {
                        availableBalance[0] = formatAmount(asset.optString("balance", "0"));
                        break;
                    }
                }
                balanceHint.setText(t("available_balance", availableBalance[0], displayAssetSymbol(selectedAsset[0])));
            }
            @Override public void onError(String message) { balanceHint.setText(t("wallet_balance_load_failed")); }
        });
        refreshBalance[0].run();
        showWalletTransferSheet(t("withdraw"), t("submit_withdraw"), formScroll, withdrawDialog -> {
            String walletAddress = boundAddress;
            String value = amount.getText().toString().trim();
            if (walletAddress.isEmpty() || value.isEmpty()) { toast(t("withdraw_fields_required")); return; }
            JSONObject body = new JSONObject();
            try { body.put("symbol", selectedAsset[0]); body.put("chain", "BSC"); body.put("amount", value); body.put("address", walletAddress); } catch (Exception ignored) { }
            ApiClient.post(this, "wallet.withdraw", body, new ApiClient.Callback() {
                @Override public void onSuccess(Object data) { withdrawDialog.dismiss(); toast(t("withdraw_submitted")); }
                @Override public void onError(String message) { toast(message); }
            });
        });
    }

    private interface WalletTransferSubmit { void submit(Dialog dialog); }

    private void showWalletTransferSheet(String title, String actionLabel, View form, WalletTransferSubmit submit) {
        Dialog dialog = new Dialog(this);
        LinearLayout sheet = column();
        sheet.setPadding(dp(20), dp(16), dp(20), dp(18));
        sheet.setBackground(round(Color.WHITE, 20));
        LinearLayout heading = row();
        LinearLayout titleBlock = column();
        TextView titleView = bodyText(title, 19, TEXT);
        titleView.setTypeface(null, android.graphics.Typeface.BOLD);
        titleBlock.addView(titleView);
        titleBlock.addView(bodyText(t("wallet_transfer_sheet_hint"), 12, MUTED));
        heading.addView(titleBlock, new LinearLayout.LayoutParams(0, -2, 1));
        TextView close = centeredText("×", 25, MUTED);
        close.setOnClickListener(v -> dialog.dismiss());
        heading.addView(close, new LinearLayout.LayoutParams(dp(38), dp(42)));
        sheet.addView(heading);
        View divider = new View(this);
        divider.setBackgroundColor(Color.rgb(237, 240, 243));
        LinearLayout.LayoutParams dividerParams = new LinearLayout.LayoutParams(-1, dp(1));
        dividerParams.setMargins(0, dp(12), 0, dp(8));
        sheet.addView(divider, dividerParams);
        sheet.addView(form, new LinearLayout.LayoutParams(-1, -2));
        TextView submitButton = centeredText(actionLabel, 15, Color.WHITE);
        submitButton.setTypeface(null, android.graphics.Typeface.BOLD);
        submitButton.setBackground(round(BLUE, 12));
        LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(-1, dp(50));
        buttonParams.setMargins(0, dp(12), 0, 0);
        sheet.addView(submitButton, buttonParams);
        submitButton.setOnClickListener(v -> submit.submit(dialog));
        dialog.setContentView(sheet);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);
        dialog.show();
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
            window.setLayout(getResources().getDisplayMetrics().widthPixels - dp(24), WindowManager.LayoutParams.WRAP_CONTENT);
            window.setGravity(Gravity.BOTTOM);
            window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
            WindowManager.LayoutParams attributes = window.getAttributes();
            attributes.dimAmount = 0.35f;
            window.setAttributes(attributes);
        }
    }

    private void showAddressDialog() {
        showTransferDialog("deposit");
    }

    private void openOrdersPage() { commerce().orders(); }

    private void openAddressPage() { commerce().addresses(null); }

    private EditText formInput(String hint, String value) {
        EditText input = new EditText(this);
        input.setHint(tr(hint));
        input.setText(value);
        input.setTextSize(16);
        input.setTextColor(TEXT);
        input.setHintTextColor(Color.rgb(105, 119, 143));
        input.setPadding(dp(14), dp(8), dp(14), dp(8));
        input.setBackground(inputBackground(false));
        input.setOnFocusChangeListener((view, focused) -> input.setBackground(inputBackground(focused)));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, dp(56));
        params.setMargins(0, 0, 0, dp(12));
        input.setLayoutParams(params);
        return input;
    }

    private GradientDrawable inputBackground(boolean focused) {
        GradientDrawable background = round(focused ? Color.WHITE : Color.rgb(246, 248, 253), 12);
        background.setStroke(dp(focused ? 2 : 1), focused ? BLUE : Color.rgb(183, 195, 218));
        return background;
    }

    private NumberPicker picker(String[] values, String selected) {
        if (values.length == 0) values = new String[]{t("please_select")};
        NumberPicker picker = new NumberPicker(this);
        picker.setMinValue(0);
        picker.setMaxValue(values.length - 1);
        picker.setDisplayedValues(values);
        picker.setWrapSelectorWheel(true);
        picker.setDescendantFocusability(NumberPicker.FOCUS_BLOCK_DESCENDANTS);
        picker.setFocusable(true);
        picker.setFocusableInTouchMode(true);
        for (int i = 0; i < values.length; i++) {
            if (values[i].equals(selected)) picker.setValue(i);
        }
        return picker;
    }

    private void addOrder(LinearLayout parent, String name, String price, String status) {
        addOrder(parent, 0, name, price, status);
    }

    private void addOrder(LinearLayout parent, int orderId, String name, String price, String status) {
        LinearLayout card = row();
        card.setPadding(dp(16), dp(16), dp(16), dp(16));
        card.setBackground(round(Color.WHITE, 16));
        LinearLayout info = column();
        info.addView(bodyText(name, 16, TEXT));
        info.addView(bodyText(t("order_number_value", orderId, price), 13, MUTED));
        card.addView(info, new LinearLayout.LayoutParams(0, -2, 1));
        String shownStatus = "pending".equals(status) ? t("order_pending") : ("shipped".equals(status) ? t("order_shipped") : ("delivered".equals(status) || "completed".equals(status) ? t("completed") : ("cancelled".equals(status) ? t("cancelled") : status)));
        card.addView(bodyText(shownStatus, 13, ("completed".equals(status) || "delivered".equals(status)) ? Color.rgb(46, 145, 95) : Color.rgb(196, 119, 33)));
        if (orderId > 0 && "pending".equals(status)) {
            TextView cancel = bodyText(t("cancel"), 13, Color.rgb(231, 76, 60));
            cancel.setPadding(dp(8), dp(4), 0, dp(4));
            cancel.setOnClickListener(v -> new AlertDialog.Builder(this).setMessage(t("cancel_order_confirm")).setNegativeButton(t("back"), null).setPositiveButton(t("cancel_order"), (d, w) -> {
                JSONObject request = new JSONObject();
                try { request.put("order_id", orderId); } catch (Exception ignored) { return; }
                ApiClient.post(this, "orders.cancel", request, new ApiClient.Callback() {
                    @Override public void onSuccess(Object data) { toast(t("order_cancelled")); openOrdersPage(); }
                    @Override public void onError(String message) { toast(message); }
                });
            }).show());
            card.addView(cancel);
        }
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.setMargins(0, 0, 0, dp(12));
        parent.addView(card, params);
    }

    private void openAddFriendPage() {
        LinearLayout root = subPageRoot(t("add_friend"), t("add_friend_subtitle"));
        LinearLayout body = column();
        body.setPadding(dp(20), dp(24), dp(20), dp(20));
        EditText input = formInput(t("email_or_spx_id"), "");
        input.setSingleLine(true);
        body.addView(input);
        TextView searchButton = centeredText(t("find_friend"), 15, Color.WHITE);
        searchButton.setTypeface(null, android.graphics.Typeface.BOLD);
        searchButton.setBackground(round(BLUE, 14));
        searchButton.setOnClickListener(v -> {
            String keyword = input.getText().toString().trim();
            if (keyword.isEmpty()) { toast(t("email_or_spx_id_required")); return; }
            Map<String, String> params = new HashMap<>();
            params.put("q", keyword);
            ApiClient.get(this, "contacts.search", params, new ApiClient.Callback() {
                @Override public void onSuccess(Object data) {
                    if (!(data instanceof JSONArray) || ((JSONArray) data).length() == 0) { toast(t("user_not_found")); return; }
                    JSONObject user = ((JSONArray) data).optJSONObject(0);
                    if (user == null) { toast(t("user_not_found")); return; }
                    loadUserProfile(user.optInt("id"), new UserProfileCallback() {
                        @Override public void onProfile(JSONObject profile) { openFriendProfilePage(profile); }
                        @Override public void onError(String message) { toast(t("profile_load_failed", message)); }
                    });
                }
                @Override public void onError(String message) { toast(message); }
            });
        });
        LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(-1, dp(48));
        buttonParams.setMargins(0, dp(14), 0, dp(24));
        body.addView(searchButton, buttonParams);
        body.addView(centeredText(t("scan_my_qr_hint"), 13, MUTED));
        TextView qr = centeredText(t("view_my_qr") + "\n" + currentUserSpxId, 20, BLUE);
        qr.setOnClickListener(v -> showQrDialog(currentUserSpxId));
        qr.setBackground(round(Color.WHITE, 18));
        LinearLayout.LayoutParams qrParams = new LinearLayout.LayoutParams(-1, dp(150));
        qrParams.setMargins(dp(30), dp(18), dp(30), 0);
        body.addView(qr, qrParams);
        root.addView(body, new LinearLayout.LayoutParams(-1, 0, 1));
        openSubPage(root, activeTab);
    }

    private void openCreateGroupPage() {
        LinearLayout root = subPageRoot(t("group_create"), t("group_create_subtitle"));
        ScrollView scroll = new ScrollView(this);
        LinearLayout list = column();
        list.setPadding(dp(16), dp(16), dp(16), dp(24));
        EditText groupName = formInput(t("group_name"), "");
        list.addView(groupName);
        Set<Integer> selectedIds = new HashSet<>();
        JSONArray[] friendList = {new JSONArray()};
        TextView selectedSummary = bodyText(t("no_friend_selected"), 14, MUTED);
        selectedSummary.setPadding(dp(14), dp(12), dp(14), dp(12));
        selectedSummary.setBackground(round(Color.WHITE, 10));
        list.addView(selectedSummary);
        TextView chooseFriends = centeredText(t("choose_members"), 14, BLUE);
        chooseFriends.setBackground(round(Color.rgb(238, 242, 255), 10));
        chooseFriends.setOnClickListener(v -> {
            if (friendList[0].length() == 0) { toast(t("friends_loading_or_empty")); return; }
            showFriendPicker(t("choose_group_members"), t("confirm_selection"), friendList[0], selected -> {
            selectedIds.clear();
            StringBuilder names = new StringBuilder();
            int count = 0;
            for (int i = 0; i < selected.length(); i++) {
                JSONObject contact = selected.optJSONObject(i);
                if (contact == null) continue;
                selectedIds.add(contact.optInt("id"));
                String remark = normalizeOptionalText(contact.optString("remark", ""));
                String nickname = normalizeOptionalText(contact.optString("nickname", ""));
                if (count > 0) names.append(t("list_separator"));
                names.append(remark.isEmpty() ? (nickname.isEmpty() ? t("friend") : nickname) : remark);
                count++;
            }
            selectedSummary.setText(count == 0 ? t("no_friend_selected") : t("selected_members", count, names));
            });
        });
        LinearLayout.LayoutParams chooseParams = new LinearLayout.LayoutParams(-1, dp(48));
        chooseParams.setMargins(0, 0, 0, dp(12));
        list.addView(chooseFriends, chooseParams);
        ApiClient.get(this, "contacts", null, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) { if (data instanceof JSONArray) friendList[0] = (JSONArray) data; }
            @Override public void onError(String message) { list.addView(note(message)); }
        });
        TextView create = centeredText(t("create_group"), 15, Color.WHITE);
        create.setBackground(round(BLUE, 14));
        create.setOnClickListener(v -> {
            String name = groupName.getText().toString().trim();
            if (name.isEmpty()) { toast(t("group_name_required")); return; }
            if (selectedIds.isEmpty()) { toast(t("select_one_member")); return; }
            JSONArray memberIds = new JSONArray();
            for (Integer id : selectedIds) memberIds.put(id);
            JSONObject request = new JSONObject();
            try { request.put("name", name); request.put("member_ids", memberIds); } catch (Exception ignored) { return; }
            ApiClient.post(this, "groups.create", request, new ApiClient.Callback() {
                @Override public void onSuccess(Object data) {
                    int groupId = data instanceof JSONObject ? ((JSONObject) data).optInt("group_id") : 0;
                    invalidateChatSnapshot();
                    closeSubPage();
                    toast(t("group_created"));
                    if (groupId > 0) openChatWindow(0, groupId, name, t("group_avatar"), "group", "#5B7CFA", "#9B5DE5");
                }
                @Override public void onError(String message) { toast(message); }
            });
        });
        LinearLayout.LayoutParams createParams = new LinearLayout.LayoutParams(-1, dp(48));
        createParams.setMargins(0, dp(18), 0, 0);
        list.addView(create, createParams);
        scroll.addView(list, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        openSubPage(root, activeTab);
    }

    private void openScanPage() {
        LinearLayout root = subPageRoot(t("scan"), t("scan_subtitle"));
        LinearLayout body = column();
        body.setGravity(Gravity.CENTER_HORIZONTAL);
        body.setPadding(dp(24), dp(48), dp(24), dp(24));
        TextView scan = centeredText("▦\n\n" + t("scan_subtitle"), 20, BLUE);
        scan.setBackground(round(Color.WHITE, 22));
        body.addView(scan, new LinearLayout.LayoutParams(-1, dp(280)));
        TextView start = centeredText(t("start_scan"), 15, Color.WHITE);
        start.setBackground(round(BLUE, 12));
        start.setOnClickListener(v -> new IntentIntegrator(this).setDesiredBarcodeFormats(IntentIntegrator.QR_CODE).setPrompt(t("scan_spx_qr_prompt")).setBeepEnabled(false).setOrientationLocked(true).initiateScan());
        body.addView(start, new LinearLayout.LayoutParams(-1, dp(50)));
        TextView fromGallery = centeredText(t("scan_gallery"), 15, BLUE);
        fromGallery.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("image/*");
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            try { startActivityForResult(Intent.createChooser(intent, t("choose_qr_image")), PICK_SCAN_IMAGE); }
            catch (Exception ignored) { toast(t("image_picker_unavailable")); }
        });
        body.addView(fromGallery, new LinearLayout.LayoutParams(-1, dp(50)));
        TextView byId = centeredText(t("join_by_group_id"), 15, BLUE);
        byId.setOnClickListener(v -> showFindGroupDialog());
        body.addView(byId, new LinearLayout.LayoutParams(-1, dp(50)));
        root.addView(body, new LinearLayout.LayoutParams(-1, 0, 1));
        openSubPage(root, activeTab);
    }

    private void openBenefitsPage() {
        LinearLayout root = subPageRoot(t("my_benefits"), t("benefits_subtitle"));
        LinearLayout body = column();
        body.setPadding(dp(16), dp(16), dp(16), dp(16));
        addBenefit(body, t("eco_pass"), t("eco_pass_desc"), t("activated"));
        addBenefit(body, t("staking_member"), t("staking_member_desc"), t("activated"));
        addBenefit(body, t("store_points"), t("store_points_desc"), t("redeemable"));
        root.addView(body, new LinearLayout.LayoutParams(-1, 0, 1));
        openSubPage(root, 3);
    }

    private void addBenefit(LinearLayout parent, String title, String desc, String status) {
        LinearLayout item = row();
        item.setPadding(dp(16), dp(16), dp(16), dp(16));
        item.setBackground(round(Color.WHITE, 16));
        LinearLayout text = column();
        text.addView(bodyText(title, 17, TEXT));
        text.addView(bodyText(desc, 13, MUTED));
        item.addView(text, new LinearLayout.LayoutParams(0, -2, 1));
        item.addView(bodyText(status, 13, BLUE));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.setMargins(0, 0, 0, dp(12));
        parent.addView(item, params);
    }

    private void openHelpPage() {
        LinearLayout root = subPageRoot(t("support"), t("support_subtitle"));
        ScrollView scroll = new ScrollView(this);
        LinearLayout body = column();
        body.setPadding(dp(16), dp(16), dp(16), dp(24));
        EditText subject = formInput(t("subject"), "");
        EditText detail = formInput(t("issue_description"), "");
        detail.setMinLines(4);
        detail.setGravity(Gravity.TOP | Gravity.START);
        body.addView(subject);
        body.addView(detail);
        TextView submit = centeredText(t("submit_ticket"), 15, Color.WHITE);
        submit.setBackground(round(BLUE, 12));
        submit.setOnClickListener(v -> {
            String title = subject.getText().toString().trim();
            String content = detail.getText().toString().trim();
            if (title.isEmpty() || content.isEmpty()) { toast(t("ticket_fields_required")); return; }
            JSONObject request = new JSONObject();
            try { request.put("subject", title); request.put("content", content); } catch (Exception ignored) { return; }
            ApiClient.post(this, "support.tickets.create", request, new ApiClient.Callback() {
                @Override public void onSuccess(Object data) {
                    subject.setText("");
                    detail.setText("");
                    toast(t("ticket_submitted"));
                    loadSupportTickets(body);
                }
                @Override public void onError(String message) { toast(message); }
            });
        });
        LinearLayout.LayoutParams submitParams = new LinearLayout.LayoutParams(-1, dp(48));
        submitParams.setMargins(0, 0, 0, dp(16));
        body.addView(submit, submitParams);
        body.addView(section(t("my_submissions")));
        loadSupportTickets(body);
        scroll.addView(body, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        openSubPage(root, 3);
    }

    private void openInvitePage() {
        LinearLayout root = subPageRoot(t("invite"), t("invite_subtitle"));
        ScrollView scroll = new ScrollView(this);
        LinearLayout body = column();
        body.setPadding(dp(16), dp(16), dp(16), dp(24));
        LinearLayout inviteCard = column();
        inviteCard.setPadding(dp(20), dp(20), dp(20), dp(18));
        inviteCard.setBackground(gradient("#315BEB", "#4778F2", 18));
        inviteCard.addView(bodyText(t("invite_friends"), 18, Color.WHITE));
        TextView inviteSubtitle = bodyText(t("invite_reward_desc"), 13, Color.WHITE);
        inviteSubtitle.setPadding(0, dp(4), 0, dp(16));
        inviteCard.addView(inviteSubtitle);
        inviteCard.addView(bodyText(t("my_spx_id"), 12, Color.rgb(226, 235, 255)));
        TextView inviteId = bodyText(currentUserSpxId, 26, Color.WHITE);
        inviteId.setTypeface(null, android.graphics.Typeface.BOLD);
        inviteId.setPadding(0, dp(4), 0, dp(10));
        inviteId.setOnClickListener(v -> copyText(currentUserSpxId, "SPX ID"));
        inviteCard.addView(inviteId);
        inviteCard.addView(bodyText(t("invite_reward_rule"), 13, Color.WHITE));
        String[] inviteLink = {"http://spx001.top/login.php?invite=" + currentUserSpxId};
        TextView copyLink = centeredText(t("copy_invite_link"), 14, BLUE);
        copyLink.setPadding(0, dp(10), 0, dp(10));
        copyLink.setBackground(round(Color.WHITE, 10));
        copyLink.setOnClickListener(v -> copyText(inviteLink[0], t("invite_link")));
        inviteCard.addView(copyLink, new LinearLayout.LayoutParams(-1, dp(42)));
        TextView qr = centeredText(t("show_invite_qr"), 14, BLUE);
        qr.setPadding(0, dp(10), 0, dp(10));
        qr.setBackground(round(Color.WHITE, 10));
        LinearLayout.LayoutParams qrParams = new LinearLayout.LayoutParams(-1, dp(42));
        qrParams.setMargins(0, dp(14), 0, 0);
        qr.setOnClickListener(v -> showQrDialog(inviteLink[0]));
        inviteCard.addView(qr, qrParams);
        body.addView(inviteCard);

        LinearLayout summary = row();
        summary.setPadding(0, dp(12), 0, dp(8));
        LinearLayout countTile = column();
        countTile.setPadding(dp(14), dp(12), dp(14), dp(12));
        countTile.setBackground(round(Color.WHITE, 12));
        countTile.addView(bodyText(t("invite_count"), 12, MUTED));
        TextView inviteCount = bodyText("—", 22, TEXT);
        inviteCount.setTypeface(null, android.graphics.Typeface.BOLD);
        countTile.addView(inviteCount);
        LinearLayout rewardTile = column();
        rewardTile.setPadding(dp(14), dp(12), dp(14), dp(12));
        rewardTile.setBackground(round(Color.WHITE, 12));
        rewardTile.addView(bodyText(t("total_reward"), 12, MUTED));
        TextView rewardTotal = bodyText("—", 22, BLUE);
        rewardTotal.setTypeface(null, android.graphics.Typeface.BOLD);
        rewardTile.addView(rewardTotal);
        LinearLayout.LayoutParams tileParams = new LinearLayout.LayoutParams(0, -2, 1);
        tileParams.setMargins(0, 0, dp(6), 0);
        summary.addView(countTile, tileParams);
        LinearLayout.LayoutParams rewardParams = new LinearLayout.LayoutParams(0, -2, 1);
        rewardParams.setMargins(dp(6), 0, 0, 0);
        summary.addView(rewardTile, rewardParams);
        body.addView(summary);
        LinearLayout withdrawRow = row();
        withdrawRow.setPadding(dp(14), dp(10), dp(12), dp(10));
        withdrawRow.setBackground(round(Color.WHITE, 12));
        LinearLayout availableInfo = column();
        availableInfo.addView(bodyText(t("withdrawable"), 12, MUTED));
        TextView available = bodyText(t("points_placeholder"), 16, TEXT);
        available.setTypeface(null, android.graphics.Typeface.BOLD);
        availableInfo.addView(available);
        withdrawRow.addView(availableInfo, new LinearLayout.LayoutParams(0, -2, 1));
        TextView withdraw = centeredText(t("go_withdraw"), 14, BLUE);
        withdraw.setOnClickListener(v -> showTransferDialog(t("withdraw"), "SPX001"));
        withdraw.setBackground(round(Color.rgb(238, 242, 255), 10));
        withdrawRow.addView(withdraw, new LinearLayout.LayoutParams(dp(82), dp(40)));
        LinearLayout.LayoutParams withdrawParams = new LinearLayout.LayoutParams(-1, -2);
        withdrawParams.setMargins(0, 0, 0, dp(8));
        body.addView(withdrawRow, withdrawParams);
        body.addView(section(t("my_referrals")));
        TextView loading = note(t("invite_loading"));
        loading.setTag("invite_loading");
        body.addView(loading);
        ApiClient.get(this, "referrals", null, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                if (!(data instanceof JSONObject)) return;
                JSONObject result = (JSONObject) data;
                currentUserSpxId = result.optString("invite_code", currentUserSpxId);
                inviteLink[0] = result.optString("invite_url", "http://spx001.top/login.php?invite=" + currentUserSpxId);
                inviteId.setText(currentUserSpxId);
                inviteCount.setText(result.optString("invited_count", "0"));
                rewardTotal.setText(formatAmount(result.optString("total_rewards", "0")));
                    available.setText(t("points_amount", formatAmount(result.optString("withdrawable_spx", "0"))));
                for (int i = body.getChildCount() - 1; i >= 0; i--) {
                    if ("invite_loading".equals(body.getChildAt(i).getTag())) body.removeViewAt(i);
                }
                JSONArray users = result.optJSONArray("users");
                 if (users == null || users.length() == 0) { body.addView(note(t("no_referrals"))); return; }
                for (int i = 0; i < users.length(); i++) {
                    JSONObject user = users.optJSONObject(i);
                    if (user == null) continue;
                    LinearLayout member = column();
                    member.setPadding(dp(14), dp(12), dp(14), dp(12));
                    member.setBackground(round(Color.WHITE, 10));
                    member.addView(bodyText(user.optString("nickname", t("spx_user")), 15, TEXT));
                    member.addView(bodyText(user.optString("spx_id", ""), 12, BLUE));
                     member.addView(bodyText(t("referral_summary", formatAmount(user.optString("stake_total", "0")), formatAmount(user.optString("reward_total", "0"))), 12, MUTED));
                    LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
                    params.setMargins(0, 0, 0, dp(8));
                    body.addView(member, params);
                }
            }
            @Override public void onError(String message) {
                for (int i = body.getChildCount() - 1; i >= 0; i--) {
                    if ("invite_loading".equals(body.getChildAt(i).getTag())) body.removeViewAt(i);
                }
                body.addView(note(message));
            }
        });
        scroll.addView(body, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        openSubPage(root, 3);
    }

    private void loadSupportTickets(LinearLayout body) {
        ApiClient.get(this, "support.tickets", null, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                if (!(data instanceof JSONArray)) return;
                for (int i = body.getChildCount() - 1; i >= 0; i--) {
                    if ("support_ticket".equals(body.getChildAt(i).getTag())) body.removeViewAt(i);
                }
                JSONArray tickets = (JSONArray) data;
                for (int i = 0; i < tickets.length(); i++) {
                    JSONObject ticket = tickets.optJSONObject(i);
                    if (ticket == null) continue;
                    LinearLayout item = column();
                    item.setTag("support_ticket");
                    item.setPadding(dp(14), dp(12), dp(14), dp(12));
                    item.setBackground(round(Color.WHITE, 10));
                    item.addView(bodyText(ticket.optString("subject"), 15, TEXT));
                    item.addView(bodyText(ticket.optString("content"), 13, MUTED));
                    String reply = ticket.optString("admin_reply", "");
                     item.addView(bodyText(t("ticket_status", ticket.optString("status"), reply), 12, BLUE));
                    LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
                    params.setMargins(0, 0, 0, dp(8));
                    body.addView(item, params);
                }
                 if (tickets.length() == 0) body.addView(note(t("no_submissions")));
            }
            @Override public void onError(String message) { toast(message); }
        });
    }

    private void openSecurityPage() {
        openSimpleSettingsPage(t("security_settings"), new String[]{t("login_password"), t("device_management"), t("login_protection"), t("identity_verification")});
    }

    private void openSettingsPage() {
        LinearLayout root = subPageRoot(t("general_settings"), "");
        LinearLayout body = column();
        body.setPadding(0, dp(12), 0, dp(24));
        addSettingsSection(body, t("general"), new String[]{"language|" + t("language") + "|" + languageDisplayName(), "background|" + t("chat_background") + "|", "lock|" + t("change_password") + "|", "update|" + t("check_updates") + "|", "cache|" + t("clear_cache") + "|", "about|" + t("about") + "|"});
        addSettingsSection(body, "", new String[]{"history|" + t("update_history") + "|", "agreement|" + t("agreement") + "|"});
        TextView logout = centeredText(t("sign_out"), 16, Color.rgb(231, 76, 60));
        logout.setBackground(stroke(Color.WHITE, Color.rgb(255, 190, 190), 12, 1));
        logout.setOnClickListener(v -> new AlertDialog.Builder(this).setMessage(t("logout_confirm")).setNegativeButton(t("cancel"), null).setPositiveButton(t("sign_out"), (d, w) -> {
            if (ApiClient.token(this).isEmpty()) {
                ApiClient.clearToken(this);
                showAuthenticationPage();
                return;
            }
            ApiClient.post(this, "auth.logout", new JSONObject(), new ApiClient.Callback() {
                @Override public void onSuccess(Object data) { ApiClient.clearToken(MainActivity.this); showAuthenticationPage(); }
                @Override public void onError(String message) { ApiClient.clearToken(MainActivity.this); showAuthenticationPage(); toast(t("local_login_cleared")); }
            });
        }).show());
        LinearLayout.LayoutParams logoutParams = new LinearLayout.LayoutParams(-1, dp(58));
        logoutParams.setMargins(dp(20), dp(22), dp(20), 0);
        body.addView(logout, logoutParams);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(body, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        openSubPage(root, 3);
    }

    private void addSettingsSection(LinearLayout parent, String title, String[] items) {
        LinearLayout section = column();
        section.setPadding(dp(18), dp(8), dp(18), dp(8));
        section.setBackground(round(Color.WHITE, 12));
        if (!title.isEmpty()) {
            TextView heading = bodyText(title, 14, MUTED);
            heading.setPadding(dp(4), dp(8), 0, dp(8));
            section.addView(heading);
        }
        for (String entry : items) {
            String[] parts = entry.split("\\|", -1);
            String icon = parts[0];
            String name = parts[1];
            String value = parts.length > 2 ? parts[2] : "";
            LinearLayout row = row();
            row.setGravity(Gravity.CENTER_VERTICAL);
            SimpleIconView iconView = new SimpleIconView(this, icon);
            LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(dp(38), dp(38));
            iconParams.setMargins(0, 0, dp(10), 0);
            row.addView(iconView, iconParams);
            row.addView(bodyText(name, 16, TEXT), new LinearLayout.LayoutParams(0, dp(58), 1));
            if (!value.isEmpty()) row.addView(bodyText(value, 14, MUTED));
            row.addView(bodyText("›", 22, Color.rgb(184, 197, 214)));
            row.setOnClickListener(v -> {
                   if (name.equals(t("language"))) showLanguageDialog();
                   else if (name.equals(t("chat_background"))) showChatBackgroundDialog();
                   else if (name.equals(t("change_password"))) showChangePasswordDialog();
                 else if (name.equals(t("check_updates"))) checkAppUpdate(true);
                 else if (name.equals(t("update_history"))) openUpdateHistoryPage();
                 else if (name.equals(t("about"))) showAboutDialog();
                 else if (name.equals(t("agreement"))) showAgreementDialog();
                 else if (name.equals(t("clear_cache"))) new AlertDialog.Builder(this).setMessage(t("clear_cache_confirm")).setNegativeButton(t("cancel"), null).setPositiveButton(t("clear"), (d, w) -> { clearDirectory(getCacheDir()); clearDirectory(new File(getFilesDir(), "media-cache")); clearDirectory(new File(getFilesDir(), "ecology-image-cache")); toast(t("cache_cleared")); }).show();
                 else toast(t("settings_action", name));
            });
            section.addView(row);
        }
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.setMargins(dp(20), dp(8), dp(20), dp(10));
        parent.addView(section, params);
    }


    private int installedVersionCode() {
        try {
            android.content.pm.PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), 0);
            long code = Build.VERSION.SDK_INT >= 28 ? info.getLongVersionCode() : info.versionCode;
            return (int) Math.min(Integer.MAX_VALUE, Math.max(0, code));
        } catch (Exception ignored) {
            return 0;
        }
    }

    private void checkAppUpdate(boolean manual) {
        if (updateCheckInProgress) return;
        if (manual) updatePromptShown = false;
        updateCheckInProgress = true;
        Map<String, String> params = new HashMap<>();
        params.put("version_code", String.valueOf(installedVersionCode()));
        ApiClient.get(this, "app.update.check", params, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                updateCheckInProgress = false;
                if (!(data instanceof JSONObject)) {
                    if (manual) toast(t("update_info_invalid"));
                    return;
                }
                JSONObject result = (JSONObject) data;
                if (!result.optBoolean("update_available", false)) {
                    updateRequired = false;
                    if (manual) toast(t("current_latest"));
                    return;
                }
                availableRelease = result;
                updateRequired = true;
                if (manual || !updatePromptShown) showAppUpdatePrompt(result);
            }
            @Override public void onError(String message) {
                updateCheckInProgress = false;
                if (manual) toast(t("update_check_failed", message));
            }
        });
    }

    private void showAppUpdatePrompt(JSONObject release) {
        if (isFinishing() || updatePromptShown) return;
        updatePromptShown = true;
        String version = release.optString("version_name", t("new_version"));
        String notes = release.optString("release_notes", t("update_optimization")).trim();
        String message = t("new_version_message", version, notes);
        new AlertDialog.Builder(this)
                .setTitle(t("new_version"))
                .setMessage(message)
                .setPositiveButton(t("send_and_install"), (dialog, which) -> openAppUpdatePage(release))
                .setCancelable(false)
                .show();
    }

    private void openAppUpdatePage(JSONObject release) {
        LinearLayout root = subPageRoot(t("app_update"), "SPX IM · Android");
        ScrollView scroll = new ScrollView(this);
        LinearLayout body = column();
        body.setPadding(dp(20), dp(20), dp(20), dp(32));

        LinearLayout versionPanel = column();
        versionPanel.setPadding(dp(18), dp(18), dp(18), dp(18));
        versionPanel.setBackground(round(Color.WHITE, 16));
        TextView versionTitle = bodyText(t("app_version", release.optString("version_name", "")), 22, TEXT);
        versionTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        versionPanel.addView(versionTitle);
        versionPanel.addView(bodyText(t("version_code", release.optInt("version_code")), 13, MUTED));
        body.addView(versionPanel);

        TextView notesHeading = bodyText(t("update_notes"), 16, TEXT);
        notesHeading.setTypeface(null, android.graphics.Typeface.BOLD);
        notesHeading.setPadding(0, dp(24), 0, dp(10));
        body.addView(notesHeading);
        TextView notes = bodyText(release.optString("release_notes", t("update_optimization")), 14, Color.rgb(77, 91, 108));
        notes.setPadding(dp(16), dp(16), dp(16), dp(16));
        notes.setBackground(round(Color.WHITE, 14));
        notes.setLineSpacing(dp(4), 1f);
        body.addView(notes);

        ProgressBar progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgress(0);
        LinearLayout.LayoutParams progressParams = new LinearLayout.LayoutParams(-1, dp(8));
        progressParams.setMargins(0, dp(28), 0, dp(10));
        body.addView(progress, progressParams);
        TextView progressLabel = bodyText(t("wait_download"), 13, MUTED);
        body.addView(progressLabel);

        TextView downloadButton = centeredText(t("send_and_install"), 16, Color.WHITE);
        downloadButton.setTypeface(null, android.graphics.Typeface.BOLD);
        downloadButton.setBackground(round(BLUE, 14));
        LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(-1, dp(54));
        buttonParams.setMargins(0, dp(24), 0, 0);
        body.addView(downloadButton, buttonParams);
        downloadButton.setOnClickListener(v -> startAppUpdateDownload(release, progress, progressLabel, downloadButton));

        scroll.addView(body, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        if (bottomNav == null) setContentView(root);
        else openSubPage(root, 3);
    }

    private void startAppUpdateDownload(JSONObject release, ProgressBar progress, TextView status, TextView button) {
        int releaseId = release.optInt("id");
        if (releaseId <= 0) { toast(t("release_id_invalid")); return; }
        button.setEnabled(false);
        button.setText(t("download"));
        status.setText(t("connecting_update_server"));
        File updateDirectory = new File(getCacheDir(), "updates");
        if (!updateDirectory.isDirectory() && !updateDirectory.mkdirs()) {
            button.setEnabled(true);
            button.setText(t("redownload"));
            status.setText(t("update_directory_failed"));
            return;
        }
        File destination = new File(updateDirectory, "spxchat-" + release.optInt("version_code") + ".apk");
        String expected = release.optString("apk_sha256", "").toLowerCase(java.util.Locale.ROOT);
        if (destination.isFile() && expected.matches("[a-f0-9]{64}") && expected.equals(sha256File(destination))) {
            pendingUpdateApk = destination;
            progress.setIndeterminate(false);
            progress.setProgress(100);
            status.setText(t("apk_ready_to_install"));
            button.setEnabled(true);
            button.setText(t("open_installer"));
            button.setOnClickListener(v -> installDownloadedApk(destination));
            installDownloadedApk(destination);
            return;
        }
        Map<String, String> params = new HashMap<>();
        params.put("id", String.valueOf(releaseId));
        ApiClient.download(this, "app.update.download", params, destination, new ApiClient.DownloadCallback() {
            @Override public void onProgress(int percent, long received, long total) {
                if (percent >= 0) {
                    progress.setIndeterminate(false);
                    progress.setProgress(percent);
                    status.setText(t("download_percent", percent));
                } else {
                    progress.setIndeterminate(true);
                    status.setText(t("downloading_update_package"));
                }
            }
            @Override public void onSuccess(File file) {
                progress.setIndeterminate(false);
                progress.setProgress(100);
                status.setText(t("download_complete_verifying"));
                String actual = sha256File(file);
                if (!expected.matches("[a-f0-9]{64}") || !expected.equals(actual)) {
                    file.delete();
                    button.setEnabled(true);
                    button.setText(t("redownload"));
                    status.setText(t("apk_verification_failed"));
                    return;
                }
                status.setText(t("verification_opening_installer"));
                pendingUpdateApk = file;
                button.setEnabled(true);
                button.setText(t("reopen_installer"));
                button.setOnClickListener(v -> installDownloadedApk(file));
                installDownloadedApk(file);
            }
            @Override public void onError(String message) {
                progress.setIndeterminate(false);
                button.setEnabled(true);
                button.setText(t("redownload"));
                status.setText(message);
            }
        });
    }

    private String sha256File(File file) {
        try (InputStream input = new java.io.FileInputStream(file)) {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] buffer = new byte[65536];
            int count;
            while ((count = input.read(buffer)) != -1) digest.update(buffer, 0, count);
            StringBuilder result = new StringBuilder(64);
            for (byte value : digest.digest()) result.append(String.format(java.util.Locale.ROOT, "%02x", value & 0xff));
            return result.toString();
        } catch (Exception ignored) {
            return "";
        }
    }

    private void installDownloadedApk(File apk) {
        if (apk == null || !apk.isFile()) { toast(t("downloaded_apk_missing")); return; }
        pendingUpdateApk = apk;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !getPackageManager().canRequestPackageInstalls()) {
            waitingForInstallPermission = true;
            try {
                Intent permission = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                        Uri.parse("package:" + getPackageName()));
                startActivity(permission);
            } catch (Exception exception) {
                waitingForInstallPermission = false;
                toast(t("allow_unknown_app_install"));
            }
            return;
        }
        try {
            Uri apkUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", apk);
            Intent install = new Intent(Intent.ACTION_VIEW);
            install.setDataAndType(apkUri, "application/vnd.android.package-archive");
            install.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(install);
        } catch (Exception exception) {
            toast(t("installer_open_failed", exception.getMessage() == null ? t("retry") : exception.getMessage()));
        }
    }

    private void openUpdateHistoryPage() {
        LinearLayout root = subPageRoot(t("update_history"), t("update_history_subtitle"));
        LinearLayout body = column();
        body.setPadding(dp(20), dp(16), dp(20), dp(16));
        TextView loading = note(t("reading_release_history"));
        body.addView(loading);
        ApiClient.get(this, "app.update.history", null, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                body.removeView(loading);
                if (!(data instanceof JSONArray) || ((JSONArray) data).length() == 0) {
                    body.addView(note(t("no_update_history")));
                    return;
                }
                JSONArray releases = (JSONArray) data;
                int installedCode = installedVersionCode();
                for (int i = 0; i < releases.length(); i++) {
                    JSONObject release = releases.optJSONObject(i);
                    if (release == null) continue;
                    LinearLayout card = column();
                    card.setPadding(dp(16), dp(14), dp(16), dp(14));
                    card.setBackground(round(Color.WHITE, 10));
                    TextView version = bodyText(t("release_version", release.optString("version_name"), release.optInt("version_code")), 16, TEXT);
                    version.setTypeface(null, android.graphics.Typeface.BOLD);
                    card.addView(version);
                    TextView published = bodyText(release.optString("created_at"), 12, MUTED);
                    published.setPadding(0, dp(3), 0, dp(8));
                    card.addView(published);
                    TextView notes = bodyText(release.optString("release_notes"), 14, Color.rgb(77, 91, 108));
                    notes.setLineSpacing(dp(3), 1f);
                    card.addView(notes);
                    TextView state = bodyText(release.optInt("version_code") == installedCode ? t("currently_installed") : t("published"), 12, BLUE);
                    state.setPadding(0, dp(8), 0, 0);
                    card.addView(state);
                    LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
                    params.setMargins(0, 0, 0, dp(10));
                    body.addView(card, params);
                }
            }
            @Override public void onError(String message) {
                body.removeView(loading);
                body.addView(note(t("release_history_failed", message)));
            }
        });
        root.addView(body, new LinearLayout.LayoutParams(-1, 0, 1));
        openSubPage(root, 3);
    }

    private void showAboutDialog() {
        try {
            String version = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
            new AlertDialog.Builder(this).setTitle(t("about_spx_im")).setMessage(t("about_version", version)).setPositiveButton(t("ok"), null).show();
        } catch (Exception ignored) {
            toast(t("version_info_failed"));
        }
    }

    private void showLanguageDialog() {
        String[] values = {t("lang_simplified"), t("lang_traditional"), t("lang_english"), t("lang_japanese"), t("lang_korean")};
        String[] codes = {"zh-CN", "zh-TW", "en", "ja", "ko"};
        int selected = 0;
        for (int i = 0; i < codes.length; i++) if (codes[i].equals(appLanguage)) selected = i;
        new AlertDialog.Builder(this).setTitle(t("language")).setSingleChoiceItems(values, selected, (dialog, which) -> {
            appLanguage = codes[which];
            preferences.edit().putString("language", appLanguage).apply();
            dialog.dismiss();
            refreshForLanguageChange();
            toast(t("language_saved"));
        }).setNegativeButton(t("cancel"), null).show();
    }

    /** Rebuild the active user surface so every app-owned label uses the new locale immediately. */
    private void refreshForLanguageChange() {
        chatWindowOpen = false;
        askWindowOpen = false;
        subPageOpen = false;
        walletAssetDetailOpen = false;
        if (bottomNav == null || content == null) {
            if (bottomNav == null) renderAuthenticationPage();
            return;
        }
        setBottomNavVisible(true);
        renderTab(activeTab);
        for (int i = 0; i < bottomNav.getChildCount(); i++) {
            TextView item = (TextView) bottomNav.getChildAt(i);
            item.setTextColor(i == activeTab ? BLUE : MUTED);
        }
    }

    private void showChangePasswordDialog() {
        LinearLayout form = column();
        form.setPadding(dp(8), 0, dp(8), 0);
        TextView email = bodyText(userEmail.isEmpty() ? t("reading_bound_email") : t("verification_sent_to", userEmail), 14, MUTED);
        email.setPadding(dp(0), dp(4), 0, dp(12));
        EditText code = formInput(t("email_code"), "");
        code.setInputType(2);
        TextView sendCode = centeredText(t("get_code"), 14, BLUE);
        sendCode.setBackground(round(Color.rgb(238, 242, 255), 12));
        EditText newPassword = formInput(t("new_password"), "");
        newPassword.setInputType(129);
        form.addView(email);
        LinearLayout codeRow = row();
        codeRow.addView(code, new LinearLayout.LayoutParams(0, dp(56), 1));
        LinearLayout.LayoutParams sendParams = new LinearLayout.LayoutParams(dp(112), dp(56));
        sendParams.setMargins(dp(8), 0, 0, 0);
        codeRow.addView(sendCode, sendParams);
        form.addView(codeRow);
        form.addView(newPassword);
        sendCode.setOnClickListener(v -> {
            sendCode.setEnabled(false);
            ApiClient.post(this, "password.email.code", new JSONObject(), new ApiClient.Callback() {
                @Override public void onSuccess(Object data) {
                    if (data instanceof JSONObject) {
                        userEmail = ((JSONObject) data).optString("email", userEmail);
                        preferences.edit().putString("user_email", userEmail).apply();
                        email.setText(t("verification_sent_to", userEmail));
                    }
                    startCodeCountdown(sendCode, 60);
                }
                @Override public void onError(String message) { sendCode.setEnabled(true); toast(message); }
            });
        });
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle(t("change_password")).setView(form).setNegativeButton(t("cancel"), null).setPositiveButton(t("save"), null).create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String verificationCode = code.getText().toString().trim();
            String newValue = newPassword.getText().toString();
            if (newValue.length() < 6) { toast(t("password_short")); return; }
            if (!verificationCode.matches("\\d{6}")) { toast(t("email_code_invalid")); return; }
            JSONObject body = new JSONObject();
            try { body.put("code", verificationCode); body.put("new_password", newValue); } catch (Exception ignored) { }
            ApiClient.post(this, "password.update.email", body, new ApiClient.Callback() {
                @Override public void onSuccess(Object data) {
                    if (data instanceof JSONObject) ApiClient.saveToken(MainActivity.this, ((JSONObject) data).optString("token", ""));
                    dialog.dismiss();
                    toast(t("password_changed"));
                }
                @Override public void onError(String message) { toast(message); }
            });
        }));
        dialog.show();
    }

    private void showAgreementDialog() {
        new AlertDialog.Builder(this).setTitle(t("agreement")).setMessage(t("agreement_text"))
                .setPositiveButton(t("know"), null).show();
    }

    private void clearDirectory(java.io.File directory) {
        java.io.File[] files = directory.listFiles();
        if (files == null) return;
        for (java.io.File file : files) {
            if (file.isDirectory()) clearDirectory(file);
            file.delete();
        }
    }

    private void openSimpleSettingsPage(String title, String[] items) {
        LinearLayout root = subPageRoot(title, "");
        LinearLayout body = column();
        body.setPadding(0, dp(12), 0, dp(12));
        for (String itemName : items) {
            addProfileMenu(body, "*", itemName, "", () -> toast(t("open_demo", itemName)));
        }
        root.addView(body, new LinearLayout.LayoutParams(-1, 0, 1));
        openSubPage(root, 3);
    }

    private void showActionSheet() {
        LinearLayout box = dialogBox();
        TextView title = centeredText(t("new_item"), 18, Color.BLACK);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        box.addView(title, new LinearLayout.LayoutParams(-1, dp(34)));
        addDialogAction(box, "▦", t("scan"), t("scan_join_group_desc"), () -> openScanPage());
        addDialogAction(box, t("group_avatar"), t("join_group"), t("join_group_desc"), () -> showFindGroupDialog());
        addDialogAction(box, "+", t("add_friend_short"), t("add_friend_desc"), () -> openAddFriendPage());
        addDialogAction(box, t("group_avatar"), t("group_create"), t("create_group_desc"), () -> openCreateGroupPage());
        TextView cancel = centeredText(t("cancel"), 16, Color.rgb(231, 76, 60));
        cancel.setPadding(0, dp(14), 0, dp(14));
        cancel.setOnClickListener(v -> ((Dialog) box.getTag()).dismiss());
        box.addView(cancel);
        showTopActionDialog(box);
    }

    private void showRemarkDialog(String defaultValue, TextView target, String remarkKey, int peerId, boolean contactLabel) {
        if (peerId <= 0) { toast(t("contact_unavailable_remark")); return; }
        EditText input = new EditText(this);
        input.setHint(t("remark_input"));
        String initialRemark = normalizeOptionalText(defaultValue);
        input.setText(t("none").equals(initialRemark) ? "" : initialRemark);
        new AlertDialog.Builder(this).setTitle(t("set_remark")).setView(input).setNegativeButton(t("cancel"), null).setPositiveButton(t("save"), (d, w) -> {
            String remark = input.getText().toString().trim();
            JSONObject body = new JSONObject();
            try { body.put("contact_user_id", peerId); body.put("remark", remark); } catch (Exception ignored) { return; }
            ApiClient.post(this, "contacts.remark", body, new ApiClient.Callback() {
                @Override public void onSuccess(Object data) {
                    preferences.edit().putString(remarkKey, remark).apply();
                    updateCachedContactRemark(peerId, remark);
                    JSONObject cachedProfile = readCachedUserProfile(peerId);
                    if (cachedProfile != null) {
                        try { cachedProfile.put("contact_remark", remark); cachedProfile.put("is_contact", 1); }
                        catch (Exception ignored) { }
                        cacheUserProfile(cachedProfile);
                        preferences.edit().putLong(userProfileCacheKey(peerId) + "_time", System.currentTimeMillis()).apply();
                    }
                    target.setText(contactLabel ? t("remark_display", remark.isEmpty() ? t("none") : remark) : (remark.isEmpty() ? t("remark_not_set") : remark));
                    invalidateChatSnapshot();
                    if (activeTab == 0 && !chatWindowOpen && !subPageOpen) renderTab(0);
                    if (activeTab == 1 && !subPageOpen) renderTab(1);
                    toast(remark.isEmpty() ? t("remark_cleared") : t("remark_saved"));
                }
                @Override public void onError(String message) { toast(message); }
            });
        }).show();
    }

    private void openConversationDetail(String name, String avatarText, String status, boolean group, String c1, String c2) {
        chatWindowOpen = false;
        int detailChatId = activeChatId;
        int detailPeerId = activePeerUserId > 0 ? activePeerUserId : findChatPeerUserId(detailChatId);
        activePeerUserId = detailPeerId;
        LinearLayout root = subPageRoot(t("chat_details"), "");
        ScrollView scroll = new ScrollView(this);
        LinearLayout body = column();
        body.setPadding(dp(0), dp(0), dp(0), dp(24));

        LinearLayout members = row();
        members.setPadding(dp(28), dp(24), dp(28), dp(20));
        members.setBackgroundColor(Color.WHITE);
        FrameLayout avatarFrame = new FrameLayout(this);
        avatarFrame.setLayoutParams(new LinearLayout.LayoutParams(dp(68), dp(68)));
        TextView fallbackAvatar = avatar(avatarText, c1, c2, 68);
        avatarFrame.addView(fallbackAvatar, new FrameLayout.LayoutParams(-1, -1));
        ImageView profileAvatar = new ImageView(this);
        profileAvatar.setScaleType(ImageView.ScaleType.CENTER_CROP);
        profileAvatar.setBackground(gradient(c1, c2, 50));
        profileAvatar.setClipToOutline(true);
        profileAvatar.setVisibility(View.GONE);
        avatarFrame.addView(profileAvatar, new FrameLayout.LayoutParams(-1, -1));
        members.addView(avatarFrame, new LinearLayout.LayoutParams(dp(68), dp(68)));
        LinearLayout profileInfo = column();
        profileInfo.setPadding(dp(14), 0, 0, 0);
        TextView profileName = bodyText(normalizeOptionalText(name).isEmpty() ? t("contact") : normalizeOptionalText(name), 19, TEXT);
        profileName.setTypeface(null, android.graphics.Typeface.BOLD);
        TextView profileId = bodyText(t("reading_profile"), 13, MUTED);
        profileInfo.addView(profileName);
        profileInfo.addView(profileId);
        members.addView(profileInfo, new LinearLayout.LayoutParams(0, -2, 1));
        body.addView(members);
        if (detailPeerId > 0) {
            loadUserProfile(detailPeerId, new UserProfileCallback() {
                @Override public void onProfile(JSONObject user) {
                    String nickname = normalizeOptionalText(user.optString("nickname", ""));
                    String remark = normalizeOptionalText(user.optString("contact_remark", ""));
                    String spxId = normalizeOptionalText(user.optString("spx_id", ""));
                    String avatarUrl = normalizeOptionalText(user.optString("avatar_url", ""));
                    profileName.setText(remark.isEmpty() ? (nickname.isEmpty() ? t("contact") : nickname) : remark);
                    profileId.setText(spxId.isEmpty() ? t("spx_user") : t("spx_id_label", spxId));
                    if (!avatarUrl.isEmpty()) loadAvatarInto(profileAvatar, avatarUrl);
                }
                @Override public void onError(String message) { profileId.setText(t("profile_unavailable")); }
            });
        } else {
            profileId.setText(t("profile_unavailable"));
        }

        LinearLayout find = settingRow("⌕", t("search_chat_content"), true);
        find.setOnClickListener(v -> openMessageSearchPage(detailChatId, 0, name));
        body.addView(find);
        LinearLayout muteRow = settingSwitchRow(t("mute_messages"), false);
        Switch muteSwitch = (Switch) muteRow.getChildAt(1);
        body.addView(muteRow);
        LinearLayout pinRow = settingSwitchRow(t("pin_chat"), false);
        Switch pinSwitch = (Switch) pinRow.getChildAt(1);
        body.addView(pinRow);
        loadChatSettings(detailChatId, muteSwitch, pinSwitch);
        LinearLayout clear = settingRow("⌫", t("clear_history"), false);
        clear.setOnClickListener(v -> new AlertDialog.Builder(this).setMessage(t("clear_chat_confirm", name)).setNegativeButton(t("cancel"), null).setPositiveButton(t("clear_records"), (d, w) -> {
            if (detailChatId <= 0) { toast(t("conversation_unavailable")); return; }
            JSONObject request = new JSONObject();
            try { request.put("chat_id", detailChatId); } catch (Exception ignored) { return; }
            ApiClient.post(this, "messages.clear", request, new ApiClient.Callback() {
                @Override public void onSuccess(Object data) {
                    chatCache.clear("chat", detailChatId);
                    renderedMessageIds.clear();
                    renderedMessageViews.clear();
                    invalidateChatSnapshot();
                    toast(t("chat_history_cleared"));
                    closeSubPage();
                }
                @Override public void onError(String message) { toast(message); }
            });
        }).show());
        body.addView(clear);
        LinearLayout complaint = settingRow("!", t("complaint"), true);
        complaint.setOnClickListener(v -> openHelpPage());
        body.addView(complaint);
        LinearLayout block = settingRow("⊘", t("block"), false);
        block.setOnClickListener(v -> new AlertDialog.Builder(this).setMessage(t("block_confirm")).setNegativeButton(t("cancel"), null).setPositiveButton(t("block"), (d, w) -> {
            if (detailChatId <= 0) { toast(t("conversation_unavailable")); return; }
            JSONObject request = new JSONObject();
            try { request.put("chat_id", detailChatId); request.put("blocked", 1); } catch (Exception ignored) { return; }
            ApiClient.post(this, "chats.settings", request, new ApiClient.Callback() {
                @Override public void onSuccess(Object data) { toast(t("blocked")); closeSubPage(); }
                @Override public void onError(String message) { toast(message); }
            });
        }).show());
        body.addView(block);
        scroll.addView(body, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        openSubPage(root, activeTab);
    }

    private void loadChatSettings(int chatId, Switch mute, Switch pinned) {
        if (chatId <= 0) return;
        Map<String, String> params = new HashMap<>();
        params.put("chat_id", String.valueOf(chatId));
        ApiClient.get(this, "chats.settings.get", params, new ApiClient.Callback() {
            private void bind() {
                mute.setOnCheckedChangeListener((button, checked) -> saveChatSetting(chatId, "mute", checked));
                pinned.setOnCheckedChangeListener((button, checked) -> {
                    saveChatSetting(chatId, "pinned", checked);
                    invalidateChatSnapshot();
                });
            }
            @Override public void onSuccess(Object data) {
                if (data instanceof JSONObject) {
                    JSONObject settings = (JSONObject) data;
                    mute.setChecked(settings.optInt("mute") == 1);
                    pinned.setChecked(settings.optInt("pinned") == 1);
                }
                bind();
            }
            @Override public void onError(String message) { bind(); }
        });
    }

    private void saveChatSetting(int chatId, String key, boolean value) {
        JSONObject body = new JSONObject();
        try { body.put("chat_id", chatId); body.put(key, value ? 1 : 0); } catch (Exception ignored) { return; }
        ApiClient.post(this, "chats.settings", body, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                JSONArray snapshot = readChatSnapshot();
                for (int i = 0; i < snapshot.length(); i++) {
                    JSONObject item = snapshot.optJSONObject(i);
                    if (item == null || "group".equals(item.optString("kind")) || item.optInt("id") != chatId) continue;
                    try { item.put(key, value ? 1 : 0); } catch (Exception ignored) { }
                }
                storeChatSnapshot(snapshot);
                invalidateChatSnapshot();
            }
            @Override public void onError(String message) { toast(message); }
        });
    }

    private int cachedGroupSetting(int groupId, String key) {
        JSONArray snapshot = readChatSnapshot();
        for (int i = 0; i < snapshot.length(); i++) {
            JSONObject item = snapshot.optJSONObject(i);
            if (item != null && "group".equals(item.optString("kind")) && item.optInt("id") == groupId) return item.optInt(key);
        }
        return 0;
    }

    private void saveGroupSetting(int groupId, String key, boolean value) {
        JSONObject body = new JSONObject();
        try { body.put("group_id", groupId); body.put(key, value ? 1 : 0); } catch (Exception ignored) { return; }
        ApiClient.post(this, "groups.settings", body, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                JSONArray snapshot = readChatSnapshot();
                for (int i = 0; i < snapshot.length(); i++) {
                    JSONObject item = snapshot.optJSONObject(i);
                    if (item == null || !"group".equals(item.optString("kind")) || item.optInt("id") != groupId) continue;
                    try { item.put(key, value ? 1 : 0); } catch (Exception ignored) { }
                }
                storeChatSnapshot(snapshot);
                invalidateChatSnapshot();
            }
            @Override public void onError(String message) { toast(message); }
        });
    }

    private void openMessageSearchPage(int chatId, int groupId, String conversationName) {
        LinearLayout root = subPageRoot(t("search_chat_content"), conversationName);
        EditText query = search(t("search_message_input"));
        root.addView(query);
        ScrollView scroll = new ScrollView(this);
        LinearLayout results = column();
        results.setPadding(dp(16), dp(8), dp(16), dp(20));
        scroll.addView(results);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        int[] generation = {0};
        Handler handler = new Handler(Looper.getMainLooper());
        Runnable[] pending = {null};
        query.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (pending[0] != null) handler.removeCallbacks(pending[0]);
                String keyword = s.toString().trim();
                int requestGeneration = ++generation[0];
                results.removeAllViews();
                if (keyword.isEmpty()) return;
                pending[0] = () -> {
                    Map<String, String> params = new HashMap<>();
                    params.put("q", keyword);
                    if (chatId > 0) params.put("chat_id", String.valueOf(chatId));
                    if (groupId > 0) params.put("group_id", String.valueOf(groupId));
                    ApiClient.get(MainActivity.this, "messages.search", params, new ApiClient.Callback() {
                        @Override public void onSuccess(Object data) {
                            if (requestGeneration != generation[0]) return;
                            if (!(data instanceof JSONArray) || ((JSONArray) data).length() == 0) { results.addView(note(t("no_matching_messages"))); return; }
                            JSONArray matches = (JSONArray) data;
                            for (int i = 0; i < matches.length(); i++) {
                                JSONObject item = matches.optJSONObject(i);
                                if (item == null) continue;
                                LinearLayout row = column();
                                row.setPadding(dp(14), dp(11), dp(14), dp(11));
                                row.setBackground(round(Color.WHITE, 10));
                                row.addView(bodyText(item.optString("conversation_name", conversationName), 13, BLUE));
                                row.addView(bodyText(item.optString("content", ""), 15, TEXT));
                                row.addView(bodyText(shortChatTime(item.optString("created_at", "")), 11, MUTED));
                                row.setOnClickListener(v -> {
                                    int resultChatId = item.optInt("chat_id");
                                    int resultGroupId = item.optInt("group_id");
                                    openChatWindow(resultChatId, resultGroupId, item.optString("conversation_name", conversationName), resultGroupId > 0 ? t("group_avatar") : t("chat_avatar"), resultGroupId > 0 ? "group" : "online", resultGroupId > 0 ? "#5B7CFA" : "#A8C0FF", resultGroupId > 0 ? "#9B5DE5" : "#3F5EFB");
                                });
                                LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
                                p.setMargins(0, 0, 0, dp(8));
                                results.addView(row, p);
                            }
                        }
                        @Override public void onError(String message) { if (requestGeneration == generation[0]) results.addView(note(message)); }
                    });
                };
                handler.postDelayed(pending[0], 280);
            }
            @Override public void afterTextChanged(Editable s) { }
        });
        openSubPage(root, activeTab);
    }

    private void openGroupDetailPage(String name, String avatarText, String c1, String c2) {
        openGroupDetailPage(name, avatarText, c1, c2, true);
    }

    private String groupDetailCacheKey(int groupId) { return "group_detail_" + currentUserId + "_" + groupId; }

    private void cacheGroupDetail(JSONObject group) {
        if (group == null || group.optInt("id") <= 0) return;
        preferences.edit().putString(groupDetailCacheKey(group.optInt("id")), group.toString()).apply();
        JSONArray snapshot = readChatSnapshot();
        boolean found = false;
        for (int i = 0; i < snapshot.length(); i++) {
            JSONObject item = snapshot.optJSONObject(i);
            if (item == null || !"group".equals(item.optString("kind")) || item.optInt("id") != group.optInt("id")) continue;
            try {
                JSONObject merged = new JSONObject(group.toString());
                merged.put("kind", "group");
                merged.put("unread_count", item.optInt("unread_count"));
                merged.put("mute", item.optInt("mute"));
                merged.put("pinned", item.optInt("pinned"));
                snapshot.put(i, merged);
                found = true;
            } catch (Exception ignored) { }
        }
        if (!found) {
            try { JSONObject merged = new JSONObject(group.toString()); merged.put("kind", "group"); snapshot.put(merged); } catch (Exception ignored) { }
        }
        storeChatSnapshot(snapshot);
    }

    private void openGroupDetailPage(String name, String avatarText, String c1, String c2, boolean refresh) {
        chatWindowOpen = false;
        JSONObject groupInfo = null;
        try {
            String cached = preferences.getString(groupDetailCacheKey(activeGroupId), "");
            if (!cached.isEmpty()) groupInfo = new JSONObject(cached);
        } catch (Exception ignored) { }
        JSONArray snapshot = readChatSnapshot();
        for (int i = 0; groupInfo == null && i < snapshot.length(); i++) {
            JSONObject item = snapshot.optJSONObject(i);
            if (item != null && "group".equals(item.optString("kind")) && item.optInt("id") == activeGroupId) { groupInfo = item; break; }
        }
        if (groupInfo != null) preferences.edit().putString(groupDetailCacheKey(activeGroupId), groupInfo.toString()).apply();
        if (groupInfo == null) {
            LinearLayout loading = subPageRoot(t("chat_details"), t("group_info_members"));
            loading.addView(note(t("reading_group_info")), new LinearLayout.LayoutParams(-1, dp(120)));
            openSubPage(loading, activeTab);
            Map<String, String> params = new HashMap<>();
            params.put("group_id", String.valueOf(activeGroupId));
            ApiClient.get(this, "groups.info", params, new ApiClient.Callback() {
                @Override public void onSuccess(Object data) {
                    if (!(data instanceof JSONObject)) { toast(t("group_info_unavailable")); return; }
                    JSONObject group = (JSONObject) data;
                    cacheGroupDetail(group);
                    openGroupDetailPage(group.optString("name", name), avatarText, c1, c2, false);
                }
                @Override public void onError(String message) { toast(t("group_info_failed", message)); }
            });
            return;
        }
        String groupName = groupInfo.optString("name", name);
        String groupCode = normalizeOptionalText(groupInfo.optString("group_code", ""));
        String groupAvatarUrl = groupInfo.optString("avatar_url", "");
        String announcement = groupInfo.optString("announcement", "");
        int memberCount = groupInfo.optInt("member_count");
        boolean isOwner = "owner".equals(groupInfo.optString("role"));
        boolean canManage = isOwner || "admin".equals(groupInfo.optString("role"));
        boolean canViewMembers = isOwner || "admin".equals(groupInfo.optString("role")) || groupInfo.optInt("allow_member_details", 1) == 1;
        activeGroupCanManage = canManage;
        activeGroupCanViewMemberDetails = canViewMembers;
        LinearLayout root = subPageRoot(t("chat_details"), memberCount > 0 ? t("member_count", groupName, memberCount) : groupName);
        ScrollView scroll = new ScrollView(this);
        LinearLayout body = column();
        body.setPadding(0, 0, 0, dp(24));
        activeGroupName = groupName;
        activeDetailGroupId = activeGroupId;
        LinearLayout summary = row();
        summary.setPadding(dp(22), dp(18), dp(22), dp(18));
        summary.setBackgroundColor(Color.WHITE);
        summary.addView(avatarWithRemoteImage(t("group_avatar"), groupAvatarUrl, c1, c2, 60));
        LinearLayout groupInfoText = column();
        groupInfoText.setPadding(dp(14), 0, 0, 0);
        TextView nameView = bodyText(groupName, 19, TEXT);
        nameView.setTypeface(null, android.graphics.Typeface.BOLD);
        groupInfoText.addView(nameView);
        groupInfoText.addView(bodyText(memberCount > 0 ? t("member_count_short", memberCount) : t("group_members"), 13, MUTED));
        summary.addView(groupInfoText);
        body.addView(summary);
        HorizontalScrollView memberScroll = new HorizontalScrollView(this);
        memberScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout members = row();
        members.setPadding(dp(20), dp(16), dp(20), dp(14));
        members.setBackgroundColor(Color.WHITE);
        memberScroll.addView(members, new HorizontalScrollView.LayoutParams(-2, -2));
        body.addView(memberScroll);
        Map<String, String> memberParams = new HashMap<>();
        memberParams.put("group_id", String.valueOf(activeDetailGroupId));
        if (canViewMembers) ApiClient.get(this, "groups.members", memberParams, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                if (!(data instanceof JSONArray)) return;
                JSONArray liveMembers = (JSONArray) data;
                for (int i = 0; i < liveMembers.length(); i++) {
                    JSONObject member = liveMembers.optJSONObject(i);
                    if (member == null) continue;
                    String role = member.optString("role", "member");
                    addGroupMember(members, member.optInt("id"), member.optString("nickname", t("group_member")), member.optString("avatar_url", ""), role, true);
                }
            }
            @Override public void onError(String message) { toast(message); }
        });
        if (!canViewMembers) members.addView(centeredText(t("member_details_disabled"), 13, MUTED), new LinearLayout.LayoutParams(-1, dp(74)));
        addGroupMenu(body, t("share_group"), t("share_group_desc"), this::showGroupShareDialog);
        addGroupMenu(body, t("group_qr"), t("group_qr_desc"), () -> showGroupQrDialog(groupCode, groupName, groupAvatarUrl, memberCount));
        addGroupMenu(body, t("group_id"), groupCode.isEmpty() ? t("group_code_loading") : t("group_code_copy", groupCode), () -> {
            if (groupCode.isEmpty()) toast(t("group_code_unavailable")); else copyText(groupCode, t("group_id"));
        });
        if (canManage) addGroupMenu(body, t("invite_members"), t("choose_from_contacts"), this::showAddGroupMembersDialog);
        addGroupMenu(body, t("search_group_members"), canViewMembers ? t("search_group_members_hint") : t("member_details_disabled"), () -> {
            if (canViewMembers) showGroupMembersDialog(); else toast(t("member_details_disabled"));
        });
        LinearLayout groupFind = settingRow("⌕", t("search_chat_content"), true);
        groupFind.setOnClickListener(v -> openMessageSearchPage(0, activeDetailGroupId, groupName));
        body.addView(groupFind);
        int cachedMute = cachedGroupSetting(activeDetailGroupId, "mute");
        int cachedPinned = cachedGroupSetting(activeDetailGroupId, "pinned");
        LinearLayout groupMuteRow = settingSwitchRow(t("mute_messages"), cachedMute == 1);
        Switch groupMute = (Switch) groupMuteRow.getChildAt(1);
        groupMute.setOnCheckedChangeListener((button, checked) -> saveGroupSetting(activeDetailGroupId, "mute", checked));
        body.addView(groupMuteRow);
        LinearLayout groupPinRow = settingSwitchRow(t("pin_chat"), cachedPinned == 1);
        Switch groupPin = (Switch) groupPinRow.getChildAt(1);
        groupPin.setOnCheckedChangeListener((button, checked) -> {
            saveGroupSetting(activeDetailGroupId, "pinned", checked);
            invalidateChatSnapshot();
        });
        body.addView(groupPinRow);
        if (canManage) addGroupMenu(body, t("group_name"), groupName, () -> editGroupField(t("group_name"), groupName));
        else body.addView(groupTextRow(t("group_name"), groupName, false));
        if (canManage) addGroupMenu(body, t("group_avatar_label"), groupAvatarUrl.isEmpty() ? t("change_group_avatar") : t("set"), () -> chooseGroupAvatar());
        else body.addView(groupTextRow(t("group_avatar_label"), groupAvatarUrl.isEmpty() ? t("not_set") : t("set"), false));
        if (canManage) addGroupMenu(body, t("group_announcement"), announcement.isEmpty() ? t("no_group_announcement") : announcement, () -> editGroupField(t("group_announcement"), announcement));
        else body.addView(groupTextRow(t("group_announcement"), announcement.isEmpty() ? t("no_group_announcement") : announcement, false));
        addGroupMenu(body, t("group_members"), t("view_group_members"), () -> {
            if (activeDetailGroupId <= 0) { showGroupMembersDialog(); return; }
            showGroupMembersDialog();
        });
        if (canManage) addGroupMenu(body, t("group_management"), t("group_management_desc"), () -> showGroupAdminDialog());
        if (canManage) {
            addGroupSwitch(body, t("allow_member_details"), groupInfo.optInt("allow_member_details", 1) == 1, "allow_member_details");
            addGroupSwitch(body, t("allow_private_message"), groupInfo.optInt("allow_private_message", 1) == 1, "allow_private_message");
        }
        if (isOwner) {
            addGroupMenu(body, t("transfer_owner"), t("transfer_owner_desc"), this::showTransferGroupOwnerDialog);
            LinearLayout dissolve = groupTextRow(t("dissolve_group"), t("dissolve_group_desc"), false);
            dissolve.setOnClickListener(v -> new AlertDialog.Builder(this).setMessage(t("dissolve_group_confirm")).setNegativeButton(t("cancel"), null).setPositiveButton(t("confirm_dissolve"), (d, w) -> dissolveActiveGroup()).show());
            body.addView(dissolve);
        }
        LinearLayout leave = groupTextRow(t("leave_group"), "", false);
        leave.setOnClickListener(v -> new AlertDialog.Builder(this).setMessage(t("leave_group_confirm")).setNegativeButton(t("cancel"), null).setPositiveButton(t("leave"), (d, w) -> {
            JSONObject request = new JSONObject();
            try { request.put("group_id", activeDetailGroupId); } catch (Exception ignored) { return; }
            ApiClient.post(this, "groups.leave", request, new ApiClient.Callback() {
                @Override public void onSuccess(Object data) {
                    chatCache.clear("group", activeDetailGroupId);
                    JSONArray snapshot = readChatSnapshot();
                    for (int i = snapshot.length() - 1; i >= 0; i--) {
                        JSONObject item = snapshot.optJSONObject(i);
                        if (item != null && "group".equals(item.optString("kind")) && item.optInt("id") == activeDetailGroupId) snapshot.remove(i);
                    }
                    storeChatSnapshot(snapshot);
                    invalidateChatSnapshot();
                    closeSubPage();
                    toast(t("left_group"));
                }
                @Override public void onError(String message) { toast(message); }
            });
        }).show());
        body.addView(leave);
        scroll.addView(body, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        openSubPage(root, activeTab);
        if (refresh) refreshGroupDetail(name, avatarText, c1, c2, groupInfo);
    }

    private void refreshGroupDetail(String name, String avatarText, String c1, String c2, JSONObject displayed) {
        Map<String, String> params = new HashMap<>();
        int groupId = activeDetailGroupId;
        params.put("group_id", String.valueOf(groupId));
        ApiClient.get(this, "groups.info", params, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                if (!(data instanceof JSONObject) || groupId != activeDetailGroupId) return;
                JSONObject latest = (JSONObject) data;
                String previous = displayed.toString();
                cacheGroupDetail(latest);
                if (!previous.equals(latest.toString())) openGroupDetailPage(latest.optString("name", name), avatarText, c1, c2, false);
            }
            @Override public void onError(String message) { }
        });
    }

    private void addGroupMember(LinearLayout parent, int userId, String name, String avatarUrl, String role, boolean canViewDetails) {
        LinearLayout cell = column();
        cell.setGravity(Gravity.CENTER_HORIZONTAL);
        String initial = name.isEmpty() ? t("group_avatar") : name.substring(0, 1);
        View memberAvatar = avatarWithRemoteImage(initial, avatarUrl, "#A8C0FF", "#3F5EFB", 52);
        if (canViewDetails && userId > 0) memberAvatar.setOnClickListener(v -> showGroupMemberInfo(activeDetailGroupId, userId));
        if (activeGroupId > 0 && userId > 0) memberAvatar.setOnLongClickListener(v -> {
            if (activeMessageInput != null) {
                int position = Math.max(activeMessageInput.getSelectionStart(), 0);
                activeMessageInput.getText().insert(position, "@" + name + " ");
                activeMessageInput.requestFocus();
                toast(t("mentioned_member", name));
            }
            return true;
        });
        cell.addView(memberAvatar);
        String roleLabel = "owner".equals(role) ? t("owner") : ("admin".equals(role) ? t("administrator") : t("member"));
        TextView label = centeredText(name, 11, "owner".equals(role) ? BLUE : MUTED);
        cell.addView(label);
        cell.addView(centeredText(roleLabel, 10, MUTED));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(dp(64), -2);
        params.setMargins(0, 0, dp(8), 0);
        parent.addView(cell, params);
    }

    private void addGroupSwitch(LinearLayout parent, String label, boolean checked, String key) {
        LinearLayout row = settingSwitchRow(label, checked);
        Switch toggle = (Switch) row.getChildAt(1);
        toggle.setOnCheckedChangeListener((button, value) -> {
            JSONObject request = new JSONObject();
            try { request.put("group_id", activeDetailGroupId); request.put(key, value ? 1 : 0); } catch (Exception ignored) { return; }
            ApiClient.post(this, "groups.settings", request, new ApiClient.Callback() {
                @Override public void onSuccess(Object data) {
                    try {
                        JSONObject cached = new JSONObject(preferences.getString(groupDetailCacheKey(activeDetailGroupId), "{}"));
                        cached.put(key, value ? 1 : 0);
                        cacheGroupDetail(cached);
                    } catch (Exception ignored) { }
                    toast(t("group_privacy_saved"));
                }
                @Override public void onError(String message) {
                    toggle.setOnCheckedChangeListener(null);
                    toggle.setChecked(!value);
                    toggle.setOnCheckedChangeListener((buttonView, checkedNow) -> saveGroupPrivacy(key, checkedNow));
                    toast(message);
                }
            });
        });
        parent.addView(row);
    }

    private void saveGroupPrivacy(String key, boolean value) {
        JSONObject request = new JSONObject();
        try { request.put("group_id", activeDetailGroupId); request.put(key, value ? 1 : 0); } catch (Exception ignored) { return; }
        ApiClient.post(this, "groups.settings", request, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) { toast(t("group_privacy_saved")); }
            @Override public void onError(String message) { toast(message); }
        });
    }

    private void showGroupQrDialog(String groupCode, String groupName, String avatarUrl, int memberCount) {
        if (!normalizeOptionalText(groupCode).matches("[A-Z0-9]{6}")) { toast(t("group_code_retry")); return; }
        LinearLayout box = column();
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(dp(20), dp(20), dp(20), dp(20));
        LinearLayout groupHeader = row();
        groupHeader.setGravity(Gravity.CENTER_VERTICAL);
        groupHeader.addView(avatarWithRemoteImage(t("group_avatar"), avatarUrl, "#5B7CFA", "#9B5DE5", 54));
        LinearLayout groupTitle = column();
        groupTitle.setPadding(dp(12), 0, 0, 0);
        TextView title = bodyText(groupName, 17, TEXT);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        groupTitle.addView(title);
        groupTitle.addView(bodyText(t("group_code_member_count", memberCount, groupCode), 12, MUTED));
        groupHeader.addView(groupTitle, new LinearLayout.LayoutParams(0, -2, 1));
        box.addView(groupHeader, new LinearLayout.LayoutParams(-1, dp(62)));
        ImageView qr = new ImageView(this);
        qr.setPadding(dp(10), dp(10), dp(10), dp(10));
        qr.setBackgroundColor(Color.WHITE);
        try {
            BitMatrix matrix = new MultiFormatWriter().encode("SPXGROUP:" + groupCode, BarcodeFormat.QR_CODE, dp(230), dp(230));
            Bitmap bitmap = Bitmap.createBitmap(matrix.getWidth(), matrix.getHeight(), Bitmap.Config.ARGB_8888);
            for (int x = 0; x < matrix.getWidth(); x++) for (int y = 0; y < matrix.getHeight(); y++) bitmap.setPixel(x, y, matrix.get(x, y) ? Color.BLACK : Color.WHITE);
            qr.setImageBitmap(bitmap);
        } catch (Exception exception) { toast(t("group_qr_failed")); return; }
        box.addView(qr, new LinearLayout.LayoutParams(dp(250), dp(250)));
        box.addView(centeredText(t("group_code_people", groupCode, memberCount), 14, MUTED));
        box.addView(centeredText(t("scan_view_join_group"), 13, MUTED));
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(box);
        dialog.setCanceledOnTouchOutside(true);
        dialog.show();
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(round(Color.WHITE, 20));
            dialog.getWindow().setLayout(dp(310), WindowManager.LayoutParams.WRAP_CONTENT);
        }
    }

    private void showFindGroupDialog() {
        EditText input = formInput(t("group_code_input"), "");
        input.setSingleLine(true);
        input.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(6)});
        new AlertDialog.Builder(this).setTitle(t("join_group")).setMessage(t("group_code_search_hint")).setView(input).setNegativeButton(t("cancel"), null).setPositiveButton(t("search"), (dialog, which) -> {
            String value = input.getText().toString().trim().toUpperCase(java.util.Locale.ROOT);
            if (!value.matches("[A-Z0-9]{6}")) { toast(t("group_code_format_invalid")); return; }
            joinGroupByCode(value);
        }).show();
    }

    private void joinGroupByCode(String value) {
        String groupCode = normalizeOptionalText(value).toUpperCase(java.util.Locale.ROOT);
        if (!groupCode.matches("[A-Z0-9]{6}")) { toast(t("group_code_invalid")); return; }
        Map<String, String> params = new HashMap<>();
        params.put("group_code", groupCode);
        ApiClient.get(this, "groups.search", params, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                if (!(data instanceof JSONObject)) { toast(t("group_not_found")); return; }
                JSONObject group = (JSONObject) data;
                int groupId = group.optInt("id");
                String name = group.optString("name", t("group_chat"));
                String avatarUrl = group.optString("avatar_url", "");
                int memberCount = group.optInt("member_count");
                LinearLayout preview = row();
                preview.setPadding(dp(16), dp(12), dp(16), dp(12));
                preview.addView(avatarWithRemoteImage(t("group_avatar"), avatarUrl, "#5B7CFA", "#9B5DE5", 56));
                LinearLayout previewText = column();
                previewText.setPadding(dp(12), 0, 0, 0);
                TextView previewName = bodyText(name, 17, TEXT);
                previewName.setTypeface(null, android.graphics.Typeface.BOLD);
                previewText.addView(previewName);
                previewText.addView(bodyText(t("group_code_member_count", memberCount, groupCode), 13, MUTED));
                preview.addView(previewText, new LinearLayout.LayoutParams(0, -2, 1));
                new AlertDialog.Builder(MainActivity.this).setTitle(t("group_preview")).setView(preview)
                        .setNegativeButton(t("cancel"), null).setPositiveButton(t("join_group_chat"), (d, w) -> {
                            JSONObject body = new JSONObject();
                            try { body.put("group_code", groupCode); } catch (Exception ignored) { return; }
                            ApiClient.post(MainActivity.this, "groups.join", body, new ApiClient.Callback() {
                                @Override public void onSuccess(Object result) {
                                    int joinedGroupId = result instanceof JSONObject ? ((JSONObject) result).optInt("group_id", groupId) : groupId;
                                    toast(t("joined_group"));
                                    Map<String, String> infoParams = new HashMap<>();
                                    infoParams.put("group_id", String.valueOf(joinedGroupId));
                                    ApiClient.get(MainActivity.this, "groups.info", infoParams, new ApiClient.Callback() {
                                        @Override public void onSuccess(Object detail) {
                                            if (detail instanceof JSONObject) cacheGroupDetail((JSONObject) detail);
                                            invalidateChatSnapshot();
                                            openChatWindow(0, joinedGroupId, name, t("group_avatar"), "group", "#5B7CFA", "#9B5DE5");
                                        }
                                        @Override public void onError(String error) { openChatWindow(0, joinedGroupId, name, t("group_avatar"), "group", "#5B7CFA", "#9B5DE5"); }
                                    });
                                }
                                @Override public void onError(String error) { toast(error); }
                            });
                        }).show();
            }
            @Override public void onError(String message) { toast(t("group_search_failed", message)); }
        });
    }

    private interface FriendPickerCallback { void onSelected(JSONArray contacts); }

    private void showFriendPicker(String title, String actionLabel, JSONArray contacts, FriendPickerCallback callback) {
        if (contacts == null || contacts.length() == 0) { toast(t("no_friends_add_first")); return; }
        LinearLayout panel = column();
        panel.setPadding(dp(4), dp(4), dp(4), dp(2));
        EditText filter = search(t("search_friend_hint"));
        panel.addView(filter);
        LinearLayout rows = column();
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        scroll.addView(rows, new ScrollView.LayoutParams(-1, -2));
        panel.addView(scroll, new LinearLayout.LayoutParams(-1, dp(360)));
        Set<Integer> selected = new HashSet<>();
        Runnable[] render = new Runnable[1];
        render[0] = () -> {
            rows.removeAllViews();
            String keyword = filter.getText().toString().trim().toLowerCase(java.util.Locale.ROOT);
            int shown = 0;
            for (int i = 0; i < contacts.length(); i++) {
                JSONObject contact = contacts.optJSONObject(i);
                if (contact == null) continue;
                int id = contact.optInt("id");
                String nickname = normalizeOptionalText(contact.optString("nickname", ""));
                String remark = normalizeOptionalText(contact.optString("remark", ""));
                String displayName = remark.isEmpty() ? nickname : remark;
                if (displayName.isEmpty()) displayName = t("friend");
                String spxId = contact.optString("spx_id", "");
                String searchable = (displayName + " " + nickname + " " + spxId + " " + id).toLowerCase(java.util.Locale.ROOT);
                if (!keyword.isEmpty() && !searchable.contains(keyword)) continue;
                boolean checked = selected.contains(id);
                LinearLayout item = row();
                item.setGravity(Gravity.CENTER_VERTICAL);
                item.setPadding(dp(10), dp(9), dp(10), dp(9));
                item.setBackground(round(checked ? Color.rgb(238, 243, 255) : Color.WHITE, 9));
                item.addView(avatarWithRemoteImage(displayName.substring(0, 1), contact.optString("avatar_url", ""), "#A8C0FF", "#3F5EFB", 44));
                LinearLayout text = column();
                text.setPadding(dp(11), 0, dp(8), 0);
                TextView name = bodyText(displayName, 15, TEXT);
                name.setTypeface(null, android.graphics.Typeface.BOLD);
                text.addView(name);
                text.addView(bodyText("SPX ID " + spxId, 12, MUTED));
                item.addView(text, new LinearLayout.LayoutParams(0, -2, 1));
                TextView mark = centeredText(checked ? t("checked") : t("unchecked"), 19, checked ? BLUE : MUTED);
                item.addView(mark, new LinearLayout.LayoutParams(dp(32), dp(44)));
                item.setOnClickListener(v -> {
                    if (selected.contains(id)) selected.remove(id); else selected.add(id);
                    render[0].run();
                });
                rows.addView(item);
                rows.addView(separator());
                shown++;
            }
            if (shown == 0) rows.addView(note(keyword.isEmpty() ? t("no_friends") : t("no_matching_friends")));
        };
        filter.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { render[0].run(); }
            @Override public void afterTextChanged(Editable s) { }
        });
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle(title).setView(panel).setNegativeButton(t("cancel"), null)
                .setPositiveButton(actionLabel, (d, w) -> {
                    JSONArray chosen = new JSONArray();
                    for (int i = 0; i < contacts.length(); i++) {
                        JSONObject contact = contacts.optJSONObject(i);
                        if (contact != null && selected.contains(contact.optInt("id"))) chosen.put(contact);
                    }
                    if (chosen.length() == 0) { toast(t("select_friend_first")); return; }
                    callback.onSelected(chosen);
                }).create();
        render[0].run();
        dialog.show();
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(BLUE);
    }

    private void showGroupShareDialog() {
        int groupId = activeDetailGroupId;
        JSONObject group = null;
        try { group = new JSONObject(preferences.getString(groupDetailCacheKey(groupId), "")); } catch (Exception ignored) { }
        if (group == null || normalizeOptionalText(group.optString("group_code", "")).isEmpty()) {
            toast(t("group_info_loading_retry"));
            return;
        }
        JSONObject groupInfo = group;
        ApiClient.get(this, "contacts", null, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                if (!(data instanceof JSONArray)) { toast(t("load_friends_failed")); return; }
                showFriendPicker(t("share_group_to_friends"), t("send_group_card"), (JSONArray) data,
                        selected -> shareGroupToContacts(groupId, groupInfo, selected, 0, new int[]{0}, new int[]{0}, new String[]{""}));
            }
            @Override public void onError(String message) { toast(t("load_friends_failed_detail", message)); }
        });
    }

    private void shareGroupToContacts(int groupId, JSONObject group, JSONArray targets, int index, int[] lastChatId, int[] lastPeerId, String[] lastName) {
        if (index >= targets.length()) {
            invalidateChatSnapshot();
            if (lastChatId[0] > 0) {
                closeSubPage();
                openChatWindow(lastChatId[0], 0, lastName[0], lastName[0].isEmpty() ? t("friend_avatar") : lastName[0].substring(0, 1), "online", "#A8C0FF", "#3F5EFB", lastPeerId[0]);
            }
            toast(t("group_card_sent"));
            return;
        }
        JSONObject contact = targets.optJSONObject(index);
        if (contact == null) { shareGroupToContacts(groupId, group, targets, index + 1, lastChatId, lastPeerId, lastName); return; }
        int peerId = contact.optInt("id");
        JSONObject create = new JSONObject();
        try { create.put("peer_user_id", peerId); } catch (Exception ignored) { return; }
        ApiClient.post(this, "chats.create", create, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                int chatId = data instanceof JSONObject ? ((JSONObject) data).optInt("chat_id") : 0;
                if (chatId <= 0) { shareGroupToContacts(groupId, group, targets, index + 1, lastChatId, lastPeerId, lastName); return; }
                String groupCode = group.optString("group_code", "");
                JSONObject card = new JSONObject();
                try {
                    card.put("group_code", groupCode);
                    card.put("name", group.optString("name", t("group_chat")));
                    card.put("avatar_url", group.optString("avatar_url", ""));
                    card.put("member_count", group.optInt("member_count"));
                } catch (Exception ignored) { return; }
                String content = "SPXGROUP:" + groupCode + "\n" + card;
                String clientId = UUID.randomUUID().toString();
                JSONObject request = new JSONObject();
                try {
                    request.put("chat_id", chatId);
                    request.put("content", content);
                    request.put("message_type", "text");
                    request.put("client_message_id", clientId);
                } catch (Exception ignored) { return; }
                ApiClient.post(MainActivity.this, "messages.send", request, new ApiClient.Callback() {
                    @Override public void onSuccess(Object result) {
                        JSONObject local = new JSONObject();
                        try {
                            local.put("id", result instanceof JSONObject ? ((JSONObject) result).optInt("id") : 0);
                            local.put("chat_id", chatId);
                            local.put("sender_id", currentUserId);
                            local.put("nickname", userName);
                            local.put("avatar_url", remoteAvatarUrl);
                            local.put("content", content);
                            local.put("message_type", "text");
                            local.put("client_message_id", clientId);
                            chatCache.put("chat", chatId, local);
                            cacheSharedGroupConversation(chatId, contact, local);
                        } catch (Exception ignored) { }
                        lastChatId[0] = chatId;
                        lastPeerId[0] = peerId;
                        lastName[0] = normalizeOptionalText(contact.optString("remark", contact.optString("nickname", t("friend"))));
                        if (lastName[0].isEmpty()) lastName[0] = t("friend");
                        shareGroupToContacts(groupId, group, targets, index + 1, lastChatId, lastPeerId, lastName);
                    }
                    @Override public void onError(String error) {
                        toast(t("send_group_card_failed", contact.optString("nickname", t("friend")), error));
                        shareGroupToContacts(groupId, group, targets, index + 1, lastChatId, lastPeerId, lastName);
                    }
                });
            }
            @Override public void onError(String error) {
                toast(t("private_chat_missing", contact.optString("nickname", t("friend"))));
                shareGroupToContacts(groupId, group, targets, index + 1, lastChatId, lastPeerId, lastName);
            }
        });
    }

    private void cacheSharedGroupConversation(int chatId, JSONObject contact, JSONObject message) {
        JSONArray snapshot = readChatSnapshot();
        JSONObject chat = null;
        for (int i = 0; i < snapshot.length(); i++) {
            JSONObject item = snapshot.optJSONObject(i);
            if (item != null && !"group".equals(item.optString("kind")) && item.optInt("id") == chatId) { chat = item; break; }
        }
        if (chat == null) {
            chat = new JSONObject();
            snapshot.put(chat);
        }
        String nickname = normalizeOptionalText(contact.optString("nickname", t("friend")));
        String remark = normalizeOptionalText(contact.optString("remark", ""));
        try {
            chat.put("kind", "chat");
            chat.put("id", chatId);
            chat.put("peer_user_id", contact.optInt("id"));
            chat.put("nickname", nickname);
            chat.put("display_name", remark.isEmpty() ? nickname : remark);
            chat.put("avatar_url", contact.optString("avatar_url", ""));
            chat.put("last_message", t("group_invitation_message"));
            chat.put("updated_at", new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).format(new java.util.Date()));
            chat.put("unread_count", chat.optInt("unread_count", 0));
        } catch (Exception ignored) { }
        storeChatSnapshot(snapshot);
        invalidateChatSnapshot();
    }

    private void showTransferGroupOwnerDialog() {
        Map<String, String> params = new HashMap<>();
        params.put("group_id", String.valueOf(activeDetailGroupId));
        ApiClient.get(this, "groups.members", params, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                if (!(data instanceof JSONArray)) { toast(t("load_members_failed")); return; }
                JSONArray members = (JSONArray) data;
                ArrayList<JSONObject> candidates = new ArrayList<>();
                ArrayList<String> labels = new ArrayList<>();
                for (int i = 0; i < members.length(); i++) {
                    JSONObject member = members.optJSONObject(i);
                    if (member == null || member.optInt("id") == currentUserId) continue;
                    candidates.add(member);
                    labels.add(member.optString("nickname", t("group_member")));
                }
                if (candidates.isEmpty()) { toast(t("no_transfer_candidates")); return; }
                new AlertDialog.Builder(MainActivity.this).setTitle(t("transfer_owner")).setItems(labels.toArray(new String[0]), (dialog, which) -> {
                    JSONObject target = candidates.get(which);
                    new AlertDialog.Builder(MainActivity.this).setMessage(t("transfer_owner_confirm", target.optString("nickname")))
                            .setNegativeButton(t("cancel"), null).setPositiveButton(t("confirm_transfer"), (d, w) -> {
                                JSONObject request = new JSONObject();
                                try { request.put("group_id", activeDetailGroupId); request.put("owner_user_id", target.optInt("id")); } catch (Exception ignored) { return; }
                                ApiClient.post(MainActivity.this, "groups.transfer", request, new ApiClient.Callback() {
                                    @Override public void onSuccess(Object result) { clearGroupDetailCache(activeDetailGroupId); toast(t("owner_transferred")); openGroupDetailPage(activeGroupName, t("group_avatar"), "#5B7CFA", "#9B5DE5", true); }
                                    @Override public void onError(String error) { toast(error); }
                                });
                            }).show();
                }).show();
            }
            @Override public void onError(String message) { toast(message); }
        });
    }

    private void dissolveActiveGroup() {
        int groupId = activeDetailGroupId;
        JSONObject request = new JSONObject();
        try { request.put("group_id", groupId); } catch (Exception ignored) { return; }
        ApiClient.post(this, "groups.dissolve", request, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                chatCache.clear("group", groupId);
                clearGroupDetailCache(groupId);
                JSONArray snapshot = readChatSnapshot();
                for (int i = snapshot.length() - 1; i >= 0; i--) {
                    JSONObject item = snapshot.optJSONObject(i);
                    if (item != null && "group".equals(item.optString("kind")) && item.optInt("id") == groupId) snapshot.remove(i);
                }
                storeChatSnapshot(snapshot);
                invalidateChatSnapshot();
                toast(t("group_dissolved"));
                closeSubPage();
            }
            @Override public void onError(String message) { toast(message); }
        });
    }

    private void clearGroupDetailCache(int groupId) {
        preferences.edit().remove(groupDetailCacheKey(groupId)).apply();
    }

    private void showGroupAnnouncementOnEntry(int groupId) {
        Map<String, String> params = new HashMap<>();
        params.put("group_id", String.valueOf(groupId));
        ApiClient.get(this, "groups.info", params, new ApiClient.Callback() {
            @Override public void onSuccess(Object data) {
                if (!(data instanceof JSONObject) || !chatWindowOpen || activeGroupId != groupId) return;
                JSONObject group = (JSONObject) data;
                cacheGroupDetail(group);
                String announcement = normalizeOptionalText(group.optString("announcement", ""));
                int version = group.optInt("announcement_version");
                if (announcement.isEmpty() || version <= 0) return;
                String key = "group_announcement_seen_" + currentUserId + "_" + groupId;
                if (preferences.getInt(key, 0) >= version) return;
                new AlertDialog.Builder(MainActivity.this).setTitle(group.optString("name", t("group_announcement")))
                        .setMessage(announcement).setCancelable(false).setPositiveButton(t("know"), (dialog, which) -> preferences.edit().putInt(key, version).apply()).show();
            }
            @Override public void onError(String message) { }
        });
    }

    private void showGroupMemberInfo(int groupId, int userId) {
        if (groupId <= 0 || userId <= 0) return;
        Map<String, String> groupParams = new HashMap<>();
        groupParams.put("group_id", String.valueOf(groupId));
        ApiClient.get(this, "groups.info", groupParams, new ApiClient.Callback() {
            @Override public void onSuccess(Object groupData) {
                if (!(groupData instanceof JSONObject)) { toast(t("member_profile_unavailable")); return; }
                JSONObject group = (JSONObject) groupData;
                cacheGroupDetail(group);
                JSONObject permissions = group.optJSONObject("permissions");
                if (permissions == null || !permissions.optBoolean("view_members", false)) { toast(t("member_details_disabled")); return; }
                Map<String, String> memberParams = new HashMap<>();
                memberParams.put("group_id", String.valueOf(groupId));
                memberParams.put("q", String.valueOf(userId));
                ApiClient.get(MainActivity.this, "groups.members", memberParams, new ApiClient.Callback() {
                    @Override public void onSuccess(Object data) {
                        if (!(data instanceof JSONArray)) { toast(t("member_profile_unavailable")); return; }
                        JSONArray members = (JSONArray) data;
                        for (int i = 0; i < members.length(); i++) {
                            JSONObject member = members.optJSONObject(i);
                            if (member == null || member.optInt("id") != userId) continue;
                            try {
                                member.put("allow_private_message", group.optInt("allow_private_message", 1));
                                renderContactDetail(member);
                            } catch (Exception ignored) { toast(t("member_profile_unavailable")); }
                            return;
                        }
                        toast(t("member_left_group"));
                    }
                    @Override public void onError(String message) { toast(message); }
                });
            }
            @Override public void onError(String message) { toast(t("group_permissions_failed", message)); }
        });
    }


    private void addGroupMenu(LinearLayout parent, String title, String value, Runnable action) {
        LinearLayout item = groupTextRow(title, value, true);
        item.setOnClickListener(v -> action.run());
        parent.addView(item);
    }

    private LinearLayout groupTextRow(String title, String value, boolean arrow) {
        LinearLayout item = row();
        item.setPadding(dp(42), dp(14), dp(22), dp(14));
        item.setBackgroundColor(Color.WHITE);
        LinearLayout text = column();
        text.addView(bodyText(title, 17, TEXT));
        if (!value.isEmpty()) text.addView(bodyText(value, 15, MUTED));
        item.addView(text, new LinearLayout.LayoutParams(0, -2, 1));
        if (arrow) item.addView(bodyText(t("arrow"), 26, Color.rgb(176, 176, 176)), new LinearLayout.LayoutParams(dp(28), dp(42)));
        return item;
    }

    private void editGroupField(String title, String value) {
        EditText input = new EditText(this);
        input.setText(value);
        new AlertDialog.Builder(this).setTitle(title).setView(input).setNegativeButton(t("cancel"), null).setPositiveButton(t("save"), (d, w) -> {
            String result = input.getText().toString().trim();
            if (result.isEmpty() && title.equals(t("group_name"))) { toast(t("group_name_required")); return; }
            JSONObject request = new JSONObject();
            try {
                request.put("group_id", activeDetailGroupId);
                request.put(title.equals(t("group_name")) ? "name" : "announcement", result);
            } catch (Exception ignored) { return; }
            ApiClient.post(this, "groups.update", request, new ApiClient.Callback() {
                @Override public void onSuccess(Object data) {
                    String oldName = activeGroupName;
                    if (title.equals(t("group_name"))) {
                        activeGroupName = result;
                        preferences.edit().putString("group_name_" + oldName, result).apply();
                    } else preferences.edit().putString("group_notice_" + activeGroupName, result).apply();
                    JSONArray snapshot = readChatSnapshot();
                    for (int i = 0; i < snapshot.length(); i++) {
                        JSONObject item = snapshot.optJSONObject(i);
                        if (item == null || !"group".equals(item.optString("kind")) || item.optInt("id") != activeDetailGroupId) continue;
                        try { item.put(title.equals(t("group_name")) ? "name" : "announcement", result); } catch (Exception ignored) { }
                    }
                    storeChatSnapshot(snapshot);
                    toast(t("field_saved", title));
                    invalidateChatSnapshot();
                    openGroupDetailPage(activeGroupName, t("group_avatar"), "#5B7CFA", "#9B5DE5");
                }
                @Override public void onError(String message) { toast(message); }
            });
        }).show();
    }

    private void showGroupMembersDialog() {
        if (activeDetailGroupId <= 0) return;
        if (!activeGroupCanViewMemberDetails) { toast(t("member_details_disabled")); return; }
        LinearLayout box = column();
        box.setPadding(dp(16), dp(12), dp(16), dp(10));
        EditText query = search(t("search_member_hint"));
        box.addView(query);
        LinearLayout results = column();
        ScrollView scroll = new ScrollView(this);
        scroll.addView(results, new ScrollView.LayoutParams(-1, -2));
        box.addView(scroll, new LinearLayout.LayoutParams(-1, dp(390)));
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle(t("group_members")).setView(box).setNegativeButton(t("close"), null).create();
        int[] generation = {0};
        Runnable[] pending = {null};
        Handler handler = new Handler(Looper.getMainLooper());
        Runnable load = () -> {
            int requestId = ++generation[0];
            Map<String, String> params = new HashMap<>();
            params.put("group_id", String.valueOf(activeDetailGroupId));
            String keyword = query.getText().toString().trim();
            if (!keyword.isEmpty()) params.put("q", keyword);
            ApiClient.get(MainActivity.this, "groups.members", params, new ApiClient.Callback() {
                @Override public void onSuccess(Object data) {
                    if (requestId != generation[0] || !(data instanceof JSONArray)) return;
                    JSONArray members = (JSONArray) data;
                    results.removeAllViews();
                    if (members.length() == 0) { results.addView(note(t("no_matching_members"))); return; }
                    for (int i = 0; i < members.length(); i++) {
                        JSONObject member = members.optJSONObject(i);
                        if (member == null) continue;
                        LinearLayout row = row();
                        row.setPadding(dp(10), dp(10), dp(10), dp(10));
                        row.addView(avatarWithRemoteImage(member.optString("nickname", t("group_avatar")).substring(0, 1), member.optString("avatar_url", ""), "#A8C0FF", "#3F5EFB", 42));
                        LinearLayout text = column();
                        text.setPadding(dp(12), 0, 0, 0);
                        text.addView(bodyText(member.optString("nickname", t("group_member")), 15, TEXT));
                        text.addView(bodyText(t("member_spx_role", member.optString("spx_id", ""), member.optString("role", "member")), 12, MUTED));
                        row.addView(text, new LinearLayout.LayoutParams(0, -2, 1));
                        row.addView(bodyText(activeGroupCanManage ? t("manage") : t("details"), 13, BLUE));
                        row.setOnClickListener(v -> {
                            if (activeGroupCanManage) showGroupMemberActions(activeDetailGroupId, member);
                            else showContactDetail(member.optInt("id"), member.optString("nickname", t("group_member")), member.optString("spx_id", ""), member.optString("avatar_url", ""), false);
                        });
                        results.addView(row);
                        results.addView(separator());
                    }
                }
                @Override public void onError(String message) { if (requestId == generation[0]) { results.removeAllViews(); results.addView(note(message)); } }
            });
        };
        query.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (pending[0] != null) handler.removeCallbacks(pending[0]);
                pending[0] = load;
                handler.postDelayed(pending[0], 250);
            }
            @Override public void afterTextChanged(Editable s) { }
        });
        dialog.show();
        load.run();
    }

    private void showGroupMemberActions(int groupId, JSONObject member) {
        String role = member.optString("role", "member");
        int userId = member.optInt("id");
        String name = member.optString("nickname", t("group_member"));
        boolean muted = member.optInt("mute") == 1;
        if ("owner".equals(role)) { toast(t("owner_permission_locked")); return; }
        if (!activeGroupCanManage) { toast(t("no_member_manage_permission")); return; }
        if (!isCurrentGroupOwner() && "admin".equals(role)) { toast(t("admin_cannot_manage_admin")); return; }
        ArrayList<String> actionLabels = new ArrayList<>();
        if (isCurrentGroupOwner() && !"owner".equals(role)) actionLabels.add("admin".equals(role) ? t("remove_admin") : t("make_admin"));
        actionLabels.add(muted ? t("unmute") : t("mute"));
        actionLabels.add(t("remove_from_group"));
        String[] actions = actionLabels.toArray(new String[0]);
        new AlertDialog.Builder(this).setTitle(name).setItems(actions, (dialog, which) -> {
            String selected = actions[which];
            String action = selected.equals(t("remove_admin")) || selected.equals(t("make_admin")) ? "groups.members.role" : (selected.equals(t("unmute")) || selected.equals(t("mute")) ? "groups.members.mute" : "groups.members.remove");
            JSONObject request = new JSONObject();
            try {
                request.put("group_id", groupId);
                request.put("user_id", userId);
                if (action.equals("groups.members.role")) request.put("role", "admin".equals(role) ? "member" : "admin");
                if (action.equals("groups.members.mute")) request.put("mute", muted ? 0 : 1);
            } catch (Exception ignored) { return; }
            Runnable send = () -> ApiClient.post(this, action, request, new ApiClient.Callback() {
                @Override public void onSuccess(Object data) { toast(t("member_settings_updated")); showGroupMembersDialog(); }
                @Override public void onError(String message) { toast(message); }
            });
            if (action.equals("groups.members.remove")) new AlertDialog.Builder(this).setMessage(t("remove_member_confirm", name)).setNegativeButton(t("cancel"), null).setPositiveButton(t("remove"), (d, w) -> send.run()).show();
            else send.run();
        }).show();
    }

    private boolean isCurrentGroupOwner() {
        try { return "owner".equals(new JSONObject(preferences.getString(groupDetailCacheKey(activeDetailGroupId), "{}")).optString("role")); }
        catch (Exception ignored) { return false; }
    }

    private void showGroupAdminDialog() { showGroupMembersDialog(); }

    private void showAddGroupMembersDialog() {
        if (activeDetailGroupId <= 0) return;
        Map<String, String> memberParams = new HashMap<>();
        memberParams.put("group_id", String.valueOf(activeDetailGroupId));
        ApiClient.get(this, "groups.members", memberParams, new ApiClient.Callback() {
            @Override public void onSuccess(Object memberData) {
                if (!(memberData instanceof JSONArray)) { toast(t("load_members_failed")); return; }
                HashSet<Integer> memberIds = new HashSet<>();
                JSONArray members = (JSONArray) memberData;
                for (int i = 0; i < members.length(); i++) {
                    JSONObject member = members.optJSONObject(i);
                    if (member != null) memberIds.add(member.optInt("id"));
                }
                ApiClient.get(MainActivity.this, "contacts", null, new ApiClient.Callback() {
                    @Override public void onSuccess(Object data) {
                        if (!(data instanceof JSONArray)) { toast(t("load_friends_failed")); return; }
                        JSONArray contacts = new JSONArray();
                        JSONArray allContacts = (JSONArray) data;
                        for (int i = 0; i < allContacts.length(); i++) {
                            JSONObject contact = allContacts.optJSONObject(i);
                            if (contact != null && !memberIds.contains(contact.optInt("id"))) contacts.put(contact);
                        }
                        if (contacts.length() == 0) { toast(t("no_new_friends_to_invite")); return; }
                        showFriendPicker(t("invite_friends_to_group"), t("invite_to_group"), contacts, selected -> {
                            JSONArray userIds = new JSONArray();
                            for (int i = 0; i < selected.length(); i++) {
                                JSONObject contact = selected.optJSONObject(i);
                                if (contact != null) userIds.put(contact.optInt("id"));
                            }
                            JSONObject request = new JSONObject();
                            try { request.put("group_id", activeDetailGroupId); request.put("user_ids", userIds); } catch (Exception ignored) { return; }
                            ApiClient.post(MainActivity.this, "groups.members.add", request, new ApiClient.Callback() {
                                @Override public void onSuccess(Object result) { invalidateChatSnapshot(); toast(t("friends_invited_note")); showGroupMembersDialog(); }
                                @Override public void onError(String message) { toast(message); }
                            });
                        });
                    }
                    @Override public void onError(String message) { toast(t("load_friends_failed_detail", message)); }
                });
            }
            @Override public void onError(String message) { toast(t("load_members_failed_detail", message)); }
        });
    }

    private void chooseGroupAvatar() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("image/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(intent, 1003);
    }

    private LinearLayout settingRow(String icon, String label, boolean arrow) {
        LinearLayout row = row();
        row.setPadding(dp(28), dp(14), dp(22), dp(14));
        row.setBackgroundColor(Color.WHITE);
        TextView iconView = centeredText(icon, 18, TEXT);
        row.addView(iconView, new LinearLayout.LayoutParams(dp(30), dp(42)));
        TextView labelView = bodyText(label, 17, TEXT);
        row.addView(labelView, new LinearLayout.LayoutParams(0, dp(42), 1));
        if (arrow) row.addView(bodyText("›", 26, Color.rgb(176, 176, 176)), new LinearLayout.LayoutParams(dp(28), dp(42)));
        return row;
    }

    private LinearLayout settingSwitchRow(String label, boolean checked) {
        LinearLayout row = row();
        row.setPadding(dp(28), dp(13), dp(22), dp(13));
        row.setBackgroundColor(Color.WHITE);
        row.addView(bodyText(label, 17, TEXT), new LinearLayout.LayoutParams(0, dp(52), 1));
        Switch toggle = new Switch(this);
        toggle.setChecked(checked);
        row.addView(toggle, new LinearLayout.LayoutParams(dp(58), dp(52)));
        return row;
    }

    private void showChatBackgroundDialog() {
        String[] options = {t("chat_background_telegram_gray"), t("chat_background_telegram_light"), t("chat_background_telegram_warm"), t("choose_gallery"), t("restore_default")};
        new AlertDialog.Builder(this).setTitle(t("chat_background_settings")).setItems(options, (dialog, which) -> {
            if (which == 3) {
                chooseChatBackground();
            } else if (which == 4) {
                chatBackgroundUri = null;
                chatBackgroundPreset = 0;
                preferences.edit().remove("chat_background_uri").putInt("chat_background_preset", 0).apply();
                toast(t("restored_default_background"));
            } else {
                chatBackgroundUri = null;
                chatBackgroundPreset = which + 1;
                preferences.edit().remove("chat_background_uri").putInt("chat_background_preset", chatBackgroundPreset).apply();
                toast(t("background_updated"));
            }
        }).show();
    }

    private void addDialogAction(LinearLayout box, String icon, String title, String desc, Runnable action) {
        LinearLayout row = row();
        row.setPadding(dp(14), dp(10), dp(14), dp(10));
        row.setBackground(round(BG, 14));
        TextView iconView = centeredText(icon, 20, BLUE);
        iconView.setBackground(round(Color.rgb(238, 242, 255), 12));
        row.addView(iconView, new LinearLayout.LayoutParams(dp(42), dp(42)));
        LinearLayout text = column();
        text.setPadding(dp(14), 0, 0, 0);
        TextView titleView = bodyText(title, 16, TEXT);
        titleView.setTypeface(null, android.graphics.Typeface.BOLD);
        text.addView(titleView);
        text.addView(bodyText(desc, 13, MUTED));
        row.addView(text, new LinearLayout.LayoutParams(0, -2, 1));
        row.setOnClickListener(v -> { action.run(); ((Dialog) box.getTag()).dismiss(); });
        box.addView(row, new LinearLayout.LayoutParams(-1, dp(64)));
    }

    private void showBottomDialog(LinearLayout box) {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(box);
        dialog.setCanceledOnTouchOutside(true);
        box.setTag(dialog);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(round(Color.WHITE, 24));
            window.setLayout(-1, -2);
            window.setGravity(Gravity.BOTTOM);
            WindowManager.LayoutParams params = window.getAttributes();
            params.width = -1;
            params.dimAmount = 0.4f;
            window.setAttributes(params);
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        }
        dialog.show();
        if (dialog.getWindow() != null) dialog.getWindow().setLayout(-1, -2);
    }

    private void showTopActionDialog(LinearLayout box) {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(box);
        dialog.setCanceledOnTouchOutside(true);
        box.setTag(dialog);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawableResource(android.R.color.transparent);
            window.setGravity(Gravity.TOP | Gravity.RIGHT);
            WindowManager.LayoutParams params = window.getAttributes();
            params.width = dp(310);
            params.height = WindowManager.LayoutParams.WRAP_CONTENT;
            params.x = dp(12);
            params.y = dp(56);
            params.dimAmount = 0.08f;
            window.setAttributes(params);
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        }
        dialog.show();
        if (dialog.getWindow() != null) {
            dialog.getWindow().setLayout(dp(310), WindowManager.LayoutParams.WRAP_CONTENT);
        }
    }

    private LinearLayout dialogBox() {
        LinearLayout box = column();
        box.setPadding(dp(20), dp(20), dp(20), dp(24));
        box.setBackground(round(Color.WHITE, 24));
        return box;
    }

    private final class SimpleIconView extends View {
        private final String type;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        SimpleIconView(android.content.Context context, String type) {
            super(context);
            this.type = type;
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float scale = Math.min(getWidth(), getHeight()) / 40f;
            canvas.save();
            canvas.scale(scale, scale);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.rgb(239, 243, 255));
            canvas.drawRoundRect(0, 0, 40, 40, 12, 12, paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(1.8f);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeJoin(Paint.Join.ROUND);
            paint.setColor(Color.rgb(62, 99, 245));

            switch (type) {
                case "gallery":
                    canvas.drawRoundRect(8, 9, 32, 31, 3, 3, paint);
                    canvas.drawCircle(15, 15, 2, paint);
                    Path landscape = new Path(); landscape.moveTo(10, 27); landscape.lineTo(17, 20); landscape.lineTo(21, 24); landscape.lineTo(25, 18); landscape.lineTo(30, 26); canvas.drawPath(landscape, paint);
                    break;
                case "camera":
                    canvas.drawRoundRect(7, 13, 33, 30, 4, 4, paint);
                    canvas.drawRoundRect(13, 9, 20, 14, 2, 2, paint);
                    canvas.drawCircle(21, 21, 6, paint); canvas.drawCircle(21, 21, 2, paint);
                    break;
                case "phone":
                    Path handset = new Path(); handset.moveTo(13, 9); handset.cubicTo(10, 10, 10, 14, 13, 20);
                    handset.cubicTo(17, 27, 23, 31, 28, 29); handset.lineTo(31, 24); handset.lineTo(25, 20);
                    handset.lineTo(22, 23); handset.cubicTo(18, 21, 16, 18, 15, 15); handset.lineTo(18, 12); handset.close(); canvas.drawPath(handset, paint);
                    break;
                case "video":
                    canvas.drawRoundRect(6, 12, 26, 28, 3, 3, paint);
                    Path lens = new Path(); lens.moveTo(27, 17); lens.lineTo(34, 13); lens.lineTo(34, 27); lens.lineTo(27, 23); lens.close(); canvas.drawPath(lens, paint);
                    break;
                case "wallet":
                    canvas.drawRoundRect(9, 12, 31, 29, 3, 3, paint);
                    line(canvas, 12, 10, 26, 10);
                    canvas.drawRoundRect(23, 17, 32, 24, 2, 2, paint);
                    canvas.drawCircle(27, 20.5f, 1, paint);
                    break;
                case "orders":
                case "history":
                    Path receipt = new Path();
                    receipt.moveTo(12, 8); receipt.lineTo(28, 8); receipt.lineTo(28, 31);
                    receipt.lineTo(25, 29); receipt.lineTo(22, 31); receipt.lineTo(19, 29);
                    receipt.lineTo(16, 31); receipt.lineTo(12, 29); receipt.close();
                    canvas.drawPath(receipt, paint);
                    line(canvas, 16, 14, 24, 14); line(canvas, 16, 19, 24, 19); line(canvas, 16, 24, 22, 24);
                    break;
                case "address":
                    Path pin = new Path();
                    pin.moveTo(20, 31); pin.cubicTo(18, 27, 11, 20, 11, 16);
                    pin.cubicTo(11, 11, 15, 8, 20, 8); pin.cubicTo(25, 8, 29, 11, 29, 16);
                    pin.cubicTo(29, 20, 22, 27, 20, 31); canvas.drawPath(pin, paint);
                    canvas.drawCircle(20, 16, 3, paint);
                    break;
                case "stake":
                    canvas.drawCircle(20, 20, 10, paint);
                    line(canvas, 15, 23, 19, 19); line(canvas, 19, 19, 22, 21); line(canvas, 22, 21, 26, 15);
                    line(canvas, 23, 15, 26, 15); line(canvas, 26, 15, 26, 18);
                    break;
                case "invite":
                    canvas.drawCircle(16, 15, 4, paint);
                    Path person = new Path(); person.moveTo(8, 29); person.cubicTo(8, 22, 11, 20, 16, 20); person.cubicTo(21, 20, 24, 22, 24, 29); canvas.drawPath(person, paint);
                    line(canvas, 28, 13, 28, 23); line(canvas, 23, 18, 33, 18);
                    break;
                case "help":
                    canvas.drawCircle(20, 20, 11, paint);
                    paint.setStyle(Paint.Style.FILL); paint.setTextSize(16); paint.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
                    canvas.drawText("?", 16.6f, 25.5f, paint);
                    break;
                case "benefit":
                    Path star = new Path();
                    for (int i = 0; i < 10; i++) {
                        double angle = -Math.PI / 2 + i * Math.PI / 5;
                        float radius = i % 2 == 0 ? 11 : 5;
                        float x = 20 + (float) Math.cos(angle) * radius;
                        float y = 19 + (float) Math.sin(angle) * radius;
                        if (i == 0) star.moveTo(x, y); else star.lineTo(x, y);
                    }
                    star.close(); canvas.drawPath(star, paint);
                    line(canvas, 15, 28, 14, 33); line(canvas, 25, 28, 26, 33);
                    break;
                case "support":
                    canvas.drawRoundRect(8, 9, 32, 27, 6, 6, paint);
                    Path tail = new Path(); tail.moveTo(14, 27); tail.lineTo(12, 32); tail.lineTo(20, 27); canvas.drawPath(tail, paint);
                    canvas.drawCircle(15, 18, 1, paint); canvas.drawCircle(20, 18, 1, paint); canvas.drawCircle(25, 18, 1, paint);
                    break;
                case "settings":
                    canvas.drawCircle(20, 20, 8, paint); canvas.drawCircle(20, 20, 3, paint);
                    for (int i = 0; i < 8; i++) {
                        double a = i * Math.PI / 4;
                        line(canvas, 20 + (float) Math.cos(a) * 10, 20 + (float) Math.sin(a) * 10,
                                20 + (float) Math.cos(a) * 13, 20 + (float) Math.sin(a) * 13);
                    }
                    break;
                case "language":
                    canvas.drawCircle(20, 20, 11, paint); canvas.drawOval(15, 9, 25, 31, paint);
                    line(canvas, 9, 20, 31, 20); line(canvas, 12, 14, 28, 14); line(canvas, 12, 26, 28, 26);
                    break;
                case "lock":
                    canvas.drawRoundRect(11, 17, 29, 30, 3, 3, paint);
                    Path shackle = new Path(); shackle.moveTo(15, 18); shackle.lineTo(15, 14); shackle.cubicTo(15, 7, 25, 7, 25, 14); shackle.lineTo(25, 18); canvas.drawPath(shackle, paint);
                    canvas.drawCircle(20, 23, 1, paint); line(canvas, 20, 24, 20, 27);
                    break;
                case "cache":
                    line(canvas, 12, 12, 28, 12); line(canvas, 15, 9, 25, 9);
                    canvas.drawRoundRect(13, 13, 27, 31, 2, 2, paint);
                    line(canvas, 17, 17, 17, 27); line(canvas, 23, 17, 23, 27);
                    break;
                case "about":
                    canvas.drawCircle(20, 20, 11, paint); canvas.drawCircle(20, 14, 1, paint);
                    line(canvas, 20, 18, 20, 26);
                    break;
                case "agreement":
                    Path sheet = new Path(); sheet.moveTo(12, 8); sheet.lineTo(24, 8); sheet.lineTo(29, 13); sheet.lineTo(29, 32); sheet.lineTo(12, 32); sheet.close(); canvas.drawPath(sheet, paint);
                    line(canvas, 24, 8, 24, 13); line(canvas, 24, 13, 29, 13);
                    line(canvas, 16, 19, 25, 19); line(canvas, 16, 23, 25, 23); line(canvas, 16, 27, 23, 27);
                    break;
                default:
                    canvas.drawCircle(20, 20, 10, paint);
                    break;
            }
            canvas.restore();
        }

        private void line(Canvas canvas, float x1, float y1, float x2, float y2) {
            canvas.drawLine(x1, y1, x2, y2, paint);
        }
    }

    private TextView title(String text) { TextView v=bodyText(text, 27, TEXT); v.setTypeface(android.graphics.Typeface.create("sans-serif-medium", 0)); return v; }
    private LinearLayout headerTitle(String title, String sub) {
        LinearLayout box = column();
        box.setPadding(dp(18), dp(14), dp(18), dp(10));
        box.setBackgroundColor(Color.WHITE);
        box.addView(this.title(title));
        box.addView(bodyText(sub, 14, MUTED));
        return box;
    }

    private EditText search(String hint) {
        EditText search = new EditText(this);
        search.setSingleLine(true);
        search.setTextSize(16);
        search.setHint("⌕  " + tr(hint));
        search.setHintTextColor(Color.rgb(142, 154, 175));
        search.setTextColor(TEXT);
        search.setPadding(dp(18), 0, dp(18), 0);
        search.setGravity(Gravity.CENTER_VERTICAL);
        search.setBackground(stroke(Color.rgb(245, 247, 251), MallUi.LINE, 15, 1));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(46));
        p.setMargins(dp(16), dp(4), dp(16), dp(10));
        search.setLayoutParams(p);
        return search;
    }

    private View avatarWithRemoteImage(String text, String url, String start, String end, int size) {
        if (url == null || url.trim().isEmpty()) return avatar(text, start, end, size);
        FrameLayout frame = new FrameLayout(this);
        frame.setLayoutParams(new LinearLayout.LayoutParams(dp(size), dp(size)));
        TextView fallback = avatar(text, start, end, size);
        frame.addView(fallback, new FrameLayout.LayoutParams(-1, -1));
        ImageView image = new ImageView(this);
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        image.setBackground(gradient(start, end, 50));
        image.setClipToOutline(true);
        image.setVisibility(View.GONE);
        frame.addView(image, new FrameLayout.LayoutParams(-1, -1));
        loadAvatarInto(image, url.trim());
        return frame;
    }

    private TextView avatar(String text, String start, String end, int size) {
        TextView view = centeredText(text, size > 60 ? 28 : 18, Color.WHITE);
        view.setTypeface(null, android.graphics.Typeface.BOLD);
        GradientDrawable avatarBackground = gradient(start, end, 50);
        avatarBackground.setStroke(dp(size > 60 ? 3 : 2), Color.WHITE);
        view.setBackground(avatarBackground);
        view.setLayoutParams(new LinearLayout.LayoutParams(dp(size), dp(size)));
        return view;
    }

    private TextView circleButton(String text) {
        TextView view = centeredText(text, 18, BLUE);
        view.setBackground(round(MallUi.TINT, 14));
        MallUi.touch(view, 14);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(40), dp(40));
        view.setLayoutParams(p);
        return view;
    }

    private TextView badge(String text) {
        TextView view = centeredText(text, 12, Color.WHITE);
        view.setBackground(round(BLUE, 30));
        view.setPadding(dp(7), 0, dp(7), 0);
        return view;
    }

    private TextView note(String text) { return centeredText(text, 12, Color.rgb(154, 166, 181)); }
    private TextView section(String text) {
        TextView view = bodyText(text.toUpperCase(), 13, MUTED);
        view.setPadding(dp(18), dp(14), dp(18), dp(7));
        return view;
    }

    private LinearLayout roundCard() {
        LinearLayout card = column();
        card.setPadding(dp(10), dp(12), dp(10), dp(12));
        card.setBackground(round(Color.WHITE, 14));
        return card;
    }

    private LinearLayout stakingMetric(String label, TextView value) {
        LinearLayout metric = column();
        metric.setGravity(Gravity.CENTER_HORIZONTAL);
        metric.addView(centeredText(label, 11, MUTED));
        value.setGravity(Gravity.CENTER);
        value.setTypeface(null, android.graphics.Typeface.BOLD);
        metric.addView(value);
        return metric;
    }

    private String resolveAppLanguage() {
        String saved = preferences.getString("language", "");
        if (saved.equals("zh-CN") || saved.equals("zh-TW") || saved.equals("en") || saved.equals("ja") || saved.equals("ko")) return saved;
        Locale locale = Locale.getDefault();
        String language = locale.getLanguage().toLowerCase(Locale.ROOT);
        String country = locale.getCountry().toUpperCase(Locale.ROOT);
        if ("zh".equals(language)) return ("HK".equals(country) || "MO".equals(country) || "TW".equals(country)) ? "zh-TW" : "zh-CN";
        if ("ja".equals(language)) return "ja";
        if ("ko".equals(language)) return "ko";
        return "en";
    }

    private String languageDisplayName() {
        if ("zh-TW".equals(appLanguage)) return t("lang_traditional");
        if ("ja".equals(appLanguage)) return t("lang_japanese");
        if ("ko".equals(appLanguage)) return t("lang_korean");
        if ("en".equals(appLanguage)) return t("lang_english");
        return t("lang_simplified");
    }

    private String tr(String text) {
        if (text == null || "zh-CN".equals(appLanguage)) return text;
        String resourceValue = I18n.translate(this, appLanguage, text);
        if (!text.equals(resourceValue)) return resourceValue;
        String composite = I18n.translateComposite(this, appLanguage, text);
        if (!text.equals(composite)) return composite;
        return text;
    }

    private String t(String key, Object... args) {
        return I18n.t(this, appLanguage, key, args);
    }

    private TextView bodyText(String text, int size, int color) {
        TextView view = new LocalizedTextView(this);
        view.setText(tr(text));
        view.setTextSize(size);
        view.setTextColor(color);
        view.setGravity(Gravity.CENTER_VERTICAL);
        view.setFontFeatureSettings("kern");
        view.setLineSpacing(dp(2), 1f);
        return view;
    }

    /** TextViews created by the UI factory also localize later async state updates. */
    private final class LocalizedTextView extends TextView {
        LocalizedTextView(Context context) { super(context); }
        @Override public void setText(CharSequence text, BufferType type) {
            String value = text == null ? null : text.toString();
            super.setText(value, type);
        }
    }

    private TextView centeredText(String text, int size, int color) {
        TextView view = bodyText(text, size, color);
        view.setGravity(Gravity.CENTER);
        return view;
    }

    private LinearLayout row() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private View separator() { View v = new View(this); v.setBackgroundColor(Color.rgb(240, 242, 245)); return v; }
    private View space(int width) { View v = new View(this); v.setLayoutParams(new LinearLayout.LayoutParams(dp(width), 1)); return v; }
    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }

    private GradientDrawable round(int color, int radius) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d; }
    private GradientDrawable stroke(int fill, int line, int radius, int width) { GradientDrawable d = round(fill, radius); d.setStroke(dp(width), line); return d; }
    private GradientDrawable gradient(String start, String end, int radius) { GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{Color.parseColor(start), Color.parseColor(end)}); d.setCornerRadius(dp(radius)); return d; }
    private int statusColor(String status) { return status.equals("online") ? Color.rgb(46, 204, 113) : status.equals("busy") ? Color.rgb(243, 156, 18) : MUTED; }
    private String statusLabel(String status) { return status.equals("online") ? t("online") : status.equals("busy") ? t("busy") : t("offline"); }
    private void toast(String message) { Toast.makeText(this, tr(message), Toast.LENGTH_SHORT).show(); }
}
