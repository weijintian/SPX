<?php
declare(strict_types=1);

require_once __DIR__ . '/response.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/staking_settlement.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/smtp.php';
require_once __DIR__ . '/ws-event.php';
require_once __DIR__ . '/AvePriceService.php';
require_once __DIR__ . '/mall.php';

function publicBaseUrl(): string
{
    $config = require __DIR__ . '/config.php';
    $configured = trim((string) ($config['app']['public_base_url'] ?? ''));
    if ($configured !== '') return rtrim($configured, '/');
    $forwardedProto = strtolower(trim(explode(',', (string) ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? ''))[0] ?? ''));
    $scheme = $forwardedProto === 'https' || (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = trim((string) ($_SERVER['HTTP_X_FORWARDED_HOST'] ?? $_SERVER['HTTP_HOST'] ?? '127.0.0.1'));
    $host = trim(explode(',', $host)[0]);
    return $scheme . '://' . $host . rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? '/'), '/');
}

function inviteBaseUrl(): string
{
    $setting = db()->prepare('SELECT `value` FROM app_settings WHERE `key`=? LIMIT 1');
    $setting->execute(['invite_base_url']);
    $value = rtrim(trim((string) ($setting->fetchColumn() ?: '')), '/');
    return $value !== '' ? $value : 'http://spx001.top';
}

function apiClientIp(): string
{
    $ip = trim((string) ($_SERVER['REMOTE_ADDR'] ?? ''));
    return filter_var($ip, FILTER_VALIDATE_IP) ? $ip : 'unknown';
}

function enforceApiRateLimit(string $scope, int $limit = 5): void
{
    $pdo = db();
    $windowStart = date('Y-m-d H:00:00');
    $scopeKey = $scope . ':' . apiClientIp();
    $statement = $pdo->prepare('INSERT INTO api_rate_limits (scope_key,window_start,attempts) VALUES (?,?,1) ON DUPLICATE KEY UPDATE attempts=attempts+1');
    $statement->execute([$scopeKey, $windowStart]);
    $current = $pdo->prepare('SELECT attempts FROM api_rate_limits WHERE scope_key=? AND window_start=? LIMIT 1');
    $current->execute([$scopeKey, $windowStart]);
    if ((int) $current->fetchColumn() > $limit) jsonResponse(null, '操作频繁，请稍后再试', 429);
}

function isTokenContractAddress(string $address): bool
{
    $normalized = strtolower(trim($address));
    return in_array($normalized, [
        '0x55d398326f99059ff775485246999027b3197955',
        '0x0e920821464625cf661a4dcedeb6406e1b48ffff',
    ], true);
}

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    jsonResponse(null);
}

$action = trim((string) ($_GET['action'] ?? 'health'));
$method = $_SERVER['REQUEST_METHOD'];
$body = requestBody();

try {
    runStakingSettlement();
    mallHandleApi($action, $method, $body);
    switch ($action) {
        case 'health':
            db()->query('SELECT 1');
            jsonResponse(['service' => 'spxchat', 'time' => date(DATE_ATOM)]);

        case 'app.config':
            $nodesSetting = db()->prepare('SELECT `value` FROM app_settings WHERE `key`=? LIMIT 1');
            $nodesSetting->execute(['api_nodes']);
            $configuredNodes = json_decode((string) ($nodesSetting->fetchColumn() ?: '[]'), true);
            $nodes = [];
            if (is_array($configuredNodes)) foreach ($configuredNodes as $node) {
                if (!is_array($node) || !is_string($node['url'] ?? null) || !preg_match('#^https?://[^/\s]+(?:/[^\s]*)?$#i', $node['url'])) continue;
                $nodes[] = ['url' => rtrim((string) $node['url'], '/'), 'weight' => max(1, min(1000, (int) ($node['weight'] ?? 1))), 'enabled' => (int) ($node['enabled'] ?? 1) === 1 ? 1 : 0];
            }
            jsonResponse(['api_path' => '/spxchat/api.php', 'nodes' => $nodes], '节点配置已获取');

        case 'app.update.check':
            $release = db()->query('SELECT id,version_code,version_name,release_notes,apk_size,apk_sha256,download_count,created_at FROM app_releases WHERE is_active=1 ORDER BY version_code DESC LIMIT 1')->fetch();
            if (!$release) jsonResponse(['update_available' => false, 'current_version_code' => max(0, (int) ($_GET['version_code'] ?? 0))]);
            $currentCode = max(0, (int) ($_GET['version_code'] ?? 0));
            $release['id'] = (int) $release['id'];
            $release['version_code'] = (int) $release['version_code'];
            $release['apk_size'] = (int) $release['apk_size'];
            $release['download_count'] = (int) $release['download_count'];
            $release['current_version_code'] = $currentCode;
            $release['update_available'] = $release['version_code'] > $currentCode;
            jsonResponse($release, '版本信息已获取');

        case 'app.update.history':
            $releases = db()->query('SELECT version_code,version_name,release_notes,created_at FROM app_releases ORDER BY version_code DESC')->fetchAll();
            foreach ($releases as &$release) $release['version_code'] = (int) $release['version_code'];
            unset($release);
            jsonResponse($releases, '版本更新记录');

        case 'app.update.download':
            $releaseId = max(0, (int) ($_GET['id'] ?? 0));
            $releaseQuery = db()->prepare('SELECT id,version_name,file_path,apk_size FROM app_releases WHERE id=? AND is_active=1 LIMIT 1');
            $releaseQuery->execute([$releaseId]);
            $release = $releaseQuery->fetch();
            if (!$release || !preg_match('#^/uploads/app-releases/[a-f0-9]{64}-[a-f0-9]{16}\\.apk$#', (string) $release['file_path'])) {
                jsonResponse(null, '更新文件不存在', 404);
            }
            $directory = realpath(__DIR__ . '/uploads/app-releases');
            $apkPath = realpath(__DIR__ . $release['file_path']);
            if (!$directory || !$apkPath || strpos($apkPath, $directory . DIRECTORY_SEPARATOR) !== 0 || !is_file($apkPath)) {
                jsonResponse(null, '更新文件不可用', 404);
            }
            db()->prepare('UPDATE app_releases SET download_count=download_count+1 WHERE id=? AND is_active=1')->execute([$releaseId]);
            header('Content-Type: application/vnd.android.package-archive');
            header('Content-Length: ' . (string) filesize($apkPath));
            header('Content-Disposition: attachment; filename="spxchat-' . rawurlencode((string) $release['version_name']) . '.apk"');
            header('Cache-Control: no-store, no-cache, must-revalidate');
            header('X-Content-Type-Options: nosniff');
            readfile($apkPath);
            exit;

        case 'auth.email.code':
            requireFields($body, ['email']);
            $email = strtolower(trim((string) $body['email']));
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) jsonResponse(null, '邮箱格式不正确', 422);
            $purpose = (string) ($body['purpose'] ?? 'register');
            if (!in_array($purpose, ['register', 'password_reset'], true)) jsonResponse(null, '验证码用途无效', 422);
            enforceApiRateLimit('email_code');
            if ($purpose === 'password_reset') {
                $account = db()->prepare('SELECT id FROM users WHERE email=? LIMIT 1');
                $account->execute([$email]);
                if (!$account->fetch()) jsonResponse(['email' => $email, 'expires_in' => 300], '验证码已发送，请查看邮箱');
            }
            $config = require __DIR__ . '/config.php';
            $recent = db()->prepare('SELECT id FROM email_verification_codes WHERE email=? AND purpose=? AND created_at > ? ORDER BY id DESC LIMIT 1');
            $recent->execute([$email, $purpose, date('Y-m-d H:i:s', time() - (int) $config['app']['verification_resend_seconds'])]);
            if ($recent->fetch()) jsonResponse(null, '验证码发送过于频繁，请稍后再试', 429);
            $code = (string) random_int(100000, 999999);
            $codeStatement = db()->prepare('INSERT INTO email_verification_codes (email,purpose,code_hash,expires_at,request_ip) VALUES (?,?,?,?,?)');
            $codeStatement->execute([
                $email,
                $purpose,
                hash('sha256', $code),
                date('Y-m-d H:i:s', time() + (int) $config['app']['verification_code_ttl']),
                $_SERVER['REMOTE_ADDR'] ?? null,
            ]);
            try {
                $label = $purpose === 'password_reset' ? '密码重置' : '注册验证';
                smtpSend($email, 'SPX Chat ' . $label . '验证码', '<div style="font-family:Arial,sans-serif"><h2>SPX Chat ' . $label . '</h2><p>你的验证码是：</p><p style="font-size:30px;letter-spacing:8px;font-weight:bold">' . htmlspecialchars($code, ENT_QUOTES, 'UTF-8') . '</p><p>验证码 5 分钟内有效。如非本人操作，请忽略此邮件。</p></div>');
            } catch (Throwable $exception) {
                db()->prepare('DELETE FROM email_verification_codes WHERE id=?')->execute([db()->lastInsertId()]);
                throw $exception;
            }
            jsonResponse(['email' => $email, 'expires_in' => (int) $config['app']['verification_code_ttl']], '验证码已发送');

        case 'auth.password.reset':
            requireFields($body, ['email', 'code', 'new_password']);
            $email = strtolower(trim((string) $body['email']));
            $code = trim((string) $body['code']);
            $newPassword = (string) $body['new_password'];
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) jsonResponse(null, '邮箱格式不正确', 422);
            if (!preg_match('/^\d{6}$/', $code)) jsonResponse(null, '验证码格式不正确', 422);
            if (strlen($newPassword) < 6) jsonResponse(null, '新密码至少 6 位', 422);
            $pdo = db();
            $pdo->beginTransaction();
            $statement = $pdo->prepare('SELECT * FROM email_verification_codes WHERE email=? AND purpose="password_reset" AND used_at IS NULL AND expires_at>NOW() ORDER BY id DESC LIMIT 1 FOR UPDATE');
            $statement->execute([$email]);
            $verification = $statement->fetch();
            if (!$verification) { $pdo->rollBack(); jsonResponse(null, '验证码错误或已过期', 422); }
            if ((int) $verification['attempts'] >= 5) { $pdo->commit(); jsonResponse(null, '验证码尝试次数过多，请重新获取', 429); }
            if (!hash_equals($verification['code_hash'], hash('sha256', $code))) {
                $pdo->prepare('UPDATE email_verification_codes SET attempts=attempts+1 WHERE id=?')->execute([$verification['id']]);
                $pdo->commit();
                jsonResponse(null, '验证码错误或已过期', 422);
            }
            $user = $pdo->prepare('SELECT id FROM users WHERE email=? LIMIT 1 FOR UPDATE');
            $user->execute([$email]);
            $userId = (int) $user->fetchColumn();
            if ($userId <= 0) { $pdo->rollBack(); jsonResponse(null, '账号不存在', 404); }
            $pdo->prepare('UPDATE users SET password_hash=? WHERE id=?')->execute([password_hash($newPassword, PASSWORD_DEFAULT), $userId]);
            $pdo->prepare('UPDATE email_verification_codes SET used_at=NOW() WHERE id=?')->execute([$verification['id']]);
            $pdo->prepare('DELETE FROM user_tokens WHERE user_id=?')->execute([$userId]);
            $pdo->commit();
            jsonResponse(null, '密码重置成功，请使用新密码登录');

        case 'auth.register':
            requireFields($body, ['email', 'code', 'username', 'password']);
            $email = strtolower(trim((string) $body['email']));
            $code = trim((string) $body['code']);
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) jsonResponse(null, '邮箱格式不正确', 422);
            if (!preg_match('/^\d{6}$/', $code)) jsonResponse(null, '验证码格式不正确', 422);
            $username = trim((string) $body['username']);
            $password = (string) $body['password'];
            if (strlen($password) < 6) jsonResponse(null, '密码至少 6 位', 422);
            $pdo = db();
            $pdo->beginTransaction();
            $codeStatement = $pdo->prepare('SELECT * FROM email_verification_codes WHERE email=? AND purpose="register" AND used_at IS NULL AND expires_at > NOW() ORDER BY id DESC LIMIT 1 FOR UPDATE');
            $codeStatement->execute([$email]);
            $verification = $codeStatement->fetch();
            if (!$verification) { $pdo->rollBack(); jsonResponse(null, '验证码错误或已过期', 422); }
            if ((int) $verification['attempts'] >= 5) { $pdo->commit(); jsonResponse(null, '验证码尝试次数过多，请重新获取', 429); }
            if (!hash_equals($verification['code_hash'], hash('sha256', $code))) {
                $pdo->prepare('UPDATE email_verification_codes SET attempts=attempts+1 WHERE id=?')->execute([$verification['id']]);
                $pdo->commit();
                jsonResponse(null, '验证码错误或已过期', 422);
            }
            $check = db()->prepare('SELECT id FROM users WHERE username = ? LIMIT 1');
            $check->execute([$username]);
            if ($check->fetch()) { $pdo->rollBack(); jsonResponse(null, '用户名已存在', 409); }
            $emailCheck = db()->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
            $emailCheck->execute([$email]);
            if ($emailCheck->fetch()) { $pdo->rollBack(); jsonResponse(null, '邮箱已注册', 409); }
            $inviterId = null;
            $inviteCode = trim((string) ($body['invite_code'] ?? ''));
            if ($inviteCode !== '') {
                $inviter = $pdo->prepare('SELECT id FROM users WHERE spx_id=? LIMIT 1');
                $inviter->execute([$inviteCode]);
                $inviterRow = $inviter->fetch();
                if (!$inviterRow) { $pdo->rollBack(); jsonResponse(null, '邀请码无效，请检查后重试', 422); }
                $inviterId = (int) $inviterRow['id'];
            }
            do {
                $spxId = 'spx' . random_int(100000, 999999);
                $idCheck = $pdo->prepare('SELECT id FROM users WHERE spx_id=? LIMIT 1');
                $idCheck->execute([$spxId]);
            } while ($idCheck->fetch());
            $statement = $pdo->prepare('INSERT INTO users (username,email,email_verified_at,invited_by_user_id,nickname,password_hash,spx_id,registration_ip,device_id,device_model,android_version,app_version) VALUES (?, ?, NOW(), ?, ?, ?, ?, ?, ?, ?, ?, ?)');
            $statement->execute([$username, $email, $inviterId, $body['nickname'] ?? $username, password_hash($password, PASSWORD_DEFAULT), $spxId, $_SERVER['REMOTE_ADDR'] ?? null, $body['device_id'] ?? null, $body['device_model'] ?? null, $body['android_version'] ?? null, $body['app_version'] ?? null]);
            $userId = (int) $pdo->lastInsertId();
            $pdo->prepare('INSERT INTO wallet_assets (user_id,symbol,chain,balance) VALUES (?,"SPX001","BSC",0),(?,"USDT","BSC",0)')->execute([$userId, $userId]);
            $pdo->prepare('UPDATE email_verification_codes SET used_at=NOW() WHERE id=?')->execute([$verification['id']]);
            $pdo->commit();
            $token = issueToken($userId);
            $userStatement = db()->prepare('SELECT id, username, email, nickname, spx_id, avatar_url, remark, created_at FROM users WHERE id = ? LIMIT 1');
            $userStatement->execute([$userId]);
            jsonResponse(['token' => $token, 'user' => $userStatement->fetch()], '注册成功', 201);

        case 'auth.login':
            requireFields($body, ['username', 'password']);
            enforceApiRateLimit('login');
            $login = trim((string) $body['username']);
            $statement = db()->prepare('SELECT * FROM users WHERE username = ? OR email = ? LIMIT 1');
            $statement->execute([$login, strtolower($login)]);
            $user = $statement->fetch();
            if (!$user || !password_verify((string) $body['password'], $user['password_hash'])) {
                jsonResponse(null, '用户名或密码错误', 401);
            }
            if ((int) ($user['status'] ?? 1) !== 1) jsonResponse(null, '账号已停用，请联系平台客服', 403);
            $deviceFields = [];
            $deviceValues = [];
            foreach (['device_id', 'device_model', 'android_version', 'app_version'] as $field) {
                if (array_key_exists($field, $body) && trim((string) $body[$field]) !== '') {
                    $deviceFields[] = $field . '=?';
                    $deviceValues[] = trim((string) $body[$field]);
                    $user[$field] = trim((string) $body[$field]);
                }
            }
            if ($deviceFields) {
                $deviceValues[] = $user['id'];
                db()->prepare('UPDATE users SET ' . implode(',', $deviceFields) . ' WHERE id=?')->execute($deviceValues);
            }
            $token = issueToken((int) $user['id']);
            unset($user['password_hash']);
            jsonResponse(['token' => $token, 'user' => $user]);

        case 'me':
            jsonResponse(currentUser());

        case 'presence.update':
            $user = currentUser();
            requireFields($body, ['device_id', 'online']);
            $deviceId = trim((string) $body['device_id']);
            if (!preg_match('/^[A-Za-z0-9._:-]{8,128}$/', $deviceId)) jsonResponse(null, '设备编号无效', 422);
            $online = filter_var($body['online'], FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
            if ($online === null) jsonResponse(null, '在线状态无效', 422);
            $pdo = db();
            $countOnline = $pdo->prepare('SELECT COUNT(*) FROM user_presence WHERE user_id=? AND is_online=1 AND last_seen_at>=DATE_SUB(NOW(),INTERVAL 90 SECOND)');
            $countOnline->execute([$user['id']]);
            $wasOnline = (int) $countOnline->fetchColumn() > 0;
            $pdo->prepare('INSERT INTO user_presence (user_id,device_id,is_online,last_seen_at) VALUES (?,?,?,NOW()) ON DUPLICATE KEY UPDATE is_online=VALUES(is_online),last_seen_at=NOW()')->execute([$user['id'], $deviceId, $online ? 1 : 0]);
            $countOnline->execute([$user['id']]);
            $isOnline = (int) $countOnline->fetchColumn() > 0;
            if ($wasOnline !== $isOnline) {
                $friends = $pdo->prepare('SELECT contact_user_id FROM contacts WHERE user_id=? AND status="accepted"');
                $friends->execute([$user['id']]);
                foreach ($friends->fetchAll(PDO::FETCH_COLUMN) as $friendId) notifyWebSocket(['type' => 'presence.updated', 'user_id' => (int) $friendId, 'peer_user_id' => (int) $user['id'], 'is_online' => $isOnline]);
            }
            jsonResponse(['is_online' => $isOnline]);

        case 'user.profile':
            $user = currentUser();
            if (trim((string) ($_GET['id'] ?? '')) === '') jsonResponse(null, '缺少参数: id', 422);
            $statement = db()->prepare('SELECT u.id,u.nickname,u.spx_id,u.avatar_url,u.created_at,CASE WHEN c.remark IS NULL OR TRIM(c.remark)="" OR LOWER(TRIM(c.remark)) IN ("null","undefined") THEN "" ELSE TRIM(c.remark) END AS contact_remark,IF(c.id IS NULL,0,1) AS is_contact,IF(EXISTS(SELECT 1 FROM user_presence p WHERE p.user_id=u.id AND p.is_online=1 AND p.last_seen_at>=DATE_SUB(NOW(),INTERVAL 90 SECOND)),1,0) AS is_online FROM users u LEFT JOIN contacts c ON c.user_id=? AND c.contact_user_id=u.id WHERE (u.id=? OR u.spx_id=?) AND u.id<>? LIMIT 1');
            $lookup = (string) ($_GET['id'] ?? '');
            $statement->execute([$user['id'], ctype_digit($lookup) ? (int) $lookup : 0, $lookup, $user['id']]);
            $profile = $statement->fetch();
            if (!$profile) jsonResponse(null, '用户不存在', 404);
            jsonResponse($profile);

        case 'auth.logout':
            currentUser();
            $token = bearerToken();
            db()->prepare('DELETE FROM user_tokens WHERE token = ?')->execute([$token]);
            jsonResponse(null, '已退出登录');

        case 'password.update':
            $user = currentUser();
            requireFields($body, ['current_password', 'new_password']);
            if (strlen((string) $body['new_password']) < 6) jsonResponse(null, '新密码至少 6 位', 422);
            $statement = db()->prepare('SELECT password_hash FROM users WHERE id=? LIMIT 1');
            $statement->execute([$user['id']]);
            $row = $statement->fetch();
            if (!$row || !password_verify((string) $body['current_password'], $row['password_hash'])) jsonResponse(null, '当前密码不正确', 422);
            db()->prepare('UPDATE users SET password_hash=? WHERE id=?')->execute([password_hash((string) $body['new_password'], PASSWORD_DEFAULT), $user['id']]);
            jsonResponse(null, '密码已修改');

        case 'password.email.code':
            $user = currentUser();
            $email = strtolower(trim((string) ($user['email'] ?? '')));
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) jsonResponse(null, '当前账号未绑定有效邮箱', 409);
            enforceApiRateLimit('password_change_code');
            $config = require __DIR__ . '/config.php';
            $recent = db()->prepare('SELECT id FROM email_verification_codes WHERE email=? AND purpose="password_change" AND created_at>? ORDER BY id DESC LIMIT 1');
            $recent->execute([$email, date('Y-m-d H:i:s', time() - (int) $config['app']['verification_resend_seconds'])]);
            if ($recent->fetch()) jsonResponse(null, '验证码发送过于频繁，请稍后再试', 429);
            $code = (string) random_int(100000, 999999);
            $statement = db()->prepare('INSERT INTO email_verification_codes (email,purpose,code_hash,expires_at,request_ip) VALUES (?,?,?,?,?)');
            $statement->execute([$email, 'password_change', hash('sha256', $code), date('Y-m-d H:i:s', time() + (int) $config['app']['verification_code_ttl']), $_SERVER['REMOTE_ADDR'] ?? null]);
            try {
                smtpSend($email, 'SPX Chat 修改密码验证码', '<div style="font-family:Arial,sans-serif"><h2>SPX Chat 修改密码</h2><p>你的验证码是：</p><p style="font-size:30px;letter-spacing:8px;font-weight:bold">' . htmlspecialchars($code, ENT_QUOTES, 'UTF-8') . '</p><p>验证码 5 分钟内有效。如非本人操作，请立即修改密码并联系平台客服。</p></div>');
            } catch (Throwable $exception) {
                db()->prepare('DELETE FROM email_verification_codes WHERE id=?')->execute([db()->lastInsertId()]);
                throw $exception;
            }
            jsonResponse(['email' => $email, 'expires_in' => (int) $config['app']['verification_code_ttl']], '验证码已发送');

        case 'password.update.email':
            $user = currentUser();
            requireFields($body, ['code', 'new_password']);
            $email = strtolower(trim((string) ($user['email'] ?? '')));
            $code = trim((string) $body['code']);
            $newPassword = (string) $body['new_password'];
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) jsonResponse(null, '当前账号未绑定有效邮箱', 409);
            if (!preg_match('/^\d{6}$/', $code)) jsonResponse(null, '验证码格式不正确', 422);
            if (strlen($newPassword) < 6) jsonResponse(null, '新密码至少 6 位', 422);
            $pdo = db();
            $pdo->beginTransaction();
            $verificationQuery = $pdo->prepare('SELECT * FROM email_verification_codes WHERE email=? AND purpose="password_change" AND used_at IS NULL AND expires_at>NOW() ORDER BY id DESC LIMIT 1 FOR UPDATE');
            $verificationQuery->execute([$email]);
            $verification = $verificationQuery->fetch();
            if (!$verification) { $pdo->rollBack(); jsonResponse(null, '验证码错误或已过期', 422); }
            if ((int) $verification['attempts'] >= 5) { $pdo->commit(); jsonResponse(null, '验证码尝试次数过多，请重新获取', 429); }
            if (!hash_equals((string) $verification['code_hash'], hash('sha256', $code))) {
                $pdo->prepare('UPDATE email_verification_codes SET attempts=attempts+1 WHERE id=?')->execute([$verification['id']]);
                $pdo->commit();
                jsonResponse(null, '验证码错误或已过期', 422);
            }
            $pdo->prepare('UPDATE users SET password_hash=? WHERE id=?')->execute([password_hash($newPassword, PASSWORD_DEFAULT), $user['id']]);
            $pdo->prepare('UPDATE email_verification_codes SET used_at=NOW() WHERE id=?')->execute([$verification['id']]);
            $pdo->prepare('DELETE FROM user_tokens WHERE user_id=?')->execute([$user['id']]);
            $pdo->commit();
            $token = issueToken((int) $user['id']);
            jsonResponse(['token' => $token], '密码已修改');

        case 'profile.update':
            $user = currentUser();
            $fields = [];
            $values = [];
            foreach (['nickname', 'avatar_url', 'remark', 'device_id', 'device_model', 'android_version', 'app_version'] as $field) {
                if (array_key_exists($field, $body)) {
                    $fields[] = "{$field} = ?";
                    $values[] = $body[$field];
                }
            }
            if (array_key_exists('spx_id', $body)) {
                jsonResponse(null, 'SPX ID 注册后不可修改', 403);
            }
            if ($fields) {
                $values[] = $user['id'];
                db()->prepare('UPDATE users SET ' . implode(', ', $fields) . ' WHERE id = ?')->execute($values);
            }
            jsonResponse(currentUser());

        case 'upload.avatar':
            $user = currentUser();
            if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
                jsonResponse(null, '请上传头像文件', 422);
            }
            $file = $_FILES['file'];
            if ($file['size'] > 5 * 1024 * 1024) jsonResponse(null, '头像不能超过 5MB', 422);
            $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
            $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif'];
            if (!isset($allowed[$mime])) jsonResponse(null, '只支持 JPG、PNG、WEBP、GIF', 422);
            $uploadDir = __DIR__ . '/uploads';
            if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
            $filename = 'avatar_' . $user['id'] . '_' . bin2hex(random_bytes(8)) . '.' . $allowed[$mime];
            $target = $uploadDir . '/' . $filename;
            if (!move_uploaded_file($file['tmp_name'], $target)) jsonResponse(null, '头像保存失败', 500);
            $url = publicBaseUrl() . '/uploads/' . $filename;
            db()->prepare('UPDATE users SET avatar_url=? WHERE id=?')->execute([$url, $user['id']]);
            $recipients = db()->prepare('SELECT user_id FROM contacts WHERE contact_user_id=? UNION SELECT user_id FROM chats WHERE peer_user_id=?');
            $recipients->execute([$user['id'], $user['id']]);
            foreach ($recipients->fetchAll(PDO::FETCH_COLUMN) as $recipientId) {
                notifyWebSocket(['type' => 'profile.updated', 'user_id' => (int) $recipientId, 'peer_user_id' => (int) $user['id'], 'avatar_url' => $url]);
            }
            jsonResponse(['url' => $url], '头像上传成功');

        case 'upload.message':
            $user = currentUser();
            if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
                jsonResponse(null, '请上传图片、视频或语音文件', 422);
            }
            $file = $_FILES['file'];
            if ($file['size'] > 50 * 1024 * 1024) jsonResponse(null, '媒体文件不能超过 50MB', 422);
            $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
            $allowed = [
                'image/jpeg' => ['jpg', 'image'], 'image/png' => ['png', 'image'],
                'image/webp' => ['webp', 'image'], 'image/gif' => ['gif', 'image'],
                'video/mp4' => ['mp4', 'video'], 'video/quicktime' => ['mov', 'video'],
                'video/webm' => ['webm', 'video'],
                'audio/3gpp' => ['3gp', 'voice'], 'audio/amr' => ['amr', 'voice'],
                'video/3gpp' => ['3gp', 'voice'],
                'audio/mp4' => ['m4a', 'voice'], 'audio/aac' => ['aac', 'voice'],
                'audio/mpeg' => ['mp3', 'voice'], 'audio/ogg' => ['ogg', 'voice'],
            ];
            if (!isset($allowed[$mime])) jsonResponse(null, '只支持常用图片、视频或语音格式', 422);
            $uploadDir = __DIR__ . '/uploads/messages';
            if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
            $filename = 'message_' . $user['id'] . '_' . bin2hex(random_bytes(8)) . '.' . $allowed[$mime][0];
            if (!move_uploaded_file($file['tmp_name'], $uploadDir . '/' . $filename)) jsonResponse(null, '媒体保存失败', 500);
            $url = publicBaseUrl() . '/uploads/messages/' . $filename;
            jsonResponse(['url' => $url, 'message_type' => $allowed[$mime][1], 'mime' => $mime], '媒体上传成功', 201);

        case 'contacts':
            $user = currentUser();
            $statement = db()->prepare('SELECT u.id,u.nickname,u.spx_id,u.avatar_url,CASE WHEN c.remark IS NULL OR TRIM(c.remark)="" OR LOWER(TRIM(c.remark)) IN ("null","undefined") THEN "" ELSE TRIM(c.remark) END AS remark,IF(EXISTS(SELECT 1 FROM user_presence p WHERE p.user_id=u.id AND p.is_online=1 AND p.last_seen_at>=DATE_SUB(NOW(),INTERVAL 90 SECOND)),1,0) AS is_online,c.created_at FROM contacts c JOIN users u ON u.id=c.contact_user_id WHERE c.user_id=? AND c.status="accepted" ORDER BY c.id DESC');
            $statement->execute([$user['id']]);
            jsonResponse($statement->fetchAll());

        case 'contacts.search':
            $user = currentUser();
            $keyword = trim((string) ($_GET['q'] ?? ''));
            if ($keyword === '') jsonResponse([]);
            $statement = db()->prepare('SELECT u.id,u.nickname,u.spx_id,u.avatar_url,CASE WHEN c.remark IS NULL OR TRIM(c.remark)="" OR LOWER(TRIM(c.remark)) IN ("null","undefined") THEN "" ELSE TRIM(c.remark) END AS remark,IF(EXISTS(SELECT 1 FROM user_presence p WHERE p.user_id=u.id AND p.is_online=1 AND p.last_seen_at>=DATE_SUB(NOW(),INTERVAL 90 SECOND)),1,0) AS is_online FROM users u LEFT JOIN contacts c ON c.user_id=? AND c.contact_user_id=u.id WHERE u.id<>? AND (u.spx_id LIKE ? OR u.email LIKE ? OR u.nickname LIKE ? OR CAST(u.id AS CHAR)=?) ORDER BY (u.spx_id=? OR u.email=?) DESC LIMIT 20');
            $like = '%' . $keyword . '%';
            $statement->execute([$user['id'], $user['id'], $like, $like, $like, $keyword, $keyword, strtolower($keyword)]);
            jsonResponse($statement->fetchAll());

        case 'contacts.add':
            $user = currentUser();
            if (empty($body['spx_id']) && empty($body['email'])) jsonResponse(null, '请提供 SPX ID 或邮箱', 422);
            $lookup = trim((string) ($body['spx_id'] ?? $body['email']));
            $peerStatement = db()->prepare('SELECT id FROM users WHERE spx_id=? OR email=? LIMIT 1');
            $peerStatement->execute([$lookup, strtolower($lookup)]);
            $peer = $peerStatement->fetch();
            if (!$peer) jsonResponse(null, '未找到该 SPX 用户', 404);
            if ((int) $peer['id'] === (int) $user['id']) jsonResponse(null, '不能添加自己', 422);
            db()->prepare('INSERT IGNORE INTO contacts (user_id,contact_user_id,remark,status) VALUES (?,?,?,"accepted"),(?,?,?,"accepted")')->execute([
                $user['id'], $peer['id'], $body['remark'] ?? null,
                $peer['id'], $user['id'], null,
            ]);
            jsonResponse(['user_id' => (int) $peer['id']], '好友已添加', 201);

        case 'contacts.remark':
            $user = currentUser();
            if (!array_key_exists('contact_user_id', $body) || trim((string) $body['contact_user_id']) === '') jsonResponse(null, '缺少参数: contact_user_id', 422);
            if (!array_key_exists('remark', $body)) jsonResponse(null, '缺少参数: remark', 422);
            $peerId = (int) $body['contact_user_id'];
            if ($peerId <= 0 || $peerId === (int) $user['id']) jsonResponse(null, '联系人参数无效', 422);
            $remark = is_scalar($body['remark']) ? trim((string) $body['remark']) : '';
            if (in_array(strtolower($remark), ['null', 'undefined'], true)) $remark = '';
            $statement = db()->prepare('INSERT INTO contacts (user_id,contact_user_id,remark,status) VALUES (?,?,?,"accepted") ON DUPLICATE KEY UPDATE remark=VALUES(remark),status="accepted"');
            $statement->execute([$user['id'], $peerId, $remark]);
            jsonResponse(null, '备注已保存');

        case 'contacts.delete':
            $user = currentUser();
            requireFields($body, ['contact_user_id']);
            $peerId = (int) $body['contact_user_id'];
            if ($peerId <= 0 || $peerId === (int) $user['id']) jsonResponse(null, '联系人参数无效', 422);
            $pdo = db();
            $sessions = $pdo->prepare('SELECT id,user_id FROM chats WHERE (user_id=? AND peer_user_id=?) OR (user_id=? AND peer_user_id=?)');
            $sessions->execute([$user['id'], $peerId, $peerId, $user['id']]);
            $sessionRows = $sessions->fetchAll();
            $pdo->beginTransaction();
            $pdo->prepare('DELETE FROM contacts WHERE (user_id=? AND contact_user_id=?) OR (user_id=? AND contact_user_id=?)')->execute([$user['id'], $peerId, $peerId, $user['id']]);
            $pdo->prepare('DELETE FROM chats WHERE (user_id=? AND peer_user_id=?) OR (user_id=? AND peer_user_id=?)')->execute([$user['id'], $peerId, $peerId, $user['id']]);
            $pdo->commit();
            foreach ($sessionRows as $session) {
                notifyWebSocket(['type' => 'conversation.deleted', 'user_id' => (int) $session['user_id'], 'chat_id' => (int) $session['id'], 'peer_user_id' => $peerId]);
            }
            $deletedChatIds = [];
            foreach ($sessionRows as $session) if ((int) $session['user_id'] === (int) $user['id']) $deletedChatIds[] = (int) $session['id'];
            jsonResponse(['deleted_chat_ids' => $deletedChatIds], '好友及双方聊天记录已删除');

        case 'chats':
            $user = currentUser();
            $statement = db()->prepare(
                'SELECT c.*, u.nickname, u.avatar_url, u.spx_id,IF(EXISTS(SELECT 1 FROM user_presence p WHERE p.user_id=u.id AND p.is_online=1 AND p.last_seen_at>=DATE_SUB(NOW(),INTERVAL 90 SECOND)),1,0) AS is_online,
                        CASE WHEN contacts.remark IS NULL OR TRIM(contacts.remark)="" OR LOWER(TRIM(contacts.remark)) IN ("null","undefined") THEN "" ELSE TRIM(contacts.remark) END AS contact_remark,
                        CASE WHEN contacts.remark IS NULL OR TRIM(contacts.remark)="" OR LOWER(TRIM(contacts.remark)) IN ("null","undefined") THEN u.nickname ELSE TRIM(contacts.remark) END AS display_name,
                        COALESCE(cs.pinned,0) AS pinned, COALESCE(cs.mute,0) AS mute, COALESCE(cs.blocked,0) AS blocked
                 FROM chats c JOIN users u ON u.id = c.peer_user_id
                 LEFT JOIN contacts ON contacts.user_id=c.user_id AND contacts.contact_user_id=c.peer_user_id
                 LEFT JOIN chat_settings cs ON cs.user_id=c.user_id AND cs.chat_id=c.id
                 WHERE c.user_id = ? ORDER BY COALESCE(cs.pinned,0) DESC,c.updated_at DESC'
            );
            $statement->execute([$user['id']]);
            jsonResponse($statement->fetchAll());

        case 'chats.create':
            $user = currentUser();
            requireFields($body, ['peer_user_id']);
            $peerId = (int) $body['peer_user_id'];
            if ($peerId === (int) $user['id']) jsonResponse(null, '不能创建与自己的会话', 422);
            $contact = db()->prepare('SELECT 1 FROM contacts mine JOIN contacts peer ON peer.user_id=mine.contact_user_id AND peer.contact_user_id=mine.user_id WHERE mine.user_id=? AND mine.contact_user_id=? AND mine.status="accepted" AND peer.status="accepted" LIMIT 1');
            $contact->execute([$user['id'], $peerId]);
            if (!$contact->fetch()) jsonResponse(null, '请先添加好友后再发起私聊', 403);
            $privacy = db()->prepare('SELECT g.id FROM chat_groups g JOIN chat_group_members a ON a.group_id=g.id AND a.user_id=? JOIN chat_group_members b ON b.group_id=g.id AND b.user_id=? WHERE g.allow_private_message=0 LIMIT 1');
            $privacy->execute([$user['id'], $peerId]);
            if ($privacy->fetch()) jsonResponse(null, '共同群组已禁止成员互相私信', 403);
            $peer = db()->prepare('SELECT id,nickname FROM users WHERE id = ? LIMIT 1');
            $peer->execute([$peerId]);
            $peerUser = $peer->fetch();
            if (!$peerUser) jsonResponse(null, '用户不存在', 404);
            $statement = db()->prepare('SELECT id FROM chats WHERE user_id = ? AND peer_user_id = ? LIMIT 1');
            $statement->execute([$user['id'], $peerId]);
            $chat = $statement->fetch();
            if (!$chat) {
                $create = db()->prepare('INSERT INTO chats (user_id,peer_user_id,title) VALUES (?,?,?)');
                $create->execute([$user['id'], $peerId, $peerUser['nickname']]);
                $chatId = (int) db()->lastInsertId();
            } else {
                $chatId = (int) $chat['id'];
            }
            jsonResponse(['chat_id' => $chatId], '会话已创建', 201);

        case 'groups':
            $user = currentUser();
            $statement = db()->prepare('SELECT g.*, gm.role, gm.unread_count, gm.mute, gm.pinned, (SELECT COUNT(*) FROM chat_group_members count_members WHERE count_members.group_id=g.id) AS member_count, (SELECT gm2.content FROM chat_group_messages gm2 WHERE gm2.group_id=g.id ORDER BY gm2.id DESC LIMIT 1) AS last_message, (SELECT gm2.created_at FROM chat_group_messages gm2 WHERE gm2.group_id=g.id ORDER BY gm2.id DESC LIMIT 1) AS last_message_at FROM chat_groups g JOIN chat_group_members gm ON gm.group_id=g.id WHERE gm.user_id=? ORDER BY gm.pinned DESC,g.id DESC');
            $statement->execute([$user['id']]);
            jsonResponse($statement->fetchAll());

        case 'groups.info':
            $user = currentUser();
            $groupId = (int) ($_GET['group_id'] ?? 0);
            if ($groupId <= 0) jsonResponse(null, '缺少参数: group_id', 422);
            $statement = db()->prepare('SELECT g.id,g.group_code,g.owner_user_id,g.name,g.avatar_url,g.announcement,g.allow_member_details,g.allow_private_message,g.announcement_version,gm.role,COUNT(all_members.id) AS member_count FROM chat_groups g JOIN chat_group_members gm ON gm.group_id=g.id AND gm.user_id=? JOIN chat_group_members all_members ON all_members.group_id=g.id WHERE g.id=? GROUP BY g.id,g.group_code,g.owner_user_id,g.name,g.avatar_url,g.announcement,g.allow_member_details,g.allow_private_message,g.announcement_version,gm.role LIMIT 1');
            $statement->execute([$user['id'], $groupId]);
            $group = $statement->fetch();
            if (!$group) jsonResponse(null, '群组不存在或无权访问', 404);
            $role = (string) $group['role'];
            $group['member_count'] = (int) $group['member_count'];
            $group['permissions'] = [
                'view_info' => true,
                'view_members' => (int) $group['allow_member_details'] === 1 || in_array($role, ['owner', 'admin'], true),
                'update_group' => in_array($role, ['owner', 'admin'], true),
                'manage_settings' => in_array($role, ['owner', 'admin'], true),
                'invite_members' => in_array($role, ['owner', 'admin'], true),
                'transfer_owner' => $role === 'owner',
                'dissolve_group' => $role === 'owner',
            ];
            jsonResponse($group);

        case 'groups.search':
            currentUser();
            $groupCode = strtoupper(trim((string) ($_GET['group_code'] ?? '')));
            if (!preg_match('/^[A-Z0-9]{6}$/', $groupCode)) jsonResponse(null, '群号格式不正确', 422);
            $statement = db()->prepare('SELECT g.id,g.group_code,g.name,g.avatar_url,g.announcement,g.announcement_version,(SELECT COUNT(*) FROM chat_group_members gm WHERE gm.group_id=g.id) AS member_count FROM chat_groups g WHERE g.group_code=? LIMIT 1');
            $statement->execute([$groupCode]);
            $group = $statement->fetch();
            if (!$group) jsonResponse(null, '群组不存在', 404);
            $group['member_count'] = (int) $group['member_count'];
            jsonResponse($group);

        case 'groups.join':
            $user = currentUser();
            requireFields($body, ['group_code']);
            $groupCode = strtoupper(trim((string) $body['group_code']));
            if (!preg_match('/^[A-Z0-9]{6}$/', $groupCode)) jsonResponse(null, '群号格式不正确', 422);
            $pdo = db();
            $pdo->beginTransaction();
            $group = $pdo->prepare('SELECT id,group_code FROM chat_groups WHERE group_code=? FOR UPDATE');
            $group->execute([$groupCode]);
            $groupRow = $group->fetch();
            if (!$groupRow) { $pdo->rollBack(); jsonResponse(null, '群组不存在', 404); }
            $groupId = (int) $groupRow['id'];
            $member = $pdo->prepare('SELECT role FROM chat_group_members WHERE group_id=? AND user_id=? FOR UPDATE');
            $member->execute([$groupId, $user['id']]);
            $existingRole = $member->fetchColumn();
            if ($existingRole !== false) {
                $pdo->commit();
                jsonResponse(['group_id' => $groupId, 'group_code' => $groupRow['group_code'], 'role' => $existingRole, 'joined' => false], '你已在该群聊中');
            }
            $pdo->prepare('INSERT INTO chat_group_members (group_id,user_id,role) VALUES (?,? ,"member")')->execute([$groupId, $user['id']]);
            $pdo->commit();
            jsonResponse(['group_id' => $groupId, 'group_code' => $groupRow['group_code'], 'role' => 'member', 'joined' => true], '已加入群聊', 201);

        case 'groups.create':
            $user = currentUser();
            requireFields($body, ['name']);
            $memberIds = is_array($body['member_ids'] ?? null) ? array_map('intval', $body['member_ids']) : [];
            $memberIds[] = (int) $user['id'];
            $memberIds = array_values(array_unique(array_filter($memberIds)));
            if (count($memberIds) < 2) jsonResponse(null, '至少选择一位好友加入群聊', 422);
            $pdo = db();
            $pdo->beginTransaction();
            if ($memberIds) {
                $placeholders = implode(',', array_fill(0, count($memberIds), '?'));
                $existing = $pdo->prepare("SELECT id FROM users WHERE id IN ({$placeholders})");
                $existing->execute($memberIds);
                if (count($existing->fetchAll()) !== count($memberIds)) {
                    $pdo->rollBack();
                    jsonResponse(null, '群成员中包含不存在的用户', 422);
                }
            }
            $friendIds = array_values(array_diff($memberIds, [(int) $user['id']]));
            $friendPlaceholders = implode(',', array_fill(0, count($friendIds), '?'));
            $friends = $pdo->prepare("SELECT COUNT(*) FROM users target JOIN contacts mine ON mine.user_id=? AND mine.contact_user_id=target.id AND mine.status='accepted' JOIN contacts peer ON peer.user_id=target.id AND peer.contact_user_id=? AND peer.status='accepted' WHERE target.id IN ({$friendPlaceholders})");
            $friends->execute(array_merge([(int) $user['id'], (int) $user['id']], $friendIds));
            if ((int) $friends->fetchColumn() !== count($friendIds)) {
                $pdo->rollBack();
                jsonResponse(null, '只能邀请已接受的好友加入群聊', 403);
            }
            $announcement = array_key_exists('announcement', $body) ? trim((string) $body['announcement']) : null;
            $create = null;
            $groupCode = '';
            for ($attempt = 0; $attempt < 10; $attempt++) {
                $groupCode = generateGroupCode();
                try {
                    $create = $pdo->prepare('INSERT INTO chat_groups (group_code,owner_user_id,name,avatar_url,announcement,announcement_version) VALUES (?,?,?,?,?,?)');
                    $create->execute([$groupCode, $user['id'], trim((string) $body['name']), $body['avatar_url'] ?? null, $announcement, $announcement === null || $announcement === '' ? 0 : 1]);
                    break;
                } catch (PDOException $exception) {
                    if ((string) ($exception->errorInfo[0] ?? '') !== '23000' || (int) ($exception->errorInfo[1] ?? 0) !== 1062 || $attempt === 9) throw $exception;
                }
            }
            $groupId = (int) $pdo->lastInsertId();
            $member = $pdo->prepare('INSERT IGNORE INTO chat_group_members (group_id,user_id,role) VALUES (?,?,?)');
            foreach ($memberIds as $memberId) $member->execute([$groupId, $memberId, $memberId === (int) $user['id'] ? 'owner' : 'member']);
            $pdo->commit();
            jsonResponse(['group_id' => $groupId, 'group_code' => $groupCode, 'member_count' => count($memberIds)], '群聊已创建', 201);

        case 'groups.update':
            $user = currentUser();
            requireFields($body, ['group_id']);
            $groupId = (int) $body['group_id'];
            $pdo = db();
            $groupStatement = $pdo->prepare('SELECT * FROM chat_groups WHERE id=? FOR UPDATE');
            $pdo->beginTransaction();
            $groupStatement->execute([$groupId]);
            $group = $groupStatement->fetch();
            if (!$group) { $pdo->rollBack(); jsonResponse(null, '群组不存在', 404); }
            $roleStatement = $pdo->prepare('SELECT role FROM chat_group_members WHERE group_id=? AND user_id=? LIMIT 1');
            $roleStatement->execute([$groupId, $user['id']]);
            $role = $roleStatement->fetchColumn();
            if (!in_array($role, ['owner', 'admin'], true)) { $pdo->rollBack(); jsonResponse(null, '群组不存在或没有管理权限', 403); }
            $fields = [];
            $values = [];
            foreach (['name', 'avatar_url', 'announcement'] as $field) {
                if (array_key_exists($field, $body)) {
                    $value = $field === 'announcement' ? trim((string) $body[$field]) : $body[$field];
                    $fields[] = "{$field}=?";
                    $values[] = $value;
                    if ($field === 'announcement' && (string) $group['announcement'] !== (string) $value) {
                        $fields[] = 'announcement_version=announcement_version+1';
                    }
                }
            }
            if (!$fields) { $pdo->rollBack(); jsonResponse(null, '没有需要更新的群资料', 422); }
            $values[] = $groupId;
            $statement = $pdo->prepare('UPDATE chat_groups SET ' . implode(',', $fields) . ' WHERE id=?');
            $statement->execute($values);
            $pdo->commit();
            jsonResponse(null, '群资料已更新');

        case 'groups.members.add':
            $user = currentUser();
            requireFields($body, ['group_id', 'user_ids']);
            if (!is_array($body['user_ids'])) jsonResponse(null, 'user_ids 必须是数组', 422);
            $owner = db()->prepare('SELECT gm.role FROM chat_groups g JOIN chat_group_members gm ON gm.group_id=g.id AND gm.user_id=? WHERE g.id=? LIMIT 1');
            $owner->execute([$user['id'], (int) $body['group_id']]);
            $inviterRole = $owner->fetchColumn();
            if (!in_array($inviterRole, ['owner', 'admin'], true)) jsonResponse(null, '只有群主或管理员可以邀请成员', 403);
            $memberIds = array_values(array_unique(array_filter(array_map('intval', $body['user_ids']))));
            if (!$memberIds) jsonResponse(null, '至少选择一名成员', 422);
            $placeholders = implode(',', array_fill(0, count($memberIds), '?'));
            $existing = db()->prepare("SELECT id FROM users WHERE id IN ({$placeholders})");
            $existing->execute($memberIds);
            if (count($existing->fetchAll()) !== count($memberIds)) jsonResponse(null, '成员中包含不存在的用户', 422);
            $friends = db()->prepare("SELECT COUNT(*) FROM users target JOIN contacts mine ON mine.user_id=? AND mine.contact_user_id=target.id AND mine.status='accepted' JOIN contacts peer ON peer.user_id=target.id AND peer.contact_user_id=? AND peer.status='accepted' WHERE target.id IN ({$placeholders})");
            $friends->execute(array_merge([$user['id'], $user['id']], $memberIds));
            if ((int) $friends->fetchColumn() !== count($memberIds)) jsonResponse(null, '只能邀请已接受的好友加入群聊', 403);
            $insert = db()->prepare('INSERT IGNORE INTO chat_group_members (group_id,user_id,role) VALUES (?,? ,"member")');
            $added = 0;
            foreach ($memberIds as $memberId) {
                $insert->execute([(int) $body['group_id'], $memberId]);
                if ($insert->rowCount() > 0) {
                    $added++;
                    notifyWebSocket(['type' => 'group.joined', 'user_id' => $memberId, 'group_id' => (int) $body['group_id']]);
                }
            }
            jsonResponse(['added' => $added], '群成员已更新');

        case 'groups.members.role':
        case 'groups.members.remove':
        case 'groups.members.mute':
            $user = currentUser();
            requireFields($body, ['group_id', 'user_id']);
            $groupId = (int) $body['group_id'];
            $targetId = (int) $body['user_id'];
            $owner = db()->prepare('SELECT owner_user_id FROM chat_groups WHERE id=? LIMIT 1');
            $owner->execute([$groupId]);
            $group = $owner->fetch();
            if (!$group) jsonResponse(null, '群组不存在', 404);
            $actor = db()->prepare('SELECT role FROM chat_group_members WHERE group_id=? AND user_id=? LIMIT 1');
            $actor->execute([$groupId, $user['id']]);
            $actorRole = (string) $actor->fetchColumn();
            if (!in_array($actorRole, ['owner', 'admin'], true)) jsonResponse(null, '只有群主或管理员可以管理成员', 403);
            $member = db()->prepare('SELECT role FROM chat_group_members WHERE group_id=? AND user_id=? LIMIT 1');
            $member->execute([$groupId, $targetId]);
            $target = $member->fetch();
            if (!$target) jsonResponse(null, '群成员不存在', 404);
            if ($target['role'] === 'owner') jsonResponse(null, '不能修改群主权限', 409);
            if ($actorRole === 'admin' && $target['role'] === 'admin') jsonResponse(null, '管理员不能管理其他管理员', 403);
            if ($action === 'groups.members.role') {
                requireFields($body, ['role']);
                $role = (string) $body['role'];
                if (!in_array($role, ['admin', 'member'], true)) jsonResponse(null, '角色仅支持 admin 或 member', 422);
                if ($actorRole !== 'owner' && $role === 'admin') jsonResponse(null, '只有群主可以设置管理员', 403);
                db()->prepare('UPDATE chat_group_members SET role=? WHERE group_id=? AND user_id=?')->execute([$role, $groupId, $targetId]);
                jsonResponse(['role' => $role], '成员角色已更新');
            }
            if ($action === 'groups.members.remove') {
                db()->prepare('DELETE FROM chat_group_members WHERE group_id=? AND user_id=?')->execute([$groupId, $targetId]);
                notifyWebSocket(['type' => 'group.member_removed', 'user_id' => $targetId, 'group_id' => $groupId]);
                jsonResponse(null, '成员已移出群聊');
            }
            requireFields($body, ['mute']);
            db()->prepare('UPDATE chat_group_members SET mute=? WHERE group_id=? AND user_id=?')->execute([(int) ((bool) $body['mute']), $groupId, $targetId]);
            jsonResponse(['mute' => (int) ((bool) $body['mute'])], '成员禁言状态已更新');

        case 'groups.members':
            $user = currentUser();
            $groupId = (int) ($_GET['group_id'] ?? 0);
            $access = db()->prepare('SELECT gm.role,g.allow_member_details FROM chat_group_members gm JOIN chat_groups g ON g.id=gm.group_id WHERE gm.group_id=? AND gm.user_id=? LIMIT 1');
            $access->execute([$groupId, $user['id']]);
            $membership = $access->fetch();
            if (!$membership) jsonResponse(null, '无权访问该群组', 403);
            if ((int) $membership['allow_member_details'] === 0 && !in_array($membership['role'], ['owner', 'admin'], true)) jsonResponse(null, '群主已关闭成员详情查看', 403);
            $keyword = trim((string) ($_GET['q'] ?? ''));
            $sql = 'SELECT u.id,u.nickname,u.spx_id,u.avatar_url,gm.role,gm.mute,COALESCE(contact.remark,"") AS contact_remark,IF(contact.id IS NULL,0,1) AS is_contact FROM chat_group_members gm JOIN users u ON u.id=gm.user_id LEFT JOIN contacts contact ON contact.user_id=? AND contact.contact_user_id=u.id WHERE gm.group_id=?';
            $parameters = [$user['id'], $groupId];
            if ($keyword !== '') {
                $sql .= ' AND (u.nickname LIKE ? OR u.spx_id LIKE ? OR CAST(u.id AS CHAR) LIKE ?)';
                $like = '%' . $keyword . '%';
                $parameters[] = $like;
                $parameters[] = $like;
                $parameters[] = $like;
            }
            $sql .= ' ORDER BY FIELD(gm.role,"owner","admin","member"),gm.id ASC';
            $statement = db()->prepare($sql);
            $statement->execute($parameters);
            jsonResponse($statement->fetchAll());

        case 'groups.messages':
            $user = currentUser();
            $groupId = (int) ($_GET['group_id'] ?? 0);
            $access = db()->prepare('SELECT 1 FROM chat_group_members WHERE group_id=? AND user_id=? LIMIT 1');
            $access->execute([$groupId, $user['id']]);
            if (!$access->fetch()) jsonResponse(null, '无权访问该群组', 403);
            $afterId = max(0, (int) ($_GET['after_id'] ?? 0));
            if ($afterId > 0) {
                $statement = db()->prepare('SELECT gm.*,u.nickname,u.avatar_url FROM chat_group_messages gm JOIN users u ON u.id=gm.sender_id WHERE gm.group_id=? AND gm.id>? ORDER BY gm.id ASC LIMIT 200');
                $statement->execute([$groupId, $afterId]);
                $messages = $statement->fetchAll();
                foreach ($messages as &$message) $message['mention_user_ids'] = json_decode((string) ($message['mention_user_ids'] ?? '[]'), true) ?: [];
                unset($message);
                jsonResponse($messages);
            }
            $statement = db()->prepare('SELECT gm.*,u.nickname,u.avatar_url FROM chat_group_messages gm JOIN users u ON u.id=gm.sender_id WHERE gm.group_id=? ORDER BY gm.id DESC LIMIT 200');
            $statement->execute([$groupId]);
            $messages = array_reverse($statement->fetchAll());
            foreach ($messages as &$message) $message['mention_user_ids'] = json_decode((string) ($message['mention_user_ids'] ?? '[]'), true) ?: [];
            unset($message);
            jsonResponse($messages);

        case 'groups.messages.send':
            $user = currentUser();
            requireFields($body, ['group_id', 'content']);
            $content = trim((string) $body['content']);
            if ($content === '') jsonResponse(null, '消息内容不能为空', 422);
            $messageType = (string) ($body['message_type'] ?? 'text');
            $mediaUrl = trim((string) ($body['media_url'] ?? '')) ?: null;
            $clientMessageId = trim((string) ($body['client_message_id'] ?? '')) ?: null;
            $requestedMentions = is_array($body['mention_user_ids'] ?? null) ? array_values(array_unique(array_filter(array_map('intval', $body['mention_user_ids'])))) : [];
            if (!in_array($messageType, ['text', 'image', 'video', 'voice'], true)) jsonResponse(null, '消息类型不正确', 422);
            if ($messageType !== 'text' && !$mediaUrl) jsonResponse(null, '媒体消息缺少地址', 422);
            $access = db()->prepare('SELECT role,mute FROM chat_group_members WHERE group_id=? AND user_id=? LIMIT 1');
            $access->execute([(int) $body['group_id'], $user['id']]);
            $membership = $access->fetch();
            if (!$membership) jsonResponse(null, '无权访问该群组', 403);
            if ((int) $membership['mute'] === 1 && !in_array($membership['role'], ['owner', 'admin'], true)) jsonResponse(null, '你已被群管理员禁言', 403);
            if ($clientMessageId !== null) {
                $existing = db()->prepare('SELECT id FROM chat_group_messages WHERE group_id=? AND sender_id=? AND client_message_id=? LIMIT 1');
                $existing->execute([(int) $body['group_id'], $user['id'], $clientMessageId]);
                $existingId = $existing->fetchColumn();
                if ($existingId) jsonResponse(['id' => (int) $existingId, 'client_message_id' => $clientMessageId, 'duplicate' => true], '消息已发送');
            }
            $validMentions = [];
            if ($requestedMentions) {
                $placeholders = implode(',', array_fill(0, count($requestedMentions), '?'));
                $mentionQuery = db()->prepare("SELECT user_id FROM chat_group_members WHERE group_id=? AND user_id IN ({$placeholders})");
                $mentionQuery->execute(array_merge([(int) $body['group_id']], $requestedMentions));
                $validMentions = array_map('intval', $mentionQuery->fetchAll(PDO::FETCH_COLUMN));
            }
            $statement = db()->prepare('INSERT INTO chat_group_messages (group_id,sender_id,client_message_id,content,message_type,media_url,mention_user_ids) VALUES (?,?,?,?,?,?,?)');
            $statement->execute([(int) $body['group_id'], $user['id'], $clientMessageId, $content, $messageType, $mediaUrl, json_encode($validMentions)]);
            $messageId = (int) db()->lastInsertId();
            $message = db()->prepare('SELECT gm.*,u.nickname,u.avatar_url FROM chat_group_messages gm JOIN users u ON u.id=gm.sender_id WHERE gm.id=? LIMIT 1');
            $message->execute([$messageId]);
            $messageData = $message->fetch() ?: ['id' => $messageId, 'group_id' => (int) $body['group_id'], 'sender_id' => (int) $user['id'], 'content' => $content, 'message_type' => $messageType, 'media_url' => $mediaUrl];
            $messageData['mention_user_ids'] = $validMentions;
            $members = db()->prepare('SELECT user_id FROM chat_group_members WHERE group_id=? AND user_id<>?');
            $members->execute([(int) $body['group_id'], $user['id']]);
            foreach ($members->fetchAll() as $member) {
                db()->prepare('UPDATE chat_group_members SET unread_count=unread_count+1 WHERE group_id=? AND user_id=?')->execute([(int) $body['group_id'], $member['user_id']]);
                notifyWebSocket(['type' => 'message', 'user_id' => (int) $member['user_id'], 'group_id' => (int) $body['group_id'], 'message' => $messageData]);
            }
            notifyWebSocket(['type' => 'message', 'user_id' => (int) $user['id'], 'group_id' => (int) $body['group_id'], 'message' => $messageData]);
            jsonResponse(['id' => $messageId, 'client_message_id' => $clientMessageId, 'message_type' => $messageType, 'media_url' => $mediaUrl], '发送成功', 201);

        case 'groups.messages.read':
            $user = currentUser();
            requireFields($body, ['group_id']);
            $access = db()->prepare('SELECT 1 FROM chat_group_members WHERE group_id=? AND user_id=? LIMIT 1');
            $access->execute([(int) $body['group_id'], $user['id']]);
            if (!$access->fetch()) jsonResponse(null, '无权访问该群组', 403);
            db()->prepare('UPDATE chat_group_members SET unread_count=0 WHERE group_id=? AND user_id=?')->execute([(int) $body['group_id'], $user['id']]);
            jsonResponse(null, '群消息已读');

        case 'groups.settings':
            $user = currentUser();
            $groupId = (int) ($_GET['group_id'] ?? $body['group_id'] ?? 0);
            if ($groupId <= 0) jsonResponse(null, '缺少参数: group_id', 422);
            $access = db()->prepare('SELECT gm.role,gm.mute,gm.pinned,g.allow_member_details,g.allow_private_message FROM chat_group_members gm JOIN chat_groups g ON g.id=gm.group_id WHERE gm.group_id=? AND gm.user_id=? LIMIT 1');
            $access->execute([$groupId, $user['id']]);
            $settings = $access->fetch();
            if (!$settings) jsonResponse(null, '无权访问该群组', 403);
            if ($method === 'GET') {
                jsonResponse([
                    'group_id' => $groupId,
                    'mute' => (int) $settings['mute'],
                    'pinned' => (int) $settings['pinned'],
                    'allow_member_details' => (int) $settings['allow_member_details'],
                    'allow_private_message' => (int) $settings['allow_private_message'],
                ]);
            }
            $memberFields = [];
            $memberValues = [];
            foreach (['mute', 'pinned'] as $field) {
                if (array_key_exists($field, $body)) {
                    $memberFields[] = "{$field}=?";
                    $memberValues[] = !empty($body[$field]) ? 1 : 0;
                }
            }
            $groupFields = [];
            $groupValues = [];
            foreach (['allow_member_details', 'allow_private_message'] as $field) {
                if (array_key_exists($field, $body)) {
                    $groupFields[] = "{$field}=?";
                    $groupValues[] = !empty($body[$field]) ? 1 : 0;
                }
            }
            if ($groupFields && !in_array($settings['role'], ['owner', 'admin'], true)) jsonResponse(null, '只有群主或管理员可以修改群敏感设置', 403);
            if (!$memberFields && !$groupFields) jsonResponse(null, '没有可更新的设置', 422);
            $pdo = db();
            $pdo->beginTransaction();
            if ($memberFields) {
                $memberValues[] = $groupId;
                $memberValues[] = $user['id'];
                $pdo->prepare('UPDATE chat_group_members SET ' . implode(',', $memberFields) . ' WHERE group_id=? AND user_id=?')->execute($memberValues);
            }
            if ($groupFields) {
                $groupValues[] = $groupId;
                $pdo->prepare('UPDATE chat_groups SET ' . implode(',', $groupFields) . ' WHERE id=?')->execute($groupValues);
            }
            $pdo->commit();
            jsonResponse(['group_id' => $groupId], '群设置已保存');

        case 'groups.leave':
            $user = currentUser();
            requireFields($body, ['group_id']);
            $groupId = (int) $body['group_id'];
            $pdo = db();
            $group = $pdo->prepare('SELECT owner_user_id FROM chat_groups WHERE id=? LIMIT 1');
            $group->execute([$groupId]);
            $ownerId = (int) $group->fetchColumn();
            if ($ownerId <= 0) jsonResponse(null, '群聊不存在', 404);
            $member = $pdo->prepare('SELECT 1 FROM chat_group_members WHERE group_id=? AND user_id=?');
            $member->execute([$groupId, $user['id']]);
            if (!$member->fetch()) jsonResponse(null, '你已不在该群聊中', 404);
            $count = $pdo->prepare('SELECT COUNT(*) FROM chat_group_members WHERE group_id=?');
            $count->execute([$groupId]);
            if ($ownerId === (int) $user['id'] && (int) $count->fetchColumn() > 1) jsonResponse(null, '群主请先转让群主身份后再退出', 409);
            $pdo->beginTransaction();
            $pdo->prepare('DELETE FROM chat_group_members WHERE group_id=? AND user_id=?')->execute([$groupId, $user['id']]);
            $remaining = $pdo->prepare('SELECT COUNT(*) FROM chat_group_members WHERE group_id=?');
            $remaining->execute([$groupId]);
            if ((int) $remaining->fetchColumn() === 0) $pdo->prepare('DELETE FROM chat_groups WHERE id=?')->execute([$groupId]);
            $pdo->commit();
            jsonResponse(null, '已退出群聊');

        case 'groups.transfer':
            $user = currentUser();
            requireFields($body, ['group_id', 'owner_user_id']);
            $groupId = (int) $body['group_id'];
            $newOwnerId = (int) $body['owner_user_id'];
            if ($newOwnerId <= 0 || $newOwnerId === (int) $user['id']) jsonResponse(null, '新群主必须是其他成员', 422);
            $pdo = db();
            $pdo->beginTransaction();
            $group = $pdo->prepare('SELECT owner_user_id FROM chat_groups WHERE id=? FOR UPDATE');
            $group->execute([$groupId]);
            $groupRow = $group->fetch();
            if (!$groupRow) { $pdo->rollBack(); jsonResponse(null, '群组不存在', 404); }
            if ((int) $groupRow['owner_user_id'] !== (int) $user['id']) { $pdo->rollBack(); jsonResponse(null, '只有群主可以转让群主身份', 403); }
            $target = $pdo->prepare('SELECT role FROM chat_group_members WHERE group_id=? AND user_id=? FOR UPDATE');
            $target->execute([$groupId, $newOwnerId]);
            if (!$target->fetch()) { $pdo->rollBack(); jsonResponse(null, '新群主必须是群成员', 422); }
            $pdo->prepare('UPDATE chat_groups SET owner_user_id=? WHERE id=?')->execute([$newOwnerId, $groupId]);
            $pdo->prepare('UPDATE chat_group_members SET role="member" WHERE group_id=? AND user_id=?')->execute([$groupId, $user['id']]);
            $pdo->prepare('UPDATE chat_group_members SET role="owner" WHERE group_id=? AND user_id=?')->execute([$groupId, $newOwnerId]);
            $pdo->commit();
            jsonResponse(['group_id' => $groupId, 'owner_user_id' => $newOwnerId], '群主已转让');

        case 'groups.dissolve':
            $user = currentUser();
            requireFields($body, ['group_id']);
            $groupId = (int) $body['group_id'];
            $pdo = db();
            $pdo->beginTransaction();
            $group = $pdo->prepare('SELECT owner_user_id FROM chat_groups WHERE id=? FOR UPDATE');
            $group->execute([$groupId]);
            $groupRow = $group->fetch();
            if (!$groupRow) { $pdo->rollBack(); jsonResponse(null, '群组不存在', 404); }
            if ((int) $groupRow['owner_user_id'] !== (int) $user['id']) { $pdo->rollBack(); jsonResponse(null, '只有群主可以解散群聊', 403); }
            $members = $pdo->prepare('SELECT user_id FROM chat_group_members WHERE group_id=?');
            $members->execute([$groupId]);
            $memberIds = array_map('intval', $members->fetchAll(PDO::FETCH_COLUMN));
            $pdo->prepare('DELETE FROM chat_groups WHERE id=?')->execute([$groupId]);
            $pdo->commit();
            foreach ($memberIds as $memberId) notifyWebSocket(['type' => 'group.deleted', 'user_id' => $memberId, 'group_id' => $groupId]);
            jsonResponse(['group_id' => $groupId], '群聊已解散');

        case 'groups.messages.edit':
            $user = currentUser();
            requireFields($body, ['group_id', 'message_id', 'content']);
            $content = trim((string) $body['content']);
            if ($content === '') jsonResponse(null, '消息内容不能为空', 422);
            $pdo = db();
            $message = $pdo->prepare('SELECT id FROM chat_group_messages WHERE id=? AND group_id=? AND sender_id=? AND message_type="text" LIMIT 1');
            $message->execute([(int) $body['message_id'], (int) $body['group_id'], $user['id']]);
            if (!$message->fetch()) jsonResponse(null, '只能编辑自己发送的文本消息', 403);
            $pdo->prepare('UPDATE chat_group_messages SET content=? WHERE id=?')->execute([$content, (int) $body['message_id']]);
            $statement = $pdo->prepare('SELECT gm.*,u.nickname,u.avatar_url FROM chat_group_messages gm JOIN users u ON u.id=gm.sender_id WHERE gm.id=?');
            $statement->execute([(int) $body['message_id']]);
            $messageData = $statement->fetch();
            $members = $pdo->prepare('SELECT user_id FROM chat_group_members WHERE group_id=?');
            $members->execute([(int) $body['group_id']]);
            foreach ($members->fetchAll() as $member) notifyWebSocket(['type' => 'message.updated', 'user_id' => (int) $member['user_id'], 'group_id' => (int) $body['group_id'], 'message' => $messageData]);
            jsonResponse($messageData, '消息已编辑');

        case 'groups.messages.delete':
            $user = currentUser();
            requireFields($body, ['group_id', 'message_id']);
            $pdo = db();
            $message = $pdo->prepare('SELECT id FROM chat_group_messages WHERE id=? AND group_id=? AND sender_id=? LIMIT 1');
            $message->execute([(int) $body['message_id'], (int) $body['group_id'], $user['id']]);
            if (!$message->fetch()) jsonResponse(null, '只能删除自己发送的消息', 403);
            $pdo->prepare('DELETE FROM chat_group_messages WHERE id=?')->execute([(int) $body['message_id']]);
            $members = $pdo->prepare('SELECT user_id FROM chat_group_members WHERE group_id=?');
            $members->execute([(int) $body['group_id']]);
            foreach ($members->fetchAll() as $member) notifyWebSocket(['type' => 'message.deleted', 'user_id' => (int) $member['user_id'], 'group_id' => (int) $body['group_id'], 'message_id' => (int) $body['message_id']]);
            jsonResponse(null, '消息已为所有人删除');

        case 'chats.settings':
            $user = currentUser();
            requireFields($body, ['chat_id']);
            $chatId = (int) $body['chat_id'];
            $owned = db()->prepare('SELECT id FROM chats WHERE id = ? AND user_id = ? LIMIT 1');
            $owned->execute([$chatId, $user['id']]);
            if (!$owned->fetch()) jsonResponse(null, '会话不存在', 404);
            $allowed = ['mute', 'pinned', 'blocked', 'background_url'];
            $fields = [];
            $setValues = [];
            foreach ($allowed as $field) {
                if (array_key_exists($field, $body)) {
                    $fields[] = "{$field} = ?";
                    $setValues[] = $body[$field];
                }
            }
            if (!$fields) jsonResponse(null, '没有可更新的设置', 422);
            db()->prepare('INSERT INTO chat_settings (user_id,chat_id) VALUES (?,?) ON DUPLICATE KEY UPDATE ' . implode(',', $fields))->execute(array_merge([$user['id'], $chatId], $setValues));
            jsonResponse(['chat_id' => $chatId], '会话设置已保存');

        case 'chats.settings.get':
            $user = currentUser();
            $chatId = (int) ($_GET['chat_id'] ?? 0);
            if ($chatId <= 0) jsonResponse(null, '缺少参数: chat_id', 422);
            $owned = db()->prepare('SELECT id FROM chats WHERE id=? AND user_id=? LIMIT 1');
            $owned->execute([$chatId, $user['id']]);
            if (!$owned->fetch()) jsonResponse(null, '会话不存在', 404);
            $statement = db()->prepare('SELECT * FROM chat_settings WHERE user_id=? AND chat_id=? LIMIT 1');
            $statement->execute([$user['id'], $chatId]);
            jsonResponse($statement->fetch() ?: ['user_id' => $user['id'], 'chat_id' => $chatId, 'mute' => 0, 'pinned' => 0, 'blocked' => 0, 'background_url' => null]);

        case 'messages.clear':
            $user = currentUser();
            requireFields($body, ['chat_id']);
            db()->prepare('DELETE FROM messages WHERE chat_id = ? AND user_id = ?')->execute([(int) $body['chat_id'], $user['id']]);
            jsonResponse(null, '聊天记录已清空');

        case 'messages.clear.both':
            $user = currentUser();
            requireFields($body, ['chat_id']);
            $pdo = db();
            $chat = $pdo->prepare('SELECT id,peer_user_id FROM chats WHERE id=? AND user_id=? LIMIT 1');
            $chat->execute([(int) $body['chat_id'], $user['id']]);
            $chatRow = $chat->fetch();
            if (!$chatRow) jsonResponse(null, '会话不存在', 404);
            $peerChat = $pdo->prepare('SELECT id FROM chats WHERE user_id=? AND peer_user_id=? LIMIT 1');
            $peerChat->execute([(int) $chatRow['peer_user_id'], $user['id']]);
            $peerChatId = (int) $peerChat->fetchColumn();
            $pdo->beginTransaction();
            $pdo->prepare('DELETE FROM messages WHERE (chat_id=? AND user_id=?) OR (chat_id=? AND user_id=?)')->execute([(int) $body['chat_id'], $user['id'], $peerChatId, (int) $chatRow['peer_user_id']]);
            $pdo->prepare('UPDATE chats SET last_message=NULL,updated_at=NOW() WHERE id IN (?,?)')->execute([(int) $body['chat_id'], $peerChatId]);
            $pdo->commit();
            jsonResponse(['deleted_chat_ids' => array_values(array_filter([(int) $body['chat_id'], $peerChatId]))], '双方聊天记录已清空');

        case 'messages.read':
            $user = currentUser();
            requireFields($body, ['chat_id']);
            db()->prepare('UPDATE chats SET unread_count=0 WHERE id=? AND user_id=?')->execute([(int) $body['chat_id'], $user['id']]);
            jsonResponse(null, '消息已读');

        case 'messages.edit':
            $user = currentUser();
            requireFields($body, ['chat_id', 'message_id', 'content']);
            $content = trim((string) $body['content']);
            if ($content === '') jsonResponse(null, '消息内容不能为空', 422);
            $pdo = db();
            $chat = $pdo->prepare('SELECT id,peer_user_id FROM chats WHERE id=? AND user_id=? LIMIT 1');
            $chat->execute([(int) $body['chat_id'], $user['id']]);
            $chatRow = $chat->fetch();
            if (!$chatRow) jsonResponse(null, '会话不存在', 404);
            $find = $pdo->prepare('SELECT id,client_message_id FROM messages WHERE id=? AND chat_id=? AND user_id=? AND sender_id=? AND message_type="text" LIMIT 1');
            $find->execute([(int) $body['message_id'], (int) $body['chat_id'], $user['id'], $user['id']]);
            $messageRow = $find->fetch();
            if (!$messageRow) jsonResponse(null, '只能编辑自己发送的文本消息', 403);
            if (!$messageRow['client_message_id']) jsonResponse(null, '该旧消息不支持编辑', 409);
            $peerChat = $pdo->prepare('SELECT id FROM chats WHERE user_id=? AND peer_user_id=? LIMIT 1');
            $peerChat->execute([(int) $chatRow['peer_user_id'], $user['id']]);
            $peerChatId = (int) $peerChat->fetchColumn();
            $pdo->prepare('UPDATE messages SET content=? WHERE sender_id=? AND client_message_id=?')->execute([$content, $user['id'], $messageRow['client_message_id']]);
            foreach ([[ (int) $user['id'], (int) $body['chat_id'] ], [ (int) $chatRow['peer_user_id'], $peerChatId ]] as [$ownerId, $ownerChatId]) {
                if ($ownerChatId <= 0) continue;
                $last = $pdo->prepare('SELECT content,message_type FROM messages WHERE user_id=? AND chat_id=? ORDER BY id DESC LIMIT 1');
                $last->execute([$ownerId, $ownerChatId]);
                $latest = $last->fetch();
                $preview = !$latest ? null : ($latest['message_type'] === 'image' ? '[图片]' : ($latest['message_type'] === 'video' ? '[视频]' : ($latest['message_type'] === 'voice' ? '[语音]' : $latest['content'])));
                $pdo->prepare('UPDATE chats SET last_message=?,updated_at=NOW() WHERE id=? AND user_id=?')->execute([$preview, $ownerChatId, $ownerId]);
            }
            $statement = $pdo->prepare('SELECT m.*,u.nickname,u.avatar_url FROM messages m JOIN users u ON u.id=m.sender_id WHERE m.id=?');
            $statement->execute([(int) $body['message_id']]);
            $messageData = $statement->fetch();
            notifyWebSocket(['type' => 'message.updated', 'user_id' => (int) $user['id'], 'chat_id' => (int) $body['chat_id'], 'message' => $messageData]);
            if ($peerChatId > 0) {
                $peerMessage = $pdo->prepare('SELECT m.*,u.nickname,u.avatar_url FROM messages m JOIN users u ON u.id=m.sender_id WHERE m.user_id=? AND m.sender_id=? AND m.client_message_id=? LIMIT 1');
                $peerMessage->execute([(int) $chatRow['peer_user_id'], $user['id'], $messageRow['client_message_id']]);
                notifyWebSocket(['type' => 'message.updated', 'user_id' => (int) $chatRow['peer_user_id'], 'chat_id' => $peerChatId, 'message' => $peerMessage->fetch() ?: $messageData]);
            }
            jsonResponse($messageData, '消息已编辑');

        case 'messages.delete':
            $user = currentUser();
            requireFields($body, ['chat_id', 'message_id']);
            $pdo = db();
            $chat = $pdo->prepare('SELECT id,peer_user_id FROM chats WHERE id=? AND user_id=? LIMIT 1');
            $chat->execute([(int) $body['chat_id'], $user['id']]);
            $chatRow = $chat->fetch();
            if (!$chatRow) jsonResponse(null, '会话不存在', 404);
            $find = $pdo->prepare('SELECT id,client_message_id FROM messages WHERE id=? AND chat_id=? AND user_id=? AND sender_id=? LIMIT 1');
            $find->execute([(int) $body['message_id'], (int) $body['chat_id'], $user['id'], $user['id']]);
            $messageRow = $find->fetch();
            if (!$messageRow) jsonResponse(null, '只能为所有人删除自己发送的消息', 403);
            if (!$messageRow['client_message_id']) jsonResponse(null, '该旧消息不支持为所有人删除', 409);
            $peerChat = $pdo->prepare('SELECT id FROM chats WHERE user_id=? AND peer_user_id=? LIMIT 1');
            $peerChat->execute([(int) $chatRow['peer_user_id'], $user['id']]);
            $peerChatId = (int) $peerChat->fetchColumn();
            $peerMessageId = 0;
            if ($peerChatId > 0) {
                $peerMessage = $pdo->prepare('SELECT id FROM messages WHERE user_id=? AND sender_id=? AND client_message_id=? LIMIT 1');
                $peerMessage->execute([(int) $chatRow['peer_user_id'], $user['id'], $messageRow['client_message_id']]);
                $peerMessageId = (int) $peerMessage->fetchColumn();
            }
            $pdo->beginTransaction();
            $pdo->prepare('DELETE FROM messages WHERE sender_id=? AND client_message_id=?')->execute([$user['id'], $messageRow['client_message_id']]);
            foreach ([[ (int) $user['id'], (int) $body['chat_id'] ], [ (int) $chatRow['peer_user_id'], $peerChatId ]] as [$ownerId, $ownerChatId]) {
                if ($ownerChatId <= 0) continue;
                $last = $pdo->prepare('SELECT content,message_type FROM messages WHERE user_id=? AND chat_id=? ORDER BY id DESC LIMIT 1');
                $last->execute([$ownerId, $ownerChatId]);
                $latest = $last->fetch();
                $preview = !$latest ? null : ($latest['message_type'] === 'image' ? '[图片]' : ($latest['message_type'] === 'video' ? '[视频]' : ($latest['message_type'] === 'voice' ? '[语音]' : $latest['content'])));
                $pdo->prepare('UPDATE chats SET last_message=?,updated_at=NOW() WHERE id=? AND user_id=?')->execute([$preview, $ownerChatId, $ownerId]);
            }
            $pdo->commit();
            notifyWebSocket(['type' => 'message.deleted', 'user_id' => (int) $user['id'], 'chat_id' => (int) $body['chat_id'], 'message_id' => (int) $body['message_id']]);
            if ($peerMessageId > 0) notifyWebSocket(['type' => 'message.deleted', 'user_id' => (int) $chatRow['peer_user_id'], 'chat_id' => $peerChatId, 'message_id' => $peerMessageId]);
            jsonResponse(null, '消息已为所有人删除');

        case 'chats.delete':
            $user = currentUser();
            requireFields($body, ['chat_id']);
            db()->prepare('DELETE FROM chats WHERE id=? AND user_id=?')->execute([(int) $body['chat_id'], $user['id']]);
            jsonResponse(null, '会话已删除');

        case 'messages.search':
            $user = currentUser();
            $keyword = trim((string) ($_GET['q'] ?? ''));
            if ($keyword === '') jsonResponse([]);
            $like = '%' . $keyword . '%';
            $chatId = (int) ($_GET['chat_id'] ?? 0);
            $groupId = (int) ($_GET['group_id'] ?? 0);
            if ($chatId > 0) {
                $owned = db()->prepare('SELECT c.id,c.peer_user_id,COALESCE(NULLIF(ct.remark,""),u.nickname) AS conversation_name FROM chats c JOIN users u ON u.id=c.peer_user_id LEFT JOIN contacts ct ON ct.user_id=c.user_id AND ct.contact_user_id=c.peer_user_id WHERE c.id=? AND c.user_id=? LIMIT 1');
                $owned->execute([$chatId, $user['id']]);
                $chat = $owned->fetch();
                if (!$chat) jsonResponse(null, '会话不存在', 404);
                $statement = db()->prepare('SELECT "chat" AS kind,m.id,m.chat_id,0 AS group_id,c.peer_user_id AS conversation_user_id,? AS conversation_name,m.content,m.message_type,m.created_at FROM messages m JOIN chats c ON c.id=m.chat_id AND c.user_id=m.user_id WHERE m.user_id=? AND m.chat_id=? AND m.content LIKE ? ORDER BY m.id DESC LIMIT 100');
                $statement->execute([$chat['conversation_name'], $user['id'], $chatId, $like]);
                jsonResponse($statement->fetchAll());
            }
            if ($groupId > 0) {
                $access = db()->prepare('SELECT g.name FROM chat_groups g JOIN chat_group_members gm ON gm.group_id=g.id WHERE g.id=? AND gm.user_id=? LIMIT 1');
                $access->execute([$groupId, $user['id']]);
                $groupName = $access->fetchColumn();
                if (!$groupName) jsonResponse(null, '无权访问该群组', 403);
                $statement = db()->prepare('SELECT "group" AS kind,gm.id,0 AS chat_id,gm.group_id,0 AS conversation_user_id,? AS conversation_name,gm.content,gm.message_type,gm.created_at FROM chat_group_messages gm WHERE gm.group_id=? AND gm.content LIKE ? ORDER BY gm.id DESC LIMIT 100');
                $statement->execute([$groupName, $groupId, $like]);
                jsonResponse($statement->fetchAll());
            }
            $statement = db()->prepare('SELECT "chat" AS kind,m.id,m.chat_id,0 AS group_id,c.peer_user_id AS conversation_user_id,COALESCE(NULLIF(ct.remark,""),u.nickname) AS conversation_name,m.content,m.message_type,m.created_at FROM messages m JOIN chats c ON c.id=m.chat_id AND c.user_id=m.user_id JOIN users u ON u.id=c.peer_user_id LEFT JOIN contacts ct ON ct.user_id=m.user_id AND ct.contact_user_id=c.peer_user_id WHERE m.user_id=? AND m.content LIKE ? UNION ALL SELECT "group" AS kind,gm.id,0 AS chat_id,gm.group_id,0 AS conversation_user_id,g.name AS conversation_name,gm.content,gm.message_type,gm.created_at FROM chat_group_messages gm JOIN chat_group_members member ON member.group_id=gm.group_id AND member.user_id=? JOIN chat_groups g ON g.id=gm.group_id WHERE gm.content LIKE ? ORDER BY created_at DESC LIMIT 100');
            $statement->execute([$user['id'], $like, $user['id'], $like]);
            jsonResponse($statement->fetchAll());

        case 'messages':
            $user = currentUser();
            $chatId = (int) ($_GET['chat_id'] ?? 0);
            $afterId = max(0, (int) ($_GET['after_id'] ?? 0));
            if ($afterId > 0) {
                $statement = db()->prepare('SELECT m.*,u.nickname,u.avatar_url FROM messages m JOIN users u ON u.id=m.sender_id WHERE m.chat_id = ? AND m.user_id = ? AND m.id>? ORDER BY m.id ASC LIMIT 200');
                $statement->execute([$chatId, $user['id'], $afterId]);
                jsonResponse($statement->fetchAll());
            }
            $statement = db()->prepare('SELECT m.*,u.nickname,u.avatar_url FROM messages m JOIN users u ON u.id=m.sender_id WHERE m.chat_id = ? AND m.user_id = ? ORDER BY m.id DESC LIMIT 200');
            $statement->execute([$chatId, $user['id']]);
            jsonResponse(array_reverse($statement->fetchAll()));

        case 'messages.send':
            $user = currentUser();
            requireFields($body, ['chat_id', 'content']);
            $chatStatement = db()->prepare('SELECT * FROM chats WHERE id = ? AND user_id = ? LIMIT 1');
            $chatStatement->execute([(int) $body['chat_id'], $user['id']]);
            $chat = $chatStatement->fetch();
            if (!$chat) jsonResponse(null, '会话不存在', 404);
            $contact = db()->prepare('SELECT 1 FROM contacts mine JOIN contacts peer ON peer.user_id=mine.contact_user_id AND peer.contact_user_id=mine.user_id WHERE mine.user_id=? AND mine.contact_user_id=? AND mine.status="accepted" AND peer.status="accepted" LIMIT 1');
            $contact->execute([$user['id'], $chat['peer_user_id']]);
            if (!$contact->fetch()) jsonResponse(null, '请先添加好友后再发送消息', 403);
            $privacy = db()->prepare('SELECT g.id FROM chat_groups g JOIN chat_group_members a ON a.group_id=g.id AND a.user_id=? JOIN chat_group_members b ON b.group_id=g.id AND b.user_id=? WHERE g.allow_private_message=0 LIMIT 1');
            $privacy->execute([$user['id'], $chat['peer_user_id']]);
            if ($privacy->fetch()) jsonResponse(null, '共同群组已禁止成员互相私信', 403);
            $blocked = db()->prepare('SELECT blocked FROM chat_settings WHERE user_id=? AND chat_id=? LIMIT 1');
            $blocked->execute([$user['id'], $chat['id']]);
            if ((int) $blocked->fetchColumn() === 1) jsonResponse(null, '你已拉黑该联系人，无法发送消息', 403);
            $peerChatIdQuery = db()->prepare('SELECT id FROM chats WHERE user_id=? AND peer_user_id=? LIMIT 1');
            $peerChatIdQuery->execute([$chat['peer_user_id'], $user['id']]);
            $peerChatIdForBlock = (int) $peerChatIdQuery->fetchColumn();
            if ($peerChatIdForBlock > 0) {
                $peerBlocked = db()->prepare('SELECT blocked FROM chat_settings WHERE user_id=? AND chat_id=? LIMIT 1');
                $peerBlocked->execute([$chat['peer_user_id'], $peerChatIdForBlock]);
                if ((int) $peerBlocked->fetchColumn() === 1) jsonResponse(null, '对方暂不接收你的消息', 403);
            }
            $content = trim((string) $body['content']);
            if ($content === '') jsonResponse(null, '消息内容不能为空', 422);
            $messageType = (string) ($body['message_type'] ?? 'text');
            $mediaUrl = trim((string) ($body['media_url'] ?? '')) ?: null;
            $clientMessageId = trim((string) ($body['client_message_id'] ?? '')) ?: null;
            if (!in_array($messageType, ['text', 'image', 'video', 'voice'], true)) jsonResponse(null, '消息类型不正确', 422);
            if ($messageType !== 'text' && !$mediaUrl) jsonResponse(null, '媒体消息缺少地址', 422);
            if ($clientMessageId !== null) {
                $existing = db()->prepare('SELECT id FROM messages WHERE user_id=? AND sender_id=? AND client_message_id=? LIMIT 1');
                $existing->execute([$user['id'], $user['id'], $clientMessageId]);
                $existingId = $existing->fetchColumn();
                if ($existingId) jsonResponse(['id' => (int) $existingId, 'client_message_id' => $clientMessageId, 'duplicate' => true], '消息已发送');
            }
            $statement = db()->prepare('INSERT INTO messages (chat_id, user_id, sender_id, client_message_id, content, message_type, media_url) VALUES (?, ?, ?, ?, ?, ?, ?)');
            $statement->execute([$chat['id'], $user['id'], $user['id'], $clientMessageId, $content, $messageType, $mediaUrl]);
            $messageId = (int) db()->lastInsertId();
            $lastMessage = strncmp($content, 'SPXGROUP:', 9) === 0 ? '[群组邀请]' : ($messageType === 'image' ? '[图片]' : ($messageType === 'video' ? '[视频]' : ($messageType === 'voice' ? '[语音]' : $content)));
            db()->prepare('UPDATE chats SET last_message=?, updated_at=NOW() WHERE id=?')->execute([$lastMessage, $chat['id']]);
            $peerChat = db()->prepare('SELECT id FROM chats WHERE user_id=? AND peer_user_id=? LIMIT 1');
            $peerChat->execute([$chat['peer_user_id'], $user['id']]);
            $peerRow = $peerChat->fetch();
            $peerMessageId = 0;
            if ($peerRow) {
                $peerInsert = db()->prepare('INSERT INTO messages (chat_id,user_id,sender_id,client_message_id,content,message_type,media_url) VALUES (?,?,?,?,?,?,?)');
                $peerInsert->execute([$peerRow['id'], $chat['peer_user_id'], $user['id'], $clientMessageId, $content, $messageType, $mediaUrl]);
                $peerMessageId = (int) db()->lastInsertId();
                db()->prepare('UPDATE chats SET last_message=?,unread_count=unread_count+1,updated_at=NOW() WHERE id=?')->execute([$lastMessage, $peerRow['id']]);
            } else {
                $createPeer = db()->prepare('INSERT INTO chats (user_id,peer_user_id,title,last_message,unread_count) VALUES (?,?,?,?,1)');
                $createPeer->execute([$chat['peer_user_id'], $user['id'], $user['nickname'], $lastMessage]);
                $peerChatId = (int) db()->lastInsertId();
                $peerInsert = db()->prepare('INSERT INTO messages (chat_id,user_id,sender_id,client_message_id,content,message_type,media_url) VALUES (?,?,?,?,?,?,?)');
                $peerInsert->execute([$peerChatId, $chat['peer_user_id'], $user['id'], $clientMessageId, $content, $messageType, $mediaUrl]);
                $peerMessageId = (int) db()->lastInsertId();
            }
            $message = db()->prepare('SELECT m.*,u.nickname,u.avatar_url FROM messages m JOIN users u ON u.id=m.sender_id WHERE m.id=? LIMIT 1');
            $message->execute([$messageId]);
            $messageData = $message->fetch() ?: ['id' => $messageId, 'chat_id' => (int) $chat['id'], 'sender_id' => (int) $user['id'], 'content' => $content, 'message_type' => $messageType, 'media_url' => $mediaUrl];
            notifyWebSocket(['type' => 'message', 'user_id' => (int) $user['id'], 'chat_id' => (int) $chat['id'], 'message' => $messageData]);
            $peerMessage = db()->prepare('SELECT m.*,u.nickname,u.avatar_url FROM messages m JOIN users u ON u.id=m.sender_id WHERE m.id=? LIMIT 1');
            $peerMessage->execute([$peerMessageId]);
            $peerMessageData = $peerMessage->fetch() ?: $messageData;
            notifyWebSocket(['type' => 'message', 'user_id' => (int) $chat['peer_user_id'], 'chat_id' => $peerRow ? (int) $peerRow['id'] : $peerChatId, 'message' => $peerMessageData]);
            jsonResponse(['id' => $messageId, 'client_message_id' => $clientMessageId, 'message_type' => $messageType, 'media_url' => $mediaUrl], '发送成功', 201);

        case 'products':
            jsonResponse(mallProducts(db(), max(0, (int) ($_GET['merchant_id'] ?? 0)), mb_substr(trim((string) ($_GET['q'] ?? '')), 0, 100), mb_substr(trim((string) ($_GET['category'] ?? '')), 0, 80), max(1, (int) ($_GET['page'] ?? 1))));

        case 'product':
            $pdo = db();
            $statement = $pdo->prepare(mallProductSelect() . ' WHERE p.id=? AND ' . mallVisibleWhere() . ' LIMIT 1');
            $statement->execute([(int) ($_GET['id'] ?? 0)]);
            $product = $statement->fetch();
            if (!$product) jsonResponse(null, '商品不存在', 404);
            jsonResponse(mallDecorateProduct($pdo, $product));

        case 'orders':
            $user = currentUser();
            $statement = db()->prepare('SELECT o.*,COALESCE(JSON_UNQUOTE(JSON_EXTRACT(o.product_snapshot,"$.name")),p.name) AS name,p.image_url,p.product_type FROM orders o JOIN products p ON p.id=o.product_id WHERE o.user_id = ? ORDER BY o.id DESC');
            $statement->execute([$user['id']]);
            jsonResponse($statement->fetchAll());

        case 'order':
            $user = currentUser();
            $statement = db()->prepare('SELECT o.*,COALESCE(JSON_UNQUOTE(JSON_EXTRACT(o.product_snapshot,"$.name")),p.name) AS name,COALESCE(JSON_UNQUOTE(JSON_EXTRACT(o.product_snapshot,"$.description")),p.description) AS description,p.image_url,p.product_type FROM orders o JOIN products p ON p.id=o.product_id WHERE o.id=? AND o.user_id=? LIMIT 1');
            $statement->execute([(int) ($_GET['id'] ?? 0), $user['id']]);
            $order = $statement->fetch();
            if (!$order) jsonResponse(null, '订单不存在', 404);
            jsonResponse($order);

        case 'orders.cancel':
            $user = currentUser();
            requireFields($body, ['order_id']);
            $pdo = db();
            $pdo->beginTransaction();
            $buyerLock=$pdo->prepare("SELECT id FROM users WHERE id=? FOR UPDATE");$buyerLock->execute([$user["id"]]);
            $find = $pdo->prepare('SELECT * FROM orders WHERE id=? AND user_id=? AND status="pending" FOR UPDATE');
            $find->execute([(int) $body['order_id'], $user['id']]);
            $order = $find->fetch();
            if (!$order) { $pdo->rollBack(); jsonResponse(null, '订单不存在或已不能取消', 409); }
            mallRefundOrder($pdo,$order);
            $pdo->commit();
            jsonResponse(null, '订单已取消，SPX 已退回余额');

        case 'wallet':
            $user = currentUser();
            $statement = db()->prepare('SELECT * FROM wallet_assets WHERE user_id = ? ORDER BY symbol ASC');
            $statement->execute([$user['id']]);
            jsonResponse($statement->fetchAll());

        case 'wallet.binding':
            $user = currentUser();
            $statement = db()->prepare('SELECT bsc_wallet_address FROM users WHERE id=? LIMIT 1');
            $statement->execute([$user['id']]);
            $address = $statement->fetchColumn();
            jsonResponse(['bound' => is_string($address) && $address !== '', 'bound_address' => $address ?: null]);

        case 'wallet.bind':
            $user = currentUser();
            requireFields($body, ['address', 'password']);
            $address = strtolower(trim((string) $body['address']));
            if (!preg_match('/^0x[a-f0-9]{40}$/', $address)) jsonResponse(null, 'BSC 钱包地址格式无效', 422);
            if (isTokenContractAddress($address)) jsonResponse(null, '不能绑定 USDT 或 SPX001 合约地址', 422);
            $pdo = db();
            $pdo->beginTransaction();
            $existing = $pdo->prepare('SELECT bsc_wallet_address,password_hash FROM users WHERE id=? FOR UPDATE');
            $existing->execute([$user['id']]);
            $account = $existing->fetch();
            if (!$account || !password_verify((string) $body['password'], (string) $account['password_hash'])) {
                $pdo->rollBack();
                jsonResponse(null, '密码验证失败，无法绑定钱包', 403);
            }
            $boundAddress = $account['bsc_wallet_address'];
            if (is_string($boundAddress) && $boundAddress !== '') {
                $pdo->rollBack();
                if (strtolower($boundAddress) === $address) jsonResponse(['bound' => true, 'bound_address' => $boundAddress], '该地址已绑定');
                jsonResponse(null, '钱包地址已绑定且不可修改', 409);
            }
            $addressOwner = $pdo->prepare('SELECT id FROM users WHERE bsc_wallet_address=? AND id<>? LIMIT 1');
            $addressOwner->execute([$address, $user['id']]);
            if ($addressOwner->fetch()) { $pdo->rollBack(); jsonResponse(null, '该钱包地址已绑定其他账户', 409); }
            $pdo->prepare('UPDATE users SET bsc_wallet_address=? WHERE id=? AND bsc_wallet_address IS NULL')->execute([$address, $user['id']]);
            $pdo->commit();
            jsonResponse(['bound' => true, 'bound_address' => $address], '钱包地址绑定成功', 201);

        case 'wallet.exchange.quote':
            currentUser();
            $aveConfig = require __DIR__ . '/config.ave.php';
            $service = new AvePriceService($aveConfig);
            $snapshot = $service->getSnapshot();
            $quote = $service->calcSpxAmount('1', $snapshot);
            jsonResponse([
                'symbol' => $quote['symbol'],
                'name' => $quote['name'],
                'token_id' => $quote['token_id'],
                'api_price_usd' => $quote['api_price'],
                'exchange_price_usd' => $quote['exchange_price'],
                'fee_rate' => $quote['fee_rate'],
                'spx_per_usdt' => $quote['spx_amount'],
                'updated_at' => $quote['updated_at'],
            ], '实时兑换价');

        case 'wallet.exchange':
            $user = currentUser();
            requireFields($body, ['usdt_amount', 'request_id']);
            $usdtAmount = trim((string) $body['usdt_amount']);
            $requestId = trim((string) $body['request_id']);
            if (!function_exists('bccomp')) jsonResponse(null, '服务器未安装 BCMath 扩展', 503);
            if (!preg_match('/^(?:0|[1-9][0-9]{0,17})(?:\.[0-9]{1,18})?$/', $usdtAmount) || bccomp($usdtAmount, '0', 18) <= 0) jsonResponse(null, 'USDT 金额格式无效', 422);
            if (!preg_match('/^[A-Za-z0-9._:-]{16,64}$/', $requestId)) jsonResponse(null, '兑换请求编号无效', 422);
            $pdo = db();
            $existing = $pdo->prepare('SELECT * FROM exchange_records WHERE request_id=? LIMIT 1');
            $existing->execute([$requestId]);
            $previous = $existing->fetch();
            if ($previous) {
                if ((int) $previous['user_id'] !== (int) $user['id']) jsonResponse(null, '兑换请求编号已使用', 409);
                if (bccomp((string) $previous['usdt_amount'], $usdtAmount, 18) !== 0) jsonResponse(null, '兑换请求编号与金额不匹配', 409);
                jsonResponse([
                    'request_id' => $requestId,
                    'usdt_amount' => (string) $previous['usdt_amount'],
                    'spx_amount' => (string) $previous['spx_amount'],
                    'api_price' => (string) $previous['api_price'],
                    'exchange_price' => (string) $previous['exchange_price'],
                    'fee_rate' => (string) $previous['fee_rate'],
                    'replayed' => true,
                ], '该兑换请求已处理');
            }
            $aveConfig = require __DIR__ . '/config.ave.php';
            $service = new AvePriceService($aveConfig);
            $snapshot = $service->getSnapshot(true);
            $exchange = $service->calcSpxAmount($usdtAmount, $snapshot);
            $pdo->beginTransaction();
            $pdo->prepare('INSERT IGNORE INTO wallet_assets (user_id,symbol,chain,balance) VALUES (?,"USDT","BSC",0),(?,"SPX001","BSC",0)')->execute([$user['id'], $user['id']]);
            $usdtAsset = $pdo->prepare('SELECT id,balance FROM wallet_assets WHERE user_id=? AND symbol="USDT" AND chain="BSC" FOR UPDATE');
            $usdtAsset->execute([$user['id']]);
            $usdt = $usdtAsset->fetch();
            if (!$usdt || bccomp((string) $usdt['balance'], $usdtAmount, 18) < 0) {
                $pdo->rollBack();
                jsonResponse(null, 'USDT 余额不足', 409);
            }
            $spxAsset = $pdo->prepare('SELECT id FROM wallet_assets WHERE user_id=? AND symbol="SPX001" AND chain="BSC" FOR UPDATE');
            $spxAsset->execute([$user['id']]);
            $spx = $spxAsset->fetch();
            if (!$spx) {
                $pdo->rollBack();
                jsonResponse(null, 'SPX001 资产账户不可用', 409);
            }
            $pdo->prepare('UPDATE wallet_assets SET balance=balance-? WHERE id=?')->execute([$usdtAmount, $usdt['id']]);
            $pdo->prepare('UPDATE wallet_assets SET balance=balance+? WHERE id=?')->execute([$exchange['spx_amount'], $spx['id']]);
            $record = $pdo->prepare('INSERT INTO exchange_records (user_id,usdt_amount,spx_amount,api_price,exchange_price,fee_rate,request_id,token_id,status) VALUES (?,?,?,?,?,?,?,?,"success")');
            $record->execute([$user['id'], $usdtAmount, $exchange['spx_amount'], $exchange['api_price'], $exchange['exchange_price'], $exchange['fee_rate'], $requestId, $exchange['token_id']]);
            $pdo->prepare('INSERT INTO wallet_transactions (user_id,symbol,chain,type,amount,status) VALUES (?,"USDT","BSC","exchange_out",?,"completed"),(?,"SPX001","BSC","exchange_in",?,"completed")')->execute([$user['id'], $usdtAmount, $user['id'], $exchange['spx_amount']]);
            $pdo->commit();
            jsonResponse([
                'request_id' => $requestId,
                'usdt_amount' => $usdtAmount,
                'spx_amount' => $exchange['spx_amount'],
                'api_price' => $exchange['api_price'],
                'exchange_price' => $exchange['exchange_price'],
                'fee_rate' => $exchange['fee_rate'],
                'replayed' => false,
            ], '闪兑成功');

        case 'wallet.transactions':
            $user = currentUser();
            $statement = db()->prepare('SELECT * FROM wallet_transactions WHERE user_id = ? ORDER BY id DESC LIMIT 100');
            $statement->execute([$user['id']]);
            jsonResponse($statement->fetchAll());

        case 'wallet.deposit.info':
            $config = require __DIR__ . '/config.php';
            $user = currentUser();
            $binding = db()->prepare('SELECT bsc_wallet_address FROM users WHERE id=? LIMIT 1');
            $binding->execute([$user['id']]);
            $boundAddress = $binding->fetchColumn();
            if (!is_string($boundAddress) || $boundAddress === '') jsonResponse(null, '请先绑定 BSC 钱包地址', 403);
            if (isTokenContractAddress($boundAddress)) jsonResponse(null, '已绑定地址为代币合约地址，请联系平台处理', 403);
            $setting = db()->prepare('SELECT `value` FROM app_settings WHERE `key`=? LIMIT 1');
            $setting->execute(['bsc_usdt_deposit_address']);
            $depositAddress = trim((string) ($setting->fetchColumn() ?: (getenv('FISS_BSC_USDT_DEPOSIT_ADDRESS') ?: ($config['wallet']['bsc_usdt_deposit_address'] ?? ''))));
            if (!preg_match('/^0x[0-9a-fA-F]{40}$/', $depositAddress)) {
                jsonResponse(null, '链上充值服务尚未配置，请联系平台管理员', 503);
            }
            jsonResponse([
                'chain' => 'BSC',
                'usdt_address' => $depositAddress,
                'spx001_address' => $depositAddress,
                'spx001_contract' => '0x0E920821464625cf661A4dceDEb6406E1B48FFFf',
                'symbol' => 'USDT',
                'bound_address' => $boundAddress,
                'verification' => 'automatic_after_confirmations',
                'confirmations' => max(1, (int) (getenv('FISS_BSC_CONFIRMATIONS') ?: 12)),
            ]);

        case 'wallet.deposit':
        case 'wallet.deposit.submit':
        case 'wallet.withdraw':
            $user = currentUser();
            requireFields($body, ['symbol', 'amount']);
            $amount = trim((string) $body['amount']);
            if (!preg_match('/^(?:0|[1-9][0-9]{0,17})(?:\.[0-9]{1,18})?$/', $amount) || !preg_match('/[1-9]/', $amount)) jsonResponse(null, '金额格式无效或必须大于 0', 422);
            if ($action === 'wallet.withdraw' && !function_exists('bccomp')) jsonResponse(null, '服务器未安装 BCMath 扩展', 503);
            $symbol = strtoupper(trim((string) $body['symbol']));
            $chain = strtoupper(trim((string) ($body['chain'] ?? 'BSC')));
            if (!in_array($symbol, ['SPX001', 'USDT'], true) || $chain !== 'BSC') jsonResponse(null, '仅支持 BSC 链上的 SPX001 或 USDT', 422);
            $type = $action === 'wallet.withdraw' ? 'withdraw' : 'deposit';
            $config = $type === 'deposit' ? require __DIR__ . '/config.php' : null;
            if ($type === 'withdraw') requireFields($body, ['address']);
            if ($type === 'deposit') requireFields($body, ['tx_hash']);
            $pdo = db();
            $bound = $pdo->prepare('SELECT bsc_wallet_address FROM users WHERE id=? LIMIT 1');
            $bound->execute([$user['id']]);
            $boundAddress = $bound->fetchColumn();
            if (!is_string($boundAddress) || $boundAddress === '') jsonResponse(null, '请先绑定 BSC 钱包地址', 403);
            if (isTokenContractAddress($boundAddress)) jsonResponse(null, '已绑定地址为代币合约地址，请联系平台处理', 403);
            if ($type === 'withdraw') {
                $requestedAddress = trim((string) $body['address']);
                if (!preg_match('/^0x[0-9a-fA-F]{40}$/', $requestedAddress) || strtolower($requestedAddress) !== strtolower($boundAddress)) jsonResponse(null, '提现地址必须与已绑定钱包地址完全一致', 422);
                if (isTokenContractAddress($requestedAddress)) jsonResponse(null, '不能向 USDT 或 SPX001 合约地址提现', 422);
                $pdo->beginTransaction();
                $asset = $pdo->prepare('SELECT id,balance,stakeable_balance FROM wallet_assets WHERE user_id=? AND symbol=? AND chain=? FOR UPDATE');
                $asset->execute([$user['id'], $symbol, $chain]);
                $wallet = $asset->fetch();
                if (!$wallet || bccomp((string) $wallet['balance'], $amount, 18) < 0) { $pdo->rollBack(); jsonResponse(null, '可用余额不足', 409); }
                $activeWithdrawal = $pdo->prepare('SELECT id FROM wallet_transactions WHERE user_id=? AND symbol=? AND chain=? AND type="withdraw" AND status IN ("pending","processing","sending") LIMIT 1 FOR UPDATE');
                $activeWithdrawal->execute([$user['id'], $symbol, $chain]);
                if ($activeWithdrawal->fetch()) {
                    $pdo->rollBack();
                    jsonResponse(null, '该资产已有一笔提现正在处理中，请等待完成后再提交', 409);
                }
                $fee = bcdiv($amount, '100', 18);
                $netAmount = bcsub($amount, $fee, 18);
                if (bccomp($netAmount, '0', 18) <= 0) { $pdo->rollBack(); jsonResponse(null, '提现金额必须大于手续费', 422); }
                $stakeableAmount = walletDebit($pdo, (int) $user['id'], $symbol, $chain, $amount, false);
            } else {
                
                $txHash = strtolower(trim((string) $body['tx_hash']));
                if (!preg_match('/^0x[a-f0-9]{64}$/', $txHash)) jsonResponse(null, 'BSC 交易哈希格式无效', 422);
                $setting = $pdo->prepare('SELECT `value` FROM app_settings WHERE `key`=? LIMIT 1');
                $setting->execute(['bsc_usdt_deposit_address']);
                $depositAddress = trim((string) ($setting->fetchColumn() ?: (getenv('FISS_BSC_USDT_DEPOSIT_ADDRESS') ?: ($config['wallet']['bsc_usdt_deposit_address'] ?? ''))));
                if (!preg_match('/^0x[0-9a-fA-F]{40}$/', $depositAddress)) {
                    jsonResponse(null, '链上充值服务尚未配置，请联系平台管理员', 503);
                }
                $pdo->beginTransaction();
                try {
                    $pdo->prepare('INSERT INTO recharge_records (user_id,tx_hash,amount,currency,wallet_address,deposit_address,status) VALUES (?,?,?,?,?,?,"pending")')->execute([$user['id'], $txHash, $amount, $symbol, strtolower($boundAddress), strtolower($depositAddress)]);
                    $statement = $pdo->prepare('INSERT INTO wallet_transactions (user_id,symbol,chain,type,amount,address,tx_hash,status) VALUES (?, ?,"BSC","deposit",?,?,?,"pending")');
                    $statement->execute([$user['id'], $symbol, $amount, $boundAddress, $txHash]);
                     $transactionId = (int) $pdo->lastInsertId();
                     $pdo->commit();
                } catch (PDOException $exception) {
                    if ($pdo->inTransaction()) $pdo->rollBack();
                    if ((string) ($exception->errorInfo[0] ?? '') === '23000') jsonResponse(null, '该交易哈希已提交', 409);
                     throw $exception;
                 }
                 jsonResponse(['transaction_id' => $transactionId, 'status' => 'pending', 'verification' => 'automatic_after_confirmations'], '交易已提交，达到 BSC 确认数后自动到账', 201);
            }
            $txHash = strtolower(trim((string) ($body['tx_hash'] ?? '')));
            if ($txHash !== '') {
                $duplicate = $pdo->prepare('SELECT id FROM wallet_transactions WHERE tx_hash=? LIMIT 1');
                $duplicate->execute([$txHash]);
                if ($duplicate->fetch()) {
                    if ($type === 'withdraw') $pdo->rollBack();
                    jsonResponse(null, '该交易哈希已提交', 409);
                }
            }
            $fee = $type === 'withdraw' ? bcdiv($amount, '100', 18) : '0';
            $netAmount = $type === 'withdraw' ? bcsub($amount, $fee, 18) : $amount;
            $statement = $pdo->prepare('INSERT INTO wallet_transactions (user_id,symbol,chain,type,amount,fee_amount,stakeable_amount,address,tx_hash,status) VALUES (?,?,?,?,?,?,?,?,?,"pending")');
             $statement->execute([$user['id'], $symbol, $chain, $type, $netAmount, $fee, $type === 'withdraw' ? $stakeableAmount : '0', $boundAddress, $txHash ?: null]);
             $transactionId = (int) $pdo->lastInsertId();
              if ($type === 'withdraw') {
                  $pdo->commit();
                  sendFinanceTemplate($pdo, 'withdraw_submitted', [
                      'username' => (string) ($user['username'] ?? $user['id']),
                      'nickname' => (string) ($user['nickname'] ?? ''),
                      'user_id' => (int) $user['id'],
                      'symbol' => $symbol . ' / ' . $chain,
                      'amount' => $amount,
                      'fee' => $fee,
                      'net_amount' => $netAmount,
                      'address' => $boundAddress,
                      'status' => '待审核',
                      'created_at' => date('Y-m-d H:i:s'),
                  ]);
              }
             jsonResponse(['transaction_id' => $transactionId, 'status' => 'pending', 'amount' => $amount, 'fee' => $fee, 'net_amount' => $netAmount, 'verification' => $type === 'deposit' ? 'automatic_after_confirmations' : 'manual_withdraw_review'], $type === 'deposit' ? '交易已提交，达到 BSC 确认数后自动到账' : '申请已提交，手续费 1%，实际到账 ' . $netAmount, 201);

        case 'wallet.withdraw.cancel':
            $user = currentUser();
            requireFields($body, ['transaction_id']);
            $pdo = db();
            $pdo->beginTransaction();
            $transaction = $pdo->prepare('SELECT * FROM wallet_transactions WHERE id=? AND user_id=? AND type="withdraw" AND status="pending" FOR UPDATE');
            $transaction->execute([(int) $body['transaction_id'], $user['id']]);
            $row = $transaction->fetch();
            if (!$row) { $pdo->rollBack(); jsonResponse(null, '提现申请不存在或已处理', 409); }
            $pdo->prepare('UPDATE wallet_transactions SET status="cancelled" WHERE id=?')->execute([$row['id']]);
             $refundQuery = $pdo->prepare('SELECT CAST(? AS DECIMAL(36,18))+CAST(? AS DECIMAL(36,18))');
             $refundQuery->execute([$row['amount'], $row['fee_amount'] ?? '0']);
             $refundAmount = (string) $refundQuery->fetchColumn();
             walletCreditSplit($pdo, (int) $user['id'], (string) $row['symbol'], (string) $row['chain'], $refundAmount, (string) ($row['stakeable_amount'] ?? '0'));
            $pdo->commit();
            jsonResponse(null, '提现申请已撤销，余额已退回');

        case 'wallet.address':
            $user = currentUser();
            $statement = db()->prepare('SELECT * FROM user_addresses WHERE user_id = ? ORDER BY is_default DESC, id DESC');
            $statement->execute([$user['id']]);
            jsonResponse($statement->fetchAll());

        case 'wallet.address.save':
            $user = currentUser();
            requireFields($body, ['name', 'phone', 'province', 'city', 'district', 'detail']);
            db()->prepare('UPDATE user_addresses SET is_default=0 WHERE user_id=?')->execute([$user['id']]);
            $statement = db()->prepare(
                'INSERT INTO user_addresses (user_id, name, phone, province, city, district, detail, is_default)
                 VALUES (?, ?, ?, ?, ?, ?, ?, 1)'
            );
            $statement->execute([$user['id'], $body['name'], $body['phone'], $body['province'], $body['city'], $body['district'], $body['detail']]);
            jsonResponse(['id' => (int) db()->lastInsertId()], '地址已保存', 201);

        case 'wallet.address.update':
            $user = currentUser();
            requireFields($body, ['id', 'name', 'phone', 'province', 'city', 'district', 'detail']);
            $addressId = (int) $body['id'];
            $existing = db()->prepare('SELECT is_default FROM user_addresses WHERE id=? AND user_id=? LIMIT 1');
            $existing->execute([$addressId, $user['id']]);
            $oldAddress = $existing->fetch();
            if (!$oldAddress) jsonResponse(null, '地址不存在', 404);
            $isDefault = array_key_exists('is_default', $body) ? (int) ((bool) $body['is_default']) : (int) $oldAddress['is_default'];
            if ($isDefault === 1) db()->prepare('UPDATE user_addresses SET is_default=0 WHERE user_id=?')->execute([$user['id']]);
            $statement = db()->prepare('UPDATE user_addresses SET name=?,phone=?,province=?,city=?,district=?,detail=?,is_default=? WHERE id=? AND user_id=?');
            $statement->execute([$body['name'], $body['phone'], $body['province'], $body['city'], $body['district'], $body['detail'], $isDefault, $addressId, $user['id']]);
            jsonResponse(null, '地址已更新');

        case 'wallet.address.delete':
            $user = currentUser();
            requireFields($body, ['id']);
            db()->prepare('DELETE FROM user_addresses WHERE id = ? AND user_id = ?')->execute([(int) $body['id'], $user['id']]);
            jsonResponse(null, '地址已删除');

        case 'wallet.address.default':
            $user = currentUser();
            requireFields($body, ['id']);
            $pdo = db();
            $pdo->beginTransaction();
            $pdo->prepare('UPDATE user_addresses SET is_default=0 WHERE user_id=?')->execute([$user['id']]);
            $statement = $pdo->prepare('UPDATE user_addresses SET is_default=1 WHERE id=? AND user_id=?');
            $statement->execute([(int) $body['id'], $user['id']]);
            if ($statement->rowCount() === 0) { $pdo->rollBack(); jsonResponse(null, '地址不存在', 404); }
            $pdo->commit();
            jsonResponse(null, '默认地址已更新');

        case 'faq':
            $statement = db()->query('SELECT id,category,question,answer FROM faq_items WHERE status=1 ORDER BY sort_order,id');
            jsonResponse($statement->fetchAll());

        case 'questions':
            $user = currentUser();
            $statement = db()->prepare('SELECT * FROM user_questions WHERE user_id=? ORDER BY id DESC');
            $statement->execute([$user['id']]);
            jsonResponse($statement->fetchAll());

        case 'questions.create':
            $user = currentUser();
            requireFields($body, ['question']);
            $statement = db()->prepare('INSERT INTO user_questions (user_id,question) VALUES (?,?)');
            $statement->execute([$user['id'], trim((string) $body['question'])]);
            jsonResponse(['id' => (int) db()->lastInsertId(), 'status' => 'pending'], '问题已提交', 201);

        case 'feedback.create':
            $user = currentUser();
            requireFields($body, ['content']);
            $statement = db()->prepare('INSERT INTO feedback (user_id,content,contact) VALUES (?,?,?)');
            $statement->execute([$user['id'], trim((string) $body['content']), $body['contact'] ?? null]);
            jsonResponse(['id' => (int) db()->lastInsertId()], '反馈已提交', 201);

        case 'support.tickets':
            $user = currentUser();
            $statement = db()->prepare('SELECT id,subject,content,status,admin_reply,created_at,updated_at FROM support_tickets WHERE user_id=? ORDER BY id DESC');
            $statement->execute([$user['id']]);
            jsonResponse($statement->fetchAll());

        case 'support.tickets.create':
            $user = currentUser();
            requireFields($body, ['subject', 'content']);
            $subject = trim((string) $body['subject']);
            $content = trim((string) $body['content']);
            $subjectLength = function_exists('mb_strlen') ? mb_strlen($subject) : strlen($subject);
            $contentLength = function_exists('mb_strlen') ? mb_strlen($content) : strlen($content);
            if ($subjectLength > 150 || $contentLength > 10000) jsonResponse(null, '标题或内容超过长度限制', 422);
            $statement = db()->prepare('INSERT INTO support_tickets (user_id,subject,content) VALUES (?,?,?)');
            $statement->execute([$user['id'], $subject, $content]);
            jsonResponse(['id' => (int) db()->lastInsertId(), 'status' => 'open'], '工单已提交', 201);

        case 'referrals':
            $user = currentUser();
            $members = db()->prepare('SELECT u.id,u.nickname,u.spx_id,u.created_at, COALESCE((SELECT SUM(s.amount) FROM staking_records s WHERE s.user_id=u.id),0) AS stake_total, COALESCE((SELECT SUM(r.reward_amount) FROM referral_rewards r WHERE r.staker_user_id=u.id AND r.referrer_user_id=?),0) AS reward_total FROM users u WHERE u.invited_by_user_id=? ORDER BY u.id DESC');
            $members->execute([$user['id'], $user['id']]);
            $memberRows = $members->fetchAll();
            $totals = db()->prepare('SELECT COALESCE(SUM(reward_amount),0) AS total_rewards FROM referral_rewards WHERE referrer_user_id=?');
            $totals->execute([$user['id']]);
            $rewardSummary = $totals->fetch();
            $balance = db()->prepare('SELECT balance FROM wallet_assets WHERE user_id=? AND symbol="SPX001" AND chain="BSC" LIMIT 1');
            $balance->execute([$user['id']]);
            $inviteCode = (string) $user['spx_id'];
            jsonResponse(['invite_code' => $inviteCode, 'invite_url' => inviteBaseUrl() . '/login.php?invite=' . rawurlencode($inviteCode), 'commission_rate' => '5%', 'invited_count' => count($memberRows), 'total_rewards' => $rewardSummary['total_rewards'] ?? '0', 'withdrawable_spx' => $balance->fetchColumn() ?: '0', 'users' => $memberRows]);

        case 'staking.plans':
            currentUser();
            $plans = db()->query('SELECT id,name,plan_days,apy,minimum_amount FROM staking_plans WHERE status=1 ORDER BY sort_order,plan_days')->fetchAll();
            $phase = db()->query('SELECT phase_no,name,total_quota,reserved_quota,paid_quota,status FROM staking_phases WHERE status=1 ORDER BY phase_no DESC LIMIT 1')->fetch() ?: null;
            foreach ($plans as &$plan) {
                $plan['id'] = (int) $plan['id'];
                $plan['plan_days'] = (int) $plan['plan_days'];
                $plan['apy'] = (string) $plan['apy'];
                $plan['minimum_amount'] = (string) $plan['minimum_amount'];
            }
            unset($plan);
            if ($phase) {
                $phase['phase_no'] = (int) $phase['phase_no'];
                $phase['status'] = (int) $phase['status'];
                $phase['total_quota'] = (string) $phase['total_quota'];
                $phase['reserved_quota'] = (string) $phase['reserved_quota'];
                $phase['paid_quota'] = (string) $phase['paid_quota'];
                $remainingQuery = db()->prepare('SELECT CAST(? AS DECIMAL(36,18))-CAST(? AS DECIMAL(36,18))');
                $remainingQuery->execute([$phase['total_quota'], $phase['reserved_quota']]);
                $phase['remaining_quota'] = (string) $remainingQuery->fetchColumn();
            }
            jsonResponse(['plans' => $plans, 'phase' => $phase]);

        case 'staking':
            $user = currentUser();
            $statement = db()->prepare('SELECT s.*,IF(s.status="active" AND DATE_ADD(s.created_at,INTERVAL s.plan_days DAY)<=NOW(),1,0) AS can_redeem,CAST(ROUND(s.amount*s.apy*s.plan_days/36500,18) AS DECIMAL(36,18)) AS expected_reward,COALESCE((SELECT SUM(d.amount) FROM staking_dividends d WHERE d.staking_id=s.id),0) AS paid_dividend FROM staking_records s WHERE s.user_id=? ORDER BY s.id DESC');
            $statement->execute([$user['id']]);
            jsonResponse($statement->fetchAll());

        case 'staking.create':
            $user = currentUser();
            requireFields($body, ['plan_id', 'amount']);
            $amount = trim((string) $body['amount']);
            if (!preg_match('/^[1-9][0-9]*$/', $amount)) jsonResponse(null, '质押数量必须是整数', 422);
            $amountInteger = (int) $amount;
            if ($amountInteger < 100000 || $amountInteger > 10000000 || $amountInteger % 100000 !== 0) jsonResponse(null, '质押数量必须是 100000 的整数倍，且单人累计最多 10000000 SPX001', 422);
            $pdo = db();
            $pdo->beginTransaction();
            $phaseQuery = $pdo->query('SELECT id,phase_no,name,total_quota,reserved_quota,paid_quota FROM staking_phases WHERE status=1 ORDER BY phase_no DESC LIMIT 1 FOR UPDATE');
            $phase = $phaseQuery->fetch();
            if (!$phase) { $pdo->rollBack(); jsonResponse(null, '当前没有开启的质押期，请等待后台配置', 409); }
            $planQuery = $pdo->prepare('SELECT id,name,plan_days,apy,minimum_amount FROM staking_plans WHERE id=? AND status=1 FOR UPDATE');
            $planQuery->execute([(int) $body['plan_id']]);
            $plan = $planQuery->fetch();
            if (!$plan) { $pdo->rollBack(); jsonResponse(null, '质押方案已下架，请刷新后重试', 409); }
            $activeStakeTotal = $pdo->prepare('SELECT COALESCE(SUM(amount),0) FROM staking_records WHERE user_id=? AND status="active" FOR UPDATE');
            $activeStakeTotal->execute([$user['id']]);
            if ((int) $activeStakeTotal->fetchColumn() + $amountInteger > 10000000) { $pdo->rollBack(); jsonResponse(null, '单人累计锁仓质押最多 10000000 SPX001', 409); }
            $minimumCheck = $pdo->prepare('SELECT CAST(? AS DECIMAL(36,18))>=CAST(? AS DECIMAL(36,18))');
            $minimumCheck->execute([$amount, $plan['minimum_amount']]);
            if ((int) $minimumCheck->fetchColumn() !== 1) { $pdo->rollBack(); jsonResponse(null, '该方案最低质押 ' . (string) $plan['minimum_amount'] . ' SPX001', 422); }
            $planDays = (int) $plan['plan_days'];
            $expectedQuery = $pdo->prepare('SELECT CAST(ROUND(CAST(? AS DECIMAL(36,18))*CAST(? AS DECIMAL(36,18))*CAST(? AS DECIMAL(36,18))/36500,18) AS DECIMAL(36,18))');
            $expectedQuery->execute([$amount, $plan['apy'], $planDays]);
            $expectedDividend = (string) $expectedQuery->fetchColumn();
            $referrerId = (int) ($user['invited_by_user_id'] ?? 0);
            $commission = '0';
            if ($referrerId > 0) {
                $commissionQuery = $pdo->prepare('SELECT CAST(CAST(? AS DECIMAL(36,18))*0.05 AS DECIMAL(36,18))');
                $commissionQuery->execute([$amount]);
                $commission = (string) $commissionQuery->fetchColumn();
            }
            $reserveQuery = $pdo->prepare('SELECT CAST(CAST(? AS DECIMAL(36,18))+CAST(? AS DECIMAL(36,18)) AS DECIMAL(36,18))');
            $reserveQuery->execute([$expectedDividend, $commission]);
            $reserveAmount = (string) $reserveQuery->fetchColumn();
            $quotaCheck = $pdo->prepare('SELECT CAST(? AS DECIMAL(36,18))-CAST(? AS DECIMAL(36,18))>=CAST(? AS DECIMAL(36,18))');
            $quotaCheck->execute([$phase['total_quota'], $phase['reserved_quota'], $reserveAmount]);
            if ((int) $quotaCheck->fetchColumn() !== 1) { $pdo->rollBack(); jsonResponse(null, '当前质押期剩余额度不足，无法预分配本笔分红和邀请奖励', 409); }
            $asset = $pdo->prepare('SELECT id,balance,stakeable_balance FROM wallet_assets WHERE user_id=? AND symbol="SPX001" AND chain="BSC" FOR UPDATE');
            $asset->execute([$user['id']]);
            $wallet = $asset->fetch();
            $enough = $pdo->prepare('SELECT CAST(? AS DECIMAL(36,18))>=CAST(? AS DECIMAL(36,18))');
            $enough->execute([$wallet['stakeable_balance'] ?? '0', $amount]);
            if (!$wallet || (int) $enough->fetchColumn() !== 1) { $pdo->rollBack(); jsonResponse(null, '可质押 SPX001 余额不足，邀请奖励和分红不能用于质押', 409); }
            walletDebit($pdo, (int) $user['id'], 'SPX001', 'BSC', $amount, true);
            $apy = (string) $plan['apy'];
            $statement = $pdo->prepare('INSERT INTO staking_records (user_id,phase_id,plan_days,amount,apy,status) VALUES (?, ?, ?, ?, ?, ?)');
            $statement->execute([$user['id'], $phase['id'], $planDays, $amount, $apy, 'active']);
            $stakingId = (int) $pdo->lastInsertId();
            $pdo->prepare('UPDATE staking_phases SET reserved_quota=reserved_quota+?,paid_quota=paid_quota+? WHERE id=?')->execute([$reserveAmount, $commission, $phase['id']]);
            $pdo->prepare('INSERT INTO wallet_transactions (user_id,symbol,chain,type,amount,stakeable_amount,status) VALUES (?,"SPX001","BSC","staking",?,?,"completed")')->execute([$user['id'], $amount, $amount]);
            if ($referrerId > 0) {
                walletCredit($pdo, $referrerId, 'SPX001', 'BSC', $commission, false);
                $pdo->prepare('INSERT INTO referral_rewards (staking_id,phase_id,referrer_user_id,staker_user_id,staked_amount,reward_amount) VALUES (?,?,?,?,?,?)')->execute([$stakingId, $phase['id'], $referrerId, $user['id'], $amount, $commission]);
                $pdo->prepare('INSERT INTO wallet_transactions (user_id,symbol,chain,type,amount,status) VALUES (?,"SPX001","BSC","referral_reward",?,"completed")')->execute([$referrerId, $commission]);
            }
             $pdo->commit();
             jsonResponse(['id' => $stakingId, 'referral_commission' => $commission], '质押记录已创建', 201);

        case 'staking.redeem':
            $user = currentUser();
            requireFields($body, ['id']);
            $pdo = db();
            $pdo->beginTransaction();
            $find = $pdo->prepare('SELECT *,CAST(ROUND(amount*apy*plan_days/36500,18) AS DECIMAL(36,18)) AS reward_amount FROM staking_records WHERE id=? AND user_id=? AND status="active" AND DATE_ADD(created_at, INTERVAL plan_days DAY) <= NOW() FOR UPDATE');
            $find->execute([(int) $body['id'], $user['id']]);
            $staking = $find->fetch();
            if (!$staking) { $pdo->rollBack(); jsonResponse(null, '质押记录不存在、尚未到期或已结束', 409); }
            $paidDividend = (string) $pdo->query('SELECT COALESCE(SUM(amount),0) FROM staking_dividends WHERE staking_id=' . (int) $staking['id'])->fetchColumn();
            $totalAmount = (string) $staking['amount'];
            $pdo->prepare('UPDATE staking_records SET status="redeemed" WHERE id=?')->execute([$staking['id']]);
            walletCredit($pdo, (int) $user['id'], 'SPX001', 'BSC', $totalAmount, false);
             $pdo->prepare('INSERT INTO wallet_transactions (user_id,symbol,chain,type,amount,status) VALUES (?,"SPX001","BSC","staking_redeem",?,"completed")')->execute([$user['id'], $staking['amount']]);
             $pdo->commit();
             jsonResponse(['principal' => $staking['amount'], 'paid_dividend' => $paidDividend, 'total_amount' => $totalAmount], '质押本金已赎回，分红已按周期到账');

        default:
            jsonResponse(null, '未知接口: ' . $action, 404);
    }
} catch (Throwable $exception) {
    try {
        if (db()->inTransaction()) db()->rollBack();
    } catch (Throwable $ignored) {
    }
    $config = require __DIR__ . '/config.php';
    if ($action === 'wallet.exchange.quote') {
        $status = (int) $exception->getCode() === 429 ? 429 : 502;
        jsonResponse($config['app']['debug'] ? ['error' => $exception->getMessage()] : null, 'Ave 行情请求失败', $status);
    }
    if ($action === 'wallet.exchange' && (int) $exception->getCode() === 429) {
        jsonResponse(null, 'Ave API 限流，请稍后重试', 429);
    }
    jsonResponse($config['app']['debug'] ? ['error' => $exception->getMessage()] : null, '服务器错误', 500);
}
